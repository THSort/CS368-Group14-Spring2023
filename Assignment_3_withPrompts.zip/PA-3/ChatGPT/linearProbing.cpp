#include <iostream>
#include <string>
#include "linearProbing.h"

using namespace std;

HashL::HashL() {
    tableSize = 10;
    hashTable = new block*[tableSize];
    for (int i = 0; i < tableSize; i++) {
        hashTable[i] = NULL;
    }
}

HashL::~HashL() {
    for (int i = 0; i < tableSize; i++) {
        delete hashTable[i];
    }
    delete[] hashTable;
}

unsigned long HashL::hash(string value) {
    unsigned long hashVal = 0;
    for (int i = 0; i < value.length(); i++) {
        hashVal = hashVal * 31 + value[i];
    }
    return hashVal % tableSize;
}

void HashL::insert(string value) {
    block* newBlock = new block(hash(value), value);
    int index = hash(newBlock->value);
    int i = 0;
    while (hashTable[index] != NULL && i < tableSize) {
        if (hashTable[index]->value == value) {
            return; // value already exists in table
        }
        index = (index + 1) % tableSize;
        i++;
    }
    if (i == tableSize) {
        resizeTable(); // table is full, resize
        insert(value); // insert again with new table size
        return;
    }
    hashTable[index] = newBlock;
    count++;
}

void HashL::deleteWord(string value) {
    int index = hash(value);
    int i = 0;
    while (hashTable[index] != NULL && i < tableSize) {
        if (hashTable[index]->value == value) {
            delete hashTable[index];
            hashTable[index] = NULL;
            count--;
            return;
        }
        index = (index + 1) % tableSize;
        i++;
    }
}

block* HashL::lookup(string value) {
    int index = hash(value);
    int i = 0;
    while (hashTable[index] != NULL && i < tableSize) {
        if (hashTable[index]->value == value) {
            return hashTable[index];
        }
        index = (index + 1) % tableSize;
        i++;
    }
    return NULL; // value not found in table
}

void HashL::resizeTable() {
    int oldSize = tableSize;
    tableSize = tableSize * 2; // double the table size
    block** oldTable = hashTable;
    hashTable = new block*[tableSize];
    for (int i = 0; i < tableSize; i++) {
        hashTable[i] = NULL;
    }
    for (int i = 0; i < oldSize; i++) {
        if (oldTable[i] != NULL) {
            insert(oldTable[i]->value); // reinsert each value into new table
            delete oldTable[i];
        }
    }
    delete[] oldTable;
}