#include <string>

// Polynomial hash code function
unsigned int polynomial_hash(const std::string& str, unsigned int a)
{
    const unsigned int m = 1 << 31; // 2^31
    unsigned int h = 0;
    for (char c : str) {
        h = (h * a + c) % m;
    }
    return h;
}

// Bitwise hash code function
unsigned int bitwise_hash(const std::string& str)
{
    unsigned int h = 0;
    for (char c : str) {
        h ^= (h << 5) + (h >> 2) + c;
    }
    return h;
}

// Division method compression function for polynomial hash code
unsigned int polynomial_compression(unsigned int h, unsigned int m)
{
    return h % m;
}

// Division method compression function for bitwise hash code
unsigned int bitwise_compression(unsigned int h, unsigned int m)
{
    return h % m;
}