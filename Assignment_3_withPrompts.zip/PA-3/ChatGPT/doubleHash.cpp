#include "doubleHash.h"

HashD::HashD(){
    tableSize = 7;
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize; i++){
        hashTable[i] = nullptr;
    }
    count = 0;
}

HashD::~HashD(){
    for(int i=0; i<tableSize; i++){
        delete hashTable[i];
    }
    delete[] hashTable;
}

unsigned long HashD::hash1(string value){
    unsigned long hashVal = 0;
    for(char c : value){
        hashVal = 37*hashVal + c;
    }
    return hashVal % tableSize;
}

unsigned long HashD::hash2(string value){
    unsigned long hashVal = 0;
    for(char c : value){
        hashVal = 31*hashVal + c;
    }
    return hashVal % (tableSize - 1) + 1;
}

void HashD::resizeTable(){
    long oldSize = tableSize;
    tableSize = tableSize * 2;
    block** oldTable = hashTable;
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize; i++){
        hashTable[i] = nullptr;
    }
    count = 0;
    for(int i=0; i<oldSize; i++){
        if(oldTable[i] != nullptr){
            insert(oldTable[i]->value);
            delete oldTable[i];
        }
    }
    delete[] oldTable;
}

void HashD::insert(string value){
    if(count >= tableSize/2){
        resizeTable();
    }
    unsigned long hashVal = hash1(value);
    unsigned long stepSize = hash2(value);
    int i = 0;
    int index = hashVal;
    while(hashTable[index] != nullptr && hashTable[index]->value != value){
        i++;
        index = (hashVal + i*stepSize) % tableSize;
    }
    if(hashTable[index] == nullptr){
        hashTable[index] = new block(hashVal, value);
        count++;
    }
    else{
        hashTable[index]->value = value;
    }
}

void HashD::deleteWord(string value){
    unsigned long hashVal = hash1(value);
    unsigned long stepSize = hash2(value);
    int i = 0;
    int index = hashVal;
    while(hashTable[index] != nullptr && hashTable[index]->value != value){
        i++;
        index = (hashVal + i*stepSize) % tableSize;
    }
    if(hashTable[index] != nullptr){
        delete hashTable[index];
        hashTable[index] = nullptr;
        count--;
    }
}

block* HashD::lookup(string value){
    unsigned long hashVal = hash1(value);
    unsigned long stepSize = hash2(value);
    int i = 0;
    int index = hashVal;
    while(hashTable[index] != nullptr && hashTable[index]->value != value){
        i++;
        index = (hashVal + i*stepSize) % tableSize;
    }
    if(hashTable[index] == nullptr){
        return nullptr;
    }
    else{
        return hashTable[index];
    }
}