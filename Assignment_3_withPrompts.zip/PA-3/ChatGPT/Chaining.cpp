#include "Chaining.h"
#include "HashFunctions.h"

template<class K, class V>
class HashTable {
public:
    HashTable(int size);
    ~HashTable();
    void insert(K key, V value);
    void remove(K key);
    V& operator[](K key);
private:
    int size;
    LinkedList<std::pair<K, V>>* table;
};

template<class K, class V>
HashTable<K, V>::HashTable(int size) : size(size)
{
    table = new LinkedList<std::pair<K, V>>[size];
}

template<class K, class V>
HashTable<K, V>::~HashTable()
{
    delete[] table;
}

template<class K, class V>
void HashTable<K, V>::insert(K key, V value)
{
    int index = hashFunction(key) % size;
    table[index].insertAtTail(std::make_pair(key, value));
}

template<class K, class V>
void HashTable<K, V>::remove(K key)
{
    int index = hashFunction(key) % size;
    ListItem<std::pair<K, V>>* current = table[index].getHead();
    while (current != NULL) {
        if (current->value.first == key) {
            table[index].deleteNode(current);
            break;
        }
        current = current->next;
    }
}

template<class K, class V>
V& HashTable<K, V>::operator[](K key)
{
    int index = hashFunction(key) % size;
    ListItem<std::pair<K, V>>* current = table[index].getHead();
    while (current != NULL) {
        if (current->value.first == key) {
            return current->value.second;
        }
        current = current->next;
    }
    V value;
    insert(key, value);
    current = table[index].getTail();
    return current->value.second;
}