#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <iostream>
#include <string>
#include <cmath>
using namespace std;


// this takes in a string and returns a 64bit hash.
unsigned long polyHash(string value,int a = 5){

	string use = value;
	int muliplier = value.size() - 1;
	int ascii_value = 0;
	unsigned long sum = 0;
	unsigned long partial_sum;
	ascii_value = (int) value[0];	
	for(int i = 0; i < value.size(); i++)
	{
		partial_sum = 1;
		ascii_value = (int)value[i];
		for(int j = 0; j < muliplier; j++)
		{
			partial_sum *= a;
		}
		sum += ascii_value*partial_sum;
		muliplier--;
	}
	return sum;
}


//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){

	unsigned long bitwise_hash = 0;	
	int si = 0;
	for(int i = 0; i < value.size(); i++)
	{
		si = (int)value[i];
		bitwise_hash ^= (bitwise_hash << 5) + (bitwise_hash >> 2) + si;
	}

	return bitwise_hash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
	//this is given hash values and this compresses it into something
    return hash%size;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
   

    return ((a*hash)%m)%size;
}


// 'm' and 'a' can take any value

// int main()
// {
// 	int *a;	
// 	a=new int[52];

// }

#endif

// you may write your own program to test these functions.
