#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
        tableSize = 1000; //1000 you cant change this
        hashTable=new block*[tableSize];
        for (int i = 0; i < tableSize; i++)
        {
            hashTable[i]=NULL;
        }
}

HashL::~HashL(){

    for(int i=0; i<tableSize; i++)
    {
        delete hashTable[i];
    }
    delete []hashTable;
}

unsigned long HashL :: hash(string value){
    return divCompression(bitHash(value),tableSize);
}

void HashL::resizeTable(){
    int old_size=tableSize;
    block **old=hashTable;

    if(((double)count/(double)tableSize)>=0.7)
        tableSize*=2;
    else
        tableSize/=2;

    count=0;
    hashTable=new block*[tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
    for(int i=0; i<old_size; i++)
    {
        if(old[i]!=NULL && old[i]->value!="$$$")
        {
            this->insert(old[i]->value);
        }
    }
    return;
}

void HashL::insert(string value){
    //cout<<"here"<<endl;
    if(((double)count/(double)tableSize)>=0.7)
            this->resizeTable();

    unsigned long hash_index=hash(value);
    block *temp=lookup(value);
    if(temp==NULL)
    {
        int x=hash_index;
        while(hashTable[x]!=NULL)
        {
            if(hashTable[x]->value=="$$$")
            {
                hashTable[x]->value=value;
                //hashTable[x]->key=hash_index;
                count++;
                return;
            }
            x++;
            if(x>=tableSize)
                x=0;
        }
       //not there
       hashTable[x]=new block(hash_index,value);
       count++;
    return;
    }

}

void HashL::deleteWord(string value){
    if(((double)count/(double)tableSize)<=0.3)
            this->resizeTable();

    unsigned long hash_index=hash(value);
    block *temp=lookup(value);
    if(temp!=NULL)
    {
        temp->value="$$$";
        count--;
    }

    return;
}
block* HashL::lookup(string value){
    unsigned long hash_index=hash(value);
    if(hashTable[hash_index]==NULL)
        return NULL;
    int x=hash_index;
    while(hashTable[x]!=NULL)
    {
        if(hashTable[x]->value==value)
        {
            return hashTable[x];
        }
        x++;
        if(x>=tableSize)
            x=0;
    }
    return NULL;
}
#endif
