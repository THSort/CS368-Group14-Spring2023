#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"

HashD::HashD(){
    tableSize = 10000; // you cant change this
    count=0;

    hashTable=new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
        hashTable[i]=NULL;
    }
}

HashD::~HashD(){

    for (int i=0; i<tableSize;i++)
        delete hashTable[i];

    delete [] hashTable;
}

unsigned long HashD :: hash1(string value){
    return divCompression (bitHash(value),tableSize);
}

unsigned long HashD :: hash2(string value){
    return divCompression (bitHash(value)*tableSize-1,tableSize);
}

void HashD::resizeTable(){

    int old_size=tableSize;
    block **old=hashTable;

    if(((double)count/(double)tableSize)>=0.7)
        tableSize*=2;
    else
        tableSize/=2;

    hashTable=new block*[tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
    count=0;
    for(int i=0; i<old_size; i++)
    {
        if(old[i]!=NULL && old[i]->value!="$$$")
        {
            this->insert(old[i]->value);
        }
    }
    return;
}

void HashD::insert(string value){

    double loadFactor = double(count)/double(tableSize);

    if (loadFactor>=0.7)
    {
        this->resizeTable();
    }

    int hash_index=hash1(value);
    int hash_index2=hash2(value);

    if (lookup(value)==NULL)
    {
        int i=1;

        while (hashTable[hash_index]!=NULL && hashTable[hash_index]->value!="$$$")
        {
            hash_index=divCompression(hash_index+(i*hash_index2),tableSize);
            i++;
        }
        count++;
        hashTable[hash_index]=new block(hash_index,value);
    }
}

void HashD::deleteWord(string value){

    double loadFactor=double(count)/double(tableSize);
    if (loadFactor<=0.3)
    {
        this->resizeTable();
    }
    block* temp=lookup(value);
    if(temp!=NULL)
    {
        temp->value="$$$";
        count--;
    }
}

block* HashD::lookup(string value){

    int hash_index=hash1(value);
    int hash_index2=hash2(value);
    int i=1;

    while (hashTable[hash_index]!=NULL && hashTable[hash_index]->value!=value)
    {
        hash_index=divCompression(hash_index+(i*hash_index2),tableSize);
        i++;
    }
    return hashTable[hash_index];
}


#endif
