#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"

HashD::HashD(){
    tableSize = 10000; // you cant change this
	count = 0;    
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize; i++)
    {
    	hashTable[i]=emptyBlock;
    }
}

HashD::~HashD(){
	for(int i=0; i<tableSize; i++)
    {
    	delete hashTable[i];
    } 

}

unsigned long HashD :: hash1(string value){
    return madCompression(bitHash(value), tableSize);
}

unsigned long HashD :: hash2(string value){
    return (tableSize) - (bitHash(value) % (tableSize)) ;
}

void HashD::resizeTable(){
	int oldSize = tableSize;
	tableSize = 10*oldSize;
	block** oldTable = hashTable;
	hashTable = new block*[tableSize];
	for(int i=0; i<tableSize; i++)
    {
    	hashTable[i] = emptyBlock;
    }
	count = 0;
	for(int i=0; i<oldSize; i++)
	{

			if(oldTable[i]->key==1)
			{	
				insert(oldTable[i]->value);
				delete(oldTable[i]);
			}
	}
}

void HashD::insert(string value){
   	unsigned long h_val1 = hash1(value);
   	unsigned long h_val2 = hash2(value);
   	int collisions = 1;
   	unsigned long index = h_val1;
	while(hashTable[index]->key==1)
	{
		if(hashTable[index]->value == value)
			return;
		index = (h_val1 + collisions*h_val2) % tableSize;
		collisions++;
		if(collisions>=tableSize/10)
		{
			resizeTable();
			insert(value);
			return;
		}
	}


	hashTable[index] = new block(1, value);
	count++;
	if(count >= tableSize/10)
	{ 
		resizeTable();
	}
}

void HashD::deleteWord(string value){
	unsigned long h_val1 = hash1(value);
   	unsigned long h_val2 = hash2(value);
   	int collisions = 1;
   	unsigned long index = h_val1;
    while(hashTable[index]!=emptyBlock)
	{
		if(hashTable[index]->value == value)
		{
			block* temp = hashTable[index];
			hashTable[index]= deletedBlock;
			count--;
			delete temp;
			return;
		}
		index = (h_val1 + collisions*h_val2) % tableSize;
		collisions++;

	}

}

block* HashD::lookup(string value){
	unsigned long h_val1 = hash1(value);
   	unsigned long h_val2 = hash2(value);
   	int collisions = 1;
   	unsigned long index = h_val1;
    while(hashTable[index]!=emptyBlock)
	{
		if(hashTable[index]->value == value)
		{
			return hashTable[index];
		}
		index = (h_val1 + collisions*h_val2) % tableSize;
		collisions++;
	}
	return NULL;
}

// int main()
// {
// 	vector<string> allWords;
//     ifstream file;
//     file.open("words.txt");
//     cout << "LOADING THE FILE" << endl;
//     string temp;
//     while(!file.eof()){
//         file >> temp;
//         allWords.push_back(temp);
//         // int x = rand()%5;
//         // if (x<2){
//         //     queries.push_back(temp);
//         // }
//     }
//    file.close();
//     cout << allWords.size() << " words loaded." << endl;

// 	HashD* map = new HashD();
//     cout << "starting insert" << endl;
//     for(int i=0;i<20000;i++){
//     	cout << i<< endl;
//         	map->insert(allWords[i]);
//     }
//     cout << map->tableSize<<endl;
// }

#endif