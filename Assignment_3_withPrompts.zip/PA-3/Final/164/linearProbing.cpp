#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"



HashL::HashL(){
    tableSize = 1000; // you cant change this
	count = 0;    
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize; i++)
    {
    	hashTable[i] = emptyBlock;
    }
}

HashL::~HashL(){
    for(int i=0; i<tableSize; i++)
    {
//    	if(hashTable[i]->key == 1)
    	delete hashTable[i];
    }    
}

unsigned long HashL :: hash(string value){
    return divCompression(bitHash(value), tableSize);
}

void HashL::resizeTable(){
	long oldSize = tableSize;
	tableSize = 10*oldSize;
	block** oldTable = hashTable;
	hashTable = new block*[tableSize];
	for(int i=0; i<tableSize; i++)
    {
    	hashTable[i] = emptyBlock;
    }
	count = 0;
	for(int i=0; i<oldSize; i++)
	{
		//if(oldTable[i]!=NULL)
		{
			if(oldTable[i]->key!=1)
			{	
				insert(oldTable[i]->value);
				delete oldTable[i];
			}
		}
	}
}

void HashL::insert(string value){
	
	unsigned long h_val = hash(value);
	while(hashTable[h_val]->key==1)
	{
		if(hashTable[h_val]->value == value)
			return;
		h_val = (h_val+1) % tableSize;
	}

	hashTable[h_val] = new block(1, value);
	
	count++;
	if(count >= tableSize/10)
	{ 
		resizeTable();
	}
}

void HashL::deleteWord(string value){
    unsigned long h_val = hash(value);
    while(hashTable[h_val]!=emptyBlock)
    {
    	if(hashTable[h_val]->value == value)
		{
			block* temp = hashTable[h_val];
			hashTable[h_val]= deletedBlock;
			count--;
			delete temp;
			return;
		}
		h_val = (h_val+1) % tableSize;	
    }
}
block* HashL::lookup(string value){
    unsigned long h_val = hash(value);
    while(hashTable[h_val]!=emptyBlock)
	{
		if(hashTable[h_val]->value == value)
		{
			return hashTable[h_val];
		}
		h_val = (h_val+1) % tableSize;
	}
	return NULL;
}

#endif
