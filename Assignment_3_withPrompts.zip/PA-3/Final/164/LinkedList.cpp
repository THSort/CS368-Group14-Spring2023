#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

#include <iostream>
using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
	tail=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	head = NULL;
	tail=NULL;
	for(ListItem<T>* here=otherLinkedList.head; here!=NULL; here=here->next)
	{
		insertAtTail(here->value);
	}	
}

template <class T>
LinkedList<T>::~LinkedList()
{
	ListItem<T>* here=head; 
	while(here!=NULL)
	{
		ListItem<T>* temp=here;
		here=here->next;
		delete temp;
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if(head == NULL && tail==NULL)
	{
		ListItem<T>* temp;
		temp= new ListItem<T>(item);
		temp->next=NULL;
		temp->prev=NULL;
		head= temp;
		tail= temp;

	}
	else
	{
		ListItem<T>* temp;
		temp= new ListItem<T>(item);
		temp->next=head;
		temp->prev=NULL;
		head->prev=temp;
		head= temp;
	}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if(tail == NULL && head == NULL)
	{
		ListItem<T>* temp;
		temp= new ListItem<T>(item);
		temp->next=NULL;
		temp->prev=NULL;
		head= temp;
		tail= temp;
	}
	else
	{
		ListItem<T>* temp;
		temp = new ListItem<T>(item);
		temp->next=NULL;
		temp->prev=tail;

		tail->next=temp;
		tail=temp;	
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	for(ListItem<T>* here=head; here!=NULL; here=here->next)
	{
		if(here->value == afterWhat)
		{
			if(here->next==NULL)
			{
				insertAtTail(toInsert);
			}
			else
			{
				ListItem<T>* temp;
				temp = new ListItem<T>(toInsert);
				temp->next=here->next;
				temp->prev=here;
				here->next->prev=temp;
				here->next=temp;

			}
		}
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if(head==NULL && tail == NULL)
	{
		insertAtHead(item);
		return;
	}
	if(tail->value <= item)
	{
		insertAtTail(item);
		return;
	}
	if(head->value >= item)
	{
		insertAtHead(item);
		return;
	}

	for(ListItem<T>* here=head; here!=NULL; here=here->next)
	{
		if(here->next != NULL)
		{
			if(here->value < item && here->next->value >= item)
			{
				ListItem<T>* temp;
				temp = new ListItem<T>(item);
				temp->next=here->next;
				temp->prev=here;
				here->next->prev=temp;
				here->next=temp;
			}	
		}		
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead() const
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail() const
{
	return tail;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	for(ListItem<T>* here=head; here!=NULL; here=here->next)
	{
		if(here->value == item)
			return here;
	}

	return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	for(ListItem<T>* here=head; here!=NULL; here=here->next)
	{
		if(here->value == item)
		{
			if(here == head)
				deleteHead();
			else if(here == tail)
				deleteTail();
			else
			{
				ListItem<T>* temp = here;
				here->prev->next= here->next;
				here->next->prev= here->prev;
				delete temp;
			}
		}
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	ListItem<T>* temp=head;
	if(head == NULL && tail == NULL)
	{
		return;
	}

	else if(tail==head)
	{
		head=NULL;
		tail=NULL;
		delete temp;
	}
	else
	{
		head->next->prev=NULL;
		head=head->next;
		delete temp;
	}
		
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T>* temp=tail;

	if(tail==NULL && tail==NULL)
	{
		return;
	}
	if(tail==head)
	{
		head=NULL;
		tail=NULL;
	}
	else
	{
		tail->prev->next=NULL;
		tail=tail->prev;
	}
	delete temp;	
}

template <class T>
int LinkedList<T>::length()
{
	int length = 0;
	for(ListItem<T>* here=head; here!=NULL; here=here->next)
	{
		length++;
	}
	return length;
}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T> *first, *second;
	

    first = head;
    second = head->next;
    first->next = NULL;
    first->prev = second;

    for(ListItem<T>* here=second; here!=NULL; here=here->prev)
	{
        here->prev = here->next;
        here->next = first;
        first = here; 
    }
    tail=head;
    head = first;
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	//Does not change result if length 0 or 1
	if(length() == 0 || length() == 1)
		return;


	bool isEven = !(length()%2);

	
	ListItem<T> *h1, *h2, *h22, *t1, *t2, *t22;
	h1=head;
	h2=head->next;
	h22=head->next; //Reference pointer
	t1=tail;
	t2=tail->prev;
	t22=tail->prev; //Reference pointer

	//Make the next of the head point to the third element. The third ka next to fifth. And so on
	while(h1!=NULL && h2!= NULL)
	{
		if(h1->next != NULL)
		{ 
			h1->next=h1->next->next;
		}
		if(h2->next != NULL)
		{ 
			h2->next=h2->next->next;
		}

		h1=h1->next;
		h2=h2->next;
	}


	//Make the prev of the tail point to the third last element. The third last ka prev to fifth last. And so on
	while(t1!=NULL && t2!= NULL)
	{
		if(t1->prev != NULL)
		{ 
			t1->prev=t1->prev->prev;
		}
		if(t2->prev != NULL)
		{ 
			t2->prev=t2->prev->prev;
		}

		t1=t1->prev;
		t2=t2->prev;
	}

	//Connect the two disjunct lists (different for odd and even lists)
	if(isEven)
	{
		t22->next = h22;
		h22->prev = t22;
	}
	else
	{
		tail->next = h22;
		t22->next=NULL;
		h22->prev= tail;
		tail=t22;
	}



 
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	ListItem<T>* h=head;
	ListItem<T>* t=tail;

	if(head == NULL && tail == NULL)
	 return false;
	
	while(h!=NULL && t!=NULL)
	{
		if(h->value != t->value)
		{
			return false;
		}
		h=h->next;
		t=t->prev;		
	}

	return true;

}

template <class T>
void LinkedList<T>::print()
{
	for(ListItem<T>* here=head; here!=NULL; here=here->next)
	{
		cout << here->value<< endl;		
	
	}
	cout << "---" << endl;
	for(ListItem<T>* here=tail; here!=NULL; here=here->prev)
	{
		cout << here->value<< endl;		
	}
	if(head!=NULL) cout << "Head:" << head->value << endl;
	if(tail!=NULL)cout << "Tail:" << tail->value << endl;

}

#endif
