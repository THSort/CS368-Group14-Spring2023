#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP
#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count=0;
    hashTable = new block* [tableSize] ;
    for (int i=0; i<tableSize;i++)
    {
    	hashTable[i]=NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
	return divCompression(bitHash(value), tableSize);
}

void HashL::resizeTable(){
	if(count > 0.3*tableSize)
	{
		tableSize*=2;
		block **tempTable = new block* [tableSize] ;
    		for (int i=0; i<tableSize;i++)
		    {
    			hashTable[i]=NULL;
    		}
    		block** temp= tempTable;
    		tempTable=hashTable;
    		hashTable= temp;
    		count=0;
    		for (int i=0; i<tableSize/2;i++)
    		{
    			if(tempTable[i]!=NULL)
    				insert(tempTable[i]->value);
    		}

	}
	// if(count<0.1*tableSize)
	// {
	// 	tableSize/=2;
	// 	block **tempTable = new block* [tableSize] ;
 //    		for (int i=0; i<tableSize;i++)
	// 	    {
 //    			hashTable[i]=NULL;
 //    		}
 //    		block** temp= tempTable;
 //    		tempTable=hashTable;
 //    		hashTable= temp;
 //    		for (int i=0; i<tableSize*2;i++)
 //    		{
 //    			if(tempTable[i]!=NULL || tempTable[i]->value !="")
 //    				insert(tempTable[i]->value);
 //    		}
	// }
	return;
}

void HashL::insert(string value){
	unsigned long x= hash(value);
	unsigned long current = x;
	if (lookup(value))
		return;
	while(hashTable[x]!=NULL)
		{ 
				x= (x+1)%tableSize;
		}
	hashTable[x]= new block(current, value);
	count++;		
	if(count>=0.3*tableSize)
	{
		resizeTable();
	}
	return;
}

void HashL::deleteWord(string value){
	if(lookup(value)!=NULL)
	{
		lookup(value)->value="";
		lookup(value)->key=-1;
		count--;
	}
	 if(count <0.1*tableSize)
	 	resizeTable();
    return;
}
block* HashL::lookup(string value){
	unsigned long x= hash(value);
	while (hashTable[x]!=NULL)
	{
		if (hashTable[x]->value==value)
			return hashTable[x];
		else 
			x= (x+1)% tableSize;
	}
	return NULL;
}
#endif
