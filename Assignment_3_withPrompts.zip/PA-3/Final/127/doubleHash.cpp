#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count=0;
    hashTable = new block* [tableSize];
    for (int i=0; i<tableSize;i++)
    {
    	hashTable[i]=NULL;
    }
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){

    return divCompression(bitHash(value), tableSize);
}

unsigned long HashD :: hash2(string value){
    return tableSize - madCompression(bitHash(value), tableSize);
}

void HashD::resizeTable(){
	if(count >= 0.8*tableSize)
	{
		tableSize*=2;
		block **tempTable = new block* [tableSize] ;
    		for (int i=0; i<tableSize;i++)
		    {
    			hashTable[i]=NULL;
    		}
    		block** temp= tempTable;
    		tempTable=hashTable;
    		hashTable= temp;
    		count=0;
    		for (int i=0; i<tableSize/2;i++)
    		{
    			if(tempTable[i]!=NULL)
    				insert(tempTable[i]->value);
    		}
	}
    return;
}

void HashD::insert(string value){
	if(lookup(value)!=NULL)
		return;
	else if (lookup(value) ==NULL) 
	{
		int i=0;
		unsigned long x= hash1(value);
		unsigned long y= hash2(value);
		unsigned long z= x+(i*y);
		unsigned long current= z;
		while(hashTable[z]!=NULL)
		{
			z= (x+(i*y))%tableSize;
			i++;
		}
		hashTable[z]= new block(current, value);
		count++;
	}
	if(count>=0.8*tableSize)
		resizeTable();
    return;
}

void HashD::deleteWord(string value){
	if(lookup(value)!=NULL)
	{
		lookup(value)->value="";
		lookup(value)->key=-1;
		count--;
	}
	if(count <0.1*tableSize)
		resizeTable();
    return;
}

block* HashD::lookup(string value){
	unsigned long x= hash1(value);
	unsigned long y=hash2(value);
	unsigned long z=0;
	if(hashTable[x]->value== value)
		return hashTable[x];
	else if(hashTable[y]->value==value)
		return hashTable[y];
	else 
	{

	} 
		return NULL;
}

#endif