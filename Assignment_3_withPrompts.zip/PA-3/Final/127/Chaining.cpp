#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize= size;
    hashTable = new LinkedList<string>[size];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
	return bitHash(input);
}

void HashC::insert(string word){
	unsigned long x= madCompression(hash(word), tableSize);
	hashTable[x].insertAtHead(word);
  return;
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long x= madCompression(bitHash(word), tableSize);
  return hashTable[x].searchFor(word);
}

void HashC :: deleteWord(string word){
	unsigned long x= madCompression(bitHash(word), tableSize);
	hashTable[x].deleteElement(word);
  return;
}

#endif