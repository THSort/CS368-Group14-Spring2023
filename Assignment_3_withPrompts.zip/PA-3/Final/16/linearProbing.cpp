#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL()
{
    tableSize = 1000; // you cant change this
    minSize = tableSize;
    del_mark = -1;

    count = 0;
    hashTable = new block*[tableSize];

    for (int i=0; i<tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
}

HashL::~HashL()
{
	for (long i=0; i<tableSize; i++)
	{
		delete hashTable[i];
	}
	delete hashTable;
	tableSize = 1000;
	hashTable = NULL;
    
}

void HashL :: print()
{
	for (long i=0; i<tableSize; i++)
	{
		if(hashTable[i] == NULL)
		{
			cout << "--" << endl;
		}
		else if (hashTable[i]->key == del_mark)
		{
			cout << "--" << endl;
		}
		else
		{
			cout << hashTable[i]->key << ": " << hashTable[i]->value << endl;
		}
	}
	cout << endl;
	cout << "ELEMENTS: " << count << "/" << tableSize << endl;
}


unsigned long HashL :: hash(string value)
{
  	return madCompression( (polyHash(value)), tableSize );  
}


void HashL::resizeTable()
{	
   	if (count >= (0.7*tableSize)) // GROW
   	{
		block** oldTable = hashTable;

		tableSize = tableSize * 2;
		hashTable = new block*[tableSize];
	    for (long i=0; i<tableSize; i++)
	    {
	    	hashTable[i] = NULL;
	    }

	    long oldsize = tableSize/2;
	    count = 0;
	    for (long i=0; i<oldsize; i++)
	    {
	    	if (oldTable[i] != NULL)
	    	{
	    		if (oldTable[i] -> key != del_mark)
	    		{
	    			insert(oldTable[i]->value);
	    		}
	    	}
	    	
	    }

	    for (long i=0; i<oldsize; i++)
		{
			delete oldTable[i];
		}
		delete oldTable;
		oldTable = NULL;


   	}
   	else if (count <= (0.25*tableSize)) //SHRINK
   	{
   		block** oldTable = hashTable;

		tableSize = tableSize / 2;
		hashTable = new block*[tableSize];
	    for (long i=0; i<tableSize; i++)
	    {
	    	hashTable[i] = NULL;
	    }

	    long oldsize = tableSize*2;
	    count = 0;
	    for (long i=0; i<oldsize; i++)
	    {
	    	if (oldTable[i] != NULL)
	    	{
	    		if (oldTable[i] -> key != del_mark)
	    		{
	    			insert(oldTable[i]->value);
	    		}
	    	}
	    	
	    }

	    for (long i=0; i<oldsize; i++)
		{
			delete oldTable[i];
		}
		delete oldTable;
		oldTable = NULL;
	}
}

void HashL::insert(string value)
{
	unsigned long hash_val = hash(value);
	if (hashTable[hash_val] == NULL)
	{
		hashTable[hash_val] = new block(hash_val, value);
	}
	else if (hashTable[hash_val]->key == del_mark)
	{
		hashTable[hash_val]->key = hash_val;
		hashTable[hash_val]->value = value;
	}
	else
	{
		unsigned long temp = hash_val;
		do
		{
			temp++;
			if (temp == tableSize)
			{
				temp = 0;
			}
			if (hashTable[temp] == NULL)
			{
				break;
			}
			if (hashTable[temp]->key == del_mark)
			{
				break;
			}

		}while(1);

		if (hashTable[temp] == NULL)
		{
			hashTable[temp] = new block(hash_val, value);
		}
		else
		{
			hashTable[temp]->key = hash_val;
			hashTable[temp]->value = value;
		}
		
	}
	count++;

	if (count >= (0.7*tableSize))
	{
		resizeTable();
	}
    return;
}

void HashL::deleteWord(string value)
{
	block* temp = lookup(value);
	if (temp == NULL)
	{
		return;
	}
	else
	{
		temp->key=del_mark;
		temp->value="";
		count--;
	}

	if (count <= (0.25*tableSize) && tableSize>minSize)
	{
		resizeTable();
	}
	return;
}



block* HashL::rec_lookup(string value, unsigned long here, unsigned long start)
{
	if (here == start)
	{
		return NULL;
	}
	if (hashTable[here] == NULL)
	{
		return NULL;
	}
	if (hashTable[here]->value == value)
	{
		return hashTable[here];
	}
	else
	{
		return rec_lookup(value, ((here+1) % tableSize), start);
	}
}


block* HashL::lookup(string value)
{
	unsigned long hash_val = hash(value);
	if (hashTable[hash_val] == NULL)
	{
		return NULL;
	}
	if (hashTable[hash_val]->value == value)
	{
		return hashTable[hash_val];
	}
	else
	{
		return rec_lookup(value, hash_val+1, hash_val);
	}
}
#endif