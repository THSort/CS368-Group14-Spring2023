#include "linearProbing.cpp"
#ifndef LINEARPROBING_H
#define LINEARPROBING_H

#include <string>
#include <iostream>

using namespace std;
class block{
    public:
        unsigned long key;
        string value;
        block(unsigned long _key,string _value){
            this->key = _key;
            this->value = _value;
        }
};


class HashL{
    private:
        block** hashTable;
        long tableSize;
        long minSize;
        unsigned long del_mark; // this is a marker value to mark that a value has been deleted and it needs to keep searching
        unsigned long hash(string value); // return the corresponding key of the value
        long count; // keeps a count of the number of entries in the table.
        void resizeTable();
        block* rec_lookup(string value, unsigned long here, unsigned long start);
    public:
        HashL();
        ~HashL();
        void insert(string value);
		void deleteWord(string value);
		block* lookup(string value);

		void print();
};

#endif