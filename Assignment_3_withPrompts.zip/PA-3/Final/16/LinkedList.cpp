#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	ListItem<T>* here=otherLinkedList.head;
	if (here==NULL)
	{
		head=NULL;
	} 	
	head=new ListItem<T>(here->value);
	while (here->next != NULL)
	{
		here=here->next;
		insertAtTail(here->value);
	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	ListItem<T>* temp_ptr;
    while (head != NULL)
    {
        temp_ptr=head->next;
        delete head;
        head=temp_ptr;
    }
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T>* temp_ptr=new ListItem<T>(item);
	if (head ==NULL)
	{
		head=temp_ptr;
	}
	else
	{
		temp_ptr->next=head;
	    head->prev=temp_ptr;
	    head=temp_ptr;
	}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem<T>* temp_ptr=new ListItem<T>(item);
	if (head==NULL)
	{
		head=temp_ptr;
	}
	else
	{
		ListItem<T>* here=head;
		while (here->next != NULL)
	    {
	        here=here->next;
	    }
	    temp_ptr->next=NULL;
	    temp_ptr->prev=here;
	    here->next=temp_ptr;
	}
	
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T>* here=head;
	while (here->value != afterWhat && here!=NULL)
	{
		here=here->next;
	}
	if (here==NULL)
	{
		return;
	}
	if (here->next == NULL)
	{
		insertAtTail(toInsert);
	}
	else
	{
		ListItem<T>* temp_ptr=new ListItem<T>(toInsert);
		temp_ptr->next=here->next;
		temp_ptr->prev=here;
		(here->next)->prev=temp_ptr;
		here->next=temp_ptr;
	}
	
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if(head==NULL)
	{
		head=new ListItem<T>(item);
	}
	else if (item <= head->value)
	{
		insertAtHead(item);
	}
	else
	{
		ListItem<T>* here=head;
		ListItem<T>* temp;
		while ((item > here->value) && (here->next != NULL))
		{
			temp=here;
			here=here->next;
		}
		if ((item > here->value) && (here->next == NULL))
		{
			insertAtTail(item);
		}
		else
		{
			ListItem<T>* temp_ptr=new ListItem<T>(item);
		    temp_ptr->next=here;
		    temp_ptr->prev=temp;
		    here->prev=temp_ptr;
			temp->next=temp_ptr;
		}
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if (head==NULL)
	{
		return NULL;
	}
	ListItem<T>* here=head;
	while (here->next != NULL)
	{
		here=here->next;
	}
	return here;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T>* here=head;
	while (here!=NULL)
	{
		if (here->value == item)
		{
			return here;
		}
		here=here->next;
	}
	return here;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if (searchFor(item)==NULL)
	{
		return;
	}
	if (head->value==item)
	{
		deleteHead();
		return;
	}
	else
	{
		ListItem<T>* here=head;
		ListItem<T>* temp;
		while ((here->value != item) && (here->next!=NULL))
		{
			temp=here;
			here=here->next;
		}
		if (here->next==NULL && here->value==item)
		{
			deleteTail();
			return;
		}
		else
		{
			temp->next=here->next;
			(here->next)->prev=temp;
			here->next=NULL;
			here->prev=NULL;
			delete here;
		}
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if (head==NULL)
	{
		return;
	}
	else if (head->next==NULL)
	{
		ListItem<T>* temp_ptr=head;
		head=head->next;
		delete temp_ptr;
		return;
	}
	else
	{
		ListItem<T>* temp_ptr=head;
		head=head->next;
		head->prev=NULL;
		delete temp_ptr;
		return;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	if (head==NULL)
	{
		return;
	}
	else if (head->next==NULL)
	{
		delete head;
		head=NULL;
		return;
	}
	else
	{
		ListItem<T>* here=head;
		ListItem<T>* temp;
		while (here->next != NULL)
	    {
	        temp=here;
	        here=here->next;
	    }
	    temp->next=NULL;
	    here->prev=NULL;
	    delete here;
	    return;
	}
}

template <class T>
int LinkedList<T>::length()
{
	int size=0;
	if (head==NULL)
	{
		return size;
	}
	ListItem<T>* here=head;
	size++;
	while (here->next != NULL)
	{
		size++;
		here=here->next;
	}
	return size;
}

template <class T>
void LinkedList<T>::reverse()
{
	if (head==NULL || head->next==NULL)
	{
		return;
	}
	else
	{
		ListItem<T>* t_head=head;
		ListItem<T>* tail=getTail();

		int len=length()/2;
		T temp;
		for (int i=0; i<len; i++)
		{
			temp=tail->value;
			tail->value=t_head->value;
			t_head->value=temp;
			tail=tail->prev;
			t_head=t_head->next;
		}
	}
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	if (head==NULL || head->next==NULL)
	{
		return;
	}
	T oddarr[length()];
	T evenarr[length()];
	ListItem<T>* here=head;
	int i=0,j=0;
	while (here!=NULL)
	{
		oddarr[j]=here->value;
		j++;
		if (here->next != NULL)
		{
			here=here->next;
			evenarr[i]=here->value;
			i++;
		}
		here=here->next;
	}

	ListItem<T>* here2=head;
	for (int k=0; k<j; k++) 
	{
		here2->value=oddarr[k];
		here2=here2->next;
	}
	for (int l=0; l<i; l++)
	{
		here2->value=evenarr[l];
		here2=here2->next;
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	if (head==NULL)
	{
		return 0;		
	}
	if (head->next == NULL)
	{
		return 1;
	}
	T arr[length()];
	int i=0;
	ListItem<T>* here=head;
	while (here!=NULL)
	{
		arr[i]=here->value;
		i++;
		here=here->next;
	}
	int i2=i-1;
	for (int j=0; j<(i/2); j++)
	{
		if (arr[j]!=arr[i2])
			return 0;
		i2--;
	}
	return 1;
}


#endif