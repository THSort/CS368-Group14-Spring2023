#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD()
{
    tableSize = 10000; // you cant change this
    del_mark = -1;

    count = 0;
    hashTable = new block*[tableSize];

    for (int i=0; i<tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
}

HashD::~HashD()
{
	for (long i=0; i<tableSize; i++)
	{
		delete hashTable[i];
	}
	delete hashTable;
	tableSize = 10000;
	hashTable = NULL;


}

void HashD :: print()
{
	for (long i=0; i<tableSize; i++)
	{
		if(hashTable[i] == NULL)
		{
			cout << "--" << endl;
		}
		else if (hashTable[i]->key == del_mark)
		{
			cout << "--" << endl;
		}
		else
		{
			cout << hashTable[i]->key << ": " << hashTable[i]->value << endl;
		}
	}
	cout << endl;
	cout << "ELEMENTS: " << count << "/" << tableSize << endl;
}

unsigned long HashD :: hash1(string value)
{
    return divCompression( (bitHash(value)), tableSize );  
}

unsigned long HashD :: hash2(string value)
{
	unsigned long code = 0;
	int size = value.length();

	for (int i=0; i<size; i++)
	{
		code ^= (code << 33) + (code >> 37) + int(value[i]);
	}
	return (divCompression(code, tableSize) + 1);

}

void HashD::resizeTable()
{	
   	if (count >= (0.7*tableSize)) // GROW
   	{
		block** oldTable = hashTable;

		tableSize = tableSize * 2;
		hashTable = new block*[tableSize];
	    for (long i=0; i<tableSize; i++)
	    {
	    	hashTable[i] = NULL;
	    }

	    long oldsize = tableSize/2;
	    count = 0;
	    for (long i=0; i<oldsize; i++)
	    {
	    	if (oldTable[i] != NULL)
	    	{
	    		if (oldTable[i] -> key != del_mark)
	    		{
	    			insert(oldTable[i]->value);
	    		}
	    	}
	    	
	    }

	    for (long i=0; i<oldsize; i++)
		{
			delete oldTable[i];
		}
		delete oldTable;
		oldTable = NULL;


   	}
   	else if (count <= (0.25*tableSize)) //SHRINK
   	{
   		block** oldTable = hashTable;

		tableSize = tableSize / 2;
		hashTable = new block*[tableSize];
	    for (long i=0; i<tableSize; i++)
	    {
	    	hashTable[i] = NULL;
	    }

	    long oldsize = tableSize*2;
	    count = 0;
	    for (long i=0; i<oldsize; i++)
	    {
	    	if (oldTable[i] != NULL)
	    	{
	    		if (oldTable[i] -> key != del_mark)
	    		{
	    			insert(oldTable[i]->value);
	    		}
	    	}
	    	
	    }

	    for (long i=0; i<oldsize; i++)
		{
			delete oldTable[i];
		}
		delete oldTable;
		oldTable = NULL;
	}
}

void HashD::insert(string value)
{
	unsigned long hash_val;
	long i = 0;
	while (1)
	{
		hash_val = divCompression((hash1(value) + (i * hash2(value))), tableSize);
		if (hashTable[hash_val] == NULL)
		{
			hashTable[hash_val] = new block(hash_val, value);
			break;
		}
		if (hashTable[hash_val] -> key == del_mark )
		{
			hashTable[hash_val]->key = hash_val;
			hashTable[hash_val]->value = value;
			break;
		}
		i++;
	}
	
	count ++;
	if (count >= (0.7*tableSize))
	{
		resizeTable();
	}
    return;
}

void HashD::deleteWord(string value)
{
	block* temp = lookup(value);
	if (temp == NULL)
	{
		return;
	}
	else
	{
		temp->key = del_mark;
		temp->value = "";
		count--;

	}
	if (count <= (0.25*tableSize))
	{
		resizeTable();
	}
	return;

}

block* HashD::lookup(string value)
{
	unsigned long hash_val;
	long i = 0;
	while(1)
	{
		hash_val = divCompression((hash1(value) + (i * hash2(value))), tableSize);
		if (hashTable[hash_val] == NULL)
		{
			return NULL;
		}
		if (hashTable[hash_val] -> value == value)
		{
			return hashTable[hash_val];
		}
		i++;
	}
}

#endif