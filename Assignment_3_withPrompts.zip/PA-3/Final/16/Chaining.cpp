#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
	tableSize = size;
	hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC()
{
	for (int i=0; i<tableSize; i++)
	{
		hashTable[i].~LinkedList();
	}
	hashTable = NULL;
}

unsigned long HashC :: hash(string input)
{
  	return madCompression( (bitHash(input)), tableSize );  
}

void HashC::insert(string word)
{
	unsigned long hash_value = hash(word);
	hashTable[hash_value].insertAtHead(word);
  	return;
}

ListItem<string>* HashC :: lookup(string word)
{
	unsigned long hash_value = hash(word);
  	return hashTable[hash_value].searchFor(word);
}

void HashC :: deleteWord(string word)
{
	unsigned long hash_value = hash(word);
	hashTable[hash_value].deleteElement(word);
  	return;
}

#endif