#include <iostream>
#include <string>
#include "Chaining.h"
#include "hashfunctions.cpp"
#include <fstream>
#include "LinkedList.cpp"
#include "linearProbing.cpp"
using namespace std;
int main()
{
	vector<string> allWords;
    vector<string> queries;
    srand(time(NULL));
    ifstream file;
    file.open("words.txt");
    cout << "LOADING THE FILE" << endl;
    string temp;
    while(!file.eof()){
        file >> temp;
        allWords.push_back(temp);
        int x = rand()%5;
        if (x<2){
            queries.push_back(temp);
        }
    }
    file.close();
    cout << allWords.size() << " words loaded." << endl;
    
    
    HashL * myhash=new HashL();
    for(int i=0;i<allWords.size();i++)
    {
    	myhash->insert(allWords[i]);
	}
	
	cout<<"yay inserted!"<<endl;
	
	
	
	
	
	for(int i=0;i<queries.size();i++)
	{
		myhash->deleteWord(queries[i]);
	}
	cout<<"yay deleted"<<endl;
	
	for(int i=0;i<queries.size();i++)
	{
		if(myhash->lookup(queries[i])!=NULL)
		{
			cout<<"not working"<<endl;
		}
	}	
	
	
	
	
	
	
}

