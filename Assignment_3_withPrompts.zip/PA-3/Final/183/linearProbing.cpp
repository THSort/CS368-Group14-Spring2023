#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
	count=0;
    tableSize = 1000; // you cant change this
    hashTable= new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
    	hashTable[i]=NULL;
	}
}

HashL::~HashL(){
	
	for(int i=0;i<count;i++)
	{
		delete hashTable[i];
	}
	cout<<"in destructor"<<endl;
}

unsigned long HashL :: hash(string value){
	
    return divCompression(bitHash(value),tableSize); 
}

void HashL::resizeTable(){
	if(count>=tableSize*0.5)
	{
		int old_size=tableSize;
		this->tableSize=2*this->tableSize;
		block ** temp=hashTable;
		hashTable=new block*[tableSize];
		for(int i=0;i<tableSize;i++)
		{
			hashTable[i]=NULL;	
		}
		for(int i=0;i<old_size;i++)
		{
			if(temp[i]!=NULL)
			{
				this->insert(temp[i]->value); //this is if the key is deleted
				if(temp[i]->key==0)
				{
					(this->lookup(temp[i]->value))->key=0;
				}
			}
		}
		delete [] temp;
	}
	else if(count<=tableSize*0.25)
	{
		int old_size=tableSize;
		this->tableSize=0.75*this->tableSize;
		block ** temp=hashTable;
		hashTable=new block*[tableSize];
		for(int i=0;i<tableSize;i++)
		{
			hashTable[i]=NULL;	
		}
		for(int i=0;i<old_size;i++)
		{
			if(temp[i]!=NULL)
			{
				this->insert(temp[i]->value); //this is if the key is deleted
				if(temp[i]->key==0)
				{
					(this->lookup(temp[i]->value))->key=0;
				}
			}
		}
		delete [] temp;
		
	}	
    return;
}

void HashL::insert(string value){
	unsigned long i=hash(value);
	
	long j=0;
	long index=i;
	while(hashTable[index]!=NULL)
	{
		if(hashTable[index]->key==0) // the element has been deleted
		{
			hashTable[index]=new block(1,value);
			count++;
			this->resizeTable();
			return;
		}
		j++;
		index=(i+j) % tableSize;
	}
	hashTable[index]=new block(1, value);
	count++;
	
	this->resizeTable();
	
    return;
}

void HashL::deleteWord(string value){
	
	block * del=lookup(value);
	if(del!=NULL && del->key!=0)
	{
		del->key=0;
		count--;
	}
	
	this->resizeTable();
	return;
}
block* HashL::lookup(string value){
	unsigned long val=hash(value);
	long index=val;
	while(1)
	{
		if(hashTable[index]==NULL)//the string hasnt been inserted as yet, string not found
		{
			return NULL;
		}
		else if(hashTable[index]->key==0)//the key is deleted, cannot be found, hence skip this key
		{
			index=(++val) % tableSize;
		}
		else if(hashTable[index]->value==value)//the string is found
		{
			return hashTable[index];
		}
		index=(++val) % tableSize;
	}
	
	
	
	
	
}
#endif
