#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include <string>
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count=0;
    hashTable= new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
    	hashTable[i]=NULL;
	}
}

HashD::~HashD(){
	
	delete [] hashTable;
	
}

unsigned long HashD :: hash1(string value){
	//primary hash
	return divCompression(bitHash(value),tableSize); 
}

unsigned long HashD :: hash2(string value){
	//this is the secondary hash
	unsigned long hash=0;
	for(int i=0;i<value.size();i++)
	{
		hash=11-(value[i] % 11)+hash;
	}
	return madCompression(hash,tableSize);
}

void HashD::insert(string value){
	this->resizeTable();
	unsigned long i=hash1(value);
	unsigned long h = hash2(value);
	long j=0;
	long index=i%tableSize;
	while(hashTable[index]!=NULL)
	{
		if(hashTable[index]->key==0) // the element has been deleted
		{
			hashTable[index]=new block(1,value);
			count++;
			this->resizeTable();
			return;
		}
		j++;
		index=(i+(j*(h))) % tableSize;
	}
	hashTable[index]=new block(1, value);
	count++;
	
    return;

}

void HashD::deleteWord(string value){
	block * del=lookup(value);
	while(del != NULL)	
	{
		this->resizeTable();
		
		if(del!=NULL && del->key!=0)
		{
			del->key=0;
			count--;
		}
		del=lookup(value);
	}
	
	return;
}

void HashD::resizeTable(){
	if(count>=tableSize*0.5)
	{
		int old_size=tableSize;
		this->tableSize=2*this->tableSize;
		block ** temp=hashTable;
		hashTable=new block*[tableSize];
		for(int i=0;i<tableSize;i++)
		{
			hashTable[i]=NULL;	
		}
		for(int i=0;i<old_size;i++)
		{
			if(temp[i]!=NULL)
			{
				this->insert(temp[i]->value); //this is if the key is deleted
				if(temp[i]->key==0)
				{
					(this->lookup(temp[i]->value))->key=0;
				}
			}
		}
		delete [] temp;
	}
	else if(count<=tableSize*0.25)
	{
		int old_size=tableSize;
		this->tableSize=0.75*this->tableSize;
		block ** temp=hashTable;
		hashTable=new block*[tableSize];
		for(int i=0;i<tableSize;i++)
		{
			hashTable[i]=NULL;	
		}
		for(int i=0;i<old_size;i++)
		{
			if(temp[i]!=NULL)
			{
				this->insert(temp[i]->value); //this is if the key is deleted
				if(temp[i]->key==0)
				{
					(this->lookup(temp[i]->value))->key=0;
				}
			}
		}
		delete [] temp;
		
	}	
    return;
}

block* HashD::lookup(string value){

unsigned long val=hash1(value);
	long index=val;
	long j=0;
	long h = hash2(value);
	while(1)
	{
		index=(val+j*(h)) % tableSize;
		if(hashTable[index]==NULL)//the string hasnt been inserted as yet, string not found
		{
			return NULL;
		}
		else if(hashTable[index]->key==0)//the key is deleted, cannot be found, hence skip this key
		{
			j++;
			continue;
		}
		else if(hashTable[index]->value==value)//the string is found
		{
			return hashTable[index];
		}
		j++;
		
		
	}	
	
}

#endif
