#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"
#include <vector>

using namespace std;
template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	if(otherLinkedList.head==NULL)
	{
		this->head=NULL;
		
	}
	else
	{
		ListItem <T> * temp = new ListItem<T>(otherLinkedList.head->value);
		temp->next=NULL;
		temp->prev=NULL;
		head=temp;
		ListItem <T> * iter=otherLinkedList.head->next;
		ListItem <T> * list_iter=head;
		while(iter!=NULL)
		{
			ListItem <T> * temp = new ListItem<T>(iter->value);
			temp->prev=list_iter;
			list_iter->next=temp;
			temp->next=NULL;
			iter=iter->next;
			list_iter=list_iter->next;
		}
	}
		
}

template <class T>
LinkedList<T>::~LinkedList()
{
	if(head!=NULL)
	{
		
	this->head->prev=NULL;
	ListItem <T>* iter=head->next;
	while(iter!=NULL)
	{
		
		iter->prev->next=NULL;
		iter->prev=NULL;
		iter=iter->next;
	}
}
	

}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if (head == NULL)
	{
		head = new ListItem<T>(item);
	}
	else
	{
	ListItem<T>* temp=new ListItem<T>(item);
	temp->next=head;
	
	head->prev=temp;
	
	head=temp;
	}
	
}
template <class T>
void LinkedList<T>::prints()
{
	ListItem <T>* iter=head;
	while(iter!=NULL)
	{
		cout<<"Val is "<<iter->value<<endl;
		iter=iter->next;
	}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if (head == NULL)
	{
		head = new ListItem<T>(item);
	}
	else
	{
		ListItem <T>* temp=new ListItem<T>(item);
		ListItem <T> * iter=head;
		while(iter->next!=NULL)
		{
			iter=iter->next;
		}
		iter->next=temp;
		temp->prev=iter;
		temp=NULL;
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{bool found=false;	
	if(head==NULL)
	{
		return;	
	}
	else
	{
		ListItem <T> * iter=head;
		ListItem <T> * temp=new ListItem<T>(toInsert);
		while(iter!=NULL)
		{
		
			if(iter->value==afterWhat)
			{
				found=true;
				
				break;
			}
			iter=iter->next;
		}
		if(!found)
		{
		
			return;
		}
		else if(found && iter->next==NULL)//we are at the tail
		{
		iter->next=temp;
		temp->prev=iter;
			
		}
		else
		{
		temp->next=iter->next;
		iter->next->prev=temp;
		iter->next=temp;
		temp->prev=iter;
		}
	}
	
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if(head==NULL)
	{
		head=new ListItem<T>(item);
	
	}
	else
	{
	ListItem <T> * temp=new ListItem<T>(item);	
	ListItem <T> * iter=head;
	while(iter!=NULL)
	{
		if((item > iter->value || item==iter->value) && iter->next==NULL)//at tail
		{
			iter->next=temp;
			temp->prev=iter;	
			break;
		}
		else if(item<=iter->value && iter->prev==NULL)//at head
		{
			temp->next=iter;
			iter->prev=temp;
			head=temp;
			break;
		}
		
		
		else if((item >=iter->value) && (item <= iter->next->value))
		{
			temp->next=iter->next;
			iter->next->prev=temp;
			iter->next=temp;
			temp->prev=iter;
			break;
		}
		iter=iter->next;
	}
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead() const
{
	if(head!=NULL)
	{
		return head;
	}	
	else
	{
		return NULL;
	}

}

template <class T>
ListItem<T>* LinkedList<T>::getTail() const
{
	ListItem<T> * iter=head;
	if(iter==NULL)
	{
		return NULL;	
	}
	while(iter->next!=NULL)
	{
		iter=iter->next;
	}
	return iter;

}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item) const
{
	ListItem <T> *iter=head;
	if(head==NULL)
	{
		return NULL;
	}
	while(iter!= NULL)
	{
		if(iter->value==item)
		{
			return iter;
		}	
		iter=iter->next;
	}

	return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if(head==NULL)
	{
		return;
	}
	else
	{
		ListItem <T>* iter=this->searchFor(item);
		ListItem<T>* temp;
		while(iter!=NULL)
		{
			temp = iter->next;
			if(iter->next==NULL && iter->prev==NULL)
			{
				head=NULL;
				iter=NULL;
				return;
			}
			else if(iter->next==NULL)
			{
				iter->prev->next=NULL;
				iter->prev=NULL;
			}
			else if(iter->prev==NULL)
			{
				head=iter->next;
				head->prev=NULL;
				iter->next=NULL;
			}
			else
			{
				iter->prev->next=iter->next;
				iter->next->prev=iter->prev;
				iter->next=NULL;
				iter->prev=NULL;
			}	
			delete iter;
			iter=temp;
		}
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if(head==NULL)
	{
		return;
	}
	else if(head->next==NULL)
	{
		head=NULL;	
	}
	else
	{
	ListItem <T>* iter=this->head;
	head=iter->next;
	head->prev=NULL;
	iter->next=NULL;
	}

}

template <class T>
void LinkedList<T>::deleteTail()
{
	if(head==NULL)
	{
		return;
	}
	else if(head->next==NULL)
	{
		delete head;
		head=NULL;
		return;
	}
	else
	{
	ListItem <T>* iter=head;
	while(iter->next!=NULL)//till you reach the tail
	{
		iter=iter->next;
	}
	
	iter->prev->next=NULL;
	iter->prev=NULL;
	delete iter;
	iter=NULL;

	}
}

template <class T>
int LinkedList<T>::length() const
{
	ListItem <T> * iter=this->head;
	int count=0;
	if(head==NULL)
	{
		return 0;
	}
	while(iter!=NULL)
	{
		
		iter=iter->next;
		count++;
	}
	return count;
}

template <class T>
void LinkedList<T>::reverse()
{
	if(head==NULL || head->next==NULL)
	{
		return;
	}
	else
	{
		ListItem <T> * iter;
		ListItem <T>* temp;
		
		head=getTail();
		iter=head;
		 while(iter!=NULL)
			{
				temp=iter->next;
				iter->next=iter->prev;
				iter->prev=temp;
				
				iter=iter->next;
				
			}
		temp=NULL;
		iter=NULL;	
	}

	
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	if(this->length()==0)
	{
		return;
	}
	if(this->length()%2==1)//odd case
	{
		ListItem <T> * tail_ptr=this->getTail();
		T match_val= tail_ptr->value;
		ListItem <T> * iter=head;
		ListItem <T> * removed=iter->next;
		int count=0;
		while(iter->value!=match_val)
		{	count++;
			iter->next=iter->next->next;
			iter->next->prev=iter;
			tail_ptr->next=removed;
			removed->prev=tail_ptr;
			tail_ptr=removed;
			tail_ptr->next=NULL;
			iter=iter->next;
			removed=iter->next;
						
		}
		
		return;
	
	}
	else					//even case
	{
		ListItem <T> * tail_ptr=this->getTail();
		T match_val= head->next->value;
		ListItem <T> * iter=head;
		ListItem <T> * removed=iter->next;
		int count=0;
		while(iter->value!=match_val)
		{	count++;
			iter->next=iter->next->next;
			iter->next->prev=iter;
			tail_ptr->next=removed;
			removed->prev=tail_ptr;
			tail_ptr=removed;
			tail_ptr->next=NULL;
			iter=iter->next;
			removed=iter->next;
						
		}
		
		return;
		
	}
	

}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	ListItem <T> * tail=this->getTail();
	ListItem <T> * agay=this->head;
	ListItem <T> * peechay=tail;
	if(length()==0)
	{
		return false;
	}
	//odd case
	if(this->length()%2==1)
	{
		while(agay!=peechay)
		{
			if(agay->value!=peechay->value)
			{
				return false;
			}
			else
			{
				agay=agay->next;
				peechay=peechay->prev;
			}
		}
		return true;
	}
	//even case
	else
	{
	while(agay->next!=peechay || agay!=peechay->prev)
		{
			if(agay->value!=peechay->value)
			{
				return false;
			}
			else
			{
				agay=agay->next;
				peechay=peechay->prev;
			}
		}
		if(agay->value==peechay->value)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	
}

#endif
