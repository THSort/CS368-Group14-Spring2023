#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"
#include <vector>


HashL::HashL(){
    tableSize = 10000; // you cant change this
    count = 0;
    hashTable = new block* [tableSize];
    for (int i = 0; i < tableSize; ++i)
    {
    	hashTable[i] = NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
    return bitHash(value);
}

void HashL::resizeTable(){    
    
    int old = tableSize;
    if (count == tableSize/4)  tableSize = tableSize*11;
    else return;
    vector<string> st;
    for (int i = 0; i < old; ++i)
    {   
        if (hashTable[i]!=NULL)
    	st.push_back(hashTable[i]->value);
    }

    count = 0;
    hashTable = new block* [tableSize];
        for (int i = 0; i < tableSize; ++i)
    {
      hashTable[i] = NULL;
    }
   
    for (int i = 0; i < st.size(); ++i)
    { 

    	insert(st[i]);
    }

}

void HashL::insert(string value){
    resizeTable();
    unsigned long key = hash(value);
    int index = 0;
    for (int i = 0; i < tableSize; ++i)
    {
    	index = (key+i)%tableSize;
        if (hashTable[index] == NULL){
        	hashTable[index] = new block(key+1, value);
          count++;
        	break;
        }
        else if (hashTable[index]->key == -1){
          hashTable[index]->key = key+i;
          hashTable[index]->value = value;
          count++;
          break;
        }
    }
}

void HashL::deleteWord(string value){
 


block* temp = lookup(value);
  
   if (temp!= NULL)
   {
     temp->key = -1;
     temp->value = "";
	 count--;
   }
}

block* HashL::lookup(string value){

unsigned long key = hash(value);
int index = 0;
for (int i = 0; i < tableSize; ++i)
    {
      index = (key+i)%tableSize;
        if (hashTable[index] != NULL){
          if (hashTable[index]->value == value) return hashTable[index];
          else if (hashTable[index]->key == -1) return NULL;
        }
    }
  return NULL;


}
#endif
