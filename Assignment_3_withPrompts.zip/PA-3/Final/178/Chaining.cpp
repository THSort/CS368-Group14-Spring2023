#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
#include "LinkedList.cpp"

HashC::HashC(int size){
	tableSize = size; 
	hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC(){

for (int i = 0; i<tableSize; ++i)  hashTable[i].~LinkedList();
delete[] hashTable;

}

unsigned long HashC :: hash(string input){
  return bitHash(input);
}

void HashC::insert(string word){
  
  unsigned long key = hash(word);
  hashTable[key % tableSize].insertAtTail(word);
}

ListItem<string>* HashC :: lookup(string word){
  unsigned long key = hash(word);
  return hashTable[key%tableSize].searchFor(word);
}

void HashC :: deleteWord(string word){
  unsigned long key = hash(word);
  hashTable[key%tableSize].deleteElement(word);
}

#endif
