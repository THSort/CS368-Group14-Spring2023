#ifndef __LIST_CPP
#define __LIST_CPP

#include <iostream>
using namespace std;
#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	
	head = NULL;
	tail = NULL;
	

}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{  
  if (otherLinkedList.head == NULL){
  head = NULL;
  tail = NULL;}

  else 
  {
    head = NULL;
    tail = NULL;
    ListItem<T> *temp;
    temp = otherLinkedList.head;

    while (temp!=NULL)
    {
      insertAtTail(temp->value);
      temp = temp->next;
    }
  }

}
template <class T>
LinkedList<T>::~LinkedList()
{
  ListItem<T> *temp;
  temp = head;
	
  while(temp != NULL) 
    {  
    temp=temp->next; 
    delete temp;
    }
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> *temp = new ListItem<T>(item);
    

    if(head==NULL)
      {
        head=temp;
        tail=temp;
      }
     
     else
      {

      	
        temp->next = head;
        head=temp;
        head->next->prev = head;

        ListItem<T> *tt;
        tt = head;

        while(tt->next != NULL)
        {
        	tt=tt->next;
        	tail=tt;
        }

        head->prev = NULL;

        

      }

head->prev = NULL;
      
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
      ListItem<T> *temp = new ListItem<T>(item);
      
      if(head==NULL)
      {
        head=temp;
        tail=temp;
      }

      else
      {
      	temp->prev = tail;
        tail->next = temp;
        tail=temp;
      }

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T> *tempp;
    tempp=head;

    if (afterWhat==tail->value)
    {
    	insertAtTail(toInsert);
    }

    else{

    while((tempp->value) != afterWhat)
    {  if (tempp->next!=NULL){tempp=tempp->next;}
       else {break;}
    }

    ListItem<T> *add=new ListItem<T>(toInsert);

    add->next = tempp->next;
    add->prev = tempp; 
    tempp->next->prev = add;
    tempp->next = add;



}




}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
   if (head==NULL || item<=head->value)
   {
   	  insertAtHead(item);
   }

   else if (item>=tail->value)
   {
   	  insertAtTail(item);
   }


   else
   {

   	ListItem<T> *tempp;
    tempp=head;

    while((tempp->value) <= item)
    {  if (tempp->next!=NULL){tempp=tempp->next;}
       else {break;}
    }
    
    //cout<<"yeh "<<tempp->value<<"loop k baad temp ";
    if(tempp!=head) insertAfter(item, tempp->prev->value);
    else insertAfter(item, tempp->value);

   }



}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;

}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
      return tail;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
  if (head==NULL || item==head->value)
   {
      return head;
   }

   else if (item==tail->value)
   {
      return tail;
   }


   else
   {

    ListItem<T> *tempp;
    tempp=head;

    while((tempp->value) != item)
    {  if (tempp->next!=NULL){tempp=tempp->next;}
       else {break;}
    }
    if ((tempp->value) == item) return tempp;
    else return NULL;
  }
    
    
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{

	ListItem<T> *tempp;

    
    if (item==head->value)
    {
      deleteHead(); return;
    }
    
    else if (item==tail->value)
    {
    	deleteTail(); return;
    }
    
    

    else {
    
      if (searchFor (item) != NULL)
      {
        tempp = searchFor (item);
        tempp->prev->next = tempp->next;
        tempp->next->prev = tempp->prev;
        delete tempp;}
      else;
      }
      

}

template <class T>
void LinkedList<T>::deleteHead()
{
  ListItem<T>* current = head;
if (head == tail)
    head = tail = NULL;
else
    {head = head->next;
    head->prev = NULL;
delete current; }

}

template <class T>
void LinkedList<T>::deleteTail()
{
  ListItem<T>* current = tail;
if (tail == head)
    tail = head = NULL;
else
    {tail = tail->prev;
    tail->next =NULL;
delete current;}
}

template <class T>
int LinkedList<T>::length()
{
  int count = 0;

  if (head==NULL) return 0;

  else 
  { 
  	ListItem<T> *tempp;
    tempp=head;

    while(tempp != NULL)
       
    {  
       count++;
       tempp=tempp->next;

    }

    return count;

  }

}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T> *temp;
  temp = head;
  int size = length();
  int loop = 0;
  

  while (loop!=size)
  {
    insertAtHead(temp->value);
    if(temp->next!=NULL)temp = temp->next;
    loop++;
  }

  for (int i = 0; i<size; i++)
  {
    deleteTail();
  }



}

template <class T>
void LinkedList<T>::parityArrangement()
{
  ListItem<T> *temp = head;// = new ListItem<T>(head);
  ListItem<T> *ttemp = head;// = new ListItem<T>(head);
  

  int size = length();
  int loop = 0;
  

  while (loop!=size)
  {
    if (loop%2==0){insertAtTail(temp->value);}
    
   
    if(temp->next!=NULL)temp = temp->next;
    loop++;
  }

  loop = 0;
  temp = head;

  while (loop!=size)
  {
    if (loop%2!=0){insertAtTail(temp->value);}

   
    if(temp->next!=NULL)temp = temp->next;
    loop++;
  }


for (int i = 0; i<loop; i++)
  {
 
    deleteHead();
  }

  head->prev = NULL;
 

 ListItem<T> *tt = head;


  while(tt->next != NULL)
        {
        	tt=tt->next;
        	tail=tt;
        }



	
}

template <class T>
bool LinkedList<T>::isPalindrome()

{ 
	if (head==NULL) return false;

	int  check1[length()];
	int  check2[length()];
 
    int i = 0;
	while(head != NULL)
       
    {  
       
      check1[i]=(head->value);
      i++;

       if (head->next!=NULL){head=head->next; }
       else break;
    }

    i = 0;
    while(tail != NULL)
       
    {  
       
       check2[i]=(tail->value);
       i++;

       if (tail->prev!=NULL){tail=tail->prev; }
       else break;
    }


    for (int i = 0; i < length(); ++i)
    {
    	if(check1[i]!=check2[i]) return false;
    }
   
     return true;
}




template <class T>
void LinkedList<T>::testprint()
{
	while(head != NULL)
       
    {  
       
      std::cout<<head->value<<" ";

       if (head->next!=NULL){head=head->next; }
       else break;
    }

    std::cout<<std::endl<<"reverse test"<<std::endl;

    while(tail != NULL)
       
    {  
       
       std::cout<<tail->value<<" ";

       if (tail->prev!=NULL){tail=tail->prev; }
       else break;
    }
    std::cout<<std::endl;

}




#endif
