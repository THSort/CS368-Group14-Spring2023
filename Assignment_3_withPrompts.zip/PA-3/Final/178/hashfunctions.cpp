//#include <iostream>
#include <string>
#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP

// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	
	unsigned long hashed_sum = 0.0;
	for (int i = 0; i < value.length(); ++i)
	    hashed_sum += (long(value[i]))*a^(value.length()-i+1);
    return hashed_sum;


}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	
	unsigned long bit_hash = 0.0;
	for (int i = 0; i < value.length(); ++i) 
		bit_hash += ((bit_hash << 5) | (bit_hash >> 2)) + long(value[i]);
    return bit_hash;

}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return hash % size;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    return ((m%size)*hash + a);
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.


// int main()
// {
// 	long test = divCompression(polyHash("test"), 5);
// 	long test1 = divCompression(bitHash("test"), 5);
// 	std::cout<<test<<std::endl;
// 	std::cout<<test1<<std::endl;
// 	test = madCompression(polyHash("test"), 5);
// 	test1 = madCompression(bitHash("test"), 5);
// 	std::cout<<test<<std::endl;
// 	std::cout<<test1<<std::endl;
// }