#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include <iostream>
#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    this->tableSize = 1000; // you cant change this
    this->hashTable = new block* [this->tableSize];
    for (int i = 0; i < this->tableSize; ++i)
    {
    	this->hashTable[i] = NULL;
    }
    this->count = 0;
}

HashL::~HashL(){
    delete[] this->hashTable;
}

unsigned long HashL :: hash(string value){
    return madCompression(bitHash(value), this->tableSize);
}

void HashL::resizeTable(){
	// CHECK FOR SHRINK
	if (this->count <= (0.25)*this->tableSize)
	{
		long new_size = (0.75)*this->tableSize;
		// cout << "shrink2 \n";
		block** new_hashTable = new block*[new_size];
		for (int i = 0; i < new_size; ++i)
    	{
    		new_hashTable[i] = NULL;
    	}
    	block** old_hashTable = this->hashTable;
    	long old_size = this->tableSize;
    	this->tableSize = new_size;
    	this->hashTable = new_hashTable;
    	for (int i = 0; i < old_size; ++i)
    	{
    		if (old_hashTable[i] != NULL)
    		{	
    			this->insert(old_hashTable[i]->value);
                if (old_hashTable[i]->key == 0)
                {
                    block* handle = this->lookup(old_hashTable[i]->value);
                    handle->key = 0;
                }
    		}
    	}
    	delete[] old_hashTable;
	}
	else if (this->count >= (0.5)*this->tableSize) // CHECK FOR GROW
	{
		long new_size = 2*this->tableSize;
		block** new_hashTable = new block*[new_size];
		// cout << "grow2 \n";
		for (int i = 0; i < new_size; ++i)
    	{
    		new_hashTable[i] = NULL;
    	}
    	block** old_hashTable = this->hashTable;
    	long old_size = this->tableSize;
    	this->tableSize = new_size;
    	this->hashTable = new_hashTable;
    	for (int i = 0; i < old_size; ++i)
    	{
    		if (old_hashTable[i] != NULL)
    		{	
    			this->insert(old_hashTable[i]->value);
                if (old_hashTable[i]->key == 0)
                {
                    block* handle = this->lookup(old_hashTable[i]->value);
                    handle->key = 0;
                }
    		}
    	}
    	delete[] old_hashTable;
	}
    return;
}

void HashL::insert(string value){
    unsigned long i = this->hash(value);
    unsigned long index = i % this->tableSize;
    bool inserted = false;
    while (!inserted)
    {
        // cout << "im stuck"  << endl;
    	if (this->hashTable[index] == NULL)
    	{
    		this->hashTable[index] = new block(1, value);
    		this->count++;
    		inserted = true;
       	}
       	else if (this->hashTable[index]!= NULL)
       	{
       		if (this->hashTable[index]->key == 0)
       		{
	       		this->hashTable[index] = new block(1, value);
	    		this->count++;
	    		inserted = true;
	    	}
       	}
    	index = (++i) % this->tableSize;
    }
    // cout << "i escaped" << endl;
    this->resizeTable();
}

void HashL::deleteWord(string value){
	block* temp = this->lookup(value);
	if(temp != NULL && temp->key != 0)
	{
		temp->key = 0;
		this->count--;
	}
    this->resizeTable();
    return;
}
block* HashL::lookup(string value){
	unsigned long i = this->hash(value);
	unsigned long index = i;
	bool found = false;
	while (!found)
	{
		if (this->hashTable[index] == NULL)
		{
			return NULL;
		}
		else if (this->hashTable[index]->key == 0)
		{
			index = (++i) % this->tableSize;
		}
		else if (this->hashTable[index]->value == value)
		{
			found = true;
			return this->hashTable[index];
		}
		index = (++i) % this->tableSize;
	}
}
#endif
