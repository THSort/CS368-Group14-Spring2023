#ifndef CHAINING_CPP
#define CHAINING_CPP
#include <cstdlib>
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    this->tableSize = size;
    this->hashTable = new LinkedList<string>[size];
}
HashC::~HashC(){
	delete[] this->hashTable;
}

unsigned long HashC :: hash(string input){
	return divCompression(bitHash(input), this->tableSize);
}
void HashC::insert(string word){
	this->hashTable[this->hash(word)].insertAtHead(word);
}

ListItem<string>* HashC :: lookup(string word){
	return this->hashTable[this->hash(word)].searchFor(word);
}

void HashC :: deleteWord(string word){
  	this->hashTable[this->hash(word)].deleteElement(word);
}

#endif
