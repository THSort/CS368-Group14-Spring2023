#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"
#include <iostream>
using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
    this->head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{	
	if (otherLinkedList.head == NULL)
	{
		this->head = NULL;
	}
	else
	{
		ListItem<T> *temp = new ListItem<T>(otherLinkedList.head->value);
		this->head = temp;
		ListItem<T> *iter1 = this->head;
		ListItem<T> *iter2 = otherLinkedList.head->next;
		
		while (iter2 != NULL)
		{
			temp = new ListItem<T>(iter2->value);
			temp->prev = iter1;
			iter1->next=temp;
			//iter1 = temp;
			iter1 = iter1->next;
			iter2 = iter2->next;
		}
		temp = NULL;
		iter1 = NULL;
		iter2 = NULL;
	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	ListItem<T> *temp = NULL;
	ListItem<T> *iter = this->head;
	while(iter != NULL)
	{
		iter->prev = NULL;
		temp = iter;
		iter = iter->next;
		temp->prev = NULL;
		temp->next = NULL;
		delete temp;
	}
	temp = NULL;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if(this->head != NULL)
	{	
		ListItem<T> *temp = new ListItem<T>(item);
		temp->next = this->head;
		this->head->prev = temp;
		this->head = temp;
	}
	else
	{
		this->head = new ListItem<T>(item);
	}
}


template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem<T> *temp = new ListItem<T>(item);
	ListItem<T> *tail = this->head;
	if(tail != NULL)
	{
		while(tail->next != NULL)
		{
			tail = tail->next;
		}
		tail->next = temp;
		temp->prev = tail;
		tail = NULL;
	}
	else
	{
		this->head = new ListItem<T>(item);
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T>* insert = new ListItem<T>(toInsert);
	ListItem<T>* iter = this->head;
	while(iter != NULL)
	{
		if (iter->next != NULL && iter->value == afterWhat)
		{
			insert->next = iter->next;
			iter->next = insert;
			insert->prev = iter;
			iter->next->prev = iter;
		}
		else if (iter->next == NULL && iter->value == afterWhat)
		{
			insert->prev = iter;
			iter->next = insert;
		}
		iter = iter->next;
	}
	iter = NULL;
	insert = NULL;
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if (this->head != NULL)
	{
		if (this->head->next == NULL)
		{
			if (this->head->value >= item)
			{
				this->insertAtHead(item);
			}
			else
			{
				this->insertAtTail(item);
			}
		}
		else
		{
			if (item <= this->head->value)
			{
				this->insertAtHead(item);
			}
			else if (item >= this->getTail()->value)
			{
				this->insertAtTail(item);
			}
			else
			{
				ListItem<T> *iter = this->head->next;
				while (iter != NULL)
				{
					if (iter->value >= item)
					{
						ListItem<T>* temp = new ListItem<T>(item);
						temp->next = iter;
						temp->prev = iter->prev;
						iter->prev = temp;
						temp->prev->next = temp;
						temp = NULL;
						break;
					}
					iter = iter->next;
				}
			}
		}
	}
	else
	{
		this->insertAtHead(item);
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead() const
{
	return this->head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail() const
{
	ListItem<T> *tail = this->head;
	if (tail != NULL)
	{	
		while(tail->next != NULL)
		{
			tail = tail->next;
		}
	}
	return tail;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item) const
{
	ListItem<T> *iter = this->head;
	while(iter != NULL)
	{
		if(iter->value == item)
		{
			return iter;
		}
		else
		{
			iter = iter->next;
		}
	}
	return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T>* iter = searchFor(item);
	ListItem<T>* temp;
	while(iter != NULL)
	{
		temp = iter->next;
		if (iter == this->head)
		{
			this->deleteHead();
		}
		else if (iter != NULL && iter->next != NULL)
		{
			iter->next->prev = iter->prev;
			iter->prev->next = iter->next;
			delete iter;
			iter = NULL;
		}
		else if (iter != NULL && iter->next == NULL)
		{
			iter->prev->next = NULL;
			delete iter;
			iter = NULL;
		}
		iter = temp;
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if (this->head != NULL && this->head->next != NULL)
	{
		this->head = this->head->next;
		this->head->prev->next = NULL;
		delete this->head->prev;
		this->head->prev = NULL;
	}
	else if (this->head != NULL)
	{
		delete this->head;
		this->head = NULL;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T>* del_tail = getTail();
	if (del_tail != this->head)
	{
		del_tail->prev->next = NULL;
		del_tail->prev = NULL;
		delete del_tail;
		del_tail = NULL;
	}
}

template <class T>
int LinkedList<T>::length() const
{
	int count = 0;
	ListItem<T>* iter = this->head;
	while (iter != NULL)
	{
		count++;
		iter = iter->next;
	}
	return count;
}

template <class T>
void LinkedList<T>::reverse()
{
	if (this->head != NULL)
	{
		ListItem<T> *temp = NULL;
		ListItem<T> *iter = this->head;
		while(iter->next != NULL)
		{
			temp = iter->next;
			iter->next = iter->prev;
			iter->prev = temp;
			iter = iter->prev;
		}
		temp = iter->next;
		iter->next = iter->prev;
		iter->prev = temp;
		this->head = iter;
	}
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	if(this->head == NULL)
	{
		return;
	}
	else if (this->head->next == NULL)
	{
		return;
	}
	else if (this->head->next->next == NULL)
	{
		return;
	}
	else
	{
		ListItem<T> *i = NULL;
		ListItem<T> *temp = this->head;
		ListItem<T> *tail = this->getTail();
		if (this->length()%2 != 0)
		{
			ListItem<T> *old_tail = this->getTail();
			while(temp != old_tail)
			{
				i = temp->next;
				tail->next = i;
				temp->next = i->next;
				i->prev = tail;
				i->next = NULL;
				temp->next->prev = temp;
				tail = tail->next;
				temp = temp->next;
			}
		}
		else
		{
			ListItem<T> *first_swap = this->head->next;
			while(temp != first_swap)
			{
				i = temp->next;
				tail->next = i;
				temp->next = i->next;
				i->prev = tail;
				i->next = NULL;
				temp->next->prev = temp;
				tail = i;
				temp = temp->next;
			}
		}
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	ListItem<T> *tail_iter = this->getTail();
	ListItem<T> *head_iter = this->getHead();
	
	if (head_iter == NULL)
	{
		return false;
	}
	
	if (tail_iter != head_iter)
	{
		if (this->length()%2)
		{
			while (head_iter->next != tail_iter->prev)
			{
				if(head_iter->value != tail_iter->value)
				{
					return false;
				}
				else
				{
					head_iter = head_iter->next;
					tail_iter = tail_iter->prev;
				}
			}
		}
		else
		{
			while (head_iter->next != tail_iter)
			{
				if(head_iter->value != tail_iter->value)
				{
					return false;
				}
				else
				{
					head_iter = head_iter->next;
					tail_iter = tail_iter->prev;
				}
			}
			if (head_iter->value != tail_iter->value)
			{
				return false;
			}
		}
	}
	
	return true;
}

#endif
