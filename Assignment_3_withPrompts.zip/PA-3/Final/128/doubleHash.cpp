#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    this->hashTable = new block* [this->tableSize];
    for (int i = 0; i < this->tableSize; ++i)
    {
    	this->hashTable[i] = NULL;
    }
    this->count = 0;
}

HashD::~HashD(){
	delete[] this->hashTable;
}

unsigned long HashD :: hash1(string value){
    return divCompression(bitHash(value), this->tableSize);
}

unsigned long HashD :: hash2(string value){
    return madCompression(bitHash(value), this->tableSize);
}

void HashD::resizeTable(){
    if (this->count <= (0.25)*this->tableSize)
	{
		long new_size = (0.75)*this->tableSize;
		// cout << "shrink2 \n";
		block** new_hashTable = new block*[new_size];
		for (int i = 0; i < new_size; ++i)
    	{
    		new_hashTable[i] = NULL;
    	}
    	block** old_hashTable = this->hashTable;
    	long old_size = this->tableSize;
    	this->tableSize = new_size;
    	this->hashTable = new_hashTable;
    	for (int i = 0; i < old_size; ++i)
    	{
    		if (old_hashTable[i] != NULL)
    		{	
    			this->insert(old_hashTable[i]->value);
    		}
    	}
    	delete[] old_hashTable;
	}
	else if (this->count >= (0.5)*this->tableSize) // CHECK FOR GROW
	{
		// cout << "growing" << endl;
		long new_size = 2*this->tableSize;
		block** new_hashTable = new block*[new_size];
		// cout << "grow2 \n";
		for (int i = 0; i < new_size; ++i)
    	{
    		new_hashTable[i] = NULL;
    	}
    	block** old_hashTable = this->hashTable;
    	long old_size = this->tableSize;
    	this->tableSize = new_size;
    	this->hashTable = new_hashTable;
    	for (int i = 0; i < old_size; ++i)
    	{
    		if (old_hashTable[i] != NULL)
    		{	
    			this->insert(old_hashTable[i]->value);
    		}
    	}
    	delete[] old_hashTable;
	}
    return;
}

void HashD::insert(string value){
	this->resizeTable();
    unsigned long i = hash1(value);
    bool inserted = false;
    unsigned long f_j = 0;
    unsigned long h = hash2(value);
    unsigned long j = 0;
    while(!inserted)
    {
    	f_j = j * h;
    	unsigned long index = (i + f_j) % this->tableSize;
    	if (this->hashTable[index] == NULL)
	    {
	    	this->hashTable[index] = new block(1, value);
	    	this->count++;
	    	inserted = true;
	    }
	    else if (this->hashTable[index]->key == 0)
	    {
	    	this->hashTable[index] = new block(1, value);
	    	this->count++;
	    	inserted = true;
	    }
	    else
	    {
	    	j++;
	    	// cout << "stuck" << endl;
	    }
	}
	// cout << "escaped" << endl;
	// cout << this->count << " : " << this->tableSize << endl;
}

void HashD::deleteWord(string value){
    block* temp = this->lookup(value);
    while(temp != NULL)	
    {
        this->resizeTable();
    	if(temp->key != 0)
    	{
    		temp->key = 0;
    		this->count--;
    	}
        temp = this->lookup(value);

    }
}

block* HashD::lookup(string value){
	unsigned long i = hash1(value);
    bool found = false;
    unsigned long f_j = 0;
    unsigned long h = hash2(value);
    unsigned long j = 0;
    while(!found)
    {
    	f_j = j * h;
    	unsigned long index = (i + f_j) % this->tableSize;
    	if (this->hashTable[index] == NULL)
	    {
	    	return NULL;
	    }
	    else if (this->hashTable[index]->key == 0)
	    {
	    	j++;
	    	continue;
	    }
	    else if (this->hashTable[index]->value == value)
	    {
	    	found = true;
	    	return this->hashTable[index];
	    }
	    j++;
	}	
}

#endif