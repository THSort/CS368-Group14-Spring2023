#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <cmath>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	unsigned long poly = 0;
	int k_max = value.length();
	for (int k = 0; k < k_max; k++)
	{
		poly += value[k] * pow(a, k_max - 1 - k);
	}
	return poly;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	unsigned long bitwise_hash = 0;
	int i_max = value.length();
	for (int i = 0; i < i_max; i++)
	{
		bitwise_hash ^= (bitwise_hash << 5) + (bitwise_hash >> 2) + value[i];
	} 
	return bitwise_hash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return (hash % size);
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 197,int a = 1637){
	
    return (a * hash + m) % size;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
