#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    block** temp = new block*[tableSize];
    for (int i = 0; i < tableSize; ++i)
    {
    	temp[i]= NULL;
    	
    }
    hashTable = temp;
    count=0;
    conflict=0;
    	// temp[i][0].value="";
    	// temp[i][1].key=0;
    	// temp[i][1].value=
}

HashL::~HashL(){
    for (int i = 0; i < tableSize; ++i)
    {
    	delete hashTable[i];
    }
    delete [] hashTable;
}

unsigned long HashL :: hash(string value){
    
    return bitHash(value);
}

void HashL::resizeTable(){
    long old_size = tableSize;
    if (count == (tableSize*0.8)) // in insert
    {
    	tableSize *= 2;
    	//cout<<"resize()"<<endl;

    }
    else if(count == (tableSize/4)) // in delete
    {
    	tableSize = (3*tableSize / 4);
    }
    else
    {
    	return;
    }

    block** temp = new block*[tableSize]; //make temp table
    for (int i = 0; i < tableSize; ++i)
    {
    	temp[i]= NULL;
    	
    }
    block** temp2 = hashTable; //old table ---------------
    
    
    hashTable = temp; //new table point 
    
    count = 0;

    for (int i = 0; i < old_size; ++i) // copy it into new table
    {
    	if (temp2[i]==NULL)
    	{
    		continue;
    	}
    	if (temp2[i]->value=="deleted" && temp2[i]->key==0)
    	{
    		continue;
    	}
    	insert(temp2[i]->value);
    }
    

    for (int i = 0; i < old_size; ++i) //delete old table
    {
    	delete temp2[i];
    }
    delete [] temp2;
    //cout<<"resize()"<<endl;
    return;

}

void HashL::insert(string value){
    if (count==(tableSize*0.8))
    {
    	//cout<<"resize"<<endl;

    	resizeTable();
    	
    }
    unsigned long code = hash(value);
    unsigned long index = madCompression(code,tableSize); //index
    //cout<<"insert value: "<<value<<" index:"<<index<<endl;
    // if (value == "rangolis")
    // {
    // 	cout<<index<<"insert"<<endl;
    // }
    
    count++; //adding now
    
    while(1)
    {
    	if (hashTable[index] ==NULL) //entry
	    {
	    	hashTable[index] = new block(code, value);
	    	break;
	    }
	    if (hashTable[index]->value==value) //duplicate
	    {
	    	break;
	    }
	    if (hashTable[index]->value=="deleted" && hashTable[index]->key==0)
	    {
	    	hashTable[index]->value= value;
	    	hashTable[index]->key = code;
	    	
	    	break;
	    }
	    index++;
	    
	    //conflict++;
	    if (index >= (tableSize)) //prevent overflow
	    {
	    	index= 0;

	    }

    }
   // cout<<"done";


}

void HashL::deleteWord(string value){
	while(1)
	{
	    block* temp = lookup(value);
	    if (temp==NULL)
	    {
	    	return;
	    }
	    temp->key=0;
	    temp->value="deleted";
	    count--;
	    if (count == (tableSize/4))
	    {
	    	resizeTable();
	    }
	}

    return;
}
block* HashL::lookup(string value){
    unsigned long code = hash(value);
    unsigned long index = madCompression(code,tableSize);
    //cout<<"lookup value: "<<value<<" index:"<<index<<endl;
    
    while(1) //in for loop to prevent it going in circles
    {
    	if (hashTable[index] ==NULL)
	    {
	    	return NULL;
	    }
    	if (hashTable[index]->value ==value)
	    {
	    	if (hashTable[index]->value=="deleted" && hashTable[index]->key==0)
            {
                
            }
            else
            {
                return hashTable[index];
            }
            
	    }
	    
	    index++;
	   
	    
	    if (index >= tableSize) //prevent overflow
	    {
	    	index= 0;
	    }

    }
    
}

void HashL::print()
{
	cout<<"no. of items: "<<count<<" tableSize: "<<tableSize<<" conflict: "<<conflict<<endl;
	ofstream myfile;
	myfile.open ("example.txt");
	for (int i = 0; i < tableSize; ++i)
	{
		if (hashTable[i]==NULL)
		{
			myfile<<"\n";
			continue;
		}
		if (hashTable[i]->value=="")
		{
			myfile<<"\n";
			continue;
		}
		if (hashTable[i]->value=="deleted" && hashTable[i]->key==0)
		{
			myfile<<"\n";
			continue;
		}
		myfile << hashTable[i]->value <<" "<<i<< "\n";
	}
	//myfile << "Writing this to a file.\n";
	
	myfile.close();
}
#endif
