#include <iostream>



using namespace std;

int main()
{
	cout<<"program"<<endl;
	int z=5;
	int x= 6;
	int ** a;
	int * b = &z;
	//*a = &z;
	a = &b;
	
	cout<<"a:" <<" "<<"*a:"<< b <<" "<<"**a:"<<&a<<endl ;
	return 0;
}