#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    tableSize = size;
    hashTable = new LinkedList<string>[size];

}
HashC::~HashC(){
	delete [] hashTable;
}

unsigned long HashC :: hash(string input){
   return bitHash(input);
}

void HashC::insert(string word){
  unsigned long code = hash(word);
  unsigned long index = divCompression(code,tableSize);
  hashTable[index].insertAtHead(word);
  return;
}

ListItem<string>* HashC :: lookup(string word){
  unsigned long num = hash(word);
  unsigned long index = divCompression(num, tableSize);
  return hashTable[index].searchFor(word);

}

void HashC :: deleteWord(string word){
  unsigned long num = hash(word);
  unsigned long index = divCompression(num, tableSize);
  hashTable[index].deleteElement(word);
  return;
}

#endif