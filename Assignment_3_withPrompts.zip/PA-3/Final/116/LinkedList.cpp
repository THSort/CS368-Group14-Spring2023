#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
	return;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	ListItem<T>* temp1= otherLinkedList.head;
	if (temp1 == NULL)
	{
		head=NULL;
		return;
	}
	else
	{
		head=NULL;
		ListItem<T>* temp1= otherLinkedList.head; // pointing to the head of the first list
		
		while(temp1!=NULL)
		{
			insertAtTail(temp1->value);
			temp1=temp1->next; // update knowing that the next is not NULL
		}
	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	if (head==NULL)
	{
		return;
	}
	else
	{
		ListItem<T>* temp = head;
		while(temp->next!=NULL)
		{
			temp=temp->next; //get the last node
		}
		while(temp->prev!=NULL)
		{
			ListItem<T>* dlt=temp;
			temp=temp->prev;
			delete dlt;

		}
		//now only one node remains and that is the head
		delete head;
		head=NULL;
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if (head==NULL)
	{
		ListItem<T>* temp= new ListItem<T>(item);
		temp->next=NULL;
		temp->prev=NULL;
		temp->value= item;
		head=temp;
		return;
	}
	else
	{
		ListItem<T>* temp= new ListItem<T>(item);
		temp->next=head;
		temp->prev=NULL;
		temp->value= item;
		head=temp;
		temp=temp->next;
		temp->prev=head;
		return;
	}

	
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if (head==NULL)
	{
		ListItem<T>* temp= new ListItem<T>(item);	
		temp->next=NULL;
		temp->prev=NULL;
		temp->value= item;
		head=temp;
	}
	else
	{
		ListItem<T>* temp1 = head;
		while(temp1->next!=NULL)
		{
			temp1=temp1->next; //get the last node
		}
		ListItem<T>* temp= new ListItem<T>(item);	
		temp->next=NULL;
		temp->prev=temp1;
		temp->value= item;
		temp1->next=temp;
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	if (head==NULL)
	{
		ListItem<T>* temp= new ListItem<T>(toInsert);	
		temp->next=NULL;
		temp->prev=NULL;
		temp->value= toInsert;
		head=temp;
	}
	else
	{
		ListItem<T>* temp1 = head;
		while(temp1->next!=NULL && temp1->value!=afterWhat)
		{
			temp1=temp1->next; //get the last node
		}
		ListItem<T>* temp= new ListItem<T>(toInsert);	
		temp->next=temp1->next;
		temp->prev=temp1;
		temp->value= toInsert;
		temp1->next=temp;
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if (head==NULL)
	{
		ListItem<T>* temp= new ListItem<T>(item);	
		temp->next=NULL;
		temp->prev=NULL;
		temp->value= item;
		head=temp;
	}
	else
	{
		ListItem<T>* temp1=head;
		while(temp1->next!=NULL )
		{
			if (temp1->value>item)
			{
				break;
			}
			temp1=temp1->next;

		}
		if ((temp1->value)>item)
		{
			if (temp1->prev==NULL)
			{
				
				ListItem<T>* temp= new ListItem<T>(item);	
				temp->next=temp1;
				temp->prev=NULL;
				temp->value= item;
				head=temp;
			}
			else
			{
				temp1=temp1->prev;
				ListItem<T>* temp= new ListItem<T>(item);	
				temp->next=temp1->next;
				temp->prev=temp1;
				temp->value= item;
				temp1->next=temp;
				temp1=temp->next;
				temp1->prev=temp;
			}
		}
		else
		{

			ListItem<T>* temp= new ListItem<T>(item);	
			temp->next=temp1->next;
			temp->prev=temp1;
			temp->value= item;
			temp1->next=temp;
		}
		
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if (head==NULL)
	{
		return NULL;
	}
	else
	{
		ListItem<T>* temp=head;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		return temp;
	}
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	if (head==NULL)
	{
		return NULL;
	}
	else
	{
		ListItem<T>* temp = head;
		while(temp!=NULL && temp->value!=item)
		{
			temp=temp->next;
		}
		return temp;
	}

	
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if (head==NULL)
	{
		return;
	}
	else
	{
		ListItem<T>* temp1=head;
		while(temp1->next!=NULL )
		{
			if (temp1->value==item)
			{
				break;
			}
			temp1=temp1->next;

		}
		if ((temp1->value)==item)
		{
			if (temp1->prev==NULL)
			{
				
				deleteHead();
			}
			else
			{
				ListItem<T>* temp=temp1;
				temp1=temp1->prev;
			    temp1->next=temp->next;
			    if (temp->next!=NULL)
			    {
			    	(temp->next)->prev=temp1;
			    }
			    delete temp;
			}
		}
		else
		{
			return;
			
		}
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if (head==NULL)
	{
		return;
	}
	else
	{
		ListItem<T>* temp=head;
		head=head->next;
		if (head!=NULL)
		{
			head->prev=NULL;
		}
		delete temp;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	if (head==NULL)
	{
		return;
	}
	else
	{
		ListItem<T>* temp=head;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		ListItem<T>* temp1=temp->prev;
		if (temp1==NULL)
		{
			head=NULL;
		}
		else
		{
			temp1->next=NULL;
		}
		delete temp;
		return;
	}
}

template <class T>
int LinkedList<T>::length()
{
	if (head==NULL)
	{
		return 0;
	}
	else
	{
		ListItem<T>* temp= head;
		int counter=0;
		while(temp!=NULL)
		{
			temp=temp->next;
			counter++;
		}
		return counter;
	}
}

template <class T>
void LinkedList<T>::reverse()
{
	if (head==NULL) //head case
	{
		return;
	}
	else
	{
		ListItem<T>* temp= head; // save head pointer
		ListItem<T>* temp1=temp->next; //next node
		ListItem<T>* temp2 = temp->next;
		

		

		while(temp1!=NULL) //traverse it
		{
			
			temp->next= temp->prev;
			temp->prev= temp2;
			temp=temp1;
			temp1=temp1->next;
			temp2=temp1;
		}//this will reverse and stop as temp1 gets to null
		

		if (temp!=head)
		{
			temp->next= temp->prev;
			temp->prev=NULL;
			head=temp;
		}
		
	}
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	if (head==NULL)
	{
		return;
	}
	else
	{
		
		LinkedList<T> odd;
		LinkedList<T> even;
		ListItem<T>* odditer=NULL;
		ListItem<T>* eveniter=NULL;
		ListItem<T>* iter=head;
		while(iter!=NULL)
		{
			
			odd.insertAtTail(iter->value);
			deleteHead();
			iter=head;

			if (iter==NULL)
			{
				break;
			}
			even.insertAtTail(iter->value);
			deleteHead();
			iter=head;	
		}
		

		
		//now I have two list off odd and even
		head= odd.getHead(); // first list is odd numbers
		odd.head=NULL;
		odditer=head;
		
		while(odditer->next!=NULL)
		{
			odditer=odditer->next;
		}
		odditer->next=even.getHead(); // last itemm of odditer is now connected to even
		even.head=NULL;
		if (odditer->next==NULL)
		{
			return;
		}
			
		(odditer->next)->prev = odditer; //connection complete
		return;
		
	}

}

template <class T>
void LinkedList<T>::print()
{
	std::cout<<std::endl;
	ListItem<T>* temp=head;
	while(temp!=NULL)
	{
		std::cout<<temp->value<<", ";
		temp=temp->next;
	}
	std::cout<<std::endl;
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	
	if (head==NULL)
	{
		return false;
	}
	ListItem<T>* front=head;
	ListItem<T>* back=head;
	while(back->next!=NULL)
	{
		back=back->next;
	}

	bool pal=true; 
	
	while(front!=NULL && back!=NULL)
	{
		if (front->value != back->value)
		{
			return false;
		}
		front=front->next;
		back=back->prev;
	}

	return true;


}

#endif
