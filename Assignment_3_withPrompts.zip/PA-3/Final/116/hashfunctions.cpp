#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <cmath>



// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	
	unsigned long val=0;
	int len = value.size();
	val = value[0];
	for (int i = 1; i < len; ++i)
	{
		val= val + (value[i])*(pow(a,(i)));
	}
	return val;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	unsigned long res = 0;
	int len = value.size();
	res=value[0];
	for (int i = 1; i < len; ++i)
	{
		res ^= (res<<5) + (res>>2) + value[i];
	}
	return res;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return (hash%size);
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    unsigned long res = (m*hash) + a;
    res = res % size;

    return res;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.