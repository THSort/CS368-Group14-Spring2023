#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    block** temp = new block*[tableSize];
    for (int i = 0; i < tableSize; ++i)
    {
    	temp[i]= NULL;
    	
    }
    hashTable = temp;
    count=0;
}

HashD::~HashD(){
	 for (int i = 0; i < tableSize; ++i)
    {
    	delete hashTable[i];
    }
    delete [] hashTable;
}

unsigned long HashD :: hash1(string value){
    return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return bitHash(value);
}

void HashD::resizeTable(){
    long old_size = tableSize;
    if (count == (tableSize*0.7)) // in insert
    {
        tableSize *= 25;
        //cout<<"resize()"<<endl;

    }
    else if(count == (tableSize/4)) // in delete
    {
        tableSize = (3*tableSize / 4);
    }
    else
    {
        return;
    }

    block** temp = new block*[tableSize]; //make temp table
    for (int i = 0; i < tableSize; ++i)
    {
        temp[i]= NULL;
        
    }
    block** temp2 = hashTable; //old table ---------------
    
    
    hashTable = temp; //new table point 
    
    count = 0;

    for (int i = 0; i < old_size; ++i) // copy it into new table
    {
        if (temp2[i]==NULL)
        {
            continue;
        }
        if (temp2[i]->value=="deleted" && temp2[i]->key==0)
        {
            continue;
        }
        insert(temp2[i]->value);
    }
    

    for (int i = 0; i < old_size; ++i) //delete old table
    {
        delete temp2[i];
    }
    delete [] temp2;
    //cout<<"resize()"<<endl;
    return;
}

void HashD::insert(string value){
    if (count==(tableSize*0.7))
    {
    	//cout<<"resize"<<endl;

    	//cout<<"resize";
    	resizeTable();

    	
    }
    unsigned long code = hash1(value);
    unsigned long index1 = madCompression(code,tableSize); //index
    unsigned long code2=0;
    //cout<<"insert value: "<<value<<" index:"<<index<<endl;
    // if (value == "rangolis")
    // {
    // 	cout<<index<<"insert"<<endl;
    // }
    unsigned long index2=0;
    unsigned long index = index1;
    count++; //adding now
    long num= 1;
    bool x=0;
   
    while(1)
    {
    	if (hashTable[index] ==NULL) //entry
	    {
	    	hashTable[index] = new block(code, value);
	    	return;
	    }
	    if (hashTable[index]->value==value) //duplicate
	    {
	    	return;
	    }
	    if (hashTable[index]->value=="deleted" && hashTable[index]->key==0)
	    {
	    	hashTable[index]->value= value;
	    	hashTable[index]->key = code;
	    	
	    	return;
	    }
        if (x==0)
        {
            code2 = hash2(value);
            index2 = 57 - (code2 % 57);
            x=1;
            
        }
        index= index1 + (num*index2);
        code+= code2;
	  
	    num++;
	    //conflict++;
	    if (index >= (tableSize)) //prevent overflow
	    {
	    	index= index % tableSize;

	    }

    }
}

void HashD::deleteWord(string value){
	
   while(1)
    {
        block* temp = lookup(value);
        if (temp==NULL)
        {
            return;
        }
        temp->key=0;
        temp->value="deleted";
        count--;
        if (count == (tableSize/4))
        {
            resizeTable();
        }
    }


    return;
}

block* HashD::lookup(string value){
    unsigned long code = hash1(value);
    unsigned long index1 = madCompression(code,tableSize); //index
    unsigned long code2=0;
    //cout<<"insert value: "<<value<<" index:"<<index<<endl;
    // if (value == "rangolis")
    // {
    //  cout<<index<<"insert"<<endl;
    // }
    unsigned long index2=0;
    unsigned long index = index1;
    long num= 1;
    bool x=0;
    while(1) //in for loop to prevent it going in circles
    {
        if (hashTable[index] ==NULL)
        {
            //cout<<"val: "<<value<<" ind:"<<index<<endl;
            return NULL;
        }
        if (hashTable[index]->value ==value)
        {
            if (hashTable[index]->value=="deleted" && hashTable[index]->key==0)
            {
                
            }
            else
            {
                return hashTable[index];
            }
            
            
        }
        if (x==0)
        {
            code2 = hash2(value);
            index2 = 57- (code2%57);
            x=1;
            
        }
        index= index1 + (num*index2);
        
      
        num++;
        
        if (index >= tableSize) //prevent overflow
        {
            index= index% tableSize;
        }

    }
}

void HashD::print()
{
    cout<<"no. of items: "<<count<<" tableSize: "<<tableSize<<endl;
    ofstream myfile;
    myfile.open ("example.txt");
    for (int i = 0; i < tableSize; ++i)
    {
        if (hashTable[i]==NULL)
        {
            myfile<<"\n";
            continue;
        }
        if (hashTable[i]->value=="")
        {
            myfile<<"\n";
            continue;
        }
        if (hashTable[i]->value=="deleted" && hashTable[i]->key==0)
        {
            myfile<<"\n";
            continue;
        }
        myfile << hashTable[i]->value <<" "<<i<< "\n";
    }
    //myfile << "Writing this to a file.\n";
    
    myfile.close();
}

#endif