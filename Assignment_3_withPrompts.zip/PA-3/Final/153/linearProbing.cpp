#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
	hashTable = new block*[tableSize]();
	// for(int i = 0; i < tableSize; i++)
	// 	hashTable[i] = NULL;
	count = 0;
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
    return bitHash(value);
}

void HashL::resizeTable(){
	long oldSize = tableSize;
	long a = tableSize/count;
	if(a < 3)
		tableSize *=2;
	if(a > 5)
		tableSize /=2;
	count = 0;
	block** newTable = new block*[tableSize]();
	// for(int i = 0; i < tableSize; i++){
	// 	newTable[i] = NULL;
	// }
	block** newTable1 = hashTable;
	hashTable = newTable;
	for(int i = 0; i < oldSize; i++){
		if(newTable1[i] != NULL && newTable1[i]->value != "-1"){
			insert(newTable1[i]->value);
		}
	}
	delete[] newTable1;
	return;
}

void HashL::insert(string value){
	unsigned long key = hash(value);
	unsigned long index = divCompression(key, tableSize);
	if(hashTable[index] == NULL){
		hashTable[index] = new block(key, value);
	}
	else{
		while(1){
			if(hashTable[index] == NULL){
				hashTable[index] = new block(key, value);
				break;
			}
			else if(hashTable[index]->value == "-1"){
				hashTable[index]->value = value;
				break;
			}
			index = ++index % tableSize;
		}
	}
	count++;
	long a = tableSize/count;
	if(a < 3)
		resizeTable();
    return;
}

void HashL::deleteWord(string value){
	block* temp = lookup(value);
	if(temp == NULL)
		return;
	temp->value = "-1";
	count--;
	float a = tableSize/count;
	if(a > 5 && tableSize > 2000)
		resizeTable();
    return;
}

block* HashL::lookup(string value){
    unsigned long key = hash(value);
	unsigned long index = divCompression(key, tableSize);
	while(1){
		if(hashTable[index] == NULL)
			return NULL;
		else if(hashTable[index]->key == key && hashTable[index]->value == value)
			return hashTable[index];
		index = ++index % tableSize;
	}
}
#endif
