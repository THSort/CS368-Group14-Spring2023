#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize]();
	// for(int i = 0; i < tableSize; i++)
	// 	hashTable[i] = NULL;
	count = 0;
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){
    return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return polyHash(value);
}

void HashD::resizeTable(){
	long oldSize = tableSize;
	long a = tableSize/count;
	if(a < 5)
		tableSize *=2;
	if(a > 5)
		tableSize /=2;
	count = 0;
	block** newTable = new block*[tableSize]();
	// for(int i = 0; i < tableSize; i++){
	// 	newTable[i] = NULL;
	// }
	block** newTable1 = hashTable;
	hashTable = newTable;
	for(int i = 0; i < oldSize; i++){
		if(newTable1[i] != NULL && newTable1[i]->value != "-1"){
			insert(newTable1[i]->value);
		}
	}
	delete[] newTable1;
	return;
}

void HashD::insert(string value){
	unsigned long key = hash1(value);
	unsigned long index1 = divCompression(key, tableSize);
	unsigned long index2 = madCompression(key, tableSize);
	if(hashTable[index1] == NULL){
		hashTable[index1] = new block(key, value);
	}
	else{
		int i = 0;
		unsigned long index = index1;
		while(1){
			if(hashTable[index] == NULL){
				hashTable[index] = new block(key, value);
				break;
			}
			else if(hashTable[index]->value == "-1"){
				hashTable[index]->value = value;
				break;
			}
			index = (index1 + (i*index2))%tableSize;
			i++;
		}
	}
	count++;
	long a = tableSize/count;
	if(a < 5)
		resizeTable();
    return;
}

void HashD::deleteWord(string value){
	block* temp = lookup(value);
	if(temp == NULL)
		return;
	temp->value = "-1";
	temp->key = 0;
	count--;
	float a = tableSize/count;
	if(a > 100 && tableSize > 2000)
		resizeTable();
    return;
}

block* HashD::lookup(string value){
    unsigned long key = hash1(value);
	unsigned long index1 = divCompression(key, tableSize);
	unsigned long index2 = madCompression(key, tableSize);
	int i = 0;
	unsigned long index = index1;
	while(1){
		if(hashTable[index] == NULL)
			return NULL;
		else if(hashTable[index]->key == key && hashTable[index]->value == value)
			return hashTable[index];
		index = (index1 + (i*index2))%tableSize;
		i++;
	}
}

#endif