#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"


// #include <iostream>
// using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	if(otherLinkedList.head == NULL){
		head = NULL;
	}
	else{
		ListItem<T> *traverseListOld = otherLinkedList.head;
		ListItem<T> *dummy = new ListItem<T>(traverseListOld->value);
		head = dummy;
		ListItem<T> *traverseList = head;
		ListItem<T> *p = dummy;
		traverseListOld = traverseListOld->next;
		while(traverseListOld != NULL){
			dummy = new ListItem<T>(traverseListOld->value);
			traverseList->next = dummy;
			dummy->prev = p;
			p = dummy;
			traverseList = traverseList->next;
			traverseListOld = traverseListOld->next;
		}
	}
	
}

template <class T>
LinkedList<T>::~LinkedList()
{
	ListItem<T> *temp = head;
	ListItem<T>	*dummy = head;
	while(temp != NULL){
		temp = temp->next;
		delete dummy;
		dummy = temp;
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> *temp = new ListItem<T>(item);
	if(head == NULL){
		head = temp;
	}
	else{
		head->prev = temp;
		temp->next = head;
		head = temp;
	}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem<T> *temp = new ListItem<T>(item);
	if(head == NULL){
		head = temp;
	}
	else{
		ListItem<T> *traverseList = head;
		while(traverseList != NULL){
			if (traverseList->next == NULL){
				traverseList->next = temp;
				temp->prev = traverseList;
				return;
			}
			traverseList = traverseList->next;
		}
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T> *temp = new ListItem<T>(toInsert);
	ListItem<T> *traverseList = searchFor(afterWhat);
	if (traverseList == NULL)
		return;
	else{
		if(traverseList->next == NULL)
			insertAtTail(toInsert);
		else{
			temp->next = traverseList->next;
			traverseList->next->prev = temp;
			traverseList->next = temp;
			temp->prev = traverseList;
			return;
		}
	}
	// ListItem<T> *temp = new ListItem<T>(toInsert);
	// if(head == NULL)
	// 	return;
	// else{
	// 	bool found = false;
	// 	ListItem<T> *traverseList = head;
	// 	while((!found) && (traverseList != NULL)){
	// 		if(traverseList->value == afterWhat){
	// 			found = true;
	// 			if(traverseList->next == NULL){
	// 				traverseList->next = temp;
	// 				temp->prev = traverseList;
	// 				return;
	// 			}
	// 			else{
	// 				temp->next = traverseList->next;
	// 				traverseList->next->prev = temp;
	// 				traverseList->next = temp;
	// 				temp->prev = traverseList;
	// 				return;
	// 			}
	// 		}
	// 		else if((traverseList->next == NULL) && (!found)){
	// 			return;
	// 		}
	// 		traverseList = traverseList->next;
	// 	}
	// }
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem<T> *traverseList = head;
	if((traverseList == NULL) || (traverseList->value >= item)){
		insertAtHead(item);
		return;
	}
	else{
		ListItem<T> *temp = new ListItem<T>(item);
		while(traverseList->next != NULL){
			if((traverseList->value <= item) && (traverseList->next->value >= item)){
				temp->next = traverseList->next;
				traverseList->next->prev = temp;
				traverseList->next = temp;
				temp->prev = traverseList;
				return;
			}
			traverseList = traverseList->next;
		}
		if (traverseList->next == NULL){
			traverseList->next = temp;
			temp->prev = traverseList;
			return;
		}
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if(head == NULL)
		return NULL;
	else{
		ListItem<T> *traverseList = head;
		while(traverseList != NULL){
			if(traverseList->next == NULL)
				return traverseList;
			traverseList = traverseList->next;
		}
	}
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T>* temp = head;
    while(temp){
        if (temp->value == item)
            return temp;
        else
            temp = temp->next;
    }
    return NULL;
	// if(head == NULL)
	// 	return NULL;
	// else{
	// 	bool found = false;
	// 	ListItem<T> *traverseList = head;
	// 	while((!found) && (traverseList != NULL)){
	// 		if(traverseList->value == item){
	// 			found = true;
	// 			return traverseList;
	// 		}
	// 		else if((traverseList->next == NULL) && (!found)){
	// 			return NULL;
	// 		}
	// 		traverseList = traverseList->next;
	// 	}
	// }
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T>* temp = head;
    if(temp->value == item)    {
        head = temp->next;
        // delete temp;
        return;
    }
    while(temp->next)    {
        if (temp->next->value == item)    {
            temp->next=temp->next->next;
            if(temp->next){
            	temp->next->prev=temp->next;
            }
            return;

        }
        else    {
            temp = temp->next;
        }
    }
    // }
    // if(temp)     {
    //     ListItem<T> *dummy = temp->prev;
    //     if(temp->next)  {
    //         dummy->next = temp->next;
    //         dummy = temp->next;
    //         dummy->prev = temp->prev;
    //     }    
    //     else    {
    //         temp->prev->next = NULL; 
    //     }
    //     // delete temp;
    // }
	// ListItem<T> *traverseList = searchFor(item);
	// if (traverseList == NULL)
	// 	return;
	// else if(traverseList->prev == NULL){
	// 	deleteHead();
	// }
	// else if(traverseList->next == NULL){
	// 	deleteTail();
	// }
	// else{
	// 	 ListItem<T> *dummy = traverseList;
	// 	 traverseList = traverseList->prev;
	// 	 traverseList->next = traverseList->next->next;
	// 	 dummy->next->prev = traverseList;
	// 	 delete dummy;
	// 	 return;
	// }
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if(head == NULL)
		return;
	else if(head->next == NULL){
		delete head;
		head = NULL;
		return;
	}
	else{
		head = head->next;
		delete head->prev;
		head->prev = NULL;
		return;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T> *traverseList = head;
	if (traverseList == NULL)
		return;
	else if(traverseList->next == NULL){
		delete traverseList;
		head = NULL;
	}
	else{
		while(traverseList != NULL){
			if(traverseList->next == NULL){
				traverseList = traverseList->prev;
				delete traverseList->next;
				traverseList->next = NULL;
			}
			traverseList = traverseList->next;
		}
	}
}

template <class T>
int LinkedList<T>::length()
{
	int len = 0;
	ListItem<T> *traverseList = head;
	while(traverseList != NULL){
		len++;
		traverseList = traverseList->next;
	}
	return len;
}

template <class T>
void LinkedList<T>::reverse()
{
	if(head == NULL)
		return;
	else{
		ListItem<T> *traverseList = head;
		ListItem<T> *p = traverseList;
		ListItem<T> *here = NULL;
		while(traverseList != NULL){
			traverseList = traverseList->next;
			here = p->prev;
			p->prev = p->next;
			p->next = here;
			p = traverseList;
		}
		head = here->prev;
	}
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	
	ListItem<T> *traverseList = head;
	
	int l = length();
	for(int i = 1; i <= l; i++){
		if(i % 2 == 0){
	
			insertAtTail(traverseList->value);
			deleteElement(traverseList->value);
		}
		traverseList = traverseList->next;
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	if (head == NULL)
		return 0;
	else{

		ListItem<T> *traverseList = head;
		int length = this->length();
		T *arr = new T [length];
		int i = 0;
		for ( ; i < length; ++i){
			arr[i] = traverseList->value;
			traverseList = traverseList->next;
		}
		i--;
		traverseList = head;
		while(traverseList != NULL){
			if(arr[i] != traverseList->value)
				return 0;
			else{
				traverseList = traverseList->next;
				i--;
			}
		}
		if (traverseList == NULL)
			return 1;
	}
}


// template <class T>
// void LinkedList<T>::print()
// {
// 	ListItem<T> *temp = head;
// 	while (temp != NULL){
// 		cout << temp->value << endl;
// 		temp = temp ->next;
// 	}

// }

#endif


// int main() {
// 	LinkedList<int> l;
// 	l.insertAtTail(1);
// 	l.insertAtTail(2);
// 	l.insertAtTail(3);
// 	l.insertAtTail(4);
// 	l.insertAtTail(5);
// 	l.insertAtTail(6);
// 	l.insertAtTail(7);
// 	l.insertAtTail(8);
// 	l.insertAtTail(9);
// 	l.insertAtTail(10);
// 	l.insertAtTail(11);
// 	l.insertAtHead(9);
// 	l.insertAtHead(8);
// 	l.insertAtHead(7);
// 	l.insertAtHead(6);
// 	l.insertAtHead(5);
// 	l.insertAtHead(4);
// 	l.insertAtHead(3);
// 	l.insertSorted(1);
// 	l.insertAtHead(2);
// 	l.insertAtTail(10);
// 	l.insertAtTail(11);
// 	// l.print();
// 	// l.reverse();
// 	// l.isPalindrome();
// 	l.parityArrangement();
// 	cout << endl;
// 	l.print();
// 	return 0;
// }