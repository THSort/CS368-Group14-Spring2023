#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
	tableSize = size;
	hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC()
{
	for(int i=0;i<tableSize;i++)
	{
		for(int j=0;j< hashTable[i].length();i++)
			{
				hashTable[i].deleteHead();
			}
	}
	delete[]hashTable;
}

unsigned long HashC :: hash(string input)
{
	unsigned long hash_is = divCompression(polyHash(input,5),tableSize);
    return hash_is;
}

void HashC::insert(string word)
{
	unsigned long what = hash(word);
    hashTable[what].insertAtHead(word);
	//insert at head
    return;
}

ListItem<string>* HashC :: lookup(string word)
{

  int what = hash(word);
  return hashTable[what].searchFor(word);
}

void HashC :: deleteWord(string word)
{
    int what = hash(word);
    hashTable[what].deleteElement(word);
 	return;

}

#endif
