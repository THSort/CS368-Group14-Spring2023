#include <iostream>
#include "hashfunctions.cpp"
#include <fstream>
#include <vector>

using namespace std;

int main(){
    polyHash("Sab",5);
    cout<<bitHash("sa");
    cout<<"this"<<divCompression(bitHash("A"),1000);
    cout<<madCompression(polyHash("Sab",5),5,2,3);
    return 0;
}