#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <cmath>
#include <iostream>
// this takes in a string and returns a 64bit hash.
using namespace std;

unsigned long polyHash(std::string value,int a)
{
	int len = value.length();
	unsigned long code =0;
	for(int i = 0;i< len;i++)
	{
		code += pow(a, len-1-i)* (unsigned int)value[i];
	}
	return code;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	unsigned long bitwise_hash =0;
	for(int i=0;i<value.length();i++)
	{
		bitwise_hash ^= (bitwise_hash<<5) + (bitwise_hash>>2) + (unsigned int)value[i];
	}
	return bitwise_hash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size)
{
	unsigned long compressed =0;
	if(hash <1)
	{
		hash*=-1;
	}
	compressed = hash%size;
    return compressed;
}

// multiplication addition and division compression.
unsigned long madCompression(unsigned long hash,long size,int m,int a)
{

    unsigned long madcompressed =0;
    hash = hash*m + a;
    if(hash<0)
    {
    	hash = hash*-1;
    }
    madcompressed = hash%size;
    return madcompressed;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.

