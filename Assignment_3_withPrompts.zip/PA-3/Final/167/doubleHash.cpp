#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count=0;
    hashTable =new block*[tableSize]();
}

HashD::~HashD(){
    for(int i=0;i<tableSize;i++)
    {
        hashTable[i]=nullptr;
    }
    delete [] hashTable;
}

unsigned long HashD :: hash1(string value){

    unsigned long hash_is = bitHash(value);
    return hash_is;
}

unsigned long HashD :: hash2(string value){

    unsigned long hash_2 =  polyHash(value,10);
    return hash_2;
}

void HashD::resizeTable(){

    long tableSize2 = tableSize;
    block** hashTable2 = new block*[tableSize2];
    for(int i =0;i<tableSize2;i++)
    {
        hashTable2[i]=hashTable[i];
    }
    delete[]hashTable;

    tableSize = 2*tableSize;
    hashTable = new block*[tableSize]();
    for(int i=0;i<tableSize2;i++)
    {
        hashTable[i]=hashTable2[i];
    }

    delete[]hashTable2;
    return;
}

void HashD::insert(string value){
    collide=0;
    int where = divCompression((hash1(value))+(collide*(hash2(value))),tableSize);
    if(count>(0.7*tableSize))
    {
        resizeTable();
	}
	if(hashTable[where]==nullptr)
    {
        block* to_ins = new block(where,value);
        hashTable[where]= to_ins;
        count++;
    }
     else
    {
        while(hashTable[where]!=nullptr)
        {
            collide++;
            where = divCompression((hash1(value))+(collide*(hash2(value))),tableSize);
        }
        block* to_ins = new block(where,value);
        hashTable[where]= to_ins;
        count++;
    }
    return;
}

void HashD::deleteWord(string value){

   int tsk = collide;
   while(tsk!=-1)
   {
       int where = divCompression((hash1(value))+(collide*(hash2(value))),tableSize);
        if(hashTable[where] != nullptr && hashTable[where]->value==value)
        {
            hashTable[where]=nullptr;
            return;
        }
        else
        {
            tsk--;
        }
   }
    return;
}

block* HashD::lookup(string value){

    block* to_return=NULL;
    int tsk = collide;
    while(tsk!=-1)
    {
       int where = divCompression((hash1(value))+(collide*(hash2(value))),tableSize);
        if(hashTable[where] != nullptr && hashTable[where]->value==value)
        {
            to_return =hashTable[where];
            return to_return;
        }
        else
        {
            tsk--;
        }
   }
   return to_return;
}

#endif
