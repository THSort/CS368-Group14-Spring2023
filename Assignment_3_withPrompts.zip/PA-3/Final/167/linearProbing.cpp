#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"



HashL::HashL()
{
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize]();
}

HashL::~HashL()
{
    for(int i=0;i<tableSize;i++)
    {
        hashTable[i]=nullptr;
    }
    delete [] hashTable;

}

unsigned long HashL :: hash(string value)
{

  unsigned long hash_is = divCompression(polyHash(value,5),tableSize);
  return hash_is;
}

void HashL::resizeTable()
{
    long tableSize2 = tableSize;
    block** hashTable2 = new block*[tableSize2];
    for(int i =0;i<tableSize2;i++)
    {
        hashTable2[i]=hashTable[i];
    }
    delete[]hashTable;

    tableSize = 2*tableSize;
    hashTable = new block*[tableSize]();
    for(int i=0;i<tableSize2;i++)
    {
        hashTable[i]=hashTable2[i];
    }

    delete[]hashTable2;
    return;
}

void HashL::insert(string value)
{
	int where = hash(value);
	if(count>0.6*tableSize)
    {
        resizeTable();
	}

	if(hashTable[where]==nullptr)
    {
        block* to_ins = new block(where,value);
        hashTable[where]= to_ins;
        count++;
    }
    else
    {
        while(hashTable[where]!=nullptr)
        {
            where++;
            if(where == tableSize)
            {
                where=0;
            }
        }
        if(where<tableSize)
        {
            block* to_ins = new block(where,value);
            hashTable[where]= to_ins;
            count++;
        }
    }
    return;
}

void HashL::deleteWord(string value)
{
   int where = hash(value);
    if(hashTable[where] != nullptr && hashTable[where]->value==value)
    {
        if(value == "Edessene's")
        {
            cout<<"Imma delete this poop"<<endl;
        }
        hashTable[where] = nullptr;
        return;
    }
    else
    {
        for(int j=where;j<tableSize;j++)
        {
            if(hashTable[j] != nullptr && hashTable[j]->value==value)
            {
                hashTable[j] = nullptr;
                return;
            }
        }
        for(int j= 0;j<where;j++)
        {
            if(hashTable[j] != nullptr && hashTable[j]->value==value)
            {
                hashTable[j] = nullptr;
                return;
            }
        }
    }
    cout << "Could not find: "<<value<<endl;
    return;
}

block* HashL::lookup(string value)
{
    block* to_return=NULL;
    int where = hash(value);
    if(hashTable[where] != nullptr && hashTable[where]->value==value)
    {
        to_return= hashTable[where];
        return to_return;
    }
    else
    {
        for(int j=where;j<tableSize;j++)
        {
            if(hashTable[j] != nullptr && hashTable[j]->value==value)
            {
                to_return= hashTable[j];
                return to_return;
            }
        }
        for(int j= 0;j<where;j++)
        {
            if(hashTable[j] != nullptr && hashTable[j]->value==value)
            {
                to_return= hashTable[j];
                return to_return;
            }
        }
    }
    return to_return;

}
#endif
