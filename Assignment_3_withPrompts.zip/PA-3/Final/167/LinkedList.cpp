#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include <iostream>
#include "LinkedList.h"

using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	head=NULL;
	ListItem<T>* temp;
	temp = otherLinkedList.head;
	while(temp!=NULL)
	{
		insertAtTail(temp->value);
		temp = temp->next;
	}

}

template <class T>
LinkedList<T>::~LinkedList()
{

	ListItem<T>* temp;
	temp= head;
	while(head!=NULL)
	{
		temp=head->next;
		delete head;
		head=temp;
	}

	head=NULL;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T>* temp = new ListItem<T>(item);
	temp -> next = head;
	if(head!=NULL)
	{
		head -> prev = temp;
	}
	head = temp;
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem<T>* temp = new ListItem<T>(item);
	temp -> next = NULL;
	temp ->prev = getTail();
	if(head==NULL)
	{
		head=temp;
	}
	else if(head!=NULL)
	{
		getTail()->next = temp;
	}

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T>* aw = head;
	if(head== NULL)
	{
		insertAtHead(toInsert);
	}
	else
	{
		while(aw->value != afterWhat && aw->next!=NULL)
		{
			aw= aw->next;
		}
		if(aw->value == afterWhat)
		{
			ListItem<T>* ti = new ListItem<T>(toInsert);

			if(aw->next == NULL)
			{
				ti->next=NULL;
				ti->prev = aw;

				aw->next = ti;
			}
			else
			{

				ti ->next = aw ->next;
				aw ->next = ti;
				ti-> prev = aw;
				ti->next->prev = ti;
			}
		}
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem<T>* after_this = getHead();
	if(after_this==NULL)
	{
		insertAtHead(item);
	}
	else if(after_this->next == NULL)
	{
		if(item < after_this->value)
		{
			insertAtHead(item);
		}

		else if(item >= after_this->value)
		{
			insertAtTail(item);
		}
	}
	else
	{
		after_this = getHead();
		while(after_this->next!=NULL && (after_this->next->value) < item)
		{
			after_this = after_this ->next;

		}
		if(after_this->next==NULL)
		{
			insertAtTail(item);
		}
		else if(after_this->next!=NULL)
		{
			//insertAfter(item,(after_this->value));

			ListItem<T>* ti = new ListItem<T>(item);

			if(after_this->next == NULL)
			{
				ti->next=NULL;
				ti->prev = after_this;

				after_this->next = ti;
			}
			else
			{

				ti ->next = after_this ->next;
				after_this ->next = ti;
				ti-> prev = after_this;
				ti->next->prev = ti;
			}

		}


	}

}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;

}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if(head==NULL)
	{
		return NULL;
	}
	else
	{
		ListItem<T>* tail_pointer = head;
		while(tail_pointer->next != NULL)
		{
			tail_pointer = tail_pointer ->next;
		}
		return tail_pointer;
	}

}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T>* temp= head;
	if(temp==NULL)
	{
		return NULL;
	}
	else
	{
		while(temp->next!=NULL)
		{
			if(temp->value==item)
			{
				return temp;
				break;
			}
			temp = temp->next;
		}
		if(temp-> value == item)
        {
            return temp;
        }
            return NULL;
	}
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T>* del_this;
	del_this = searchFor(item);
	if(del_this == head)
	{
		deleteHead();
	}
	else if (del_this->next==NULL)
	{
		deleteTail();
	}
	else
	{
		ListItem<T>* temp;
		temp = del_this ->prev;
		temp -> next = del_this -> next;
		del_this ->next->prev = del_this ->prev;
		delete del_this;
	}

}

template <class T>
void LinkedList<T>::deleteHead()
{
	if( head!=NULL)
	{
		ListItem<T>* temp = head;
		if(temp ->next == NULL)
		{
			//incase of 1 node
			head = NULL;
		}
		else
		{
			head = head->next;
			head -> prev = NULL;
		}

		delete temp;
	}

}

template <class T>
void LinkedList<T>::deleteTail()
{
	if( head!=NULL)
	{
		ListItem<T>* temp = getTail();
		if(temp ->prev == NULL)
		{
			//if head is equal to tail
			head = NULL;
		}
		else
		{
			ListItem<T>* before_tail = temp->prev;
			before_tail ->next = NULL;
		}

		delete temp;
	}


}

template <class T>
int LinkedList<T>::length()
{
	int count=0;
	ListItem<T>* temp = head;
	while(temp!=NULL)
	{
		temp = temp->next;
		count++;
	}
	return count;
}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T>* start;
	start = head;
	ListItem<T> *temp ;

	while(start->next!=NULL)
	{
		temp = start->next;
		start->next=start->prev;
		start->prev = temp;
		start = temp;
	}
	temp = start->next;
	start->next=start->prev;
	start->prev = temp;

	head=start;
}

template <class T>
void LinkedList<T>::parityArrangement()
{

	ListItem<T>* even=head;
	for(int i =0;i<length()/2;i++)
	{
		ListItem<T>* temp;
		temp= even->next;
		insertAtTail(temp->value);
		even -> next = temp ->next;
		even = even->next;
		even ->prev = temp ->prev;
		delete temp;


	}

}

template <class T>
bool LinkedList<T>::  isPalindrome()
{
	ListItem<T>* start = head;
	ListItem<T>* fin = getTail();
	if(length()==0)
	{
		return false;
	}
	else if(length()==1)
	{
		return true;
	}
	else if(length()%2==1)
	//if odd number
	{
		while(start!=fin)
		{
			if(start->value != fin->value)
			{
				return 0;
				break;
			}
			else if(start->value == fin ->value)
			{
				start = start->next;
				fin = fin -> prev;
			}
		}
		return 1;
	}
	else if(length()%2 ==0)
	{
		//even number of nodes
		while(start->next != fin)
		{
			if(start->value != fin->value)
			{
				return 0;
				break;
			}
			else if(start->value == fin ->value)
			{
				start = start->next;
				fin = fin -> prev;
			}
		}
		return 1;

		}

}




#endif
