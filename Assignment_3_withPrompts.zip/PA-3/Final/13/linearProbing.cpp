#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"
#include <cstdlib>

HashL::HashL()
{
    tableSize = 1000; // you cant change this
    hashTable=new block*[tableSize];
    for (int i=0;i<tableSize;i++)
    {
    	hashTable[i]=NULL;
    }
    count=0;
}

HashL::~HashL()
{
    delete hashTable;
}

unsigned long HashL :: hash(string value)
{
    unsigned long hash=bitHash(value);
 	return hash;
}
void HashL::resizeTable()
{
	if (count/tableSize>=0.8)
	{
	   long oldTsize=tableSize;
	   tableSize=tableSize*10;
	   block** hashTable2=new block*[tableSize];
	   block** oldtable=hashTable;
	   hashTable=hashTable2;
	   count=0;
	 	for (int i=0;i<tableSize;i++)
	    {
	    	hashTable[i]=NULL;
	    }

	   	for (int i=0;i<(oldTsize);i++)
	   	{	
	   		if (oldtable[i]!=NULL || hashTable[i]->value!="~~" )
	   		{
	   			
	   			insert(oldtable[i]->value);
	   			
	   		}
	   	}
	}
	if (count/tableSize<=0.2&&count/tableSize>1000)
	{
	   long oldTsize=tableSize;
	   tableSize=tableSize/2;
	   block** hashTable2=new block*[tableSize];
	   block** oldtable=hashTable;
	   hashTable=hashTable2;
	   count=0;
	 	for (int i=0;i<tableSize;i++)
	    {
	    	hashTable[i]=NULL;
	    }

	   	for (int i=0;i<(oldTsize);i++)
	   	{	
	   		if (oldtable[i]!=NULL || hashTable[i]->value!="~~" )
	   		{
	   			
	   			insert(oldtable[i]->value);
	   			
	   		}
	   	}
	}
}	

	

void HashL::insert(string value)
{
   if(count/tableSize>=0.80)
   	{
   		resizeTable();   		
   	}
	unsigned long h=hash(value);
	int index=divCompression(h,tableSize);
	block* a=new block(h,value);
	if(hashTable[index]!=NULL )
	{
		int i=index;
		
	 	while (hashTable[i]!=NULL  )
	 		{
	 			
	 			i++;
	 			if(i>tableSize-1)
	 			{
	 				i=0;
	 			}
	 			
	 		}

	 	hashTable[i]=a;
	 	count++;
	 	


	 }
	 else if(hashTable[index]==NULL )
	 {
	 	hashTable[index]=a;
	 	count++;
	 	
	 }
	

}

void HashL::deleteWord(string value)
{
   if(count/tableSize<=0.2&&count/tableSize>1000)
	{
		resizeTable();
	}
	unsigned long h=hash(value);
	int index=divCompression(h,tableSize);
	 if(hashTable[index]->value!=value)
	{
		int i=index;
		while (hashTable[i]->value!=value)
	 			{
	 				i++;
	 				if(i>tableSize-1)
	 				{
	 					i=0;
	 				}	 				
 				}

	 	hashTable[i]->value="~~";
	 	count--;
	}
	else if (hashTable[index]->value==value)
	{
		hashTable[index]->value="~~";
		count--;
	}
	
}
block* HashL::lookup(string value)
{
    unsigned long h=hash(value);
	int index=divCompression(h,tableSize);
	block* temp=NULL;
	if(hashTable[index]==NULL)
	{	
		return NULL;
	}
	else if(hashTable[index]->value!=value)
	{	
		int i=index;
		
		while (hashTable[i]->value!=value )
	 			{
	 				i++;
	 				
	 				if(i>tableSize-1)
	 				{	
	 					i=0;
	 				}
	 				
	 				if(hashTable[i]==NULL)
	 				{
	 					
	 					return NULL;
	 				}
	 				
	 			}
	 	
	 	temp=hashTable[i];
	 	return temp;
	}
	else if (hashTable[index]->value==value)
	{	
		temp=hashTable[index];
		return temp;
	}
	
}
void HashL::print()
{
	for (int i=0;i<tableSize;i++)
	{
		if(hashTable[i]!=NULL)
		{
			cout << hashTable[i]->value<<endl;
		}	
	}
}
#endif
/*int main()
{
	HashL a;
	a.insert("hello");
	a.insert("hi");
	a.insert("wtf");
	a.insert("work");
	a.insert("jesus");
	a.insert("hoho");
	a.insert("niggs");
	a.print();
	cout<<"_____"<<endl;
	a.deleteWord("hello");
	a.deleteWord("hi");
	a.deleteWord("jes");
	a.deleteWord("hoho");
	a.deleteWord("wtf");
	a.deleteWord("niggs");
	a.deleteWord("hi");
	a.deleteWord("jesus");
	a.deleteWord("work");
	block* g=a.lookup("hello");
	a.lookup("hello");
	//if(g==NULL)
		//cout<<"yes"<<endl;
	a.print();
	//cout <<a.tableSize<<endl;
}*/
