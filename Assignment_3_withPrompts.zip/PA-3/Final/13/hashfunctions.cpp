#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <cmath>
#include <iostream>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a )
{
		unsigned long h=0;
		for (int i=0;i<value.length();i++)
		{
			h+=value[i]*pow(a,value.length()-(i+1));
		} 
	return h;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value)
{
	unsigned long h=0;
	for (int i=0;i<value.length();i++)
	{
		h^=(h<<5)+(h>>27)+value[i];
	}

	return h;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size)
{
    int ind=hash%size;
    return ind;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637)
{
	int ind= ((m*hash+a)%37)%size;
    return ind;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
