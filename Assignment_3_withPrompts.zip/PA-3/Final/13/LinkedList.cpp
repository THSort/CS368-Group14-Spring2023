#ifndef __LIST_CPP
#define __LIST_CPP
#include <iostream>
#include <cstdlib>
#include "LinkedList.h"
using namespace std;
template <class T>
LinkedList<T>::LinkedList()

{
	head=NULL;

}

template <class T>
LinkedList<T>::LinkedList(LinkedList<T>& otherLinkedList)
{
			head=new ListItem<T>(otherLinkedList.getHead()->value);
			ListItem<T>* temp=otherLinkedList.getHead();
			temp=temp->next;
			int x=otherLinkedList.length()-1;
			T arr[x];
			int i=0;
			while(temp!=NULL)
			{
				arr[i]=temp->value;
				i++;
				temp=temp->next;

			}
			for (int j=0;j<x;j++)
			{
				insertAtTail(arr[j]);
			}

			
}
template <class T>
LinkedList<T>::~LinkedList()
{
	delete head;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if (head==NULL)
	{
		head = new ListItem<T>(item);
	}
	else 
		{
			ListItem<T>* temp=new ListItem<T>(item);
			temp->next =head;
			head->prev =temp;
			head=temp;
				
		}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if (head==NULL)
	{
		insertAtHead(item);
	}
	else 
		{
			ListItem<T>* temp1;
			ListItem<T>* temp2= new ListItem<T>(item);
			temp1=head;
	        while (temp1->next!=NULL)
		        {
					temp1=temp1->next;
				}	
			temp2->prev =temp1;
			temp1->next=temp2;

		}	



}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{

		ListItem<T> *temp1;
		ListItem<T> * temp2=new ListItem<T>(toInsert);
	    temp1=head;
	    while (temp1->value!=afterWhat)
	    {
	
	    	temp1=temp1->next;
	    	
	    			
	    }
	    if (temp1->next!=NULL)
			{	    
	    		temp2->prev=temp1;
	    		temp2->next=temp1->next;
	    		temp1->next->prev=temp2;
	    		temp1->next=temp2;
	    	}
	    else if (temp1->next==NULL)
	    {
	    	insertAtTail(toInsert);
	    }			



}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if (head==NULL)
		{
			insertAtHead(item);
		}

	else if(item <= head->value)
	{
		insertAtHead(item);
	}
	else 
		{
			ListItem<T>* temp1;
			temp1=head;
			ListItem<T>* temp2= new ListItem<T>(item);
		
					while (item>= temp1->value)
					{
						temp1=temp1->next;
						if (temp1==NULL)
						{
							insertAtTail(item);
							return;
						}
					}
						
					
				
					temp1->prev->next=temp2;
					temp2->prev=temp1->prev;
					temp2->next=temp1;
					temp1->prev=temp2;
					

		}	
			



}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	if(head!=NULL)
	 {
	 	return head;
	 }	
	/*else 
	  {
	  	return head;
	  }*/	
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if(head==NULL)
	 {
	 	return NULL;
	 }	
	else
	{
		ListItem<T>* temp=head;
		while (temp->next!=NULL)
		{
			temp=temp->next;
		}	
		return temp;
	}	
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	if(head==NULL)
	 {
	 	return NULL;
	 }	
	else
	{
		ListItem<T>* temp=head;
		while (temp->value!=item)
			{
				if (temp->next==NULL)
				{
					return NULL;
				}
				else
				{
					temp=temp->next;
				}
			}		
		return temp;		
	}		

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if(head==NULL)
	 {
	 	return;
	 }	
	 else if(head->value==item)
	 {
	 	head=head->next;	 }
	 else 
	 {
	 	ListItem<T>*temp=head;
	 	while (temp->value!=item)
	 	{
	 		temp=temp->next;
	 		if(temp==NULL)
	 		{
	 			return;
	 		}	
	 		
	 	}
	 	if (temp->next!=NULL)
	     {
	     	temp->prev->next=temp->next;
	 		temp->next->prev=temp->prev;	
	 	}
	 	else if(temp->next==NULL)
	 	{
	 		temp=temp->prev;
	 		temp->next=NULL;
	 	}	
	
	 }
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if (head!=NULL)
	 	{
	 		if (head->next==NULL)
	 			head=NULL;
	 		else

	 		{
	 			head=head->next;
	 			delete head->prev;
	 			head->prev=NULL;
	 		}	

	 	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	if(head==NULL)
	 {
	 		 	
	 }	
	 else
	 {
	 	ListItem<T>* temp=head;
	 	while (temp->next!=NULL)
	 	{
	 		temp=temp->next;
	 	}
	 	temp->prev->next=NULL;
	 	temp->prev=NULL;
	 }
}

template <class T>
int LinkedList<T>::length()
{
	if(head==NULL)
	 {
	 	return 0;
	 }	
	 else
	 {
	 	int s=1;
	 	ListItem<T>* temp=head;
	 	while (temp->next!=NULL)
	 	{
	 		s++;
	 		temp=temp->next;
	 		
	 	}
	 	return s;
	 } 
}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T>* temp=head->next;
	/*while (temp->next!=NULL)
	{
		temp=temp->next;
	}*/
	int len=this->length()-1;
	for (int i=0;i<len;i++)
	{
		insertAtHead(temp->value);
		temp=temp->next;
	}
	for (int j=0;j<len;j++)
	{
		deleteTail();
	}		
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	
	ListItem<T>* temp=head;
	for(int i=0;i<this->length();i++)
	{
		
		 if ((temp->value)%2!=0)
		{	
			
			T val=temp->value;
			insertAtTail(val);
			deleteElement(val);
		}
		temp=temp->next;



	}
	
}
template<class T>
bool LinkedList<T>:: isPalindrome()
{
	if(head==NULL)
	{
		return 0;
	}
	else 
		{
			ListItem<T>*hed=head;
			ListItem<T>*tal=getTail();
			int x=length();
			if (x%2==0)
			{
				for (int i=0;i<x/2;i++)
				{
					if (hed->value!=tal->value)
						return 0;
					else 
					{
						hed=hed->next;
						tal=tal->prev;
					}
				}
			}
			else
			{
				for (int i=0;i<(x/2)-1;i++)
				{
					if (hed->value!=tal->value)
						return 0;
					else 
					{
						hed=hed->next;
						tal=tal->prev;
					}
				}
			}	
			return 1;
		}	
}
template <class T>
void LinkedList<T>::print()
{
	ListItem <T>* temp;
	temp=head;
	while (temp!=NULL)
	{
		cout << temp->value<<endl;
		temp=temp->next;
	}
}


#endif
/*int main()
{
	LinkedList<int> a;
	a.insertAtHead(2);
	a.insertAtHead(1);
	a.insertAtHead(0);
	a.insertAtTail(3);
	a.insertAtTail(5);
	a.insertAfter(4,3);
	a.insertAtTail(6);
	a.insertAtTail(7);
	a.insertAtTail(8);
	//a.print();
//	b=a.searchFor(7);
	cout << a.length()<<endl;
	LinkedList<int> c(a);
//	a.parityArrangement();
	//a.reverse();
	a.print();
	cout <<"_______________"<<endl;	
	c.print();
	return 0;

 }*/