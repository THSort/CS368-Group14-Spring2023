#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable=new block*[tableSize];
    for (int i=0;i<tableSize;i++)
    {
    	hashTable[i]=NULL;
    }
    count=0;
}

HashD::~HashD()
{
	delete[] hashTable;
}

unsigned long HashD :: hash1(string value){
    unsigned long hash=bitHash(value);
 	return hash;
}

unsigned long HashD :: hash2(string value){
    unsigned long hash=31-(hash1(value)%31);
 	return hash;
}

void HashD::resizeTable()
{
    if (count/tableSize>=0.75)
	{
	   long oldTsize=tableSize;
	   tableSize=tableSize*50;
	   block** hashTable2=new block*[tableSize];
	   block** oldtable=hashTable;
	   hashTable=hashTable2;
	   count=0;
	 	for (int i=0;i<tableSize;i++)
	    {
	    	hashTable[i]=NULL;
	    }

	   	for (int i=0;i<(oldTsize);i++)
	   	{	
	   		if (oldtable[i]!=NULL || hashTable[i]->value!="~~" )
	   		{
	   			
	   			insert(oldtable[i]->value);
	   			
	   		}
	   	}
	}
	if (count/tableSize<=0.25&&count/tableSize>1000)
	{
	   long oldTsize=tableSize;
	   tableSize=tableSize*0.75;
	   block** hashTable2=new block*[tableSize];
	   block** oldtable=hashTable;
	   hashTable=hashTable2;
	   count=0;
	 	for (int i=0;i<tableSize;i++)
	    {
	    	hashTable[i]=NULL;
	    }

	   	for (int i=0;i<(oldTsize);i++)
	   	{	
	   		if (oldtable[i]!=NULL || hashTable[i]->value!="~~" )
	   		{
	   			
	   			insert(oldtable[i]->value);
	   			
	   		}
	   	}
	}
}

void HashD::insert(string value){
    if(count/tableSize>=0.75)
   	{	
 		resizeTable();
 		   	
   	}
	unsigned long h=hash1(value);
	unsigned long h2=hash2(value);
	int index=divCompression(h,tableSize);
	block* a=new block(h,value);
	if(hashTable[index]!=NULL )
	{
		int i=0;
		int newIndex=divCompression(h+i*h2,tableSize);

	 	while (hashTable[newIndex]!=NULL)
	 		{
	 			i++;
	 			newIndex=divCompression(h+i*h2,tableSize);	

	 		}
	 		cout <<newIndex<<endl;
	 	hashTable[newIndex]=a;
	 	count++;
	 	


	 }
	 else if(hashTable[index]==NULL )
	 {
	 	hashTable[index]=a;
	 	count++;
	 	
	 }
}

void HashD::deleteWord(string value)
{
   if(lookup(value)==NULL)
   {  
   		return;
   }
    unsigned long h=hash1(value);
    unsigned long h2=hash2(value);
	int index=divCompression(h,tableSize);
	 if(hashTable[index]->value!=value)
	{
		int i=0;
		int newIndex=divCompression(h+i*h2,tableSize);
		while (hashTable[newIndex]->value!=value)
	 			{
	 				i++;
	 				newIndex=divCompression(h+i*h2,tableSize);					
 				}

	 	hashTable[newIndex]->value="~~";
	 	count--;
	}
	else if (hashTable[index]->value==value)
	{
		hashTable[index]->value="~~";
		count--;
	}
	
}

block* HashD::lookup(string value)
{
	unsigned long h=hash1(value);
	unsigned long h2=hash2(value);
	int index=divCompression(h,tableSize);
	block* temp=NULL;

	if(hashTable[index]==NULL)
	{	
		return NULL;
	}
	else if(hashTable[index]->value!=value)
	{	
		int i=0;
		int newIndex=divCompression(h+i*h2,tableSize);
		while (hashTable[newIndex]->value!=value )
	 			{
	 				i++;
	 				newIndex=divCompression(h+i*h2,tableSize);	
	 				 				
	 				if(hashTable[newIndex]==NULL)
	 				{
	 					return NULL;
	 				}
	 				if(newIndex==index)
	 				{
	 					return NULL;
	 				}
	 				
	 			}
	 	
	 	temp=hashTable[newIndex];
	 	return temp;
	}
	else if (hashTable[index]->value==value)
	{	
		temp=hashTable[index];
		return temp;
	}
    
}
void HashD::print()
{
	for (int i=0;i<tableSize;i++)
	{
		if(hashTable[i]!=NULL)
		{
			cout << hashTable[i]->value<<endl;
		}	
	}
}

#endif
/*int main()
{
	HashD a;
	a.insert("hello");
	a.insert("hi");
	a.insert("sfscf");
	a.insert("work");
	a.insert("number");
	a.insert("hoho");
	a.insert("word");
	a.print();
	cout<<"_____"<<endl;
	a.deleteWord("hello");
	a.deleteWord("hi");
	a.deleteWord("je");
	a.deleteWord("hoho");
	a.deleteWord("word");
	a.deleteWord("sfscf");
	a.deleteWord("hi");
	a.deleteWord("number");
	a.deleteWord("work");
	block* g=a.lookup("work");
	a.lookup("nnn");
	if(g==NULL)
		{cout<<"yes"<<endl;}
	a.print();
	//cout <<a.tableSize<<endl;
}*/