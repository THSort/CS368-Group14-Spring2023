#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

using namespace std;

HashC::HashC(int size)
{
	hashTable=new LinkedList<string> [size];
	tableSize=size;
    
}
HashC::~HashC()
{
	delete hashTable;
}

unsigned long HashC :: hash(string input)
{
  	unsigned long hash=bitHash(input);
 	return hash;  
}

void HashC::insert(string word)
{
	unsigned long h=hash(word);
	int index=divCompression(h,tableSize);
	hashTable[index].insertAtTail(word);  
}

ListItem<string>* HashC :: lookup(string word)
{
	unsigned long h=hash(word);
	int index=divCompression(h,tableSize);
	ListItem<string> *temp;
	temp=hashTable[index].searchFor(word);
	return temp;
}

void HashC :: deleteWord(string word)
{
  	unsigned long h=hash(word);
	int index=divCompression(h,tableSize);
	hashTable[index].deleteElement(word);
}

#endif