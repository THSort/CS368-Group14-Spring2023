#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000;
     // you cant change this
    count =0;
    hashTable = new block*[tableSize];

    for (int i = 0 ; i<tableSize; i++)
    {
    	hashTable[i]=NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
    int a= bitHash(value);
	return divCompression(a, tableSize);  

}

void HashL::resizeTable(){

	unsigned long percentage = (count / tableSize) * 100;

	unsigned long oldtablesize=tableSize;

	block** oldhashTable = hashTable;
	if(percentage > 70)
	{
		tableSize = tableSize*30;
	}
	else if(percentage < 30)
	{
		tableSize = tableSize/3;
	}
	hashTable = new block*[tableSize];
	for(int i = 0; i < tableSize; i++){
		hashTable[i] = NULL;
	}
	count = 0;

	for(int i = 0; i < oldtablesize; i++){
		if(oldhashTable[i] != NULL)
		{
			if(oldhashTable[i]->value != "TheElementHasBeenDeleted"){
				insert(oldhashTable[i]->value);
			}
		}
	}
    

    return;
}

void HashL::insert(string value){
	unsigned long index = hash (value);
	double c = count;
	double t = tableSize;
	unsigned long percentage= (c/ t) * 100;

	if (percentage > 70) resizeTable();

	while (1)
	{
		if (hashTable[index]==NULL)
		{
			hashTable[index] = new block(index, value);
			count++;
			break;
		}

		else 
			index=(index +1) % tableSize;
	}



    return;
}

void HashL::deleteWord(string value){

	unsigned long index=hash (value);

	block * a= lookup (value);
	if(a!=NULL){
		a -> key =0;
		a ->value="TheElementHasBeenDeleted";
	}

	
    return;
}
block* HashL::lookup(string value){
    
	unsigned long index = hash (value);

	while(hashTable[index] != NULL)
	{
		if(hashTable[index]->value == value){
			return hashTable[index];
		}
		else
		{
			index = (index + 1) % tableSize;
		}
	}


   
}
#endif


