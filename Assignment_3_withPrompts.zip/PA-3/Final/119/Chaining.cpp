#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize=size;
  hashTable=new LinkedList <string> [tableSize];

}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
	int a= bitHash(input);
	int x=input.length();

	return divCompression(a, tableSize);  
}

void HashC::insert(string word){

	unsigned long a=hash(word);
	if(hashTable[a].searchFor(word)==NULL)
		{
			hashTable[a].insertAtHead(word);
		}
  
  return;
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long a=hash(word);
	return hashTable[a].searchFor(word);
}

void HashC :: deleteWord(string word){
		unsigned long a=hash(word);
		hashTable[a].deleteElement(word);
  return;
}

#endif

