//#include <iostream>
using namespace std;

#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	head=NULL;
	ListItem <T> *temp=otherLinkedList.head;
	while(temp !=NULL)
	{
		insertAtTail(temp->value);
		temp=temp->next;
	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	while (head!=NULL)
	{
		deleteHead();
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem <T> *temp=new ListItem <T>(item);

        if(head==NULL)
        {
            head=temp;
        }
        else
        {
            temp->next=head;
            head->prev=temp;
            temp->prev=NULL;
            head = temp;
        }       
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem <T> *temp=new ListItem <T> (item);
	ListItem <T> *current;

	current=head;

	if (head==NULL)
	{
		head=temp;
	}

	else 
	{
		while (current->next!=NULL)
		{
			current=current->next;
		}

		current->next=temp;
		temp->prev=current;
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem <T> *temp=new ListItem <T> (toInsert);
	ListItem <T> *current;
	ListItem <T> *current1;
	current=head;
	
	if (head==NULL)
	{
		head=temp;
	}

	else 
	{
		while (current->value!= afterWhat)
		{
			current=current->next;
		}


		if (current->next==NULL)
		{
			insertAtTail(toInsert);
		}

		else 
		{
			current1=current->next;
			current->next=temp;
			temp->next=current1;
			temp->prev=current;
		}
	} 

}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	//ListItem <T> *temp=new ListItem <T> (item);
	ListItem <T> *current;
	//temp->value=item;
	

	current=head;
	

	if (head== NULL || head->value > item)
	{
		insertAtHead(item);
		return;
	}

	while (current!=NULL)
	{
		if (current->next==NULL && current->value < item)
		{
			insertAtTail(item);

		return;
		}

		current=current->next;
	}

	current=head;
	while (current!=NULL)
	{
		

		 if (current->next!=NULL && current->next->value > item)
		{ 
		/*current->next->prev=temp;
		temp->next=current->next;
		current->next=temp;
		temp->prev=current;*/

			insertAfter(item,current->value);
			return;
	    }

	    else if(current->next==NULL)
	    {
	    	insertAtTail(item);

	    	return;

	    }

	    current=current->next;


	}



}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	ListItem<T> *current;

	current=head;

	if (current== NULL)
	{
		return NULL;
	}

	else 
	{	
		while (current->next!=NULL)
		{
		current=current->next;
		}

		return current;
	}	
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	//ListItem <T> *temp=new ListItem <T> (item);
	ListItem <T> *current;
	current=head;

	if(head==NULL)
	{
		return NULL;
	}
	
	else if (item==current->value)
	{
		//cout << current->value << endl;
		return current;

	}
	
	else if (current->value != item)
	{
			while (current!= NULL)
		{

			 if (current->value == item)
			 {	
			 	//cout << current->value << endl;
			 	//cout << temp->value << endl;
			 	return current;
			 	//break;
			 }

			 current=current->next;
		}
	}	

	//if (current->value != temp->value)
	if(current==NULL)
	{
		return NULL;
	}
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem <T> *temp=new ListItem <T> (item);
	ListItem <T> *current;
	ListItem <T> *current1;
	current=head;
	temp=head;
	current1=getTail();

		/*while (current1!=NULL)
		{
			current1=current1->next;
		}*/
       if(head->value==item)
        {
            deleteHead();
            return;
        }
        else if(current1->value==item)
        {
            deleteTail();
            return;
        }        
        
        	while(temp->next->value!=item)
        	{
            	temp=temp->next;
        	}

        	current=temp->next;
        	temp->next=temp->next->next;
        	if(temp->next->next!=NULL) temp->next->next->prev=temp;
        	
        	delete current;
        	current=NULL;
        
}

template <class T>
void LinkedList<T>::deleteHead()
{
		if(head == NULL) 
			{
			return;
			}
		ListItem <T> *temp;
		temp=head;
        head=head->next;
        delete temp;
        temp=NULL;
}

template <class T>
void LinkedList<T>::deleteTail()
{
	 	if(head == NULL)
	 	{
	 		return;
	 	}
	 	else if(head->next == NULL)
	 	{
	 		deleteHead();

	 	}
	 	else
	 	{	
		 	ListItem <T> *current;
		 	current=head;
	        while (current->next!=NULL)
	        {	
	        	current=current->next;
	        }

	        current = current->prev;
	        delete current->next;
	        current->next=NULL;
	     }   
}

template <class T>
int LinkedList<T>::length()
{
	ListItem <T> *temp;
	int counter=0;
	temp=head;
	if (temp==NULL)
	{
		return 0;
	}

	else
	{
		while (temp!=NULL)
		{
			counter++;
			temp=temp->next;
		}

		return counter;
	}	
}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem <T> *current;
	ListItem <T> *temp=new ListItem <T> (0);
	current=head;
	temp=NULL;

	if(current==NULL)
	{
		current = NULL;
	}

	else if (current->next==NULL)
	{
		current = head;
	}
	
	while(current!=NULL)
	{
		temp=current->prev;
		current->prev=current->next;
		current->next=temp;
		current=current->prev;
	}

	if (temp!=NULL)
	{
		temp=temp->prev;
	}
	head=temp;

        
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	ListItem <T> *temp;
	ListItem <T> *current;
	temp =head;
	current=head->next;
	int a;
	int len =length()/2;
	
	if (head==NULL || head->next==NULL)
		{
			return;
		}

	for (int i = 0; i < len; ++i)
	{
		
		current->prev->next=current->next;
		current->next->prev=current->prev;
		a=current->value;
		temp=current->next->next;
		delete current;
		current=temp;
		insertAtTail(a);
	} 
	

}

template <class T>
bool LinkedList <T> :: isPalindrome()
{
	ListItem <T> *temp;
	ListItem <T> *temp1;
	int a =0;

	temp=getHead();
	temp1=getTail();
	a=length()/2;

	if (temp==NULL)
	{
		return 0;
	}

	for (int i=0; i<a;i++)
	{
		if (temp->value==temp1->value)
		{

		}
		else 
		{
			return 0;
		}
		temp=temp->next;
		temp1=temp1->prev;
	}
	return 1;
}


/*template <class T>
void LinkedList<T>::printlist(){
	ListItem<T> *temp = head;
	if(temp == NULL){
		cout << "List is empty" << endl;
	}
	while(temp != NULL){
		cout << temp->value << " ";
		temp = temp->next;
	}
}

	int main(){
	
	LinkedList<int> l1;
	l1.printlist();
	cout << endl;
	l1.insertAtHead(69);
	l1.printlist();
	cout << endl;
	//for (int i = 0; i < 20; i++){
	//	l1.insertAtHead(i);
	//}
	//l1.insertAfter(112,19);
	//cout << l1.getHead() << endl;
	//l1.searchFor(69);
	//l1.deleteHead();
	l1.deleteTail();
	cout << endl;
	l1.insertAtHead(25);
	l1.printlist();
}*/

#endif
	
