#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <math.h>
#include <string>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
    unsigned long poly_hash_code = 0;
    int len = value.length();
    int count = 1;
    for(int j=0;j<len;j++){
        poly_hash_code = poly_hash_code+pow(a,len-count-j)*(int)value[j];
    }
    return poly_hash_code;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
    unsigned long bitwise_hash_code = 0;
    int len = value.length();
    for(int j=0;j<len;j++){
        bitwise_hash_code ^= (bitwise_hash_code << 5)+(bitwise_hash_code >> 2) + value[j];
    }
	return bitwise_hash_code;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return hash%size;
}
// multiplication addition and division compression.
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    return (a*hash + m) % size;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
