#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
#include "LinkedList.cpp"
using namespace std;
HashC::HashC(int size){
    tableSize = size;
    hashTable = new LinkedList<string>[size];

}
HashC::~HashC(){
    delete [] hashTable;
}

unsigned long HashC :: hash(string input){
    unsigned long hash = madCompression(bitHash(input),tableSize);
    return hash;
}

void HashC::insert(string word){
    unsigned long arr_index = hash(word);
if(hashTable[arr_index].searchFor(word) == NULL){
        hashTable[arr_index].insertAtHead(word);}
}

ListItem<string>* HashC :: lookup(string word){
    unsigned long arr_index = hash(word);
    return hashTable[arr_index].searchFor(word);
	
}

void HashC :: deleteWord(string word){
    unsigned long arr_index = hash(word);
if(hashTable[arr_index].searchFor(word) != NULL){
    hashTable[arr_index].deleteElement(word);}

}

#endif
