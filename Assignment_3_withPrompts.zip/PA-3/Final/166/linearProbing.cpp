#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP
#include <iostream>
#include "linearProbing.h"
#include "hashfunctions.cpp"
using namespace std;

HashL::HashL(){

    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
	hashTable[i] = NULL;
    }
}

HashL::~HashL(){
    
    delete [] hashTable;
}

unsigned long HashL :: hash(string value){
    
    unsigned long hash = bitHash(value);
    return hash;
}

void HashL::resizeTable(){
    
    if(count<(2*tableSize/4))
    {
        return;
    }
    else
    {	count=0;
        long tableSize1 = tableSize;
        tableSize = tableSize*20;
        block** hashTable1 = hashTable;
        hashTable = new block*[tableSize];
        for(int i=0;i<tableSize;i++)
        {
            hashTable[i]=NULL;
        }
        for(int i=0;i<tableSize1;i++)
        {
            if(hashTable1[i] != NULL)
            {
                insert(hashTable1[i]->value);
            }
        }
        delete [] hashTable1;
    }
    return;
}

void HashL::insert(string value){
    
    unsigned long key = hash(value);
    unsigned long arr_index = divCompression(hash(value),tableSize);
    if(hashTable[arr_index] == NULL)
    {
        hashTable[arr_index] = new block(key,value);
	count++;
    }
    else
    {
        while(hashTable[arr_index] != NULL)
        {
            arr_index++;

            //if(arr_index>=tableSize)
            //{
                arr_index = divCompression(arr_index,tableSize);
            //}
        }

	if(hashTable[arr_index]==NULL)
	{
            hashTable[arr_index] = new block(key,value);
	    count++;
	}
    }
    resizeTable();
}

void HashL::deleteWord(string value){
    unsigned long key = hash(value);
    unsigned long arr_index = divCompression(hash(value),tableSize);
    if(hashTable[arr_index]==NULL)
    {
        return;
    }
    else
    {
        while(hashTable[arr_index]!=NULL)
        {if(hashTable[arr_index]->value==value)
{hashTable[arr_index]=NULL;
return;}
            arr_index++;
          //  if(arr_index>=tableSize)
            //{
                arr_index = divCompression(arr_index,tableSize);
            //}
        }
          // hashTable[arr_index]=NULL;
     }
resizeTable();
}
block* HashL::lookup(string value){
    unsigned long key = hash(value);
    unsigned long arr_index = divCompression(hash(value),tableSize);
    if(hashTable[arr_index]==NULL)
    {
        return NULL;
    }
    else
    {
        while(hashTable[arr_index]!=NULL)
        { if(hashTable[arr_index]->value==value)
{return hashTable[arr_index];
}
            arr_index++;
            //if(arr_index>=tableSize)
            //{
                arr_index = divCompression(arr_index,tableSize);
            //}
        }
            //return hashTable[arr_index];
    }
}
#endif
