#ifndef __LIST_CPP
#define __LIST_CPP
#include <iostream>
#include <cstdlib>
#include "LinkedList.h"
using namespace std;
template <class T>
LinkedList<T>::LinkedList()
{
   head = NULL;
   tail = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
    if (otherLinkedList.head==NULL){
        head = NULL;
        tail = NULL;}
    else {
        head = new ListItem<T>(otherLinkedList.head->value);
        ListItem<T>* temp = otherLinkedList.head->next;
        ListItem<T>* temp1 = head;
        while (temp != NULL){
                temp1->next = new ListItem<T>(temp->value);
                (temp1->next)->next = NULL;
                (temp1->next)->prev = temp1;
                temp1 = temp1->next;
                temp = temp->next;}
        tail = temp1;
    }
}

template <class T>
LinkedList<T>::~LinkedList()
{
    ListItem<T>* temp = head;
    while(temp!=NULL){
        ListItem<T>* temp1 = temp;
        temp = temp->next;
        delete temp1;
    }
    head = NULL;
    tail = NULL;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
    if (head==NULL)
     {ListItem<T>* temp = new ListItem<T>(item);
      head = temp;}
     else{
        ListItem<T>* temp = new ListItem<T>(item);
        temp->next = head;
        head->prev = temp;
        head = temp;
}}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
    if(head==NULL){
        head = new ListItem<T>(item);
        tail = head;
    }
    else{
        ListItem<T>* temp = new ListItem<T>(item);
        temp->next = NULL;
        temp->prev = tail;
        tail->next = temp;
        tail = temp;
    }
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
//    cout<<"r";
    if (head==NULL){
            //        acout<<"null";
    insertAtHead(toInsert);
    }

    else if(tail->value==afterWhat)
    {
        ListItem<T>* temp = tail;
        tail = new ListItem<T>(toInsert);
        tail->next = NULL;
        tail->prev = temp;
        temp->next = tail;
    }
    else {
        ListItem<T>* temp = head;
        ListItem<T>* temp1 = head->next;
    cout<<"2";
        while(temp->next!=NULL && temp->value != afterWhat){
            temp = temp->next;

            temp1 = temp1->next;
            }
        if(temp->value==afterWhat){
            ListItem<T>* tem = new ListItem<T>(toInsert);
            temp->next = tem;
            tem->next = temp1;
            tem->prev = temp;
            temp1->prev = tem;}
        }
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
    if (head==NULL)
{
insertAtHead(item);
}
    else if(head->value>item)
    {
insertAtHead(item);
    }
    else if(tail->value<item)
    {
        insertAtTail(item);
    }
    else{
        ListItem<T>* temp = new ListItem<T>(item);
        ListItem<T>* temp1= head;
        ListItem<T>* temp2 = head->next;
        while(temp->value > temp2->value && temp2->next!=NULL)
{


    temp1 = temp1->next;
    temp2 = temp2->next;
}

temp->next=temp2;
temp2->prev=temp;
temp->prev= temp1;
temp1->next=temp;



    }
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
   // if(head==NULL){
	//ListItem<T>* temp = head;
        return head;

    //}
    //else{
      //  ListItem<T>* temp = head;
        //return temp;}
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    //if(tail==NULL){

    //}
    //else{
        ListItem<T>* temp = tail;
        return temp;}
//}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
    ListItem<T>* t=head;
        while(t!=NULL)
        {
            if(t->value==item)
            {return t;}
            t=t->next;
	}
        return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
    if(head->next==NULL && head->value==item)
    {head=NULL;}
    else if(head->next!=NULL && head->value==item)
    {deleteHead();}
    else if(head!=NULL)
    {	ListItem<T>* t1;
        ListItem<T>* t=head;
        
        while(t->next != NULL)
        {
            if(head != NULL)
            {
            t=t->next;
            if(t->next!=NULL && t->value==item)
            {	t1=t->prev;
                t1->next=t->next;
                t1->next->prev=t1;
                delete t;
                break;}

            else if(t->next==NULL && t->value==item)
            {	(t->prev)->next=NULL;
                delete t;
                break;}
}}}}

template <class T>
void LinkedList<T>::deleteHead()
{
    if(head!=NULL)
    {	ListItem<T>* temp = getHead();
	if(head->next != NULL)
        {head = head->next;
        delete temp;}
	else{
	head = NULL;}
}
}

template <class T>
void LinkedList<T>::deleteTail()
{

    if(tail!=NULL && tail->prev!=NULL){
        ListItem<T>* temp = tail;
        tail = tail->prev;
        tail->next = NULL;
        delete temp;
    }
	else if(tail!=NULL && tail->prev==NULL){
	tail = NULL;}
}

template <class T>
int LinkedList<T>::length()
{
    int counter=0;
    if(head==NULL){
        return counter;
    }
    else{
//        counter = 1;
        ListItem<T>* temp = head;
        while(temp!=NULL){

          temp=temp->next;
        counter++;
        }
    return counter;
    }
}

template <class T>
void LinkedList<T>::reverse()
{



    /*if(head->next==tail)
    {
        ListItem<T>* temp = head;
        temp->prev = tail;
        temp->next = NULL;
        tail->prev = NULL;
        tail->next = temp;
        head = tail;
        tail = temp;
    }*/
    //if(head!=NULL){
        //ListItem<T>* temp = NULL;
        ListItem<T>* temp_front=head;
        //ListItem<T>* temp1 = NULL;
        while(temp_front!=NULL)
        {
            ListItem<T>* temp1 = temp_front->next;
            temp_front->next = temp_front->prev;
            temp_front->prev = temp1;
            if(temp1==NULL){
                tail = head;
                head = temp_front;
            }
            temp_front = temp1;
           // temp = temp_front;
           // temp_front = temp1;
        }
        //tail = head;
       // head = temp;
    //}
}

template <class T>
void LinkedList<T>::parityArrangement()
{

    if (head!=NULL && head->next!=NULL && head->next->next!=NULL){

        ListItem<T>* temp_head = head;
        ListItem<T>* temp1 = head->next;
        ListItem<T>* temp_head_next = head->next;
        ListItem<T>* tem = temp_head_next->next;

        while(tem!=NULL)
        {
            temp_head->next = tem;
            tem->prev = temp_head;
            temp_head = tem;
            if(tem->next!=NULL){
                tem=tem->next;
            }
            temp1->next = tem;
            tem->prev = temp1;
            temp1 = tem;
            tem = tem->next;
        }
        temp1->next = NULL;
        temp_head->next = temp_head_next;
        temp_head_next->prev = temp_head;

    }






    /*if(head==NULL){
        return;
    }
    else if(head->next->next==NULL){
       return;
    }

    else{
        ListItem<T>* te = head;
        ListItem<T>* temp = head;
        ListItem<T>* tem = head->next;
        ListItem<T>* temp1 = head->next;
        ListItem<T>* temp2 = head->next->next;
        ListItem<T>* temp3 = temp1->next->next;
int counter=0;
        while(temp2!=NULL || temp3!=NULL)
            {cout<<counter<<" ";
                if(temp2!=NULL)
                {
                    temp->next = temp2;
                    temp2->prev = temp;
                    temp = temp2;
                    temp2 = (temp2->next)->next;
                }
                    if(counter==3){
                    cout<<"HEAD :";
                    while(te!=NULL){
                    cout<<te->value<<" ";
                    te=te->next;}
                    cout<<"tail: ";
                    while(tem!=NULL){
                    cout<<tem->value<<" ";
                    tem=tem->next;}}

                if(temp3!=NULL)
                {
                    temp1->next = temp3;
                    temp3->prev = temp1;
                    temp1 = temp3;
                    temp3 = (temp3->next)->next;
                }
                counter++;
            }

        temp1->next=NULL;
        temp->next = tem;
        tem->prev = temp;
        }*/

}

template <class T>
bool LinkedList<T>::isPalindrome(){
    if (head==NULL || head->next==NULL){
        return false;
    }
    else{

        ListItem<T>* nex = head;
        ListItem<T>* pre = tail;
        int counter=0;
        int len = length();
        if(len%2==0)
        {
            while(counter<len/2){
                counter++;
                if(nex->value==pre->value)
                {
                    nex=nex->next;
                    pre=pre->prev;
                }
                else{
                    return false;
                    break;
                }
            }
            return true;
        }
        else if(len%2!=0)
        {
            while(counter<(len/2)-1){
                counter++;
                if(nex->value==pre->value)
                {
                    nex=nex->next;
                    pre=pre->prev;
                }
                else{
                    return false;
                    break;
                }
            }
            return true;
        }

    }





}







#endif
