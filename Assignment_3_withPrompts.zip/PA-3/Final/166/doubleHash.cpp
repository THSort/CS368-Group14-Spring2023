#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
	hashTable[i] = NULL;
    }
}

HashD::~HashD(){
    delete [] hashTable;
}

unsigned long HashD :: hash1(string value){
    unsigned long hash = bitHash(value);
    return hash;
}

unsigned long HashD :: hash2(string value){
    unsigned long hash = polyHash(value);
    return hash;
}

void HashD::resizeTable(){
    if(count<(2*tableSize/4))
    {
        return;
    }
    else
    {	count=0;
        long tableSize1 = tableSize;
        tableSize = tableSize*20;
        block** hashTable1 = hashTable;
        hashTable = new block*[tableSize];
        for(int i=0;i<tableSize;i++)
        {
            hashTable[i]=NULL;
        }
        for(int i=0;i<tableSize1;i++)
        {
            if(hashTable1[i] != NULL)
            {
                insert(hashTable1[i]->value);
            }
        }
        delete [] hashTable1;
    }
    return;
}

void HashD::insert(string value){
    unsigned long key = hash1(value);
    unsigned long arr_index = divCompression(hash1(value),tableSize);
    if(hashTable[arr_index] == NULL)
    {
        hashTable[arr_index] = new block(key,value);
	count++;
    }
    else
    {   
	int i=0;
        while(hashTable[arr_index] != NULL)
        {   
            i++;
            arr_index = hash1(value)+i*hash2(value);
	    arr_index = divCompression(arr_index,tableSize);
        }

	//if(hashTable[arr_index]==NULL)
	//{
            hashTable[arr_index] = new block(key,value);
	    count++;
	//}
    }
    resizeTable();
    
}

void HashD::deleteWord(string value){
    unsigned long key = hash1(value);
    unsigned long arr_index = divCompression(hash1(value),tableSize);
    if(hashTable[arr_index]==NULL)
    {
        return;
    }
    else
    {   int i=0;
        while(hashTable[arr_index]!=NULL)
        { 
	 if(hashTable[arr_index]->value==value)
	   {
		hashTable[arr_index]=NULL;
	   }
            i++;
            arr_index = hash1(value)+i*hash2(value);
	    arr_index = divCompression(arr_index,tableSize);
            
        }
    }
resizeTable();
}

block* HashD::lookup(string value){
    unsigned long key = hash1(value);
    unsigned long arr_index = divCompression(hash1(value),tableSize);
    if(hashTable[arr_index]==NULL)
    {
        return NULL;
    }
    else
    {	int i=0;
        while(hashTable[arr_index]!=NULL)
        { 
	 if(hashTable[arr_index]->value==value)
	   {
		return hashTable[arr_index];
	   }
            i++;
            arr_index = hash1(value)+i*hash2(value);
	    arr_index = divCompression(arr_index,tableSize);
            
        }
    }
}

#endif
