#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
    tableSize = size;
    hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input)
{
	unsigned long hash_value = bitHash(input);
	unsigned long value = divCompression(hash_value, tableSize);
	return value;  
}

void HashC::insert(string word)
{
	unsigned long hash_value = hash(word);

	hashTable[hash_value].insertAtTail(word);

	return;
}

ListItem<string>* HashC :: lookup(string word)
{
	unsigned long hash_value = hash(word);

	ListItem<string>* x = hashTable[hash_value].searchFor(word);

	return x;
}

void HashC :: deleteWord(string word)
{
	unsigned long hash_value = hash(word);

	hashTable[hash_value].deleteElement(word);

	return;
}

#endif

/*int main()
{
	return 0;
}*/