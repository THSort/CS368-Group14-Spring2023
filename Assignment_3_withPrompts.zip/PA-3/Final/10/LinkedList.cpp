#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"
#include <string>
#include <iostream>
using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{

    ListItem<T> *temp_1 = otherLinkedList.head;

    ListItem<T> *temp_2 = NULL;

    while (temp_1)
    {
        if (temp_2 == NULL)
        {
            temp_2 = new ListItem<T> (temp_1->value);
            temp_1 = temp_1->next;
        }
        else
        {
            ListItem<T> *temp_3 = new ListItem<T>(temp_1->value);
            temp_3->prev = temp_2;
            temp_2->next = temp_3;
            temp_2 = temp_2->next;
            //temp_3 == NULL;

            temp_1 = temp_1->next;
        }
    }

    if (temp_2 != NULL)
    {
        while(temp_2->prev != NULL)
        {
            temp_2 = temp_2->prev;
        } 
    }
    
    head = temp_2;



}

template <class T>
LinkedList<T>::~LinkedList()
{

    ListItem<T> *temp;

    if (head != NULL)
    {
        while (head)
        {
            temp = head;
            head = head ->next;
            delete temp;
        }
        delete head;


    }
    //cout << "I am the destructor" << endl;

}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
    
    //cout << item << endl;
	if (head == NULL)
	{
	    head = new ListItem<T>(item);
	}
	else
	{
		ListItem<T> *temp;
		temp = new ListItem<T>(item);
		temp->next = head;
		head->prev = temp;
		head = temp;

	}
}
template <class T>
void LinkedList<T>::insertAtTail(T item)
{
    ListItem<T> *temp = new ListItem<T>(item);

    ListItem<T> *temp_p = head;

    if (temp_p == NULL)
    {
        head = new ListItem<T>(item);
    }
    else
    {
        while(temp_p->next)
        {
            temp_p = temp_p->next;
        }
        temp->prev = temp_p;
        temp_p->next = temp;

    }




}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
    ListItem<T> *temp = new ListItem<T>(toInsert);
    ListItem<T> *temp_search = head;

    while (temp_search)
    {
        if (temp_search->value == afterWhat)
        {
            ListItem<T> *temp_next;
            temp_next = temp_search->next;

            temp_search->next = temp;
            temp->prev = temp_search;
            temp->next = temp_next;
        }
        temp_search = temp_search->next;
    }
}
template <class T>
void LinkedList<T>::insertSorted(T item)
{
    ListItem<T> *temp = new ListItem<T>(item);
    ListItem<T> *temp_search = head;

    int found = 0;

    if (temp_search == NULL)
    {
        head = new ListItem<T>(item);
    }
    else
    {
        while (temp_search)
        {
            if (temp_search->value > item)
            {
                found = 1;
                if (temp_search->prev != NULL)
                {
                    temp_search = temp_search->prev;
                    ListItem<T> *temp_next = temp_search->next;

                    temp_search->next = temp;
                    temp->prev = temp_search;
                    temp->next = temp_next;
                    temp_next->prev = temp;

                }
                else
                {
                    temp->next = temp_search;
                    temp_search->prev = temp;
                    head = temp;
                }
                break;
            }

            temp_search = temp_search->next;
        }
        if (found == 0)
        {
            ListItem<T> *temp_search_2 = head;
            while(temp_search_2->next)
            {
                temp_search_2 = temp_search_2->next;
            }
            temp_search_2->next = temp;
            temp->prev =temp_search_2;

        }
    }


}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
    return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    ListItem<T> *temp = head;

    if (temp != NULL)
    {
    	while(temp->next)
	    {
	        temp = temp->next;
	    }
    }
    
    return temp;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item) //issue when no such item in list
{
    ListItem<T> *temp = head;

    while(temp)
    {
        if (temp->value == item)
        {
            return temp;
        }
        temp = temp->next;
    }
    //ListItem<T> *temp2 = new ListItem<T>(NULL);
    return NULL;

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
    ListItem<T> *temp = head;

    while(temp)
    {
        if (temp->value == item)
        {
            if (temp->prev && temp->next)
            {
                ListItem<T> *temp_previous = temp->prev;
                temp = temp->next;

                temp_previous->next = temp;
                temp->prev = temp_previous;
            }
            else if(head->value == item)
            {
                if (head->next)
                {
                    head = head->next;
                    head->prev = NULL;
                }
                else
                {
                    head = NULL;
                }
            }
            else if(temp->next == NULL)
            {
                temp = temp->prev;
                temp->next = NULL;
            }
            break;
        }
        temp= temp->next;
    }
}

template <class T>
void LinkedList<T>::deleteHead()
{
    if (head->next)
    {
        head = head->next;
        head->prev = NULL;
    }
    else
    {
        head = NULL;
    }

}

template <class T>
void LinkedList<T>::deleteTail()
{
    ListItem<T> *temp = head;

    if (temp == NULL)
    {

    }
    else if(temp->next)
    {
        while(temp->next)
        {
            temp = temp->next;
        }
        temp = temp->prev;
        temp->next = NULL;
    }
    else
    {
        head = NULL;
    }




}

template <class T>
int LinkedList<T>::length()
{
    ListItem<T> *temp = head;
    int counter = 0;

    while(temp)
    {
        counter++;
        temp = temp->next;

    }
    return counter;
}

template <class T>
void LinkedList<T>::reverse()
{
    ListItem<T> *temp = head;
    ListItem<T> *temp_counter = head;

    if (temp_counter == NULL || temp_counter->next == NULL)
    {

    }
    else
    {

        while (temp_counter)
        {
            temp_counter = temp_counter->next;
            if (temp_counter != NULL)
            {
                temp = temp_counter->prev;

                ListItem<T> *temp2 = temp->next;
                temp->next = temp->prev;
                temp->prev = temp2;
            }

        }
        temp =temp->prev;
        ListItem<T> *temp2 = temp->next;
        temp->next = temp->prev;
        temp->prev = temp2;



        head = temp;
    }
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	LinkedList<T> odd;
    LinkedList<T> even;

    ListItem<T> *temp = head;

    int index = 1;

    while(temp)
    {
        if (index % 2)
        {
            odd.insertSorted(temp->value);
        }
        else
        {
            even.insertSorted(temp->value);
        }
        temp = temp->next;
        index++;
    }

    ListItem<T> *temp2 = head;

    while(temp2)
    {
        if (odd.head)
        {
            temp2->value = odd.head->value;
            odd.head = odd.head->next;
        }
        else if(even.head)
        {
            temp2->value = even.head->value;
            even.head = even.head->next;
        }
        temp2 = temp2->next;
    }
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	int arr[this->length()];


	ListItem<T> *temp = head;

	int counter = 0;

    if (this->length() == 0)
    {
        return false;
    }


	while (temp)
	{
	    arr[counter] = temp->value;
	    counter++;
	    temp = temp->next;
	}



    counter=0;
    int length = this->length();
    for(int x = 0; x < length/ 2; x++)
    {
        if (arr[counter] == arr[length -1 - counter])
        {
            counter++;
        }
        else
        {
            return false;
        }
    }
    return true;
}





#endif
