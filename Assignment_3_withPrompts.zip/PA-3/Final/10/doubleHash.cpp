#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
#include <vector>
HashD::HashD()
{
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    count = 0;

    for (int i = 0; i < tableSize; i++)
	{
		hashTable[i] = new block(0,"");
	}
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value)
{
	unsigned long hash_value = bitHash(value) * 37;
	unsigned long final_value = divCompression(hash_value, tableSize);
    return final_value;
}

unsigned long HashD :: hash2(string value)
{
	unsigned long hash_value = ((tableSize - 7) - (bitHash(value) % (tableSize - 7)) );
	unsigned long final_value = divCompression(hash_value, tableSize);
    return final_value;
}

void HashD::resizeTable()
{
	vector<string> hashTable_temp;

	for (int i = 0;i < tableSize; i++)
	{
		if (( hashTable[i]->key == 0 &&  hashTable[i]->value != "")  || (hashTable[i]->key == 1 && hashTable[i]->value != "" ) || hashTable[i]->key !=0)
		{
			hashTable_temp.push_back(hashTable[i]->value);
		} 
		
	}


	tableSize = tableSize*6; //2.9
	hashTable = new block*[tableSize];

	for (int i = 0; i < tableSize; i++)
	{
		hashTable[i] = new block(0,"");
	}

	count = 0;
	for (int i = 0; i < hashTable_temp.size(); i++)
	{
		insert(hashTable_temp[i]);
	}

    return;
}

void HashD::insert(string value)
{

	unsigned long h1 = hash1(value);
	unsigned long h2 = hash2(value);

	int i = 0;

	unsigned long index = 0;
	while(true)
	{
		index = h1 + ( i * h2 );
		index = index % tableSize;
		if ( (hashTable[index]->key ==  0 && hashTable[index]->value == "") || ( hashTable[index]->key == 1 && hashTable[index]->value == "" ) )
		{
			hashTable[index]->key = h1;
			hashTable[index]->value = value;

			loadFactor();
			count++;
			return;
		}
		else
		{
			i++;
		}
	}


	/*unsigned long hashValueActual_1 = hash1(value);

	unsigned long hashValueIndex = hashValueActual_1;

	if( (hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "") || (hashTable[hashValueIndex]->key == 1 && hashTable[hashValueIndex]->value == "" ) ) //1 is the special marker for skipping
	{
		hashTable[hashValueIndex]->key = hashValueActual_1;
		hashTable[hashValueIndex]->value = value;

		count++;
		loadFactor();
		return;

	}
	else
	{
		unsigned long hashValueActual_2 = hash2(value);

		bool found = true;
		int i = 1;
		
		while(found)
		{
			
			if(hashTable[hashValueIndex]->key == hashValueActual_1)
			{
				if (hashTable[hashValueIndex]->value == value)
				{
					return;
				}
				else
				{
					hashValueIndex = (hashValueActual_1 + ( i * hashValueActual_2 )) % tableSize;
					cout << hashValueIndex << endl;

				}

			}
			else if( (hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "") || (hashTable[hashValueIndex]->key == 1 && hashTable[hashValueIndex]->value == "" ) )
			{
				hashTable[hashValueIndex]->key = hashValueActual_1;
				hashTable[hashValueIndex]->value = value; 

				count++;
				loadFactor();
				//cout << count << endl;
				return;
			}
			else
			{
				hashValueIndex = (hashValueActual_1 + ( i * hashValueActual_2 )) % tableSize;
			}

			i++;
			
		    
		}
	}*/

	
    return;
}

void HashD::deleteWord(string value)
{
	unsigned long h1 = hash1(value);
	unsigned long h2 = hash2(value);

	unsigned long index = 0;
	int i = 0;

	while(true)
	{
		index = h1 + ( h2 * i );
		index = index % tableSize;

		if(hashTable[index]->key == h1 && hashTable[index]->value == value)
		{
			hashTable[index]->key = 1;
			hashTable[index]->value = "";
			count--;
			return;
		}
		else
		{
			i++;
		}
	}


	/*unsigned long hashValueActual_1 = hash1(value);
	unsigned long hashValueIndex = hashValueActual_1;

	if (hashTable[hashValueIndex]->key == hashValueActual_1 && hashTable[hashValueIndex]->value == value)
	{
		hashTable[hashValueIndex]->key = 1;
		hashTable[hashValueIndex]->value = "";

		count--;
		loadFactor();
		return;
	}
	else
	{
		bool found = true;
		unsigned long hashValueActual_2 = hash2(value);
		int i = 1;

		while(found)
		{
			if(hashTable[hashValueIndex]->key == hashValueActual_1)
			{
				if (hashTable[hashValueIndex]->value == value)
				{
					hashTable[hashValueIndex]->key = 1;
					hashTable[hashValueIndex]->value = "";
					count--;

					return;
				}
				else
				{
					hashValueIndex = (hashValueActual_1 + ( i * hashValueActual_2 )) % tableSize;
				}

			}
			else if(hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "")
			{
				return;
			}
			else
			{
				hashValueIndex = (hashValueActual_1 + ( i * hashValueActual_2 )) % tableSize;
			}
			i++;
		}
	}*/
	

    return;
}

block* HashD::lookup(string value)
{
	/*unsigned long h1 = hash1(value);
	unsigned long h2 = hash2(value);

	unsigned long index = 0;
	int i = 0;
	while(true)
	{
		index = h1 + ( h2 * i );
		index = index % tableSize;

		if (hashTable[index]->key == h1 && hashTable[index]->value == value)
		{
			return hashTable[index];
		}
		else if(hashTable[index] == 0 && hashTable[index]->value == "")
		{
			return NULL;
		}
		else
		{
			i++;
		}
	}*/


    unsigned long hashValueActual_1 = hash1(value);
	unsigned long hashValueIndex = hashValueActual_1;



	if (hashTable[hashValueIndex]->key == hashValueActual_1 && hashTable[hashValueIndex]->value == value)
	{
		return hashTable[hashValueIndex];
	}
	else
	{
		unsigned long hashValueActual_2 = hash2(value);
		int i = 1;

		bool found = true;
		while(found)
		{
			if (hashTable[hashValueIndex]->key == hashValueActual_1 && hashTable[hashValueIndex]->value == value)
			{
				return hashTable[hashValueIndex];
			}
			else if(hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "")
			{
				return NULL;
			}
			
			else
			{
				hashValueIndex = (hashValueActual_1 + ( i * hashValueActual_2 )) % tableSize;
			}
			i++;
		}
	}

	


}

void HashD::loadFactor()
{
	float LF = float(count)/float(tableSize);

	if (LF <= 0.38) //0.381
	{
		return;
	}
	else
	{
		resizeTable();
	}
}
#endif