#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"
#include <vector>

HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    count = 0;

    for (int i = 0; i < tableSize; i++)
	{
		hashTable[i] = new block(0,"");
	}
}

HashL::~HashL()
{
	for (int i = 0; i < tableSize; i++)
	{
		delete [] hashTable[i];
	}
	delete [] hashTable;
    
}

unsigned long HashL :: hash(string value)
{
	unsigned long hash_value = bitHash(value) * 37;
	unsigned long final_value = divCompression(hash_value, tableSize);
    return final_value;
}

void HashL::resizeTable()
{
	vector<string> hashTable_temp;

	for (int i = 0;i < tableSize; i++)
	{
		if (( hashTable[i]->key == 0 &&  hashTable[i]->value != "")  || (hashTable[i]->key == 1 && hashTable[i]->value != "" ) || hashTable[i]->key !=0)
		{
			hashTable_temp.push_back(hashTable[i]->value);
		} 
		
	}


	tableSize = tableSize*3; //2.9
	hashTable = new block*[tableSize];

	for (int i = 0; i < tableSize; i++)
	{
		hashTable[i] = new block(0,"");
	}

	//cout << count << endl;
	count = 0;
	for (int i = 0; i < hashTable_temp.size(); i++)
	{
		insert(hashTable_temp[i]);
	}

    return;
}

void HashL::insert(string value)
{
	unsigned long hashValueActual = hash(value);

	unsigned long hashValueIndex = hashValueActual;

	bool found = true;
	while(found)
	{
		if( (hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "") || (hashTable[hashValueIndex]->key == 1 && hashTable[hashValueIndex]->value == "" ) ) //1 is the special marker for skipping
		{
			hashTable[hashValueIndex]->key = hashValueActual;
			hashTable[hashValueIndex]->value = value;

			count++;
			loadFactor();
			//vals.push_back(value);
			return;

		}
		else if(hashTable[hashValueIndex]->key == hashValueActual)
		{
			if (hashTable[hashValueIndex]->value == value)
			{
				return;
			}
			else
			{
				hashValueIndex = (hashValueIndex + 1) % tableSize;
			}

		}
		else
		{
			hashValueIndex = (hashValueIndex + 1) % tableSize;
		}
	    
	}
	return;
}

void HashL::deleteWord(string value)
{
	unsigned long hashValueActual = hash(value);
	unsigned long hashValueIndex = hashValueActual;

	bool found = true;
	while(found)
	{
		if (hashTable[hashValueIndex]->key == hashValueActual && hashTable[hashValueIndex]->value == value)
		{
			hashTable[hashValueIndex]->key = 1;
			hashTable[hashValueIndex]->value = "";

			count--;
			loadFactor();
			return;
		}
		else if(hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "")
		{
			return;
		}
		else
		{
			hashValueIndex = (hashValueIndex + 1) % tableSize;
		}
	}

    return;
}
block* HashL::lookup(string value)
{
	unsigned long hashValueActual = hash(value);
	unsigned long hashValueIndex = hashValueActual;

	bool found = true;
	while(found)
	{
		if (hashTable[hashValueIndex]->key == hashValueActual && hashTable[hashValueIndex]->value == value)
		{
			//cout << hashTable[hashValueIndex]->value << endl;
			return hashTable[hashValueIndex];
		}
		else if(hashTable[hashValueIndex]->key == 0 && hashTable[hashValueIndex]->value == "")
		{
			/*cout << endl;
			cout << "NULL" << endl;
			cout << value << endl;
			cout << endl;*/

			return NULL;
		}
		/*else if(hashTable[hashValueIndex]->key != hashValueActual)
		{
			return NULL;
		}*/
		else
		{
			hashValueIndex = (hashValueIndex + 1) % tableSize;
		}
	}


    return NULL;
}

void HashL::loadFactor()
{
	float LF = float(count)/float(tableSize);

	if (LF <= 0.38) //0.381
	{
		return;
	}
	else
	{
		resizeTable();
	}
}
#endif
