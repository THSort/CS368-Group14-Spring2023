#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]= NULL;
    }
    count = 0;
}

HashL::~HashL(){
    delete[] hashTable;
}

unsigned long HashL :: hash(string value){
    unsigned long hash_code = bitHash(value);
    unsigned long compressed_hash = divCompression(hash_code, tableSize);
    return compressed_hash;
}

void HashL::resizeTable(){
    if (count > tableSize/2)
    {
        long old_size=tableSize;
        tableSize*=2;

        block** new_table = new block*[tableSize];
        for(int i=0; i<tableSize; i++)
        {
            new_table[i]= NULL;
        }

        for (int i=0; i<old_size; i++)
        {
            if(hashTable[i]!=NULL)
            {
                string myvalue= hashTable[i]->value;
                unsigned long new_hash = hash(myvalue);
                for (int i=0; i<tableSize; i++)
                {
                    if (new_table[(new_hash+i)%tableSize] == NULL)
                    {
                        new_table[(new_hash+i)%tableSize] = new block(new_hash, myvalue);
                        break;
                    }
                }
            }
        }
        delete[] hashTable;
        hashTable=new_table;
    }
}

void HashL::insert(string value){
    unsigned long hash_value = hash(value);
    for (int i=0; i<tableSize; i++)
    {
        if (hashTable[(hash_value+i)%tableSize] == NULL)
        {
            hashTable[(hash_value+i)%tableSize] = new block(hash_value, value);
            count++;
            break;
        }
        else if (hashTable[(hash_value+i)%tableSize]->key == -5)
        {
            hashTable[(hash_value+i)%tableSize]->key=hash_value;
            hashTable[(hash_value+i)%tableSize]->value=value;
            count++;
            break;
        }
    }

    if (count > tableSize/2)
    {
        resizeTable();
    }
}

void HashL::deleteWord(string value){
    block* x = lookup(value);
    if(x!=NULL)
    {
        x->key = -5;
        x->value = "";
        count--;
    }
}

block* HashL::lookup(string value){
    unsigned long hash_value = hash(value);
    for (int i=0; i<tableSize; i++)
    {
        if(hashTable[(hash_value+i)%tableSize] != NULL)
        {
            if (hashTable[(hash_value+i)%tableSize]->value == value)
            {
                return hashTable[(hash_value+i)%tableSize];
            }
        }
        else
        {
            return NULL;
        }
    }
}
#endif
