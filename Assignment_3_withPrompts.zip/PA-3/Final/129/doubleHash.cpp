#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]= NULL;
    }
    count = 0;
}

HashD::~HashD(){
    delete[] hashTable;
}

unsigned long HashD :: hash1(string value){
    unsigned long hash_code = bitHash(value);
    unsigned long compressed_hash = divCompression(hash_code, tableSize);
    return compressed_hash;
}

unsigned long HashD :: hash2(string value){
    unsigned long hash_code = 7-bitHash(value)%7;
    unsigned long compressed_hash = divCompression(hash_code, tableSize);
    return compressed_hash;
}

void HashD::resizeTable(){
    if (count > tableSize/2)
    {
        long old_size=tableSize;
        tableSize*=2;

        block** new_table = new block*[tableSize];
        for(int i=0; i<tableSize; i++)
        {
            new_table[i]= NULL;
        }

        for (int i=0; i<old_size; i++)
        {
            if(hashTable[i]!=NULL)
            {
                string myvalue= hashTable[i]->value;
                unsigned long hash_value1 = hash1(myvalue);
                unsigned long hash_value2 = hash2(myvalue);

                for (int i=0; i<tableSize; i++)
                {
                    if (new_table[(hash_value1+i*hash_value2)%tableSize] == NULL)
                    {
                        new_table[(hash_value1+i*hash_value2)%tableSize] = new block(hash_value1, myvalue);
                        break;
                    }
                }
            }
        }
        delete[] hashTable;
        hashTable=new_table;
    }
}

void HashD::insert(string value){
    unsigned long hash_value1 = hash1(value);
    unsigned long hash_value2 = hash2(value);
    for (int i=0; i<tableSize; i++)
    {
        if (hashTable[(hash_value1+i*hash_value2)%tableSize] == NULL)
        {
            hashTable[(hash_value1+i*hash_value2)%tableSize] = new block(hash_value1, value);
            count++;
            break;
        }
        else if (hashTable[(hash_value1+i*hash_value2)%tableSize]->key == -5)
        {
            hashTable[(hash_value1+i*hash_value2)%tableSize]->key=hash_value1;
            hashTable[(hash_value1+i*hash_value2)%tableSize]->value=value;
            count++;
            break;
        }
    }

    if (count > tableSize/2)
    {
        resizeTable();
    }
}

void HashD::deleteWord(string value){
    block* x = lookup(value);
    if(x!=NULL)
    {
        x->key = -5;
        x->value = "";
        count--;
    }
}

block* HashD::lookup(string value){
    unsigned long hash_value1 = hash1(value);
    unsigned long hash_value2 = hash2(value);
    for (int i=0; i<tableSize; i++)
    {
        if(hashTable[(hash_value1+i*hash_value2)%tableSize] != NULL)
        {
            if (hashTable[(hash_value1+i*hash_value2)%tableSize]->value == value)
            {
                return hashTable[(hash_value1+i*hash_value2)%tableSize];
            }
        }
        else
        {
            return NULL;
        }
    }
}

#endif
