#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"


HashC::HashC(int size){
    tableSize = size;
    hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
    unsigned long hash_code = bitHash(input);
    unsigned long compression_func = divCompression(hash_code, tableSize);
    return compression_func;
}

void HashC::insert(string word){
    unsigned long hash_value = hash(word);
    if (hashTable[hash_value].searchFor(word)==NULL)
    {
        hashTable[hash_value].insertAtHead(word);
    }
}

ListItem<string>* HashC :: lookup(string word){
    unsigned long hash_value = hash(word);
    return hashTable[hash_value].searchFor(word);
}

void HashC :: deleteWord(string word){
    unsigned long hash_value = hash(word);
    hashTable[hash_value].deleteElement(word);
}

#endif
