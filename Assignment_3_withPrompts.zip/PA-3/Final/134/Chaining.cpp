#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

using namespace std;

HashC::HashC(int size)
{
	tableSize =size;
	hashTable= new LinkedList<string> [tableSize];


}
HashC::~HashC()
{
	delete [] hashTable;

}

unsigned long HashC :: hash(string input)
{
	return madCompression(polyHash(input,5),tableSize,1993,1637);

}

void HashC::insert(string word)
{
	hashTable[hash(word)].insertAtHead(word);

}

ListItem<string>* HashC :: lookup(string word)
{
	return hashTable[hash(word)].searchFor(word);

}

void HashC :: deleteWord(string word)
{
	LinkedList<string>* temp=&hashTable[hash(word)];
	while(temp->searchFor(word)!=NULL)
	{
		temp->deleteElement(word);
	}

}

/*int main()
{

}*/

#endif
