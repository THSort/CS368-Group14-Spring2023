#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable= new block* [tableSize]();
    count =0;
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){
	return polyHash(value,5),tableSize,1993,1637);
}

unsigned long HashD :: hash2(string value){
    return bitHash(value,5),tableSize,1993,1637);
}

void HashD::resizeTable()
{
	long prev=tableSize;
	if(count < tableSize/3)
	{
		tableSize/=2;
		block** temp= hashTable;
		hashTable= new block*[tableSize]();
		count=0;
		for(int i=0; i<prev; i++)
		{
			if(temp[i]!=NULL)
			{
				unsigned long t=hash1(value);
				int j=0;
				while(hashTable[t]!=NULL)
				{
					t=divCompression(hash1(value)+i*hash2(value));
					j++;
				}

				hashTable[t]=temp[i];
				count++;

			}
		}
	}	


	else if(count > tableSize/2)
	{
		tableSize*=2;
		block** temp= hashTable;
		hashTable= new block*[tableSize]();
		count=0;
		for(int i=0; i<prev; i++)
		{
				if(temp[i]!=NULL)
				{
					unsigned long t=hash1(value);
					int j=0;
					while(hashTable[t]!=NULL)
					{
						t=divCompression(hash1(value)+i*hash2(value));
						j++;
					}

					hashTable[t]=temp[i];
					count++;
				}	

			}
			
		}
	}

	else {}	
	return;

}	
 
}

void HashD::insert(string value)
{
	if(lookup(value)==NULL)
	{
		unsigned long t=hash1(value);
		int i=0;
		while(hashTable[t]!=NULL)
		{
			t=divCompression(hash1(value)+i*hash2(value));
			i++;
		}

		hashTable[t]=new block(t,value);
		count++;
	}

	resizeTable();
	return;	
 
}

void HashD::deleteWord(string value)
{
	delete lookup(value);
	count--;
	resizeTable();
    return;	
}

block* HashD::lookup(string val)
{
	unsigned long t=hash1(val);
	block* found=NULL;
	if(count ==0 || hashTable[t]==NULL)
	{}

    else if(hashTable[t]->value==val)
    {
    	found=hashTable[t];
    }

    else
    {
    	int i=1;
		while(hashTable[t]!=value)
		{
			t=divCompression(hash1(value)+i*hash2(value));
			i++;
		}

		found=hashTable[t];
    }
    return found;	

}

#endif