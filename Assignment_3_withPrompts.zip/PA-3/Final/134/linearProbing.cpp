#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL()
{
    tableSize = 1000; // you cant change this
    hashTable= new block* [tableSize]();
    count =0;
}

HashL::~HashL()
{
    
}

unsigned long HashL :: hash(string value)
{
    return madCompression(polyHash(value,5),tableSize,1993,1637);
}

void HashL::resizeTable()
{
	long prev=tableSize;
	if(count < tableSize/3)
	{
		tableSize/=2;
		block** temp= hashTable;
		hashTable= new block*[tableSize]();
		count=0;
		for(int i=0; i<prev; i++)
		{
			if(temp[i]!=NULL)
			{
				//cout<<temp[i]->value <<" place from "<<i;
				unsigned long t=hash(temp[i]->value);
				for(int j=t; j<(tableSize);j++)
				{
					if(hashTable[j]==NULL)
					{
						hashTable[j]=temp[i];
						count++;
						//cout<<" to"<<j<<endl;
						temp[i]=NULL;
						break;
					}

				}
			}
		}
	}	


	else if(count > tableSize/2)
	{
		tableSize*=2;
		block** temp= hashTable;
		hashTable= new block*[tableSize]();
		count=0;
		for(int i=0; i<prev; i++)
		{
			if(temp[i]!=NULL)
			{
				//cout<<temp[i]->value<<" place from "<<i;
				unsigned long t=hash(temp[i]->value);
				for(int j=t; j<tableSize; j++)
				{
					if(hashTable[j]==NULL)
					{
						hashTable[j]=temp[i];
						count++;
						temp[i]=NULL;
						//cout<<" to"<<j<<endl;
						break;
					}

				}
			}
		}
	}

	else {}	
	return;

}


void HashL::insert(string value)
{
	if(lookup(value)==NULL)
	{
		unsigned long t=hash(value);
		for(int i=t; i<tableSize; i++)
		{
			if (hashTable[i]==NULL)
			{
				//cout<<"need to insert "<<value<<" and found "<<hashTable[i]<<" to be NULL on key "<<i<<endl;
				hashTable[i]=new block(t,value);
				count++;
				break;	
			}

		}
	}
	resizeTable();
	/*cout<<endl<<endl<<endl;
	for(int i=0; i<tableSize; i++)
	{
		if(hashTable[i]!=NULL)
		{
			cout<<"At address "<<hashTable[i]<<" "<<hashTable[i]->value<<" on index "<<i<<endl;
		}
	}*/
	return;
}

void HashL::deleteWord(string value)
{
	delete lookup(value);
	count--;
	resizeTable();
    return;
}

block* HashL::lookup(string val)
{
	unsigned long t=hash(val);
	block* found=NULL;
	if(count ==0 || hashTable[t]==NULL)
	{}

    else if(hashTable[t]->value==val)
    {
    	found=hashTable[t];
    }

    else
    {
    	for(int i=t; t<tableSize; t++)
    	{
    		if(hashTable[i]->value==val)
    		{
    			found=hashTable[i];
    			break;
    		}
    	}
    }
    return found;
}

/*int main()
{

}*/


#endif
