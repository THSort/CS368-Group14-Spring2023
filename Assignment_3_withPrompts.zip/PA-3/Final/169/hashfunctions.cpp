#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	char temp;
	unsigned long hashpiyo = 0;
	for(int i=0; i<value.length(); i++){
		temp = value[i];
		hashpiyo = hashpiyo + temp*(a^(value.length()-i-1));
	}
	return hashpiyo;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	unsigned long hashloif = 0;
	char yea;
	for(int i=0; i<value.length(); i++){
		yea = value[i];
		hashloif ^= (hashloif<<5) + (hashloif>>2) + yea;
	}
	return hashloif;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return hash%size;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
	return (hash*m +a)%size;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
