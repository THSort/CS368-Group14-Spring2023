#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize = size;
	hashTable = new LinkedList <string> [size];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
  return divCompression(bitHash(input), tableSize);
}


void HashC::insert(string word){
	hashTable[hash(word)].insertAtHead(word);
	return;
}

ListItem<string>* HashC :: lookup(string word){
	return hashTable[hash(word)].searchFor(word);
}

void HashC :: deleteWord(string word){
	hashTable[hash(word)].deleteElement(word);
	return;
}
#endif
