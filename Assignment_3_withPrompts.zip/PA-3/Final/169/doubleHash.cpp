#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    count = 0;
    tableSize = 10000; // you cant change this
    hashTable = new block* [tableSize];
    for (int i=0; i<tableSize; i++){
		hashTable[i] = NULL;
	}
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){
    return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return bitHash(value);
}

void HashD::resizeTable(){
    return;
}

void HashD::insert(string value){
	unsigned long hashis = hash1(value);
	if(hashTable[hashis] != NULL){
		for(int i=1; hashTable[hashis]!=NULL; i++){
			hashis = hashis + i*bitHash(value);
		}
	}
	hashTable[hashis]->key = hashis;
	hashTable[hashis]->value = value;
    return;
}

void HashD::deleteWord(string value){
    unsigned long key1 = hash1(value);
    if(count == 0){
    	return;
    }
    else if(hashTable[key1] == NULL){
    	return;
    }
    else if(hashTable[key1]->value == ""){
    	return;
    }
    else if(hashTable[key1]->value == value){
    	hashTable[key1]->value = "";
    	count--;
    }
    else{
    	for(int i=0;; i++){
    		key1 = key1 + i*hash1(value);
    		if(hashTable[key1]->value == value){
    			hashTable[key1]->value = "";
    			count--;
    			break;
    		}
    	}
    }
    resizeTable();
    return;
}

block* HashD::lookup(string value){
	block* point;
	unsigned long p = hash1(value);
	if(count == 0){
		return NULL;
	}
	else if(hashTable[p]->value == value){
		return hashTable[p];
	}
	else{
		for(int i=0;; i++){
    		p = p + i*hash1(value);
    		if(hashTable[p]->value == value){
    			return hashTable[p];
    		}
    	}
	}
    return NULL;
}

#endif
