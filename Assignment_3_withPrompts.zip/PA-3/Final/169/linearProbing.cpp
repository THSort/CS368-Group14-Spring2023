#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"

HashL::HashL(){
    tableSize = 1000; // you cant change this
	hashTable = new block* [tableSize];
	for (int i=0; i<tableSize; i++){
		hashTable[i] = NULL;
	}
	count = 0;
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
    long hashpi = bitHash(value);
    hashpi = divCompression(hashpi, tableSize);
    return hashpi;
}

void HashL::resizeTable(){
    return;
}

void HashL::insert(string value){
	unsigned long key = hash(value);
	if(hashTable[key] == NULL){
		hashTable[key] = new block (key, value);
		count++;
	}
	else if(key == tableSize-1){
		key = 0;
		if(hashTable[key] == NULL){
			hashTable[key] = new block (key, value);
			count++;
		}
		else{
			while(hashTable[key] != NULL){
				key++;
				if(key >= tableSize-1){
					key = 0;
				}
			}
			hashTable[key] = new block (key, value);
			count++;
		}
	}
	else{
		while(hashTable[key] != NULL){
			key++;
			if(key >= tableSize-1){
				key = 0;
			}
		}
		hashTable[key] = new block (key, value);
		count++;
	}
	resizeTable();
    return;
}

void HashL::deleteWord(string value){
    unsigned long key1 = hash(value);
    if(count == 0){
    	return;
    }
    else if(hashTable[key1] == NULL){
    	return;
    }
    else if(hashTable[key1]->value == ""){
    	return;
    }
    else if(hashTable[key1]->value == value){
    	hashTable[key1]->value = "";
    	count--;
    }
    else{
    	for(int i=0; i<tableSize; i++){
    		if(hashTable[i]->value == value){
    			hashTable[i]->value = "";
    			count--;
    		}
    	}
    }
    resizeTable();
    return;
}
block* HashL::lookup(string value){
	block* point;
	unsigned long p = hash(value);
	if(count == 0){
		return NULL;
	}
	else if(hashTable[p]->value == value){
		return hashTable[p];
	}
	else{
		if(tableSize/(p*1.0) < 0.8){
			for(int i =p ; i< tableSize; i++){
				if(hashTable[i]->value == value){
					return hashTable[i];
				}
			}
		}
		else{
			for(int i =p ; i< tableSize; i++){
				if(hashTable[i]->value == value){
					return hashTable[i];
				}
			}
			for(int i=0 ; i<(tableSize/10); i++){
				if(hashTable[i]->value == value){
					return hashTable[i];
				}
			}
		}
	}
    return NULL;
}
#endif
