#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD()
{
	tableSize = 10; // you cant change this
	hashTable = new block*[tableSize];
	count = 0;
}

HashD::~HashD()
{
	delete []hashTable;
}

long HashD::hash1(string value)
{
	long key = madCompression(bitHash(value),	tableSize);
	if (hashTable[key] == NULL)
		return key;
	else
	{	
		int i=1;
		while (hashTable[key] != NULL)
		{	
//			cout << value << i <<"<-----\n";
			key = madCompression((pow(7,i)*bitHash(value)),	tableSize);
			i++;
		}
		return key;
	}

}

long HashD::hash2(string value)
{
	return 0;
}

void HashD::resizeTable()
{
//	cout << tableSize << "__" << count*100/75 <<" ";	
	if(tableSize < count*100/75)
	{
		cout << "resizing to smth larger cuz! size and count are (respectively):\n";// size and count are: !\n";
		cout << tableSize << " " << count << endl;		
		block** oldtable = hashTable;
		long oldsize = tableSize;
		tableSize = tableSize*5/3;
		hashTable = new block*[tableSize];
		count = 0;
		cout << "NEW SIZE IS  GONNA BE " << tableSize << "while OLDSIZE IS " << oldsize << endl;

		for (int i=0; i<tableSize; i++)
		{
			hashTable[i]=NULL;
		}
		
		for (int i=0; i<oldsize; i++)
		{	
			for (int j=0; j<6000; j++)
			{
				cout  << oldsize << " " << i << ".";
			}

			insert(oldtable[i]->value);
		}
//		delete []oldtable;
	}
}

void HashD::resizeTableDec()
{
	return;
}

void HashD::insert(string value)
{
	long key = hash1(value);
	if (hashTable[key])
		cout << "WTF @ BUGGGSZZY!!?!\nMissionAbortHoeee-----\n";
	hashTable[key] = new block(key, value);
//	cout << "Inserted @ key " << key << endl;
	count++;
	resizeTable();
}

void HashD::deleteWord(string value)
{
	block* ptr = lookup(value);

	if(ptr)
	{
		cout << "key: " << ptr->key << " value: " << ptr->value;
		delete ptr;
		count--;
		ptr = new block(-1, "nothing here gud bii thnx\n");
		// cout << "key: " << ptr->key << " value: " << ptr->value;
		resizeTableDec();
		return;
	}
	else
	{
		cout << "SAID value prolly dunt exist\n";
		return;
	}
}

block* nullptr()
{
	cout << "SAID VALUE dunt exist bitxh\n";
	return NULL;
}

block* HashD::lookup(string value)
{
	long key = madCompression(bitHash(value),	tableSize);
	if (hashTable[key] == NULL)
		return nullptr();

	if (hashTable[key]->value == value)
		return hashTable[key];
	else
	{	
		int i=1;
		while (hashTable[key]->value != value)
		{	
			key = madCompression((pow(7,i)*bitHash(value)),	tableSize);
			i++;
			if(hashTable[key] == NULL)
				return nullptr();
		}
		return hashTable[key];
	}

}

void HashD::printHash()
{
	cout << "\n\nCount: " << count << " while Table Size: " << tableSize << endl;
	for (int i=0; i < tableSize; i++)
	{
		cout <<"starting printi func ka loop\n";
		cout << "---" << i << "--  ";
		// for (int j=0; j<5000000; j++)
		// {}

	cout << "quirk checkkkk";
		if (hashTable[i] != NULL)
			if(hashTable[i]->key == -1)
				cout <<"WERKKK";


		

		if (hashTable[i])
				cout << i << ") "<< hashTable[i]->key << ", " << hashTable[i]->value << endl;

		cout <<"exiting printi func ka loop\n";
	}
}

#endif


int main()
{
	cout << "gud scene\n\n";

	HashD dicc;
	dicc.insert("lolzie");
//	dicc.printHash();
	dicc.insert("big dicky");
	dicc.insert("lolzie");
	dicc.insert("smol dicky");
	dicc.insert("polzie");
	dicc.insert("big dicky");
//	dicc.printHash();
	dicc.deleteWord("big dicky");
//	dicc.printHash();
	dicc.insert("bicsdcky");
	dicc.insert("asdxwsdfw");
	dicc.insert("tttt");
	dicc.insert("v");
	dicc.insert("phido");
	dicc.insert("tytz");
	dicc.insert("bunty");

//	cout << endl << dicc.lookup("lolzie")->key;



return 0;
}