#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

using namespace std;
#include <iostream>
#include <stack>

template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	this->head=NULL;
	ListItem<T> *tracker=otherLinkedList.head;
	if (tracker)
	{
		insertAtHead(tracker->value);
		tracker=tracker->next;
		while (tracker)
		{
			insertAtTail(tracker->value);
			tracker=tracker->next;
		}
	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	if (this->head)
	{
		ListItem<T> *tracker=head;
		while (tracker->next!=NULL)
		{
			tracker=tracker->next;
		}
		while (tracker->prev!=NULL)
		{
			tracker=tracker->prev;
			delete tracker->next;
		}
		delete tracker;
		this->head=NULL;
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> *temp= new ListItem<T>(item);
	temp->prev=NULL;
	temp->next=NULL;
	if (head)
	{
		temp->next=this->head;
		this->head->prev=temp;
	}
	head = temp;
//	cout << "Werks";
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if (this->head==NULL)
	{
//		cout << "ERROR, List is empty. Add first node at head first\n";
		return;
	}
    ListItem<T> *tracer=this->head;

	ListItem<T> *temp=new ListItem<T>(item);
	while (tracer->next!=NULL)
	{
		tracer=tracer->next;
	}//pointer tracer should now point to the last node of the list
	tracer->next=temp;
	temp->prev=tracer;
	temp->next=NULL;
}
template <class T>
void LinkedList<T>::displaylist()
{
//	this->head=NULL;
	if (this->head ==NULL)
	{
		cout <<"ERROR,(display) list empty----\n";
		return;
	}

	else
	{	
		ListItem<T> *tracer=this->head;
		while (tracer!=NULL)
		{
			cout << tracer->value << "->";
			tracer=tracer->next;
		}
		cout << "\n";
	}


}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	if (this->head == NULL)
	{
		//cout << "ERROR (insertAfter) link doesnt exist\n";
		return;
	}
	ListItem<T> *tracker=this->head;
	while (tracker->value!= afterWhat)
	{
		tracker=tracker->next;
		if (tracker==NULL)
		{
		//	cout << "ERROR! (afterWhat) node doesnt exist\n";
			return;
		}
	}
	ListItem<T> *temp= new ListItem<T>(toInsert);
	temp->next=tracker->next;
	if (tracker->next!=NULL)
		tracker->next->prev=temp;
	temp->prev=tracker;
	tracker->next=temp;
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem<T> *tracer=this->head;
	if (!tracer)
	{
	//	cout <<"BOOO--";
		insertAtHead(item);
	}
	else if (tracer->value > item)
	{
	//	cout << "BEEE---";
		this->insertAtHead(item);
	}
	else
	{
		if (! tracer->next)
		{
			insertAtTail(item);
			return;
		}
		//cout << "bazinga---";
		while (tracer->next->value < item)
		{
			tracer=tracer->next;
			if (tracer->next==NULL)
			{
				insertAtTail(item);
				return;
			}
		}
		ListItem<T> *temp=new ListItem<T>(item);
		temp->next=tracer->next;
		temp->prev=tracer;
		tracer->next=temp;
		temp->next->prev=temp;

	}
}


template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	if (!this->head)
		return NULL;
	else
		return this->head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if (!this->head)
		return NULL;
	else if(this->head->next==NULL)
		return this->head;
	else
	{
		ListItem<T> *tracer=this->head;
		while (tracer->next!=NULL)
		{
			tracer=tracer->next;
		}
		return tracer;
	}
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	if (!this->head)
		return NULL;
	else
	{
		ListItem<T> *tracer=this->head;
		while (tracer->value!=item)
		{
			tracer=tracer->next;
			if (tracer==NULL)
			{
				//cout << "ERROR, item does not exist\n";
				return NULL;
			}
		}
		return tracer;
	}
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if (!head)
	{
		cout << "ERROR Element does not exist\n";
		return;
	}
	ListItem<T> *tracker=this->head;
	while (tracker->value!=item)
	{
		tracker=tracker->next;
		if (tracker==NULL)
		{
			cout << "ERROR (delval) doesnt not exist\n";
			return;
		}
	}
	if (tracker->prev==NULL)
	{
		deleteHead();
	}
	else if (tracker->next==NULL)
	{
		deleteTail();
	}
	else
	{
		tracker->next->prev=tracker->prev;
		tracker->prev->next=tracker->next;
		delete tracker;
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	ListItem<T> *tracker=this->head;
	if (!head)
	{
//		cout << "ERROR delhead list is empty\n";
		return;
	}
	tracker=head->next;
	if (tracker)
	{
		tracker->prev=NULL;
	}
	delete head;
	head = tracker;
}
 
template <class T>
void LinkedList<T>::deleteTail()
{
	if (!head)
	{
//		cout << "ERROR (deltail) list is empty\n";
		return;
	}
	else if (head->next==NULL)
	{
		delete this->head;
		head=NULL;
		return;
	}
	else
	{
		ListItem<T> *tracker=this->head;
		while(tracker->next!=NULL)
		{
			tracker=tracker->next;
		}
		tracker=tracker->prev;
		delete tracker->next;
		tracker->next=NULL;
	}
}

template <class T>
int LinkedList<T>::length()
{
	int counter=0;
	ListItem<T> *tracker=this->head;
	while (tracker!=NULL)
	{
		counter++;
		tracker=tracker->next;
	}
	return counter;
}

template <class T>
void LinkedList<T>::reverse()
{
	if (this->head==NULL || this->head->next==NULL)//list does not require reversing
	{
		return;
	}
	ListItem<T> *tracker=this->head;
	ListItem<T> *tracker2=tracker->next;
	tracker->next=NULL;
	tracker->prev=tracker2;
	while (tracker2)
	{
		tracker2->prev=tracker2->next;
		tracker2->next=tracker;
		tracker=tracker->prev;
		tracker2=tracker2->prev;
	}
	head=tracker;

}

template <class T>
void LinkedList<T>::parityArrangement()
{
	ListItem<T> *tracker=this->head;
	if (! tracker)
		return;

	tracker=tracker->next;
	for (int a=1; a*2<=length() && (tracker->next)	; a++)
	{
		insertAtTail(tracker->value);
		tracker->next->prev=tracker->prev;
		tracker=tracker->next;
		delete tracker->prev->next;
		tracker->prev->next=tracker;
		tracker=tracker->next;
	}
}
template <class T>
bool LinkedList<T>::isPalindrome()
{
	if (! this->head)
		return false;
	ListItem<T> *ptrfront=getHead();
	ListItem<T> *ptrback=getTail();
	for (int a=0; 2*a < length(); a++)
	{	
		if(ptrback->value!=ptrfront->value)
			return false;
		ptrfront=ptrfront->next;
		ptrback=ptrback->prev;
	}
	return true;

}

#endif/*
int main()
{
	LinkedList<int> rocco;
	rocco.displaylist();
	rocco.insertAtHead(1);
	rocco.displaylist();
	rocco.insertSorted(2);
	rocco.displaylist();
	rocco.insertSorted(3);
	rocco.displaylist();

//	rocco.insertAtTail(3);
//	rocco.insertAfter(5, 4);
	rocco.insertAtTail(2);
	rocco.insertAtTail(1);
	// rocco.deleteElement(55);
	// rocco.parityArrangement();
	rocco.displaylist();
	if (rocco.isPalindrome())
		cout << "eee yussss\n";
	else
		cout<< "NO lol\n";
	LinkedList<int> bazooka(rocco);
	bazooka.displaylist();
return 0;
}*/