#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <iostream>
#include <math.h>
using namespace std;

// this takes in a string and returns a 64bit hash.
unsigned long polyHash(string value, int a = 5)
{
	unsigned long hashval = 0;
	for (int i=0; i<value.length(); i++)
	{
		hashval += value[i]*(	pow(a,i)	);
	}
	return hashval;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(string value)
{
	unsigned long bithashval = 0;
	for (int i=0l; i<value.length(); i++)
	{
		bithashval ^= (bithashval << 5) + (bithashval >> 2) + value[i];
	}
	return bithashval;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size)
{
	unsigned long ret = hash%size;
	return ret;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637)
{
	unsigned long ret = (hash*m + a)%size;
	return ret;
}
// 'm' and 'a' can take any value
#endif

// you may write your own program to test these functions.
// int main()
// {
// 	cout << polyHash("ab") << endl;

// return 0;
// }
