#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
	tableSize = size;
	hashTable = new LinkedList<string>[size];

}
HashC::~HashC()
{
		delete [] hashTable;
}

unsigned long HashC::hash(string input)
{
	return madCompression(bitHash(input),	tableSize);
}

void HashC::insert(string word)
{
	long hashvalue = hash(word);
	hashTable[hashvalue].insertAtHead(word);
}

ListItem<string>* HashC :: lookup(string word)
{
	long hashvalue = hash(word);
	ListItem<string>* ptr = hashTable[hashvalue].getHead();
	while(ptr)
	{
		if(ptr->value == word)
			break;
		ptr = ptr->next;
	}
	return ptr;
}

void HashC :: deleteWord(string word)
{
	long hashvalue = hash(word);
//	ListItem<string>* ptr = hashTable[hashvalue].getHead();
	hashTable[hashvalue].deleteElement(word);
}

void HashC::printHash()
{
	for (int i=0; i<tableSize; i++)
	{
		cout << i+1 << " ";
		hashTable[i].displaylist();
		cout << endl;
	}	
}

#endif

// int main()
// {
// 	HashC Jay(7);
// 	Jay.insert("cat");
// 	Jay.insert("alol");
// 	Jay.insert("blol");
// 	Jay.insert("all");
// 	Jay.insert("alpha");
// 	Jay.insert("beta");
// 	Jay.printHash();
// 	Jay.deleteWord("cat");
// 	Jay.printHash();

// //	cout << Jay.lookup("cat")->value;
// return 0;
// }

