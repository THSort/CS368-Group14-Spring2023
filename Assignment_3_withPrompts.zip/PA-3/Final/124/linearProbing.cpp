#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


#include <fstream>
#include <vector>
#include <stdlib.h>

HashL::HashL(){
	tableSize = 1000; // you cant change this
	count = 0;
	hashTable = NULL;
	hashTable = new block*[tableSize];
	for (int i = 0; i < tableSize; i++)
	{
		hashTable[i] = NULL;
	}
}

HashL::~HashL()
{
	// for (int i=0; i<tableSize; i++)
	// {
	// 	delete hashTable[i];
	// }
	delete []hashTable;
}

long HashL::hash(string value)
{
	return madCompression(bitHash(value),	tableSize);
}

void HashL::resizeTable()
{
	//cout << "--- " << count << "---\n";
	if(tableSize == count)
	{
		cout << "resizing to smth larger cuz! size and count are (respectively):\n";// size and count are: !\n";
		cout << tableSize << " " << count << endl;		
		block** oldtable = hashTable;

		long oldsize = tableSize;
		tableSize *= 2;
		hashTable = new block*[tableSize];
		count = 0;
//		cout << "NEW SIZE IS  GONNA BE " << tableSize << "while OLDSIZE IS " << oldsize << endl;
		for (int i=0; i<tableSize; i++)
		{
			hashTable[i]= NULL;
			
			// if (i < oldsize && oldtable[i]	&&	oldtable[i]->key > 0)
			// 	insert(oldtable[i]->value);
			// if (hashTable[i]== NULL)
			// 	cout << i << "-yea\n";
			// else
			// 	cout << hashTable[i]->key << endl;
		}
		
		for (int i=0; i<oldsize; i++)
		{
			if (oldtable[i]->key > 0)
				insert(oldtable[i]->value);
		}
//		cout << "********\n";

		delete []oldtable;
	}
}

void HashL::resizeTableDec()
{
//	cout << "TSize is " << tableSize << " while count: " << count << endl;
	if(tableSize > 1700 && 3*count < tableSize)
	{
		// cout << "resizing to smth smolr cuz y not, size n count are: \n";
		// cout << tableSize << " " << count << endl;
		block** oldtable = hashTable;
		long oldsize = tableSize;
		tableSize = tableSize*6/10;
		hashTable = new block*[tableSize];
		count = 0;

		for (int i=0; i<oldsize; i++)
		{	
			if (oldtable[i]	&&	oldtable[i]->key > 0)
				insert(oldtable[i]->value);
		}

		delete []oldtable;
	}

}
void HashL::insert(string value)
{
	long key = hash(value);
	block** ptr = &(hashTable[key]);
	int i=0;
	while(*ptr != NULL)
	{
		if((*ptr)->key == -1)
		{
			delete *ptr;
			break;
		}
		if(	*ptr == hashTable[tableSize-1])
			ptr = &hashTable[0];
		else
			ptr++;

	}

	*ptr = new block(key, value);
	count++;
	if (count == tableSize)
		resizeTable();
}

void HashL::deleteWord(string value)
{
	block* ptr= lookup(value);
	if (ptr)
	{
		count--;
//		delete ptr;
		ptr->key = -1;
		ptr->value = "block doesn't rlly exist tbh but used to";
		if(tableSize > 1700 && 3*count < tableSize)
			resizeTableDec();
	}

}
block* HashL::lookup(string value)
{
	long key = hash(value);
	block** ptr = &(hashTable[key]);
	if (!ptr)
	{
		cout << "error: key doesn't existed\n";
		return NULL;
	}
	if(	(*ptr)->value == value)
		return *ptr;

	while(	(*ptr)->value != value)
	{
		if(	*ptr == hashTable[tableSize-1])
			ptr = &hashTable[0];
		else
			ptr++;

		if (*ptr == NULL)
			return NULL;
	}

	return *ptr;
}

void HashL::printHash()
{
	cout << "\n\nCount: " << count << " while Table Size: " << tableSize << endl;
	for (int i=0; i < tableSize; i++)
	{
//		if (i%20000 == 0)
			// if (hashTable[i])
			// 	cout << i << " ";
			// 	cout << i << ") "<< hashTable[i]->key << ", " << hashTable[i]->value << endl;
	}
}

#endif
/*
int main()
{
// 	ifstream file;
// 	file.open("bbkl.txt");
// 	cout << "LOADING THE FILE" << endl;
// 	string temp;
// 	vector<string> allWords;
//     vector<string> queries;

//     srand(time(NULL));
//     int i=0;
// //	queries.push_back("cat");
// 	while(!file.eof())
// 	{
// 		i++;
// 		file >> temp;
// 		allWords.push_back(temp);
// 		int x = rand()%5;
// 		if (i < 2)
// 		{
// 			queries.push_back(temp);
// 			// cout << i << "push back success!!";
// 		}
// 	}
// 	// for (int i=0; i<5000; i++)
// 	// 	cout << ".";
// 	file.close();
// 	cout << allWords.size() << " words loaded." << endl;
// //    timeOut = false;
// 	HashL* map = new HashL();

// 	for(int i=0;i<allWords.size();i++)
// 	{
// 		// if (i == 23)
// 		// 	break;

// 		map->insert(allWords[i]);
// 		// if(i>997)
// 		// {
// 		// 	cout << "----" << i << "----";	
// 		// 	map->printHash();
// 		// }
// 	}

// 	map->printHash();
//     for(int i=0;i<allWords.size();i++)
//     {
// 		if (i == 23)
// 			break;

// 		cout << "********\n";
//         if (!map->lookup(allWords[i]))
//         {
//             cout << "TEST FAILED\n" << "LOOKUP FAILED" << endl;
//             return 0;
//         }
//         if (map->lookup(allWords[i])->value != allWords[i]){
//             cout << "TEST FAILED\n" << "LOOKUP FAILED" << endl;
//             return 0;
//         }
//     }
//     cout << " lookup passed? :'(((\n";



	ifstream file;
	file.open("words.txt");
	cout << "LOADING THE FILE" << endl;
	string temp;
	vector<string> allWords;
    vector<string> queries;

    srand(time(NULL));
    int i=0;
//	queries.push_back("cat");
	while(!file.eof())
	{
		i++;
		file >> temp;
		allWords.push_back(temp);
		int x = rand()%5;
		if (i < 5)
		{
			queries.push_back(temp);
			// cout << i << "push back success!!";
		}
	}
	// for (int i=0; i<5000; i++)
	// 	cout << ".";
	file.close();
	cout << allWords.size() << " words loaded." << endl;
//    timeOut = false;
	HashL* map = new HashL();

	for(int i=0;i<allWords.size();i++)
	{
		if (i == 20000)
			break;

		map->insert(allWords[i]);
		// if(i>997)
		// {
		// 	cout << "----" << i << "----";	
		// 	map->printHash();
		// }
	}

	map->printHash();

    cout << "*****\n";
    for(int i=0;i<allWords.size();i++)
    {
		if (i == 20000)
			break;

        if (!map->lookup(allWords[i]))
        {
            cout << "TEST FAILED\n" << "LOOKUP FAILED" << endl;
            return 0;
        }
        if (map->lookup(allWords[i])->value != allWords[i]){
            cout << "TEST FAILED\n" << "LOOKUP FAILED" << endl;
            return 0;
        }
    }
    cout << " lookup passed? :'(((\n";

	// map->printHash();

return 0;
}
*/