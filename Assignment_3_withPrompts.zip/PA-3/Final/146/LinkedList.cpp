#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
	tail = NULL;
	size = 0;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{	
	head = NULL;
	tail = NULL;
	size = 0;

	ListItem<T>*temp =otherLinkedList.head;
	while (temp != NULL)
	{
		insertAtTail(temp->value);
		temp = temp->next;
	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> *temp = new ListItem<T>(item);
	if(head == NULL)
	{
		tail = temp;
		head = temp;
	}
	else
	{
		temp->next = head;
		head->prev = temp;
		head = temp;
	}
	size++;
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{

	ListItem<T> *temp = new ListItem<T>(item);
	if(tail == NULL)
	{
		tail = temp;
		head = temp;
	}
	else
	{
		temp->prev = tail;
		tail->next = temp;
		tail = temp;
	}
	size++;
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	if(tail->value == afterWhat )
	{
		insertAtTail(toInsert);
	}
	else
	{
		ListItem<T> *traverse = head;
		while(traverse->next != NULL)
		{
			if(traverse->value == afterWhat)
			{
				ListItem<T> *temp = new ListItem<T>(toInsert);
				temp->next = traverse->next;
				temp->prev = traverse->next->prev;
				traverse->next->prev = temp;
				traverse->next = temp;
				size++; 
				break;

			}
			traverse = traverse->next;
		}
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	if((head == NULL)||(item < head->value))
	{
		insertAtHead(item);
		return;
	}
	if(item >= tail->value)
	{
		insertAtTail(item);
		return;
	}
	else
	{	
		ListItem<T> *traverse = head->next;
		while(traverse != NULL)
		{
			if(traverse->value > item)
			{
				ListItem<T> *temp = new ListItem<T>(item);
				temp->next = traverse;
				temp->prev = traverse->prev;
				traverse->prev->next = temp;
				traverse->prev = temp;
				size++;
				break;

			}
			if(traverse->next == NULL)
				break;
			traverse = traverse->next;
		}
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	return tail;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	if(head == NULL)
		return NULL;
	ListItem<T>* traverse = head;
	while (traverse->next != NULL)
	{
		if(traverse->value == item)
			return traverse;
		traverse = traverse->next;
	}
	if(traverse->value == item)
		return traverse;
	return NULL;

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if(head != NULL)
	{
		if(head->value == item)
		{	
			deleteHead();
			return;
		}
		if(tail->value == item)
		{
			deleteTail();
			return;
		}
		else
		{
			
			ListItem<T>*temp = head;
			while(temp->next != NULL)
			{	
				if(temp->value == item)
				{
					temp->prev->next = temp->next;
					temp->next->prev = temp->prev;
					delete temp;
					size--;
					break;
				}
				temp = temp->next;
			}
		}
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if(head != NULL)
	{
		ListItem<T>*temp = head;
		head = head->next;
		if(head != NULL)
		{
			head->prev = NULL;
		}
		else
			tail = NULL;
		delete temp;
		size--;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	if(tail != NULL)
	{
		ListItem<T>*temp = tail;
		if(temp == head)
		{
			deleteHead();
			return;
		}
		tail = tail->prev;
		if(tail != NULL)
		{
			tail->next = NULL;
		}

		delete temp;
		size--;

	}
}

template <class T>
int LinkedList<T>::length()
{
	return size;
}

template <class T>
void LinkedList<T>::reverse()
{
	if((head == NULL)||(head->next == NULL))
		return;
	ListItem<T>* traverse = tail;
	ListItem<T>* temp;
	while(traverse != NULL)
	{
		temp = traverse->next;
		traverse->next = traverse->prev;
		traverse->prev = temp;
		if(traverse->next == NULL)
			break;
		traverse = traverse->next;
	}

	temp = head;
	head = tail;
	tail = temp;
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	int current_length = size;
	ListItem<T>* temp = head;
	for (int i=0; i< current_length; i++)
	{
		if((i%2) == 1)
		{
			insertAtTail(temp->value);
			ListItem<T>* node = temp;
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			temp = temp->next;
			size--;
			delete node;


		}
		else
		{
			temp = temp->next;
		}	
	}
}
template <class T>
bool LinkedList<T>::isPalindrome()
{
	if(size == 0)
		return 0;
	ListItem<T>*upper = head;
	ListItem<T>*lower = tail;
	for (int i=0 ; i< size; i++)
	{
		if(head->value != tail->value)
			return 0;
		head = head->next;
		tail = tail->prev;
		if((head == NULL)||(tail==NULL))
			break;
	}
	return 1;
}

#endif
