#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	unsigned long hash_key = 0;
	unsigned long amplitude = 1;
	int b = value.size();

	for(int i=0; i<b ; i++)
	{
		for(int j=0; j<(b-i-1); j++ )
		{
			amplitude = amplitude*a;
		}

		hash_key = hash_key + ((int)value[i])*amplitude;
	}

	return hash_key;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	int length = value.length();
	unsigned long hash_key = 0;

	for(int i = 0;i<length;i++)
	{
		hash_key = (hash_key<<5) + (hash_key>>2) + ((int) value[i]);
	}

	return hash_key;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return (hash%size);
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    return ((m*hash + a)%size);
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.