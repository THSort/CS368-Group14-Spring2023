#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	hashTable = new LinkedList<string>[size];
	tableSize = size;
    
}
HashC::~HashC(){
	delete[] hashTable;
}

unsigned long HashC :: hash(string input){
  return divCompression(bitHash(input),tableSize);  
}

void HashC::insert(string word){

	unsigned long location = hash(word);
	//LinkedList<string>* chain = &hashTable[location]; 
	if(hashTable[location].searchFor(word)){
		return;
	}else{
		hashTable[location].insertAtHead(word);
	}
		

}

ListItem<string>* HashC :: lookup(string word){
	unsigned long location = hash(word);
	return hashTable[location].searchFor(word);

}

void HashC :: deleteWord(string word){
	unsigned long location = hash(word);
	hashTable[location].deleteElement(word);
  return;
}

#endif