#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize;i++)
    {
    	hashTable[i] = NULL;
    }
    count =0;
}

HashD::~HashD(){
    delete[] hashTable;

}

unsigned long HashD :: hash1(string value){
    return divCompression(bitHash(value),tableSize);
}

unsigned long HashD :: hash2(string value){
    return polyHash(value);
}

void HashD::resizeTable(){
    
    unsigned long traverse = tableSize;
	
    if(count > (0.6*tableSize))
    {
        tableSize = tableSize*2;
    }
    else if(count < (0.2*tableSize))
    {
        tableSize = tableSize/2;
    }
    
    block** point = new block*[tableSize];
	for(int i=0; i< tableSize; i++)
		point[i] = NULL;
		
		
	unsigned long h1;
    unsigned long h2;
    unsigned long location = 0;
	int collision = 0;
	
	//cout << "hellow"<<endl;
	for (int i=0; i<traverse; i++ )
	{   
	    //cout << i<<endl;
	    if(hashTable[i]!=NULL)
	    {
	        //cout<<"entered"<<endl;
	        if(hashTable[i]->key != -1)
    	    {
    	       //cout<<"NOT"<<endl;    
    	        
    	        h1 = hash1(hashTable[i]->value);
    	        h2 = 113+hash2(hashTable[i]->value);
    	        location = h1;
    	        
    	       // if(location>tableSize-1)
    	       // {
    	       //     cout <<"masla "<<endl;
    	       // }
    	       // cout <<"locationh : "<<location<<"   tablke :  "<<tableSize<<endl;
    	        while(point[location]!=NULL)
    	        {   //cout <<"locationh : "<<location<<"   tablke :  "<<tableSize<<endl;
    	            collision++;
    	            
    	            location = (h1 + collision*h2)%tableSize;
    	           // if(location>tableSize-1)
    	           // {
    	           //     cout <<"masla "<<endl;
    	           // }
    	            
    	        }
    	        //cout <<"haha"<<endl;
    	        collision = 0;
    	        point[location] = new block(location,hashTable[i]->value);
	        }
	        
	    }
	}
	// cout<<"after resize "<<endl;
	hashTable = point;
    
    
    return;
}

void HashD::insert(string value){
    if(lookup(value)!=NULL){return;}

    if(count > (0.6*tableSize))
    {
        resizeTable();
    }
    unsigned long h1 = hash1(value);
    unsigned long h2 = (113+hash2(value));
    unsigned long location = h1;
    int i=0; //  collisions counter;
    while(hashTable[location]!=NULL)
    {
        i++;
        if(hashTable[location]->key == -1)
        {
            break;
        }
        location = (h1 + i*h2)%tableSize;
            
    }
    
    hashTable[location] = new block(location,value);
	count++;
    
    return;
}

void HashD::deleteWord(string value){
    block* node = lookup(value);
	if(node!= NULL)
	{
		node->key = -1;
		count--;
		if(count <= tableSize/4)
		{
			resizeTable();
		}
	}
    return;
}

block* HashD::lookup(string value){
    unsigned long h1 = hash1(value);
    unsigned long h2 = 113+hash2(value);
    unsigned long location = h1;
    unsigned long flag = location;
    int collision =0;
    while(hashTable[location]!=NULL)
    {
        if((hashTable[location]->value==value)&&(hashTable[location]->key!=-1))
        {
            return hashTable[location];
        }
        collision++;
        location = (h1 + collision*h2)%tableSize;
        if(location == flag)
        {
            return NULL;
        }
        
    }
    return NULL;
}

#endif