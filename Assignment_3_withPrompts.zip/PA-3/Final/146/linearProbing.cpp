#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i=0; i<tableSize;i++)
    {
    	hashTable[i] = NULL;
    }
    count = 0;
}

HashL::~HashL(){
    delete[] hashTable;
}

unsigned long HashL :: hash(string value){
    return divCompression(bitHash(value),tableSize);
}

void HashL::resizeTable(){

	long traverse = tableSize;
	unsigned long location = 0;

	if(count > (0.75*tableSize))
	{
		tableSize = tableSize*2;
	}
	else if(count < 0.25*tableSize)
	{
		tableSize = tableSize/2;
	}

	block** point = new block*[tableSize];
	for(int i=0; i< tableSize; i++)
		point[i] = NULL;

	for(int i=0; i< traverse; i++)
	{
		if((hashTable[i]!=NULL)&&(hashTable[i]->key != -1))
		{
			location = hash(hashTable[i]->value);
			while(point[location]!= NULL)
			{
				if(location == tableSize-1)
					location = -1;
				location++;
			}
			point[location] = hashTable[i];
			point[location]->key = location;
		}
	}
	hashTable = point;

    return;
}

void HashL::insert(string value){
	if(lookup(value)){
		return;
	}

	if(count > (0.75*tableSize))
	{
		resizeTable();
	}
	unsigned long location = hash(value);

	while(hashTable[location]!=NULL)
	{
		if(hashTable[location]->key == -1)
			break;
		if(location >= tableSize-1)
		{
			location = 0;
			continue;
		}
		location++;
	}
	count++;
	hashTable[location] = new block(location,value);
    return;
}

void HashL::deleteWord(string value){
	block* node = lookup(value);
	if(node!= NULL)
	{
		node->key = -1;
		count--;
		if(count <= tableSize/4)
		{
			resizeTable();
		}
	}
    return;
}
block* HashL::lookup(string value){
	unsigned long location = hash(value);
	unsigned long counter = 0;

	while((hashTable[location]!=NULL)&&(counter < tableSize + 1))
	{
		if(hashTable[location]->value == value)
		{
			if(hashTable[location]->key!= -1)
			{
				return hashTable[location];
			}
		}
		location++;
		if(location == tableSize)
			location = 0;
		counter++;
	}
	//if(counter >= tableSize)
    return NULL;
    //return hashTable[location];

}
#endif
