#include <iostream>
using namespace std;

unsigned long hash(string value, int a = 5)
{
	int sum = 0;
	for(int i = 0; i < value.length(); i++)
	{
		unsigned long aval = value[i];
		sum += a * (aval);
	}
	cout << sum << endl;
}

int main()
{
	hash("hello", 5);
}