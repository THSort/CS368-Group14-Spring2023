#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD()
{
    tableSize = 10000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize];

    for(int i = 0; i < tableSize; i++)
    {
    	hashTable[i] = NULL;
	}
}

HashD::~HashD()
{

}

unsigned long HashD :: hash1(string value)
{
    return bitHash(value);
}

unsigned long HashD :: hash2(string value)
{
    return polyHash(value);
}

void HashD::resizeTable()
{
    long oldtsize = tableSize;
	float fcount = count;
	float fsize = tableSize;

	float theperc = (fcount/fsize) * 100;

    if(theperc >= 70)
    {
    	tableSize *= 4;
    }

    else if(theperc <= 30)
    {
    	tableSize /= 2;
    }

    if(oldtsize != tableSize)
    {
    	block** newone = new block*[tableSize];


	    for(int i = 0; i < tableSize; i++)
	    {
	    	newone[i] = NULL;
	    }

	    for(int i = 0; i < oldtsize; i++)
	    {
	    	if(hashTable[i] != NULL && hashTable[i]->value!="#")
	    	{
	    		for(int j = 0; j < tableSize; j++)
	    		{
	    			unsigned long ultimatehash = hash1(hashTable[i]->value) + (j * hash2(hashTable[i]->value));
	    			unsigned long theindex = divCompression(ultimatehash, tableSize);
	    			if(newone[theindex] == NULL)
	    			{
	    				newone[theindex] = new block(ultimatehash, hashTable[i]->value);
	    				break;
	    			}
	    		}
	    	}
	    }
    	hashTable = newone;
    }
}

void HashD::insert(string value)
{
    
    for(int i = 0; i < tableSize; i++)
    {
    	unsigned long ultimatehash = hash1(value) + (i * hash2(value));
    	unsigned long theindex = divCompression(ultimatehash, tableSize);

    	if(hashTable[theindex] == NULL || hashTable[theindex]->value == "#")
    	{
    		hashTable[theindex] = new block(ultimatehash, value);
    		count++;
    		break;
    	}
    }

    float fcount = count;
	float fsize = tableSize;

	float theperc = (fcount/fsize) * 100;

	if(theperc > 70)
		{
			resizeTable();
		}
    //resizeTable();
}

void HashD::deleteWord(string value)
{
   block* holder = lookup(value);

   if(holder != NULL && holder->value == value)
   {
   		holder->value = "#";
   		count--;
   		float fcount = count;
		float fsize = tableSize;

		float theperc = (fcount/fsize) * 100;

		if(theperc < 30)
		{
			resizeTable();
		}
   		return;
   }

   else if(holder == NULL)
   {
   	return;
   }

   else if(holder->value=="#")
   {
   	return;
   }
}

block* HashD::lookup(string value)
{
    for(int i = 0; i < tableSize; i++)
    {
    	unsigned long ultimatehash = hash1(value) + (i * hash2(value));
    	unsigned long theindex = divCompression(ultimatehash, tableSize);

    	if(hashTable[theindex]->value == value)
    	{
    		return hashTable[theindex];
    	}
    	else if(hashTable[theindex] == NULL || hashTable[theindex]->value=="#")
    	{
    		return NULL;
    	}
    }
}

#endif