#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
   tableSize = size;
   //string thetable[tableSize];
   hashTable = new LinkedList<string>[tableSize]; 
}
HashC::~HashC()
{
	for(int i = 0; i < tableSize; i++)
	{
		LinkedList<string>* temp = &hashTable[i];
		delete temp;
	}
}

unsigned long HashC :: hash(string input)
{
  return bitHash(input); 
}

void HashC::insert(string word)
{
  long thecode = divCompression(hash(word), tableSize);

  if(hashTable[thecode].searchFor(word) == NULL)
  {
  	hashTable[thecode].insertAtHead(word);
  }
  

}

ListItem<string>* HashC :: lookup(string word)
{
	long findcode = divCompression(hash(word), tableSize);
	return hashTable[findcode].searchFor(word);  
}

void HashC :: deleteWord(string word)
{
  long findcode = divCompression(hash(word), tableSize);
  hashTable[findcode].deleteElement(word);

}

#endif
