#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize];

    for(int i = 0; i < tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value)
{
    return bitHash(value);
}

void HashL::resizeTable()
{
    
	long oldtsize = tableSize;
	float fcount = count;
	float fsize = tableSize;

	float theperc = (fcount/fsize) * 100;

    if(theperc >= 70)
    {
    	tableSize *= 4;
    }

    else if(theperc <= 30)
    {
    	tableSize /= 2;
    }

    if(oldtsize != tableSize)
    {
    	block** newone = new block*[tableSize];

    for(int i = 0; i < tableSize; i++)
    {
    	newone[i] = NULL;
    }

    for(int i = 0; i < oldtsize; i++)
    {
		if(hashTable[i] != NULL)
		{
			unsigned long vals = divCompression(hash(hashTable[i]->value), tableSize);

	    	if(newone[vals] == NULL)
	    	{
	    		newone[vals] = new block(hash(hashTable[i]->value), hashTable[i]->value);
	    	}

	    	else
	    	{
	    		int checker = 0;
	    		for(int j = vals; j < tableSize; j++)
	    		{
	    			if(newone[j] == NULL)
	    			{
	    				newone[j] = new block(hash(hashTable[i]->value), hashTable[i]->value);
	    				checker = 1;
	    				break;
	    			}

	    		}
	    		if(checker == 0)
	    			{
	    				for(int k = 0; k < vals; k++)
	    				{
	    					if(newone[k] == NULL)
	    					{	
	    						newone[k] = new block(hash(hashTable[i]->value), hashTable[i]->value);
	    						break;	
	    					}
	    					
	    				}
	    			}
    		}
    	}
	}
    	
    hashTable = newone;
    }

}

void HashL::insert(string value)
{
	unsigned long originalplace = divCompression(hash(value), tableSize);

	if(hashTable[originalplace] == NULL)
	{
		hashTable[originalplace] = new block(hash(value), value);
		count++;
	}

	else
	{
		int checker = 0;
		for(int i = originalplace; i < tableSize; i++)
		{
			if(hashTable[i] == NULL)
			{	hashTable[i] = new block(hash(value), value);
				count++;
				checker = 1;
				break;
			}
			
		}
		
		if(checker == 0)
		{
			for(int i = 0; i < originalplace; i++)
			{
				if(hashTable[i] == NULL)
				{ 
					hashTable[i] = new block(hash(value), value);
					count++;
					break;
				}
			}
		}

	}
	

	resizeTable(); 
}

void HashL::deleteWord(string value)
{
    unsigned long theindex = divCompression(hash(value), tableSize);

    if(hashTable == NULL)
    {
    	return;
    }

    if(hashTable[theindex] != NULL && hashTable[theindex]->value == value && hashTable[theindex]->key == hash(value))
    {	
    	count--;
    	hashTable[theindex] = NULL;
    	resizeTable();
    	return;
    }
    else
    {
    	for(int i = theindex; i < tableSize; i++)
    	{
    		if(hashTable[i] != NULL && hashTable[i]->value == value && hashTable[i]->key == hash(value))
    		{
    			count--;
    			hashTable[i] = NULL;
    			resizeTable();
    			return;
    		}

    	}

    	for(int j = 0; j < theindex; j++)
    	{
    		if(hashTable[j] != NULL && hashTable[j]->value == value && hashTable[j]->key == hash(value))
    		{
    			count--;
    			hashTable[j] = NULL;
    			resizeTable();
    			return;
    		}
    	}
    }
}
block* HashL::lookup(string value)
{
    unsigned long theindex = divCompression(hash(value), tableSize);

    if(hashTable == NULL)
    {
    	return NULL;
    }

    if(hashTable[theindex] != NULL && hashTable[theindex]->value == value && hashTable[theindex]->key == hash(value))
    {	
    	return hashTable[theindex];
    }
    else
    {
    	for(int i = theindex; i < tableSize; i++)
    	{
    		if(hashTable[i] != NULL && hashTable[i]->value == value && hashTable[i]->key == hash(value))
    		{
    			return hashTable[i];
    		}
    		else if(hashTable[i] == NULL)
    		{
    			return NULL;
    		}

    	}

    	for(int j = 0; j < theindex; j++)
    	{
    		if(hashTable[j] != NULL && hashTable[j]->value == value && hashTable[j]->key == hash(value))
    		{
    			return hashTable[j];
    		}
    		else if(hashTable[j] == NULL)
    		{
    			return NULL;
    		}
    	}
    }
    return NULL;
}
#endif
