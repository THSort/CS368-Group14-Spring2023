#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include <iostream>
#include <vector>
#include "LinkedList.h"

template <class T>


LinkedList<T>::LinkedList()
{
    head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
    head == NULL;

    ListItem<T> *ohead = otherLinkedList.head;
    ListItem<T> *headtotail = head;

    if(ohead == NULL)
    {
        return;
    }

    while(ohead != NULL)
    {
        ListItem<T>* temp = new ListItem<T>(ohead->value);
        headtotail->next = temp;
        temp->next = NULL;
        temp->prev = headtotail;
        headtotail = temp;
        ohead = ohead->next;
    }
}

template <class T>
LinkedList<T>::~LinkedList()
{
    ListItem<T> *temp = head;
    while(head != NULL)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
    ListItem<T> *temp = new ListItem<T>(item);

    if(head == NULL)
    {
        head = temp;
        return;
    }

    head->prev = temp;
    temp->next = head;
    head = temp;
    head->prev = NULL;

}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
    ListItem<T> *temp = new ListItem<T>(item);
    ListItem<T> *current = getTail();

    if(head == NULL)
    {
        insertAtHead(item);
        return;
    }

    current->next = temp;
    temp->prev = current;
    temp->next = NULL;

    /*if(head->next == NULL)
    {
        head->next = temp;
        temp->next = NULL;
        temp->prev = head;
    }

    while(current->next!= NULL)
    {
        current = current->next;
    }

    current->next = temp;
    temp->prev = current;
    temp->next = NULL; */
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
    ListItem<T> *temp = new ListItem<T>(toInsert);
    ListItem<T> *current = head;

    if(current == NULL)
    {
        return;
    }

    if((current->next == NULL) && (current->value == afterWhat))
    {
        insertAtTail(toInsert);
        return;
    }

    while(current->value != afterWhat)
    {
        if(current == NULL)
        {
            return;
        }
        current = current->next;
    }

    if(current->next == NULL)
    {
        insertAtTail(toInsert);
        return;
    }

    temp->next = current->next;
    temp->prev = current;
    (current->next) = temp;
    (temp->next)->prev = temp;
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
    ListItem<T> *temp = new ListItem<T>(item);
    ListItem<T> *current = head;

    if (current == NULL)
    {
        insertAtHead(item);
        return;
    }

    if ((item >= current->value) && (current->next == NULL))
    {
        insertAtTail(item);
        return;
    }
    else if ((item <= current->value) && (current->next == NULL))
    {
        insertAtHead(item);
        return;
    }

    if (item <= current->value)
    {
        insertAtHead(item);
        return;
    }

    while(item > (current->value))
    {
        if(current->next == NULL)
        {
            insertAtTail(item);
            return;
        }
        current = current->next;
    }

    ListItem<T> *precurrent = current->prev;
    temp->next = current;
    temp->prev = precurrent;
    precurrent->next = temp;
    current->prev = temp;

    return;
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
    return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    ListItem<T> *current = head;

    if (current == NULL)
    {
        return NULL;
    }
    else if (current->next == NULL)
    {
        return getHead();
    }
    else
    {
        while(current->next != NULL)
        {
            if (current->next == NULL)
                {return current;}
            else
            {current = current->next;}
        }
        return current;
    }
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
    ListItem<T>* current = head;

    if(current == NULL)
    {
        return NULL;
    }

    while(current != NULL)
    {
        if(item == current->value)
        {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
    ListItem<T>* current = head;

    if (current == NULL)
    {
        return;
    }

    if((current->next == NULL) && (current->value==item))
    {
        deleteHead();
        return;
    }

    while(current != NULL)
    {
        if((current->value == item) && (current->next == NULL))
        {
            deleteTail();
            return;
        }

        if((current->value == item) && (current->prev == NULL))
        {
            deleteHead();
            return;
        }

        if(item == current->value)
        {
            (current->prev)->next = current->next;
            (current->next)->prev = current->prev;
            delete current;
            return;
        }
        current = current->next;
    }
}

template <class T>
void LinkedList<T>::deleteHead()
{
    if (head == NULL)
    {return;}

    if (head->next == NULL)
    {
        delete head;
        head = NULL;
        return;
    }

    ListItem<T>* temp = head;
    head = head->next;
    delete temp;
    head->prev = NULL;
}

template <class T>
void LinkedList<T>::deleteTail()
{
    ListItem<T>* current = head;
    if (current == NULL)
    {
        return;
    }

    if (current->next == NULL)
    {
        deleteHead();
        return;
    }

    while(current->next != NULL)
    {
        current = current->next;
    }
    current->prev->next = NULL;
    delete current;
}

template <class T>
int LinkedList<T>::length()
{
    int x = 0;
    ListItem<T>* current = head;
    while(current!=NULL)
    {
        current = current->next;
        x++;
    }
    return x;
}

template <class T>
void LinkedList<T>::reverse()
{
    if((head == NULL) || (head->next == NULL))
        return;

    std::vector<T> rev;
    while(head != NULL)
    {
        rev.push_back(head->value);
        deleteHead();
    }
    for(int i = 0; i < rev.size(); i++)
    {
        insertAtHead(rev[i]);
    }
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	if ((head == NULL) || (head->next == NULL))
    {
        return;
    }

    ListItem<T>* current = head;
    LinkedList<T> evens;

    int len = length();
    for(int i = 0; i < len; i++)
    {
        if(i%2)
        {}
        else
        {
            T temp = current->value;
            deleteElement(current->value);
            evens.insertAtHead(current->value);
        }
        current = current -> next;
    }
    evens.reverse();
    evens.head->prev = getTail();
    getTail()->next = evens.head;
}

#endif
