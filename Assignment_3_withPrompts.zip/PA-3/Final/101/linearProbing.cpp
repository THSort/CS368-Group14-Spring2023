#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i = 0; i < tableSize; i++)
        hashTable[i] = NULL;
    count = 0;
}

HashL::~HashL(){
    delete [] hashTable;
}

unsigned long HashL :: hash(string value){
    return bitHash(value);
}

void HashL::resizeTable(){
    int presize = tableSize;

    if(float(count)/float(tableSize) <= 0.2)
    {tableSize/=2;}
    else
    {tableSize*=2;}

    string *prehashTable = new string[presize];

    for(int i = 0; i < presize; i++)
    {
        if((hashTable[i] != NULL) && (hashTable[i]->value != "$$N$$"))
        {prehashTable[i] = hashTable[i]->value;}
        else {prehashTable[i] = "$$N$$";}
    }

    delete [] hashTable;
    count = 0;

    hashTable = new block*[tableSize];
    for(int i = 0; i < tableSize; i++)
        hashTable[i] = NULL;

    for(int i = 0; i < presize; i++)
    {
        if(prehashTable[i]!="$$N$$")
        {
            insert(prehashTable[i]);
        }
    }
}

void HashL::insert(string value){
    if(lookup(value))
        return;

    if (float(count)/float(tableSize) >= 0.8)
        resizeTable();

    unsigned long key = hash(value);
    block* toinsert = new block(key, value);
    unsigned long index = key%tableSize;

    if (hashTable[index] != NULL){
        int i = 0;
        while(1)
        {
            if(hashTable[index + i] == NULL)
            {
                hashTable[index + i] = toinsert;
                count++;
                break;
            }
            if(hashTable[index + i]->value == "$$N$$")
            {
                delete hashTable[index + i];
                hashTable[index + i] = toinsert;
                count++;
                break;
            }

            i++;
            if ((index + i) >= tableSize)
            {
                index = 0;
                i = 0;
            }
        }
    }
    else{
        hashTable[index] = toinsert;
        count++;
    }
}

void HashL::deleteWord(string value){
    if(lookup(value))
    {
        lookup(value)->value = "$$N$$";
        count--;
        if(float(count)/float(tableSize) <= 0.2)
            resizeTable();
    }
}

block* HashL::lookup(string value){
    unsigned long index = hash(value)%tableSize;
    int i = 0;
    while(1)
        {
            if(hashTable[index + i] == NULL)
            {
                return NULL;
            }
            else if(hashTable[index + i]->value == value)
            {
                return hashTable[index + i];
            }

            i++;
            if ((index + i) >= tableSize)
            {
                index = 0;
                i = 0;
            }
        }
    }
#endif
