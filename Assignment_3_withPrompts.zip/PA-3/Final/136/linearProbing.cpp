#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL()
{
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i = 0; i < tableSize; i++)
    	hashTable[i] = NULL;
}

HashL::~HashL()
{
    delete[] hashTable;
}

unsigned long HashL :: hash(string value)
{
    return divCompression(bitHash(value), tableSize);
}

void HashL::resizeTable()
{
    if(count >= tableSize)
    {
    	long tempsize = tableSize;
        tableSize = tableSize*50;
        block** newhash = hashTable;

        hashTable = new block*[tableSize];
        
        for(int i = 0; i < tableSize; i++)
            hashTable[i] = NULL;

        count = 0;
        for(int i = 0; i < tempsize; i++)
        {
            if(newhash[i] != NULL && newhash[i]->key != tempsize + 1)
                insert(newhash[i]->value);
        }
    }

    else if(count <= 0.01*tableSize && tableSize > 50000)
    {
        cout << tableSize << endl << count/tableSize;
        long tempsize = tableSize;
        tableSize = tableSize/50;
        block** newhash = hashTable;

        hashTable = new block*[tableSize];
        
        for(int i = 0; i < tableSize; i++)
            hashTable[i] = NULL;

        count = 0;
        for(int i = 0; i < tempsize; i++)
        {
            if(newhash[i] != NULL && newhash[i]->key != tempsize + 1)
                insert(newhash[i]->value);
        }
    }
}

void HashL::insert(string value)
{
    unsigned long index = hash(value);
    if(hashTable[index] == NULL)
        hashTable[index] = new block(index, value);

    else
    {
        while(hashTable[index] != NULL && hashTable[index]->key != tableSize+1)
        {
            index++;
            if(index >= tableSize)
                index = 0;
        }
        
        if(hashTable[index] == NULL)
            hashTable[index] = new block(index, value);

        else
        {    
            hashTable[index]->key = index;
            hashTable[index]->value = value;
        }
    }

        count++;

    if(count >= tableSize)
        resizeTable();
}

void HashL::deleteWord(string value)
{
    unsigned long index = hash(value);
    if(lookup(value))
    {
        block* temp = lookup(value);
        while(hashTable[index]->value != value)
        {
            index++;
            if(index == tableSize)
                index = 0;
        }
    
        if(hashTable[index]->key == tableSize+1)
            return;
        else
        {
            hashTable[index]->key = tableSize+1;
            count--;
            if(count <= 0.01*tableSize && tableSize > 50000)
                resizeTable();
        }

    }
}

block* HashL::lookup(string value)
{
    unsigned long index = hash(value);
    unsigned long temp = index;
    if(hashTable[index] == NULL)
        return NULL;
    else
    {
        if(hashTable[index]->key == index && hashTable[index]->value == value)
            return hashTable[index];

        else if(hashTable[index]->key == tableSize+1 && hashTable[index]->value == value)
            return NULL;

        else
        {
            while(hashTable[index] != NULL && hashTable[index]->value != value)
            {
                index++;
                if(index >= tableSize)
                    index = 0;
                if(temp == index)
                    return NULL;
            }
            if(hashTable[index] == NULL || hashTable[index]->key == tableSize+1) 
                return NULL;
            
            else
                return hashTable[index];
        }
        
    }
}

// int main()
// {
// 	HashL h;
    
//     for(int i = 0; i < 700; i++)
//     {    
//         h.insert(s);
//     }

//     // cout << h.lookup()
// }
#endif
