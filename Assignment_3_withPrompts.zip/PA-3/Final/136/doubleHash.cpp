#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    for(int i = 0; i < tableSize; i++)
    	hashTable[i] = NULL;
}

HashD::~HashD(){
	delete[] hashTable;
}

unsigned long HashD :: hash1(string value){
    return divCompression(bitHash(value), tableSize);
    
}

unsigned long HashD :: hash2(string value){
    return divCompression(polyHash(value, 33), tableSize);
}

void HashD::resizeTable(){

    
    if(count >= 0.4*tableSize)
    {
    	long tempsize = tableSize;
        tableSize = tableSize*60;
        block** newhash = hashTable;

        hashTable = new block*[tableSize];
        
        for(int i = 0; i < tableSize; i++)
            hashTable[i] = NULL;

        count = 0;
        for(int i = 0; i < tempsize; i++)
        {
            if(newhash[i] != NULL && newhash[i]->key != tempsize + 1)
                insert(newhash[i]->value);
        }
    }

    else if(count <= 0.01*tableSize && tableSize > 600000)
    {
        long tempsize = tableSize;
        tableSize = tableSize/60;
        block** newhash = hashTable;

        hashTable = new block*[tableSize];
        
        for(int i = 0; i < tableSize; i++)
            hashTable[i] = NULL;

        count = 0;
        for(int i = 0; i < tempsize; i++)
        {
            if(newhash[i] != NULL && newhash[i]->key != tempsize + 1)
                insert(newhash[i]->value);
        }
    }
}

void HashD::insert(string value){
    unsigned long index = hash1(value);
    unsigned long temp = index;
    if(hashTable[index] == NULL)
        hashTable[index] = new block(index, value);

    else
    {
    	int i = 1;
        unsigned long index2 = hash2(value);
        while(hashTable[index] != NULL && hashTable[index]->key != tableSize+1)
        {
            index = (index + i*index2)%tableSize;
            i++;
        }
        
        if(hashTable[index] == NULL)
            hashTable[index] = new block(index, value);

        else
        {    
            hashTable[index]->key = index;
            hashTable[index]->value = value;
        }
    }

        count++;

    if(count >= tableSize*0.4)
        resizeTable();

}

void HashD::deleteWord(string value){
    
    unsigned long index = hash1(value);
    if(lookup(value))
    {
        block* temp = lookup(value);
        int i = 1;
        while(hashTable[index]->value != value)
        {
            unsigned long index2 = hash2(value);
            index = (index + i*index2)%tableSize;
            i++;
        }
    
        if(hashTable[index]->key == tableSize+1)
            return;
        else
        {
            hashTable[index]->key = tableSize+1;
            count--;
            if(count <= 0.01*tableSize && tableSize > 600000)
                resizeTable();
        }

    }

}

block* HashD::lookup(string value){
    
    unsigned long index = hash1(value);
    unsigned long temp = index;
    if(hashTable[index] == NULL)
        return NULL;
    else
    {
        if(hashTable[index]->key == index && hashTable[index]->value == value)
            return hashTable[index];

        else if(hashTable[index]->key == tableSize+1 && hashTable[index]->value == value)
            return NULL;

        else
        {
        	int i = 1;
            while(hashTable[index] != NULL && hashTable[index]->value != value)
            {
                unsigned long index2 = hash2(value);
            	index = (index + i*index2)%tableSize;
            	i++;

            	if(temp == index)
            		return NULL;
            }
            if(hashTable[index] == NULL || hashTable[index]->key == tableSize+1) 
                return NULL;
            
            else
                return hashTable[index];
        }
        
    }
}

#endif