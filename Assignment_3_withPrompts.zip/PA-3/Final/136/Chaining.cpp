#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    tableSize = size;
    hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC(){
	for(int i = 0; i < tableSize; i++)
	{
		while(hashTable[i].getHead() != NULL)
			hashTable[i].deleteHead();
	}

	tableSize = 0;
}

unsigned long HashC :: hash(string input){
	return divCompression(bitHash(input), tableSize) ;
}

void HashC::insert(string word){
  unsigned long index = hash(word);
  hashTable[index].insertAtHead(word);
}

ListItem<string>* HashC :: lookup(string word){
  unsigned long index = hash(word);
  return hashTable[index].searchFor(word);
}

void HashC :: deleteWord(string word){
  unsigned long index = hash(word);
  hashTable[index].deleteElement(word);
}

#endif
