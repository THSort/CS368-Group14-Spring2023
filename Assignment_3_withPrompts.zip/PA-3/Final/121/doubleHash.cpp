#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
//################################################################################
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    for (int i = 0 ; i < tableSize ; i++)
    {
    	hashTable[i] = NULL;
    }
    pin_point= -10;
    count = 0;
}
//################################################################################
HashD::~HashD(){
	for (int i = 0 ; i < tableSize ; i++)
	{
		delete hashTable[i];
	}
	delete hashTable;	
}
//################################################################################
unsigned long HashD :: hash1(string value){
    return divCompression(bitHash(value),tableSize);
}
//################################################################################
unsigned long HashD :: hash2(string value){
    return divCompression(polyHash(value),tableSize);
}
//################################################################################

//################################################################################
void HashD::resizeTable(){
    long old_tsize = tableSize;
	long new_index = 0;
	
	if (count >= (0.5*tableSize) ) 
	{
		tableSize = tableSize*2;
		block** new_hashTable;
		new_hashTable = new block*[tableSize];
		for (int i = 0 ; i < tableSize ; i++ )
		{
			new_hashTable[i] = NULL;
		}
		//Copying Elements from previous Table
		for (int i = 0 ; i < old_tsize ; i++)
		{
			// INSERT IN NEW HASH TABLE
			if (hashTable[i])  
			{
				// --- UPDATING INDEX ---
				int t = 0;
				long index =((hash1(hashTable[i]->value) + t*(hash2(hashTable[i]->value  )+11))%tableSize);
				while(hashTable[index])
				{
					index = ((hash1(hashTable[i]->value) + t*(hash2(hashTable[i]->value  )+11))%tableSize);
					t++;
				}
				while(new_hashTable[new_index] != NULL)
				{
					if (new_index == tableSize-1)
					{
						new_index = 0;
						continue;
					}
					new_index++;
					//cout<<"Resizing growing"<<endl;
				}
				new_hashTable[new_index] =  hashTable[i];
				delete hashTable[i];
			}
		}
    	hashTable = new_hashTable;
    	return;
	}
		// Decrease Size
	if (count <= (int)0.25*tableSize)
	{
		tableSize = tableSize/2;
		block** new_hashTable;
		new_hashTable = new block*[tableSize];
		for (int i = 0 ; i < tableSize ; i++ )
		{
			new_hashTable[i] = NULL;
		}
		//Copying Elements from previous Table
		for (int i = 0 ; i < count ; i++)
		{
			// --- UPDATING INDEX ---
			if (hashTable[i])
			{
				int t = 0;
				long index = ((hash1(hashTable[i]->value) + t*(hash2(hashTable[i]->value  )+11))%tableSize);
				while(hashTable[index])
				{
					index =((hash1(hashTable[i]->value) + t*(hash2(hashTable[i]->value  )+11))%tableSize);
					t++;
				}
				while(new_hashTable[new_index] != NULL)
				{
					if (new_index == tableSize)
					{
						new_index = 0;
						continue;
					}
					new_index++;
				}
			new_hashTable[new_index] = hashTable[i];
			delete hashTable[i];
			}
		}
		hashTable = new_hashTable;
		return;
	}
}
//################################################################################
void HashD::insert(string value){
	 if (count >= (0.5*tableSize))
     {
     	resizeTable();
     }
    int i = 0;
    long index =( (hash1(value) + i*(hash2(value)+11)) %tableSize);
    while(hashTable[index])
    {
	    	index = ( (hash1(value) + i*(hash2(value)+11))  %tableSize);
	    	i++;
    } 
    if (hashTable[index] == NULL)
    {
    	hashTable[index] = new block(index , value);
    	count++;
    	return;
    }
    else 
    {   	
    	while( hashTable[index] != NULL )
    	{
    		// IF FOUND DELETED ITEM	
    		if ( (hashTable[index]->key == pin_point ) )
    		{
    			hashTable[index]->value =value;
    			hashTable[index]->key = index;
    			count++;
    			return;
    		}
    		index++;
    	}
    	hashTable[index] = new block(index , value);
    	count++;
    	return;
    }
}
//################################################################################
void HashD::deleteWord(string value){
	block* temp = lookup(value);
	if (temp == NULL)
	{
		return;
	}
	else if (temp != NULL)
	{
		temp->value ="";
		temp->key = pin_point;
		count--;
    	return;
	}
	if(count < 0.25*tableSize)
	{
		resizeTable();
	}
}
//################################################################################
block* HashD::lookup(string value){
    int t = 0;
    long index = ((hash1(value) + t*(hash2(value)+11))%tableSize);
    while(hashTable[index])
    {
	    	index = ((hash1(value) + t*(hash2(value)+11))%tableSize);
	    	t++;
    }
    long cut_index = index;
    
    if (hashTable[index] == NULL)
    {
    	return NULL;
    }
    if (hashTable[index]->value == value) //FOUND
    {
    	return hashTable[index];
    }
    else
    {	
    	index++;
    	while(hashTable[index] && hashTable[index]->value != value)
    	{
    		if (index == cut_index)
    		{
    			break;
    		}
    		if (index == tableSize-1){
    			index = -1;
    			continue;
    		}
    		if (hashTable[index] == NULL)
    		{
    			return NULL;
    		}
    		if ( (hashTable[index]->key == pin_point) )
    		{
    			index++;
    			continue;
    		}
    		  index++;
    	}
    	
    	if (index == cut_index)
    	{
    		return NULL;
    	}
    	if (hashTable[index] == NULL)
    		{
    			return NULL;
    		}
    	if ( (hashTable[index]->key == pin_point) )
    	{
    		return NULL;
    	}
    	if (hashTable[index]->value == value)
    	{
    		return hashTable[index];
    	}
    	else 
    	{
    		return NULL;
    	}
    }
}

//################################################################################
#endif