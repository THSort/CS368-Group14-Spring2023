#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"

//################################################################################
HashL::HashL(){
    tableSize = 1000; // you can't change this
    hashTable = new block*[tableSize];
    for (int i = 0 ; i < tableSize ; i++)
    {
    	hashTable[i] = NULL;
    }
    pin_point= -10;
    count = 0;
}
//################################################################################
HashL::~HashL(){
	for (int i = 0 ; i < tableSize ; i++)
	{
		delete hashTable[i];
	}
	delete hashTable;
}
//################################################################################
unsigned long HashL :: hash(string value){

	return divCompression(bitHash(value),tableSize);
}
//################################################################################
void HashL::resizeTable() {

	// Increase Size
	long old_tsize = tableSize;
	long new_index = 0;
	
	if (count >= (0.7*tableSize) ) 
	{
		tableSize = tableSize*2;
		block** new_hashTable;
		new_hashTable = new block*[tableSize];

		for (int i = 0 ; i < tableSize ; i++ )
		{
			new_hashTable[i] = NULL;
		}

		//Copying Elements from previous Table
		for (int i = 0 ; i < old_tsize ; i++)
		{
			// INSERT IN NEW HASH TABLE
			if (hashTable[i])  
			{
				new_index = hash(hashTable[i]->value);
					while(new_hashTable[new_index] != NULL)
					{
						if (new_index == tableSize-1)
						{
							new_index = 0;
							continue;
						}
						new_index++;
					}
					new_hashTable[new_index] =  hashTable[i];
			
			}
		}
			
    	hashTable = new_hashTable;
    	return;
	}
		// Decrease Size
	if (count <= (int)0.3*tableSize)
	{
		tableSize = tableSize/2;
		block** new_hashTable;
		new_hashTable = new block*[tableSize];
		for (int i = 0 ; i < tableSize ; i++ )
		{
			new_hashTable[i] = NULL;
		}
		//Copying Elements from previous Table
		for (int i = 0 ; i < count ; i++)
		{
			if (hashTable[i])
			{
				while(new_hashTable[new_index] != NULL)
					{
						if (new_index == tableSize)
						{
							new_index = 0;
							continue;
						}
						new_index++;
					}
					new_hashTable[new_index] =  hashTable[i];
					delete hashTable[i];
			}
		}
		hashTable = new_hashTable;
		return;
	}
}

//################################################################################
void HashL::insert(string value){
    if (count >= (0.7*tableSize))
    {
    	resizeTable();
    }
   
    long index = hash(value);
    if (hashTable[index] == NULL)
    {
    	hashTable[index] = new block(index , value);
    	count++;
    	return;
    }
    else 
    {   	
    	while( hashTable[index] != NULL )
    	{	
    		if (index == tableSize-1){
    			index = 0;
    			continue;
    		}
    		if (  (hashTable[index]->key == pin_point ) )
    		{
    			hashTable[index]->value =value;
    			hashTable[index]->key = index;
    			count++;
    			return;
    		}
    		index++;
    	}
    	hashTable[index] = new block(index , value);
    	count++;
    	return;
    }
}
//################################################################################
void HashL::deleteWord(string value){
	block* temp = lookup(value);
	if (temp == NULL)
	{
		return;
	}
	else if (temp != NULL)
	{
		temp->value ="";
		temp->key = pin_point;
		count--;
    	return;
	}
	if(count < 0.3*tableSize)
	{
		resizeTable();
	}
}
//################################################################################
block* HashL::lookup(string value){
	//cout<<"Lookup"<<endl;
    long index = hash(value);
    
    long cut_index = index;
    
    if (hashTable[index] == NULL)
    {
    	return NULL;
    }
    if (hashTable[index]->value == value) //FOUND
    {
    	return hashTable[index];
    }
    else
    {	
    	index++;
    	while(hashTable[index] && hashTable[index]->value != value)
    	{
    		// index++;
    		if (index == cut_index)
    		{
    			break;
    		}
    		if (index == tableSize-1){
    			index = -1;
    			continue;
    		}
    		if (hashTable[index] == NULL)
    		{
    			return NULL;
    		}
    		if ( (hashTable[index]->key == pin_point) )
    		{
    			index++;
    			continue;
    		}
    		  index++;
    	}
    	
    	if (index == cut_index)
    	{
    		return NULL;
    	}
    	if (hashTable[index] == NULL)
    		{
    			return NULL;
    		}
    	if ( (hashTable[index]->key == pin_point) )
    	{
    		return NULL;
    	}
    	if (hashTable[index]->value == value)
    	{
    		return hashTable[index];
    	}
    	else 
    	{
    		return NULL;
    	}
    }
}
//################################################################################
void HashL::print ()
{
	for (int i =0 ; i <tableSize ; i++ )
	{
		if (hashTable == NULL)
		{
			return;
		}
		if (hashTable[i] == NULL)
		{
			cout<<"empty poo"<<endl;
		}
		else
		{
			cout<<hashTable[i]->value<<endl;
		}
	}
	cout<<"count: "<<count<<endl;
}
#endif

