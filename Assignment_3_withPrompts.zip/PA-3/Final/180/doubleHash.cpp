#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"

HashD::HashD(){
    tableSize = 10000; // you cant change this
    count =0;
    hashTable = new block* [tableSize];
    for (int i = 0; i < tableSize; ++i)
    {
    	hashTable[i] = NULL;
    }
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){

    return madCompression(bitHash(value),tableSize);
}

unsigned long HashD :: hash2(string value){
	unsigned long temp = divCompression(bitHash(value),tableSize) ;
	return temp;
}
int tmp =0;
void HashD::resizeTable(){
	long szbf = tableSize;
	if(tmp < 3)
		tableSize *= 2;
	else if(tmp > 5)
		tableSize /= 2;

	count = 0;
	block ** temp = hashTable;
	block ** table = new block *[tableSize]();
	hashTable = table;
	int i = 0;
	while(true){
		if (i >= szbf)
			break;
		if(temp[i] != NULL && temp[i]->value != "0" )
			insert(temp[i]->value);
		i++;
	}
	delete[] temp;
}

void HashD::insert(string value){
	unsigned long key = hash1(value);
	unsigned long temp = 0;

	unsigned long var = key;
	unsigned long var1 =key;

	if(hashTable[var] == NULL){
		hashTable[var] = new block(key , value);
	}
	else{
		while(hashTable[var]){
		temp++;
			if(hashTable[var]->value == "0")
				break;
			var = (var1 +(temp*var1)) % tableSize;
		}
		if(!hashTable[var]){
			hashTable[var] = new block(key , value);
		}
		else
			hashTable[var]->value = value;

	}

	count++;
	long szbyct = tableSize/count;
	if(szbyct < 3)
		resizeTable();
    return;

}

void HashD::deleteWord(string value){
	block* ptr = lookup(value);
	if(ptr){
		ptr->value = "0";
		count--;
	}
	tmp = (tableSize/count);
	if(tmp >5 && tableSize > 2000)
		resizeTable();

}

block* HashD::lookup(string value){
	unsigned long key = hash1(value);
	unsigned long var = key;
	unsigned long var1 =key;
	int temp = 0;
	while(hashTable[var]){
		if(hashTable[var]->value == value )
			break;
		var = (var1 + (temp*var1)) % tableSize;
			temp++;
	}
	return hashTable[var];
}

#endif