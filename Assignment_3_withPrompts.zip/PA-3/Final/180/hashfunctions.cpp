#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value, int a= 37){
	int length = value.length() ;
	unsigned long polyHash = 0;
	for(int i = 1 ; i <= length ; i++)
			polyHash += pow(a , i) * (value[i]);
	return polyHash;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
    unsigned long bitwise_hash = 0;
    int str_len = value.length();
    for (int i = 0; i < str_len; i++){
        std::string si = value.substr(i,1);
        bitwise_hash ^= (bitwise_hash << 5) + (bitwise_hash >> 2) + si[0];
    }
    return bitwise_hash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return hash % size;
}
// multiplication addition and division compression.
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){

   return (a*hash + m) % size;
}
// 'm' and 'a' can take any value
#endif
