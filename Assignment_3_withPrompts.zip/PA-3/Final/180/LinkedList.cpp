#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;

}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	 head = NULL;
     ListItem<T>* temp = otherLinkedList.head;

     while(temp){
        insertAtTail(temp->value);
        temp = temp->next;
     }
}

template <class T>
LinkedList<T>::~LinkedList()
{
	//called automatically
}

// Tested. Fine.
template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> * ptr = new ListItem<T> (item);
	if (ptr == NULL)
	return;

	if (head == NULL){
		head = ptr;
		return;
	}

	ptr -> next = head;
	(head->prev) = ptr;
	head = ptr;



}

//tested. Fine.
template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	// ListItem<T> * temp_head = head;
	// while (head != NULL){
	// 	temp_head = temp_head -> next;
	// }

	// ListItem<T> * ptr = new ListItem<T> (item);
	// //ptr->next = temp_head;
	// ptr -> prev = ((temp_head -> prev) -> next);
	// temp_head = ptr;

	// //try just like head_insert


	ListItem<T> * tail = getTail();
	ListItem<T> * ptr = new ListItem<T> (item);

	if (ptr == NULL)
		return;

	if (tail == NULL){
		if (head != NULL)
			return;
		head = ptr;
		tail = ptr;
		return;
	}

	tail -> next = ptr;
	ptr -> prev = tail;
	tail = ptr;


}

//tested. searchFor. Both Fine.
template <class T>
void LinkedList<T>::insertAfter (T toInsert, T afterWhat){



	ListItem<T> *afterThis = searchFor(afterWhat);
	if (afterThis == NULL)
		return;



	ListItem<T> * ptr = new ListItem<T> (toInsert);
	if (ptr == NULL)
		return;

	ptr -> next = afterThis -> next;
	ptr -> prev = afterThis;
	if (afterThis -> next != NULL)
	(afterThis -> next) -> prev = ptr;

	afterThis -> next = ptr;


}

//Not used for iterative solution.
template <class T>
void Hp_insertSorted(ListItem<T> *head, T item)
{
	if (head == NULL)
		return;
	if ((head-> value) < item){
		ListItem<T> * ptr = new ListItem<T> (item);
		ptr-> prev = head;
		ptr -> next = head -> next;
		if (head->next != NULL)
		head->next->prev = ptr;
		head -> next = ptr;

	}
	if ((head->value) >= item){
		ListItem<T> * ptr = new ListItem<T> (item);
		ptr->next = head;
		head->prev = ptr;
		head = ptr;
	}
	Hp_insertSorted(head->next, item);

}

//try calling insertafter and headins in non-recu
template <class T>
void LinkedList<T>::insertSorted(T item)
{
	// ListItem<T> * temp_head = head;
	// while (temp_head != NULL){
	// 	if ((temp_head -> value) > item){
	// 		ListItem<T> *ptr = new ListItem<T> (item);
	// 		ptr->prev  = temp_head -> prev;
	// 		ptr-> next = temp_head;
	// 		temp_head  = ptr;
	// 		(temp_head -> prev)	= ptr;
	// 		break;
	// 	}
	// 	temp_head = temp_head -> next;
	// }

ListItem<T> *tail = getTail();

 if (head == NULL ){
   	insertAtHead(item);
   }
   else if (item < head->value){
   	insertAtHead(item);
   }
   else if (item > tail->value){
   	insertAtTail(item);
   }
   else
   	{

   	ListItem <T> * temp = head ;
	while(temp->next->value < item){
		temp = temp->next;
	}

	ListItem <T> * temp1 = new ListItem<T>(item);
	temp1->next = temp->next;
	temp->next->prev = temp1;
	temp->next = temp1;
	temp1->prev = temp;


}
}



template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}


// Tested. Fine.
template <class T>
ListItem<T>* LinkedList<T>::getTail()
{

	ListItem<T> *tail = NULL;
	ListItem<T> * temp_head = head;

	if (temp_head == NULL)
		return NULL;

	while (temp_head->next != NULL){
		temp_head = temp_head -> next;
	}


	tail = temp_head;

	return tail;
}

//recursive. Tested. Fine. Iterative solution also provided (commented)
template <class T>
ListItem<T> *searchFor2(ListItem<T> *head, T item)
{

	if (head == NULL)
		return NULL;
	if ((head -> value) == item)
		return head;
	return searchFor2(head -> next, item);

}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T> *temp_head = head;
	return searchFor2(temp_head, item);

}


//tested. Fine.
// template <class T>
// ListItem<T> *LinkedList<T>::searchFor(T item)
// {
// 	ListItem<T> *temp_head = head;
// 	if (temp_head == NULL)
// 		return NULL;

// 	while (temp_head -> value != item)
// 		temp_head = temp_head ->next;

// 	return temp_head;


// }

//this function might delete first elem from other end. :( verify.
template <class T>
void Hp_deleteElement(ListItem<T> *head, T item)
{
	if (head == NULL)
		return;
	if ((head-> value) == item){
		head = head -> next;
		head -> next -> prev = NULL;
	}
	Hp_deleteElement(head->next, item);

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	if (head == NULL)
		return;

	while (1){

	if ((head-> value) == item){
		deleteHead();
		return;
	}
	head = head->next;

	}
}

//fine.
template <class T>
void LinkedList<T>::deleteHead()
{
	if (head == NULL)
		NULL;
	if (head -> next != NULL)
	head -> next -> prev = NULL;
	head = head -> next;

}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T> * tail = getTail();
	if (tail == NULL)
		NULL;

	if (tail -> prev != NULL)
	tail -> prev -> next = NULL;
	tail = tail -> prev;
}

template <class T>
int length2(ListItem<T> *head)
{
	if (head == NULL)
		return 0;
	return 1 + length2(head->next);
}

template <class T>
int LinkedList<T>::length()
{
	return length2(head);
}


template <class T>
void LinkedList<T>::reverse()
{

}



template <class T>
void LinkedList<T>::parityArrangement()
{


    ListItem<T> *temp1 = head;
    ListItem<T> *temp2 = head->next;
    ListItem<T> *temp3 = head->next;

    while (1){
    	if (!temp1 || !temp2 || !(temp2->next)){
            temp1->next = temp3;
            return;
        }
        temp1->next = temp2->next;
        temp1 = temp2->next;


        if (!temp1->next){
            temp2->next = NULL;
            temp1->next = temp3;
            return;
        }
        temp2->next = temp1->next;
        temp2 = temp1->next;
    }

}

template <class T>
bool LinkedList<T>::isPalindrome()
{
    int len = this->length();
    if(!len)
        return false;


    ListItem <T> *tail = getTail();

    while(len > 1){
        if(head->value != tail->value)
            return false;

        head = head->next;
        tail = tail->prev;
        len -=2;
	}

    return true;

}




#endif
