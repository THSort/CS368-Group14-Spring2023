#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize]();

    for(int i=0; i<tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
	unsigned long hashVal = bitHash(input);
	hashVal = divCompression(hashVal, tableSize);
 	return hashVal;
}

void HashL::resizeTable(){
    return;
}

void HashL::insert(string value){
    return;
}

void HashL::deleteWord(string value){
    return;
}
block* HashL::lookup(string value){
    return NULL;
}
#endif