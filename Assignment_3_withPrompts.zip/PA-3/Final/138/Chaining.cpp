#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	this->tableSize = size;
	hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
	unsigned long hashVal = bitHash(input);
	hashVal = divCompression(hashVal, tableSize);
  return hashVal;  
}

void HashC::insert(string word){
	unsigned long i = hash(word);
	hashTable[i].insertAtHead(word);
  return;
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long i = hash(word);
  return hashTable[i].searchFor(word);
}

void HashC :: deleteWord(string word){
	//ListItem<string>* target = lookup(word);
	//delete target;

	unsigned long i = hash(word);
	hashTable[i].deleteElement(word);
  return;
}

#endif