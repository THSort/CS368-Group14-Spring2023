#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize=size;
	hashTable=new LinkedList<string> [size];     
}
HashC::~HashC(){
	for (unsigned int i=0;i<tableSize;i++){
		hashTable[i].~LinkedList();
	}
}

unsigned long HashC::hash(string input){
	return divCompression(bitHash(input),tableSize);
}

void HashC::insert(string word){
	unsigned long HAsh=hash(word);
	hashTable[HAsh].insertAtHead(word);	
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long HAsh=hash(word);
	ListItem<string>* temp=NULL;
	temp=hashTable[HAsh].searchFor(word);
   	return temp;
}

void HashC :: deleteWord(string word){
	unsigned long HAsh=hash(word);
	hashTable[HAsh].deleteElement(word);
  	return;
}

#endif