#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

// template <class T>
// LinkedList<T>::LinkedList(int size){	
// 	head=NULL;
// 	if (size>0){
// 		ListItem<T>* current=new ListItem<T>;
// 		head=current;
// 	}
// 		ListItem<T>* temp=head;

// 	for (int i=1;i<size;i++){
// 		ListItem<T>* current=new ListItem<T>;
// 		temp->next=cuurent;
// 		current->prev=temp;
// 		temp=current;
// 	}
// }

template <class T>
LinkedList<T>::LinkedList(){
	head=NULL;
}	

template <class T>
LinkedList<T>::~LinkedList(){
	ListItem<T> *temp=head;
		while (temp!=NULL)
		{
			ListItem<T>* ahead=temp->next;
			delete temp;
			temp= ahead;
		}
}

template <class T>
void LinkedList<T>::insertAtHead(T item){
	if (head==NULL){
		head= new ListItem<T>(item);
	}	
	else{
		ListItem<T> *temp =new ListItem<T>(item);
		temp->next=head;
		head->prev=temp;
		head=temp;
	}	
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item){
	

	ListItem<T> *traverse=head;
	while (traverse!=NULL){
		if (traverse->value==item){
			return traverse;
		}
		traverse=traverse->next;
	}

 	return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item){
	if (head->value==item){
		if (head->next==NULL){
			delete head;
		}

		else{
			ListItem<T>* temp=head;
			head=head->next;
			head->prev=NULL;
			temp->next=NULL;
			delete temp;
		}
		
	}
	else {
		ListItem<T>* traverse=head;
		ListItem<T>* ahead=head->next;
		while (ahead->value!=item){
			traverse=ahead;
			ahead=ahead->next;
		}
		if (ahead->next==NULL){
			traverse->next=NULL;
			ahead->prev=NULL;
			delete ahead;
		}
		else{
			ListItem<T>* del=ahead;
			ahead=ahead->next;	
			ahead->prev=traverse;
			traverse->next=ahead;
			del->next=NULL;
			del->prev=NULL;
			delete del;
		}
	}
}






#endif
