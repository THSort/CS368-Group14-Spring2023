#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 31){
	unsigned long hash=0;
	for (unsigned int i=0;i<value.length();i++){
		hash=a*hash + int (value[i]);
	}
	return hash;
	
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
// 	Initialize bitwise_hash = 0
// For every s i in str
// bitwise_hash ^= (bitwise_hash << 5) + (bitwise_hash >> 2) + s
	unsigned long bithash=0;

	for (unsigned int i=0;i<value.length();i++){
		bithash ^= (bithash << 5) + (bithash >> 2) + int(value[i]);
	}

 	return bithash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return hash%size;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    
	unsigned long ret;
	ret=((a*hash+0)%m)%size; 

    return ret;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions. 