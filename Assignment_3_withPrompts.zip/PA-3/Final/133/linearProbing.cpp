#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    count =0;
    for (int i=0; i<tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
	unsigned long a = bitHash(value);
	a = divCompression (a, tableSize);

  	return a;
}

void HashL::resizeTable(){

	block** temp_array;
	unsigned long tempsize = 2* tableSize;
	temp_array = new block*[tempsize];

	for (int i=0; i<tempsize; i++)
	{	
		temp_array[i]= NULL;
	}
	unsigned long temphash;
	for (int i=0; i<tableSize; i++)
	{	
		if (hashTable[i]!= NULL && hashTable[i]->key != -1)
		{
			temphash = bitHash(hashTable[i]->value);
			temphash = divCompression(temphash, tempsize);
			while (temp_array[temphash] != NULL)
			{
				temphash++;
				temphash = temphash%tempsize;
			}
			temp_array[temphash] = new block(temphash,hashTable[i]->value);
		}
	}
	tableSize *= 2;
	delete [] hashTable;
	hashTable = temp_array;
    return;
}

void HashL::insert(string v){
	unsigned long a = hash(v);
	unsigned long x = a;

		while (hashTable[a] != NULL)
		{
			a++;
			if (a >= tableSize) 
				{a = a%tableSize;} 
		}
		hashTable[a] = new block(x, v);
		count++;

	if (count > 0.7* tableSize) 
	{
		resizeTable();
		return;
	}
    	return;
}

void HashL::deleteWord(string v){

	long a = hash(v);
	while (hashTable[a] != NULL && hashTable[a]->key != -1)
	{
		if (hashTable[a]->value == v)
		{
			hashTable[a]->key = -1;
		}
		a++;
		a = a%tableSize;
	}
   	return;
}

block* HashL::lookup(string v){
	
	long a = hash(v);

	while (hashTable[a] != NULL && hashTable[a]->key != -1)
	{
		 if (hashTable[a]->value == v)
		{
			return hashTable[a];
		}
		a++;
		a = a%tableSize;
	}
	return NULL;
}


#endif

