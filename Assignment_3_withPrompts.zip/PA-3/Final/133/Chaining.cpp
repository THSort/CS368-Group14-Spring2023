#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
// #include "LinkedList.h"
// #include "LinkedList.cpp"

HashC::HashC(int size){
	tableSize = size;
	hashTable = new LinkedList<string>[size];
}

HashC::~HashC(){
}

unsigned long HashC :: hash(string input){
	unsigned long temp = bitHash(input);
	long a = divCompression(temp,tableSize);
  	return a;
}

void HashC::insert(string word){
	unsigned long i = hash(word);
	hashTable[i].insertAtHead(word);

  	return;
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long i = hash(word);
		return  hashTable[i].searchFor(word);

}

void HashC :: deleteWord(string word){
	unsigned long i = hash(word);

	hashTable[i].deleteElement(word);
	
  	
}


#endif

