#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize];
    for (int i=0; i<tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){
    unsigned long temphash = polyHash(value,5);
    temphash = madCompression(temphash, tableSize);
    return temphash;
}

unsigned long HashD :: hash2(string value){
	unsigned long temphash = bitHash(value);
	// temphash = madCompression(temphash, tableSize);
	return temphash;
}


void HashD::resizeTable(){
	unsigned long actualsize = tableSize;
	tableSize *= 20;
	block** temp_array = new block*[tableSize];
	for (int i=0; i<tableSize; i++)
	{	
		temp_array[i]= NULL;
	}

	for (int i=0; i<actualsize; i++)
	{	
		if (hashTable[i]!= NULL && hashTable[i]->value != " ")
		{
			collisions = 0;
			unsigned long a = madCompression(hash1(hashTable[i]->value),tableSize) + (collisions*(hash2(hashTable[i]->value),tableSize));
		

			while (temp_array[a] != NULL)
			{
				collisions++;
				a = ((hash1(hashTable[i]->value)) + collisions*(hash2(hashTable[i]->value))) %tableSize;
			}

			temp_array[a] = new block(a,hashTable[i]->value);
		}
	}


	// tableSize *= 20;
	delete [] hashTable;
	hashTable = temp_array;
  
}


void HashD::insert(string value){
	collisions = 0;
	unsigned long a = hash1(value) + collisions*hash2(value);
	a = madCompression(a, tableSize, 1993, 1637);
	unsigned long x = a;

	while (hashTable[a] != NULL)
	{	
		if(hashTable[a]->key == -1)
		{
			break;
		}
		collisions++;
		a = hash1(value) + (collisions)*hash2(value);
		a = a%tableSize;
	}
	hashTable[a] = new block(x, value);
	count++;

	if (count > 0.5* tableSize) 
	{
		resizeTable();
		// return;
	}
}



void HashD::deleteWord(string value){
	collisions = 0;
	block* del = NULL;
	long a = hash1(value) + (collisions)*hash2(value);
	a = madCompression(a, tableSize, 1993, 1637);

	while(hashTable[a] != NULL && hashTable[a]->key != -1)
    {
    	if (hashTable[a]->value == value)
    	{
    		del= hashTable[a];
    		break;
    	}
    	
    	collisions++;
    	a = (hash1(value) + collisions*hash2(value))%tableSize;	
    }

    del->value = " ";
    return;
}




block* HashD::lookup(string value){
	collisions = 0;
	unsigned long a = hash1(value) + (collisions)*hash2(value);
	a = madCompression(a, tableSize, 1993, 1637);

		while (hashTable[a] != NULL && hashTable[a]->value != " ")
	{
		 if (hashTable[a]->value == value)
		{
			return hashTable[a];
		}
		collisions++;
		a = (hash1(value) + (collisions*hash2(value))) % tableSize;	
	}
	return NULL;
}




#endif