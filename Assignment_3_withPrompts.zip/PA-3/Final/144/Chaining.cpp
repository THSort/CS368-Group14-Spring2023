#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
#include "LinkedList.cpp"

HashC::HashC(int size){
    hashTable = new LinkedList <string> [size];
    tableSize=size;
    return;    
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
  	unsigned long result = bitHash(input);
  	return result;  
}

void HashC::insert(string word){
	unsigned long x = hash(word);
    x = x%tableSize;

  	hashTable[x].insertAtHead(word);
	return;
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long x = hash(word);
  	x = x%tableSize;

  	return hashTable[x].searchFor(word);
  	
}

void HashC :: deleteWord(string word){
	unsigned long x = hash(word);
  	x = x%tableSize;

  	hashTable[x].deleteElement(word);
  	return;
}

#endif