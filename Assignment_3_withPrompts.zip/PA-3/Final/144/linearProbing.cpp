#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count=0;
    
    hashTable = new block*[tableSize];
    for (int i = 0; i < tableSize; i++){
    	hashTable[i]= NULL;
    	
    }
    return;
}

HashL::~HashL(){
    for (int i = 0; i < tableSize; i++){
    	delete hashTable[i];
    	
    }
    delete [] hashTable;
    hashTable=NULL;
    return;
}

unsigned long HashL :: hash(string value){
    unsigned long x = bitHash(value);
    return x;
}

void HashL::resizeTable(){
	long new_size = tableSize*2;
	block ** newtable = new block* [new_size];
	bool check = false;
	for (int i = 0; i < new_size; i++)
	{
		newtable[i] = NULL;
	}
	for (int i = 0; i < tableSize; i++)
	{
		if(hashTable[i]!= NULL)
		{
			check = true;
		}
		if(check = true)
		{
			int x = hash(hashTable[i]->value) % new_size;
			while (newtable[x]!=NULL)
			{
				x++;
				if(x > new_size)
				{
					x = x % new_size;
				}
				
			}
			newtable[x] = new block(x, hashTable[i]->value);
		}
	}
	if(check = false)
	{
		delete[] hashTable;
		hashTable = newtable;
		tableSize = new_size;
		cout << "wewwe" << endl;
	}
}

void HashL::insert(string value){
	unsigned long x = hash(value);
	unsigned long x_2 = madCompression(x, tableSize);
	bool check = false;
	bool check2 = false;
	while (check == false)
	{
		if (hashTable[x_2] == NULL)
		{
			check2 = true;
		}
		if (check2 = true)
		{
			count++;
    		block* temp = new block(x,value);
    		hashTable[x_2] = temp;
            return;
		}
		if(hashTable[x_2]->value == "abs" && hashTable[x_2]->key == 0)
		{
			count++;
            hashTable[x_2]->value= value;
	    	hashTable[x_2]->key = x;
	    	return;
		}
		x_2++;
		x_2 = x_2 % tableSize;
		return;
	}
}

void HashL::deleteWord(string value){
	while(lookup(value)){
	block* node = lookup(value);
	bool check = false;
	if (node == NULL)
		return;
	node->key = 0;
	node->value = "abs";
	count--;
	if (count == tableSize*0.5)
	{
		check = true;
	}
	if (check == true)
	{
		resizeTable();
	}
	else if (check == false)
	{
		deleteWord(value);
	}
    }
    return;
}
block* HashL::lookup(string value){
	unsigned long x = (hash(value));
	unsigned long x_2 = madCompression(x, tableSize);
    bool check = false;
    while(1)
    {
    	if(hashTable[x_2]->value==value)
    	{
    		check = true;
    	}
    	
    	if (check = true)
    	{
    		cout << "jahhgajhgihgo"<< endl;
    		block* res = hashTable[x_2];
    		return res;
    	}
    	x_2++;
    	x_2 = x_2 % tableSize;
    }
    return NULL;
}
#endif
