#ifndef __LIST_CPP
#define __LIST_CPP
#include <cstdlib>
#include "LinkedList.h"
#include <iostream>

using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	head = NULL;
	
	ListItem<T> *temp = otherLinkedList.head;
	while (!(temp == NULL))
	{
		insertAtTail(temp->value);
		temp = temp->next;
	}	
}

template <class T>
LinkedList<T>::~LinkedList()
{
	while(head!=NULL)
	{
		ListItem<T> *temp = head;
		head = head->next;
		delete temp;
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> *temp = new ListItem<T> (item);
	if (head)
	{
		temp->next = head;
		head->prev = temp;
		head = temp;
	}
	else if (head == NULL)
	{
		head = temp;
	}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem <T> *temp = new ListItem <T> (item);
	if (head == NULL)
	{
		head=temp;
	}

	else
	{


		ListItem<T> *t = head;
		while(t->next!=NULL)
		{
			t = t->next;
		}
		t->next = temp;
		temp->prev = t;
		temp->next = NULL;
	}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	
	if (head == NULL)
	{
		insertAtHead(toInsert);
	}
	ListItem<T> *n = searchFor(afterWhat);
	if(n->next == NULL)
	{
		insertAtTail(toInsert);
	}
	else
	{
		ListItem<T> *temp = new ListItem<T>(toInsert);
		temp->next = n->next;
		temp->prev = n;
		n->next->prev = temp;
		n->next = temp;
	}

}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	
	if (head == NULL)
	{
		insertAtHead(item);
	}
	else {
		ListItem<T> *temp = head;
		while (temp->next !=NULL)
			temp = temp->next;

		if (temp->value<item){
			insertAtTail(item);
		}

		else {
			  ListItem<T> *temp2 = head;
			  while (!(temp2 == NULL))
        {
            if(temp2->value>=item)
            {
            	if (temp2->prev == NULL)
                    insertAtHead(item) ;
	            else
	                {
	                   	ListItem <T> *temp3 = new ListItem <T> (item);
	                   (temp2->prev)->next = temp3 ;
	                    temp3->prev = temp2->prev ;
	                    temp3->next = temp2;
	                    temp2->prev = temp3 ;


	                }
	                 break;
	            }
	            temp2= temp2->next ;
	        }
		}
}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	if(head == NULL)
		return NULL;
	else 
		return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	if (head == NULL)
	{
		return NULL;
	}
	else
	{
		ListItem<T> *temp = head;
		while(1)
		{
			if(temp->next == NULL)
			{
				return temp;
				break;
			}
			temp = temp->next;
		}
	}
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	if (head==NULL)
		{
			// cout << "No List. "<< endl;
			return NULL;
		}
		else
		{
			ListItem<T>* temp = head;
			while (temp!=NULL)
			{
				if (temp->value == item)
				{
					return temp;
				}
				temp = temp->next;
			}
			return NULL;
		}
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem <T> *temp = searchFor(item);
	if (temp->next == NULL)
	{
		deleteTail();
	}
	else if (temp == head)
	{
		deleteHead();
	}
	else
	{
		(temp->prev)->next = temp->next;
		(temp->next)->prev = temp->prev;
		delete temp;
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
   	ListItem<T> *temp = head;
	if (head!=NULL)
	{

		temp = head->next;
		delete head;
		head = temp;
	}
		else
	{
		cout << "No list. " << endl;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T> *temp = head;
	if (temp == NULL)
	{
		return;
	}
	else
	{
		while (!(temp->next ==NULL))
			temp = temp->next;
		
		if(temp==head) 
			deleteHead();
		else
		 	temp->prev->next = NULL;
		delete temp;
	}

}

template <class T>
int LinkedList<T>::length()
{
	ListItem<T> *temp = head;
	int count = 0;
	while (temp!=NULL)
	{
		temp = temp->next;
		count++;
	}
	return count;
}

template <class T>
void LinkedList<T>::reverse()
{
	while (head)
	{
		ListItem<T> *temp = head->prev;
		head->prev = head->next;
		head->next = temp;
		if (head->prev)
		{
			head = head->prev;	
		}
		else
		{
			break;
		}
	}
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	ListItem<T> *temp = head;
	for (int i = 0; i < length(); i++)
	{
		if(temp->value % 2 != 0)
		{
			insertAtTail(temp->value);
			deleteElement(temp->value);
		}
		temp = temp->next;
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	
	if (!head)
	{
		return false;
	}
	ListItem<T>* temp = head;
	ListItem<T>* temp2 = getTail();

	while(temp!=temp2)
	{

		if(temp->value!=temp2->value)
			return false;
		temp = temp->next;
		temp2 = temp2->prev;

	}
	return true;
}

#endif
