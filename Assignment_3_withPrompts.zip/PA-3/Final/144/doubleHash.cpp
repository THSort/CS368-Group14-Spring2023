#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 1000; // you cant change this
    count=0;
    
    hashTable = new block*[tableSize];
    for (int i = 0; i < tableSize; i++){
    	hashTable[i]= NULL;
    	
    }
    return;
}

HashD::~HashD(){
	for (int i = 0; i < tableSize; i++){
    	delete hashTable[i];
    	
    }
    delete [] hashTable;
    hashTable=NULL;
    return;
}

unsigned long HashD :: hash1(string value){
    unsigned long x = bitHash(value);
    return x;
}

unsigned long HashD :: hash2(string value){
    unsigned long x = polyHash(value);
    return x;
}

void HashD::resizeTable(){
    return;
}

void HashD::insert(string value){
    unsigned long x = hash1(value);
	unsigned long x_2 = madCompression(x, tableSize);
	bool check = false;
	bool check2 = false;
	int collision =0;
	while (check == false)
	{
		if (hashTable[x_2] == NULL)
		{
			check2 = true;
		}
		if (check2 = true)
		{
			count++;
    		block* temp = new block(x,value);
    		hashTable[x_2] = temp;
            return;
		}
		if(hashTable[x_2]->value == "aaa" && hashTable[x_2]->key == 0)
		{
			count++;
            hashTable[x_2]->value= value;
	    	hashTable[x_2]->key = x;
	    	return;
		}
		collision++;
		x_2 = hash1(value)+ collision*hash2(value); 
		x_2 = x_2 % tableSize;
		return;
	}
    return;
}

void HashD::deleteWord(string value){
    return;
}

block* HashD::lookup(string value){
    return NULL;
}

#endif