#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count = 0;
    hashTable = new block* [tableSize];

    for(int i=0; i<tableSize; i++)
    {
        hashTable[i] = NULL;
    }
    deleteMarker = new block(-1,"");
}

HashL::~HashL(){
    for(int i=0; i<tableSize; i++)
    {
        if(hashTable[i] != NULL)
        {
            delete hashTable[i];
        }
        delete[] hashTable;
    }
}

unsigned long HashL :: hash(string value){
    return divCompression(bitHash(value), tableSize);
}

void HashL::resizeTable(){
    tableSize++;
    return;
}

void HashL::insert(string value){
    long key = hash(value);
    block *temp = new block(key, value);
    while(hashTable[key] != NULL && hashTable[key]->key != key && hashTable[key]->key != -1)
    {
        key = (key+1) % tableSize;
    }
    if(hashTable[key] == NULL || hashTable[key]->key == -1)
    {
        count++;
    }
    hashTable[key] = temp;
    return;
}

void HashL::deleteWord(string value){
    long key = hash(value);
    while(hashTable[key] != NULL)
    {
        if(hashTable[key]->key == key)
        {
            break;
        }
        key = (key+1) % tableSize;
    }
    if(hashTable[key] == NULL)
    {
        return;
    }
    else
    {
        //hashTable[key] = deleteMarker;
        delete hashTable[key];
    }

}
block* HashL::lookup(string value){
    long key = hash(value);
    block *temp = new block(key, value);
    while (hashTable[key] != NULL)
    {
        if(hashTable[key]->key == key)
        {
            return temp;
        }
        key = (key+1) % tableSize;
    }
    return NULL;
}
#endif
