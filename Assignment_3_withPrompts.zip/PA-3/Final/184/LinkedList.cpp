#include <iostream>

#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
    head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
    head = NULL;
    //*this = otherLinkedList;
    ListItem<T> *temp = otherLinkedList.head;
    while(temp != NULL)
    {
        insertAtTail(temp->value);
        temp = temp->next;
    }
}

template <class T>
LinkedList<T>::~LinkedList()
{
    ListItem<T> *current = head;
    while (current != NULL)
    {
       ListItem<T> *next = current->next;
       delete[] current;
       current = next;
    }
   head = NULL;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
    ListItem<T> *temp = new ListItem<T>(item);
    temp->next = head;
    temp->prev = NULL;
    if(head != NULL)
    {
        head->prev = temp;
    }
    head = temp;
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
    /*ListItem<T> *temp = new ListItem<T>(item);
    ListItem<T> *last = head;
    while (last->next != NULL)
    {
        last = last->next;
    }
    last->next = temp;
    temp->next = NULL;*/

    ListItem<T> *last = new ListItem<T>(item);
    if(head==NULL)
    {
        head = last;
    }
    else
    {
        ListItem<T> *temp = head;
        while(temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = last;
    }

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
    ListItem<T> *temp = new ListItem<T>(toInsert);
    ListItem<T> *temp2 = head;

    while (temp2->value != afterWhat || temp2->next != NULL)
    {
        temp2 = temp2->next;
    }
    ListItem<T> *temp3 = temp2;
    temp2->next = temp;
    temp->prev = temp2;
    temp->next = temp3;
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
    if (head == NULL)
    {
        head = new ListItem<T>(item);
    }

    else if (head->value >= item)
    {
        ListItem<T> *temp = new ListItem<T>(item);
        temp->next = head;
        head = temp;
    }
    else
    {
        ListItem<T> *current = head;

        while ((current->next != NULL) && (current->next->value <= item))
        {
            current = current->next;
        }

        ListItem<T> *temp = new ListItem<T>(item);
        temp->next = current->next;
        temp = current;
        current->next = temp;
    }
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
    if (head == NULL)
        return NULL;
    else
    {
        return head;
    }
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    ListItem<T> *current = head;

    if (head == NULL)
    {
        return NULL;
    }
    if (head->next == NULL)
    {
        return head;
    }
    while (current != NULL)
    {
        if(current->next == NULL)
        {
            return current;
        }
        current = current->next;
    }
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
    //ListItem<T> *temp = new ListItem<T>(item);
    ListItem<T> *ptr = head;
/*    if (head == NULL)
    {
        return NULL;
    }
    else
    {
        while (ptr->value != item || ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        if (ptr->next == NULL)
        {
            return NULL;
        }
        else
        {
            return ptr;
        }
    }*/

    while(ptr!=NULL)
    {
        if(ptr->value == item)
        {
            return ptr;
        }
        ptr = ptr->next;
    }
    return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
    ListItem<T> *prev = head;
    ListItem<T> *current = head->next;
    while(current!= NULL)
    {
        if(current->value == item)
        {
            break;
        }
        else
        {
            prev = current;
            current = current->next;
        }
    }
    if(current==NULL)
    {
        return;
    }
    else
    {
        prev->next = current->next;
        delete current;
    }


/*
    ListItem<T> *temp = head;
    ListItem<T> *prev = head;
    ListItem<T> *n = new ListItem<T>(item);

    if(temp == n)
    {
        if(temp->next == NULL)
        {
            return;
        }
        temp->value = temp->next->value;
        n = temp->next;
        temp->next = temp->next->next;
        delete temp;
        return;
    }

    while(prev->next!=NULL && prev->next!=n)
    {
        prev = prev->next;
    }

    if(prev->next == NULL)
    {
        return;
    }
    prev->next = prev->next->next;
    delete n;
    return;
*/

/*
    ListItem<T> *temp = head;
    ListItem<T> *current = head->next;
    while (current != NULL)
    {
        if(current->value == item)
        {
            temp->next = current->next;
            delete current;
            break;
        }
        else
        {
            temp = current;
            current = current->next;
        }
    }
*/
}

template <class T>
void LinkedList<T>::deleteHead()
{
    if (head == NULL)
        return;
    else
    {
        ListItem<T> *temp = head;
        ListItem<T> *tail = head;

        while (tail->next != NULL)
        {
            tail = tail->next;
        }

        if(head == tail)
        {
            head = NULL;
            tail = NULL;
        }
        else
        {
            head = head->next;
        }

        delete temp;
    }
}

template <class T>
void LinkedList<T>::deleteTail()
{
    ListItem<T> *ptr1 = head;
    ListItem<T> *ptr2 = head->next;

    if(ptr2 == NULL)
    {
        return;
    }

    while (ptr2->next != NULL)
    {
        ptr1 = ptr2;
        ptr2 = ptr2->next;
    }
    ptr1->next = NULL;

}

template <class T>
int LinkedList<T>::length()
{
    ListItem<T> *temp = head;
    int len = 1;

    if (head == NULL)
    {
        len = 0;
    }
    while (temp->next != NULL)
    {
        temp = temp->next;
        len = len + 1;
    }
    return len;
}

template <class T>
void LinkedList<T>::reverse()
{

}

template <class T>
void LinkedList<T>::parityArrangement()
{

}

#endif
