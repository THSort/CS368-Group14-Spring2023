#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    this->tableSize = size;
    hashTable = new LinkedList<string>[tableSize];
}
HashC::~HashC(){
    delete[] hashTable;
}

unsigned long HashC :: hash(string input){
  return divCompression(bitHash(input), tableSize);
}

void HashC::insert(string word){
    int index = hash(word);
    hashTable[index].insertAtTail(word);
}

ListItem<string>* HashC :: lookup(string word){
    int index = hash(word);
    return hashTable[index].searchFor(word);
}

void HashC :: deleteWord(string word){
    int index = hash(word);
    hashTable[index].deleteElement(word);

}

#endif
