#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"

HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    count = 0;
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i] = NULL;
    }
}

HashD::~HashD(){
    for(int i=0; i<tableSize; i++)
    {
        if(hashTable[i] != NULL)
        {
            delete hashTable[i];
        }
        delete[] hashTable;
    }
}

unsigned long HashD :: hash1(string value){
    return divCompression(bitHash(value), tableSize);
}

unsigned long HashD :: hash2(string value){
    int prime = 41;
    return prime - (bitHash(value) % prime);
}

void HashD::resizeTable(){
    tableSize++;
}

void HashD::insert(string value){
    long key = hash1(value);
    block *temp = new block(key, value);
    if(hashTable[key] != NULL)
    {
        long key2 = hash2(value);
        int x=1;
        while(1)
        {
            long newKey = (key + x * key2) % tableSize;
            if(hashTable[newKey] == NULL)
            {
                hashTable[newKey] = temp;
                break;
            }
            x++;
        }
    }
    else
    {
        hashTable[key] = temp;
    }
    count++;
    return;
}

void HashD::deleteWord(string value){
    return;
}

block* HashD::lookup(string value){
    long key = hash1(value);
    long key2 = hash2(value);
    block *temp = new block(key, value);
    while(hashTable[key] != NULL && hashTable[key]->key != key)
    {
        key = (key + key2) % tableSize;
    }

    return temp;
}

#endif
