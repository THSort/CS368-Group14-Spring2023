#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	ListItem<T>* travOther = otherLinkedList.head;
	if(travOther!=NULL)
	{
		head = new ListItem<T>(travOther->value);
		ListItem<T>* travMe = head;
		travOther = travOther -> next;

		while(travOther != NULL)
		{
			travMe->next = new ListItem<T>(travOther->value);
			travMe->next->prev = travMe;
			travMe = travMe -> next;
			travOther = travOther -> next;
		}

	}
	

}

template <class T>
LinkedList<T>::~LinkedList()
{
	/*ListItem<T>* temp = head;
	ListItem<T>* trav = temp;

	while(temp!= NULL)
	{
		trav = trav->next;
		delete temp;
		temp = trav;
	}
	head = NULL;*/
	while(length()!=0){
		deleteTail();
	}

}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T>* prevHead = head;
	head = new ListItem<T>(item);
	if(prevHead != NULL)
	{
		head-> next = prevHead;
		prevHead->prev = head;
	}	

}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem<T>* trav = head;

	if(head!=NULL)
	{
		while(trav->next != NULL)
		{
			trav = trav->next;
		}
		trav->next = new ListItem<T>(item);
		trav->next->prev = trav;
	}
	else
	{
		insertAtHead(item);
	}


}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T>* trav = head;
	while(trav!= NULL)
	{
		if(trav->value == afterWhat)
		{
			ListItem<T>* temp = trav->next;
			trav->next = new ListItem<T>(toInsert);
			trav->next->prev = trav;
			trav->next->next = temp;
			if(temp!=NULL)
			{
				temp->prev = trav->next;
			}
			return;
		}
		else
		{
			trav=trav->next;
		}
	}

}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem<T>* trav = head;
	if(head == NULL || head->value > item)
	{
		insertAtHead(item);
		return;
	}
	while(trav!= NULL)
	{
		if((trav->value < item && trav->next == NULL) || (trav->value < item && trav->next->value >= item))
		{
			insertAfter(item,trav->value);
			return;
		}
		else
		{
			trav=trav->next;
		}
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	ListItem<T>* trav = head;
	if(trav==NULL)
	{
		return NULL;
	}
	else
	{
		while(trav->next != NULL)
		{
			trav= trav->next;
		}
		return trav;
	}
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T>* trav = head;
	if(trav==NULL)
	{
		return NULL;
	}
	else
	{
		while(trav->next != NULL && trav->value != item)
		{
			trav= trav->next;
		}
		if(trav->value == item)
			return trav;
		else
			return NULL;
	}
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T>* find = searchFor(item);
	if(find != NULL)
	{
		if(find == head)
		{
			deleteHead();
		}
		else if (find->value == getTail()->value)
		{
			deleteTail();
		}
		else
		{
			find->next->prev = find->prev;
			find->prev->next = find->next;
			delete find;
			find = 0;
		}
	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if(head!=NULL)
	{
		ListItem<T>* temp = head;
		head = head->next;
		if(temp->next != NULL)
		{
			head->prev = NULL;
		}
		delete temp;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T>* myTail = getTail();
	if(myTail != NULL)
	{
		if(myTail == getHead())
		{
			deleteHead();
		}
		else
		{
			myTail->prev->next = NULL;
			delete myTail;
		}
	}
}

template <class T>
int LinkedList<T>::length()
{
	int num = 0;
	if(head == NULL)
	{
		return 0;
	}
	else
	{
		num++;
		ListItem<T>* trav = head;
		while(trav->next != NULL)
		{
			trav= trav->next;
			num++;
		}
		return num;
	}
}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T>* trav = getHead();
	head = getTail();

	while(trav != NULL)
	{
		ListItem<T>* temp = trav->next;
		trav->next = trav->prev;
		trav-> prev = temp;
		trav = temp;
	}

}

template <class T>
void LinkedList<T>::parityArrangement()
{
	ListItem<T>* trav = getHead();
	int counter = 1;

	while(counter != length())
	{
		if(!(counter%2))
		{
			ListItem<T>* temp = trav;
			trav->next->prev = trav->prev;
			trav->prev->next = trav->next;
			trav=trav->next;
			ListItem<T>* tail = getTail();
			tail->next = temp;
			temp->prev = tail;
			temp->next = NULL;
		}
		else
		{
			trav=trav->next;
		}
		counter++;
	}   
}
template<class T>
bool LinkedList<T>::isPalindrome()
{
	if(length() == 0)
		return false; 

	ListItem<T>* trav = getHead();
	LinkedList<T> copy;
	while(trav!=NULL)
	{
		copy.insertAtTail(trav->value);
		trav=trav->next;
	}

	copy.reverse();
	ListItem<T>* copyTrav = copy.getHead();
	trav = getHead();

	while(trav!=NULL)
	{
		if(trav->value != copyTrav->value)
			return false;
		trav=trav->next;
		copyTrav=copyTrav->next;
	}
	return true;
	
}
/*int main()
{
	LinkedList<int> myList;
	std::cout<<"started \n";
	myList.insertSorted(1);
	myList.insertSorted(2);
	myList.insertSorted(3);
	myList.insertSorted(4);

	ListItem<int>* search = myList.searchFor(5);
	if(search!= NULL)
		std::cout<<"found \n";
	return 0;
}*/
#endif
