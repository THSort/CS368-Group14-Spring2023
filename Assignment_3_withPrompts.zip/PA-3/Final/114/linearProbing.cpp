#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"
#include <iostream>

using namespace std;



HashL::HashL(){
    tableSize = 1000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize];
    incrementGrow =512;
    resizeMode = 0;
    for(int i = 0;i < tableSize; i++)
    {
      hashTable[i] = new block(tableSize,"");
    }
    // Initialising key to 1000 as they value can not be returned by compression
    // function

}

HashL::~HashL(){
  for(int i =0; i< tableSize; i++)
  {
    delete (hashTable[i]);
  }
}

unsigned long HashL :: hash(string value){
    unsigned long hashResult = bitHash(value); //polyHash(value,5);
    unsigned long index = madCompression(hashResult,tableSize,8191,131071);
    return index;
}

void HashL::resizeTable(){
    int oldTableSize = tableSize;
    int oldCount = count;
    block ** oldTable = hashTable;
    count = 0;
    

    if(resizeMode == 1)//tableGrow
    {
     // cout <<"2^"<<incrementGrow<<" values inserted"<<endl;
      tableSize *= 2;
      hashTable = new block*[tableSize];
      incrementGrow*=2;
    }
    else//tableShrink
    {
      tableSize *= 0.5;
      hashTable = new block*[tableSize];
    }


    for(int k = 0; k < tableSize; k++)//  Initialise new table
    {
      hashTable[k] = new block(tableSize, "");
    }

    for(int i = 0; i<oldTableSize; i++)
    {
      if(oldTable[i]->key != oldTableSize)
      {
        insert(oldTable[i]->value);// resizeMode is set to non 0, hence check for resize off
      }
      if(count == oldCount)//  No need to traverse rest of the list if all values have been transferred
        break;
    }
    resizeMode = 0;
    return;

}
void HashL::insert(string value){
    unsigned long hashFuncResult = hash(value);
    unsigned long trav = hashFuncResult;
    while(trav != tableSize && hashTable[trav] ->key != tableSize)
    {
      if(trav != tableSize && hashTable[trav] -> value == value)
      {
        return;
      }
      
      trav++;
    }

    if(trav != tableSize)//Value inserted
    {
      hashTable[trav] -> key = hashFuncResult;
      hashTable[trav] -> value = value;
      count++;
    }
   
    //cout<<"2^incrementGrow = "<<growthCheck<<endl;
    
    if(resizeMode == 0 && (count % incrementGrow == 0))
    {
      resizeMode = 1;
      resizeTable();
    }
    else if(trav == tableSize)
    {
      resizeMode = 1;
      resizeTable();
      insert(value);
    }

    return;
}

void HashL::deleteWord(string value){
    block* search = lookup(value);

    if(search)
    {
      search -> key = tableSize;
      search -> value = "deletedFLAG#";
      count --;
      if(count == (tableSize)/10.0)
      {
        resizeMode = -1;//  Shrink Mode
       // cout<<"Shrinking"<<endl;
        resizeTable();
      }
    }
    return;
}
block* HashL::lookup(string value){
    unsigned long hashResult = hash(value);
    unsigned long trav = hashResult;
    while(trav != tableSize)
    {
      if(hashTable[trav] -> value == value)
      {
        return hashTable[trav];
      }
      else if(hashTable[trav] -> key == tableSize && hashTable[trav] -> value == "")
        return NULL;
      trav++;
    }
    return NULL;
}
#endif
