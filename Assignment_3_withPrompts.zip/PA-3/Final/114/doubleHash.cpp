#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
#include <iostream>

using namespace std;
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize];
    incrementGrow =4500;//2^13 = 8192
    resizeMode = 0;
    hashval = 0;// As both hashes use the same function, this avoids repeat calc
    searchVal = 0;
    
    for(int i = 0;i < tableSize; i++)
    {
      hashTable[i] = new block(tableSize,"");
    }

}
HashD::~HashD(){
  for(int i =0;i<tableSize;i++)
  {
    delete hashTable[i];
  }

}

unsigned long HashD :: hash1(string value){
    hashval =bitHash(value);
    return hashval;//polyHash(value,5);
}

unsigned long HashD :: hash2(string value){
    return tableSize - hashval;
}

void HashD::resizeTable(){
    //cout<<"\n\nResizing table, occupancy at "<<count*100.0/tableSize<<endl;
    //cout<<"Count = "<<count<<", Table Size = "<<tableSize<<endl;
    int oldTableSize = tableSize;
    int oldCount = count;
    block ** oldTable = hashTable;
    count = 0;
    

    if(resizeMode == 1)//tableGrow
    {
     // cout <<"2^"<<incrementGrow<<" values inserted"<<endl;
      tableSize *= 4;
      hashTable = new block*[tableSize];
      incrementGrow*=4;
    }
    else//tableShrink
    {
      tableSize *= 0.5;
      hashTable = new block*[tableSize];
    }


    for(int k = 0; k < tableSize; k++)//  Initialise new table
    {
      hashTable[k] = new block(tableSize, "");
    }

    for(int i = 0; i<oldTableSize; i++)
    {
      if(oldTable[i]->key != oldTableSize)
      {
        insert(oldTable[i]->value);// resizeMode is set to non 0, hence check for resize off
      }
      if(count == oldCount)//  No need to traverse rest of the list if all values have been transferred
        break;
    }
    resizeMode = 0;
   // cout<<"Resizing finished"<<endl;
    return;
}

void HashD::insert(string value){
    if(lookup(value) != NULL)
      return;

    unsigned long hashResult = hash1(value);
    unsigned long additional = hash2(value);
    unsigned long trav = madCompression(hashResult,tableSize,1993,1637);
    unsigned long keyStore = trav;
    int growthCheck = incrementGrow;
    
    
    int i = 1;

    while(hashTable[trav]->key != tableSize)
    {
      trav = madCompression((hashResult + i*additional),tableSize,1993,1637);
      i++;
      if(i >= tableSize)
        break;
     // cout<<"i insert ="<<i<<endl;
    }

    if(hashTable[trav]->key == tableSize)
    {
      hashTable[trav]->key = keyStore; // madCompression(hashResult,tableSize,1993,1637);
      hashTable[trav]->value = value;
      count ++;
    }
    
    if(resizeMode == 0 && (count % growthCheck == 0))
    {
      resizeMode = 1;
      resizeTable();
    }
    else if(i >=tableSize)
    {
      resizeMode = 1;
      resizeTable();
      insert(value);
    }

    return;

}

void HashD::deleteWord(string value){
    block* search = lookup(value);
    if(search != NULL)
    {
      unsigned long hashResult = hash1(value);
      unsigned long additional = hash2(value);
      unsigned long trav = searchVal;  // madCompression(hashResult,tableSize,1993,1637);
      
      int i = 1;
      
      
      while(hashTable[trav]->value != value)
      {
        trav = madCompression((hashResult + i*additional),tableSize,1993,1637);
        i++;
      }

      hashTable[trav]->value = "deletedFLAG#";
      hashTable[trav]->key = tableSize;
      count --;
      if(count == (tableSize)/10.0)
      {
        resizeMode = -1;//  Shrink Mode
        //cout<<"Shrinking"<<endl;
        resizeTable();
      }

    }
    hashval = 0;
    return;
}

block* HashD::lookup(string value){
    unsigned long hashResult = hash1(value);
    unsigned long additional = hash2(value);
    unsigned long trav = madCompression(hashResult,tableSize,1993,1637);

    int i = 1;
    while(trav < tableSize)
    {
      if(hashTable[trav] -> value == value)
      {
        searchVal = trav;
        return hashTable[trav];
      }
      else if(hashTable[trav] -> key == tableSize && hashTable[trav] -> value == "")
      {
        return NULL;
      }
      trav=madCompression((hashResult + i*additional),tableSize,1993,1637);
      i++;
      if(i>= tableSize)
        break;
     // cout<<"i lookup = "<<i<<endl;
    }

    return NULL;
}


#endif
