#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
   hashTable = new LinkedList<string>[size];
   tableSize = size;
}
HashC::~HashC(){
   delete [] hashTable;
}

unsigned long HashC :: hash(string input){
  return divCompression(bitHash(input),tableSize);
  //return madCompression(bitHash(input),tableSize,1993,1637);
}

void HashC::insert(string word){
  unsigned long hashResult = hash(word);
 if(lookup(word) == NULL)
    hashTable[hashResult].insertAtHead(word);
  //else
    //cout<<"Not inserting duplicate word: "//<<word<<endl;
}

ListItem<string>* HashC :: lookup(string word){
  unsigned long hashResult = hash(word);
  return hashTable[hashResult].searchFor(word);
}

void HashC :: deleteWord(string word){
  unsigned long hashResult = hash(word);
  hashTable[hashResult].deleteElement(word);
}

#endif
