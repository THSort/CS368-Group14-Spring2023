#include <iostream>
#include <string>
#include "hashfunctions.cpp"

using namespace std;
int main()
{
	string input;
	cout<<"Hashing function Test"<<endl;
	cout<<"Enter string to hash:"<<endl;
	cin>>input;

	cout<<polyHash(input)<<endl;
	cout<<bitHash(input)<<endl;
	cout<<divCompression(polyHash(input),2054)<<endl;
	cout<<madCompression(polyHash(input),2054)<<endl;

	return 0;
}