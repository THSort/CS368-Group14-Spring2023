#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block*[tableSize];
    for (int i = 0;i < tableSize; i++)
    {
    	hashTable[i] = NULL; 
    }

    count = 0;
}

HashL::~HashL(){
	for (int i=0; i < tableSize; i++)
	{
		delete hashTable[i];
	}

	delete [] hashTable;  
}

unsigned long HashL :: hash(string value){
    return divCompression(polyHash(value),tableSize);
}

void HashL::resizeTable(){
	int oldSize = tableSize;
	block** oldTable = hashTable;
	tableSize *= 2;
	block** newTable = new block*[tableSize];
	

	for (int i = 0; i < oldSize;i++)
	{
		if (oldTable[i] != NULL)
		{
			block* cell;
			cell = oldTable[i];
			unsigned long newHash = hash(hashTable[i]->value);
			newTable[newHash]->key = oldTable[i]->key;
			newTable[newHash]->value = oldTable[i]->value;
			delete cell;
		}
	} 

	delete [] oldTable;

}

void HashL::insert(string value){
	unsigned long hashV = hash(value);
	bool inserted = false;

	if ((tableSize - count) < (tableSize/3))
	{
		resizeTable();
	}
	
	while (inserted != true)
	{
		if (hashTable[hashV] != NULL)
		{
			hashV += 1;
		}
		else if (hashTable[hashV] == NULL || hashTable[hashV]->value == "Deleted")
		{
			hashTable[hashV]->value = value;
			hashTable[hashV]->key = hashV;
			count++;
			inserted = true;
		}
	}
    
}

void HashL::deleteWord(string value){
	block* search = lookup(value);
	delete search;
	count--;
}

block* HashL::lookup(string value){
	unsigned long hashV = hash(value);
	bool found = false;

	while ((found != true) && (hashV < tableSize))
	{
		if (hashTable[hashV]->value == value)
		{
			found = true;
			return hashTable[hashV];
		}
		else if (hashTable[hashV]->value == "Deleted" && hashTable[hashV]->value != value)
		{
			hashV += 1;
		}
	}

	if (found == false)
	{
		return NULL;
	}  
}
#endif
