#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	
	ListItem<T> *L2 = head;
	ListItem<T> *L1 = otherLinkedList.head;

	if (L1 != NULL)
	{
		
		ListItem<T> *newNode = new ListItem<T>(L1->value);
		head = newNode;
		while (L1->next != NULL)
		{
			L1 = L1->next;
			insertAtTail(L1->value);
		}
	}
	else
	{
		head = NULL;
	}	
}

template <class T>
LinkedList<T>::~LinkedList()
{
	//ListItem<T> *temp = NULL;
	while (head != NULL)
    {
        deleteHead();
    }
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{ 
	if (head == NULL)
	{
		ListItem<T> *temp = new ListItem<T>(item);
		head = temp;
	}
	else
	{
		ListItem<T> *temp = new ListItem<T>(item);
    	temp->next = head;
    	head->prev = temp;
    	head = temp;
	}
	
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if (head == NULL)
	{
		ListItem<T> *temp = new ListItem<T>(item);
		head = temp;
	}
	else
	{
		ListItem<T> *temp = NULL;
		temp = head;
		
		while (temp->next != NULL)
		{
			temp = temp->next;
		}

		ListItem<T> *newNode = new ListItem<T>(item);
		
		temp->next = newNode;
		newNode->prev = temp;
	}
	
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T> *temp = head;
	while ((temp->value!=afterWhat) && (temp != NULL))
	{
		temp = temp->next;
	}

	if (temp->next == NULL)
	{
		ListItem<T> *newNode = new ListItem<T>(toInsert);
		temp->next = newNode;
		newNode->prev = temp;
	}
	else
	{
		ListItem<T> *newNode = new ListItem<T>(toInsert);
		newNode->next = temp->next;
		temp->next = newNode;
		newNode->prev = temp;
		(newNode->next)->prev = newNode;
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	
	ListItem<T> *newNode = new ListItem<T>(item);
	ListItem<T> *temp = head;
	if (head == NULL)
	{
		head = newNode;
	}	

	else if (head->value >= item)
	{
		newNode->next = head;
		head->prev = newNode;
		head = newNode;
	}
	else
	{
		while ((temp->next != NULL) && (temp->next->value < item))
		{
			temp = temp->next;
		} 

		if (temp->next == NULL)
		{
			temp->next = newNode;
			newNode->prev = temp;
		}
		else
		{
			newNode->next = temp->next;
			temp->next = newNode;
			newNode->next->prev = newNode;
			newNode->prev = temp;		
		}	
	}

	
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	ListItem<T> *tail = NULL;
	tail = head;

	if (tail == NULL)
	{
		return tail;
	}
	else
	{
		while (tail->next!= NULL)
		{
			tail = tail->next;
		}

		return tail;
	}
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T> *temp = NULL;
	temp = head;

	while ((temp != NULL) && (temp->value != item))
	{
		temp = temp->next;
	}

	return temp;

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T> *temp = NULL;
	temp = head;

	while ((temp != NULL) && (temp->value != item))
	{
		temp = temp->next;
	}

	if (temp != NULL)
	{
		if (temp->next == NULL)
		{
			(temp->prev)->next = NULL;
			delete temp;
		}
		else
		{
			if (temp == head)
			{
				deleteHead();
			}
			else
			{
				ListItem<T> *beforeDelete = temp->prev;
				beforeDelete->next = temp->next;
				(temp->next)->prev = beforeDelete;
				delete temp;
			}
		}
	}

}

template <class T>
void LinkedList<T>::deleteHead()
{
	ListItem<T> *temp = NULL;
	temp = head;
	if (temp == NULL)
	{
		delete head;
	}
	else
	{
		head = head->next;
		//head ->prev = NULL;
		delete temp;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T> *temp = NULL;
	temp = head;
	while (temp->next != NULL)
	{
		temp = temp->next;
	}

	if (temp == head)
	{
		delete temp;
		head = NULL;
	}
	else
	{
		(temp->prev)->next = NULL;
		delete temp;
	}
}

template <class T>
int LinkedList<T>::length()
{
	ListItem<T> *temp = NULL;
	temp = head;
	int l = 0;

	while (temp != NULL)
	{
		l++;
		temp = temp->next;
	}

	return l;

}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T> *temp = NULL;
	ListItem<T> *temp2 = head;

	while (temp2!= NULL)
	{
		temp = temp2->prev;
		temp2->prev = temp2->next;
		temp2->next = temp;
		temp2 = temp2->prev;
	}

	if (temp != NULL)
	{
		head = temp->prev;
	}	
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	ListItem<T> *temp = head;
	ListItem<T> *evenStart = NULL;
	ListItem<T> *evenEnd = NULL;
	ListItem<T> *tail = getTail();
	
	while ((temp!=NULL) && (temp!=evenStart))
	{
		if (temp->value % 2 == 0)
		{
			if (evenStart == NULL)
			{
				evenStart = temp;
			}

			//temp = temp->next;

			if (evenStart->prev == NULL)
			{
				evenStart->next->prev = NULL;
				evenStart->next = NULL;
				tail->next = evenStart;
				evenStart->prev = tail;
				head = temp;
				tail = getTail();
			}
			else
			{
				evenEnd = temp;
				temp = temp->next;
				evenEnd->prev->next = evenEnd->next;
				evenEnd->prev->next->prev = evenEnd->prev;
				tail->next = evenEnd;
				evenEnd->prev = tail;
				tail = getTail();
			}
		}
		else //when odd
		{
			temp = temp->next;
		}
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	ListItem<T> *tail = getTail();
	ListItem<T> *temp = NULL;
	temp = head;

	if (temp == NULL)
	{
		return 0;
	}
	else	
	{
		while (tail != temp)
		{
			if (temp->value == tail->value)
			{
				temp = temp->next;
				if (temp == tail)
				{
					return 1;
				}
				tail = tail->prev;
			}
			else
			{
				return 0;
			}
		}
		return 1;
	}
	
}

#endif
