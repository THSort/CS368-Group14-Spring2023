#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

using namespace std;

HashC::HashC(int size){
	this->tableSize = size;
	hashTable = new LinkedList<string>[tableSize];
	for (int i = 0; i < tableSize; i++)
	{
		hashTable[i] = LinkedList<string>();
	}

}

HashC::~HashC(){
	ListItem<string> *temp_next = NULL;
	for (int i = 0 ; i < tableSize; i++)
	{
		if (hashTable[i].getHead() != NULL)
		{
			ListItem<string>* temp = hashTable[i].getHead();
			temp_next = temp->next;
			delete temp;
		}
	}
	delete []hashTable;
}

unsigned long HashC :: hash(string input){
	unsigned long hash = madCompression(polyHash(input),tableSize);
  	return hash;  
}

void HashC::insert(string word){
	unsigned long hashValue = hash(word);
	hashTable[hashValue].insertAtTail(word);
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long hashValue = hash(word);
	return hashTable[hashValue].searchFor(word);	
}

void HashC :: deleteWord(string word){
  unsigned long hashValue = hash(word);
  hashTable[hashValue].deleteElement(word);
}

#endif