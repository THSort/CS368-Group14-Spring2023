#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    for (int i = 0;i < tableSize; i++)
    {
    	hashTable[i] = NULL; 
    }

    count = 0;
}

HashD::~HashD(){
	for (int i=0; i < tableSize; i++)
	{
		delete hashTable[i];
	}

	delete [] hashTable;

}

unsigned long HashD :: hash1(string value){
    return divCompression(polyHash(value),tableSize);
}

unsigned long HashD :: hash2(string value){
    return madCompression(bitHash(value),tableSize);
}

void HashD::resizeTable(){
	int oldSize = tableSize;
	block** oldTable = hashTable;
	tableSize *= 2;
	block** newTable = new block*[tableSize];
	

	for (int i = 0; i < oldSize;i++)
	{
		int k = 0;
		if (oldTable[i] != NULL)
		{
			block* cell;
			cell = oldTable[i];
			unsigned long newHash = hash1(hashTable[i]->value) + k*hash2(hashTable[i]->value);
			if (hashTable[newHash] != NULL)
			{
				while (hashTable[newHash] != NULL)
				{
					k++;
					newHash = hash1(hashTable[i]->value) + k*hash2(hashTable[i]->value);
				}
			}
			newTable[newHash]->key = oldTable[i]->key;
			newTable[newHash]->value = oldTable[i]->value;
			delete cell;
		}
	} 

	delete [] oldTable;
}

void HashD::insert(string value){
	int i = 0;
    unsigned long hashV = hash1(value) + i*hash2(value);
	bool inserted = false;

	if ((tableSize - count) < (tableSize/3))
	{
		resizeTable();
	}
	
	while (inserted != true)
	{
		if (hashTable[hashV] != NULL)
		{
			i += 1;
			hashV = hash1(value) + i*hash2(value);
		}
		else if (hashTable[hashV] == NULL || hashTable[hashV]->value == "Deleted")
		{
			hashTable[hashV]->value = value;
			hashTable[hashV]->key = hashV;
			count++;
			inserted = true;
		}
	}
}

void HashD::deleteWord(string value){
	
	block* search = lookup(value);
	delete search;
	count--;
}

block* HashD::lookup(string value){
	int i = 0;
    unsigned long hashV = hash1(value) + i*hash2(value);
	bool found = false;

	while ((found != true) && (hashV < tableSize))
	{
		if (hashTable[hashV]->value == value)
		{
			found = true;
			return hashTable[hashV];
		}
		else if (hashTable[hashV]->value == "Deleted" && hashTable[hashV]->value != value)
		{
			i += 1;
			hashV = hash1(value) + i*hash2(value);
		}
	}

	if (found == false)
	{
		return NULL;
	}
}

#endif