#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	
	tableSize = size;
	hashTable = new LinkedList<string>[tableSize];
    
}
HashC::~HashC(){
delete hashTable ;
}

unsigned long HashC :: hash(string input){
	
	unsigned long hashing = bitHash(input);
	hashing = divCompression(hashing,tableSize);
  	return hashing;  
}

void HashC::insert(string word){
	
	unsigned long index = hash(word);
	hashTable[index].insertAtHead(word);

	return;
}

ListItem<string>* HashC :: lookup(string word){

	unsigned long index = hash(word);
	return hashTable[index].searchFor(word);
	
}

void HashC :: deleteWord(string word){

	unsigned long index = hash(word);
	hashTable[index].deleteElement(word);
	return;
}

#endif
