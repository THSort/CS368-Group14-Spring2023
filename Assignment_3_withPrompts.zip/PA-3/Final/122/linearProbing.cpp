#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count = 0;
    hashTable=new block*[tableSize];

    for(int i=0; i < tableSize; i++)
    	hashTable[i]=NULL;

}

HashL::~HashL(){
	for(unsigned long i =0; i < tableSize; i++)
	{
		delete hashTable[i];
	}
	delete [] hashTable;
    
}

unsigned long HashL :: hash(string value){

	
	unsigned long hashing = divCompression(bitHash(value),tableSize);
  	return hashing;  
    
}

void HashL::resizeTable(){

		
		//cout << count;
		
		/*unsigned long oldsize= tableSize;
		
		tableSize= tableSize*2;
		block** temp= new block*[tableSize];

		for(unsigned long i =0; i < tableSize; i++)
		{
			temp[i]=NULL;
		}

		unsigned long i =0;
		while(i<oldsize)
		{
			if((hashTable[i]!=NULL) && hashTable[i]->key !=-1)
			{
				
				unsigned long newindex = divCompression(bitHash(hashTable[i]->value),tableSize);
				unsigned long nkey,index2 = newindex;


				while(index2<tableSize)
				{
					if(temp[newindex]== NULL)
					{
						block* temp1= new block(nkey,hashTable[i]->value);
						temp[newindex] = temp1;
						break;
					}
					else
					{
						newindex++;
						newindex%=tableSize;
						index2= newindex;
					}
				}
			}
			i++;

		}




		/*for(unsigned long i=0; i < oldsize; i++)
		{
			if (hashTable[i]!=NULL)
			{
				unsigned long index = hash(hashTable[i]->value);

				while(temp[index]!=NULL)
				{
					index = divCompression(index++, tableSize);
				}

				temp[index]= new block(index,hashTable);

			}

		}
		
		delete [] hashTable;
		hashTable = temp; 





		for(unsigned long i =0; i <oldsize; i++)
		{
			hashTable[i]= NULL;
			delete hashTable[i];
		}
		
		delete [] hashTable;

		block** hashTable = new block*[tableSize];

		for (unsigned long i =0; i < tableSize; i++)
		{
			hashTable[i]= temp[i];
		}
	*/
}
    


void HashL::insert(string value)
{	
	if (count > 0.7* tableSize)
	{
	unsigned long index = hash(value);
	block *temp= new block(index, value);

	while(hashTable[index]!= NULL)
	{	
		index++;
		index%=tableSize;
		

	}

	if(hashTable[index]==NULL)
	{
		hashTable[index]= temp;
	}
	
	count++;
	//resizeTable();
}



    return;
}

void HashL::deleteWord(string value){

	unsigned long index = hash(value);
	block *temp= new block(index, value);

	while(hashTable[index]!=NULL)
	{
		if (hashTable[index]->value==value)
		{
			hashTable[index]->value=-1;
			count--;
			return;
		}

		index++;
		index%=tableSize;

	}
	
    return;
}
block* HashL::lookup(string value){


	unsigned long index = hash(value);
	block *temp= new block(index, value);

	while(hashTable[index]!=NULL)
	{
		if (hashTable[index]->value==value)
		{	temp= hashTable[index];
			return temp;
		}

		index++;
		index%=tableSize;
	}
    return NULL;
}
#endif
