#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count = 0;
    hashTable=new block*[tableSize];

    for(int i=0; i < tableSize; i++)
    	hashTable[i]=NULL;

}

HashD::~HashD(){

		for(unsigned long i =0; i < tableSize; i++)
	{
		delete hashTable[i];
	}
	delete [] hashTable;

}

unsigned long HashD :: hash1(string value){

	unsigned long hashing = divCompression(bitHash(value),tableSize);
  	return hashing;  
    
}

unsigned long HashD :: hash2(string value){

	unsigned long hashed = tableSize - (divCompression(bitHash(value),tableSize));
  	return hashed;  
   
}

void HashD::resizeTable(){


	
    return;
}

void HashD::insert(string value){

	unsigned long index1= hash1(value);
	unsigned long index2= hash2(value);
	int i=1;
	if (hashTable[index1]!=NULL)
	{
		

		while(hashTable[index1]!=NULL)
		{
			long unsigned index3= (index1 + i *index2) ;

			if(hashTable[index3]==NULL)
			{
				hashTable[index3]->value= value;
				return;
			}
			i++;

		}

	}

	else {
		hashTable[index1]->value= value;
	}
	count++;

    return;
}

void HashD::deleteWord(string value){

	unsigned long index1= hash1(value);
	unsigned long index2= hash2(value);
	int i=1;
	if (hashTable[index1]!=NULL)
	{
		

		while(hashTable[index1]!=NULL)
		{
			long unsigned index3= (index1 + i *index2) ;

			if(hashTable[index3]->value==value)
			{
				hashTable[index3]->value= -1;
				count--;
				return;
			}
			i++;

		}

	}


    return;
}

block* HashD::lookup(string value){

	unsigned long index1= hash1(value);
	unsigned long index2= hash2(value);
	int i=1;
	
	block *temp= new block(index1, value);

		while(hashTable[index1]!=NULL)
		{
			long unsigned index3= (index1 + i *index2) ;

			if(hashTable[index3]->value==value)
			{	temp= hashTable[index3];
				//hashTable[index3]= value;
				return temp;
			}
			i++;

		}

	
    return NULL;
}

#endif