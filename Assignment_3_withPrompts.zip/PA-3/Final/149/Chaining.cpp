#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize=size;
	hashTable = new LinkedList<string>[size]();
	// for (int i = 0; i < tableSize; ++i)
	// {
	// 	hashTable[i]=NULL;
	// }
	
    
}
HashC::~HashC(){


}

unsigned long HashC :: hash(string input){

  unsigned long HashAns=bitHash(input);
  return divCompression(HashAns,tableSize);  
}

void HashC::insert(string word){

	unsigned long HashInd=hash(word);
	// if(lookup(word)==NULL)
	// {
	// 	hashTable[HashInd].insertAtHead(word);
	// }

		hashTable[HashInd].insertAtHead(word);

  
}

ListItem<string>* HashC :: lookup(string word){

	unsigned long HashInd=hash(word);

	if(HashInd<tableSize){

		return hashTable[HashInd].searchFor(word);
		
	 }

	return NULL;
  
}

void HashC :: deleteWord(string word){
	unsigned long HashInd=hash(word);

	if(lookup(word)==NULL)
	{
		return;
	}
	else
	{
		hashTable[HashInd].deleteElement(word);
		deleteWord(word);
	}
	//hashTable[HashInd].deleteElement(word);
	// while(lookup(word)!=NULL)
	// {

	// }


}

#endif