#ifndef __LIST_CPP
#define __LIST_CPP
#include <iostream>

using namespace std;

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
	tail = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	// will do later

}

template <class T>
LinkedList<T>::~LinkedList()
{
   /* while(head!=NULL)
    {
        deleteHead();
    }*/


}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T> *temp=new ListItem<T> (item);
    //temp->value=item;

    if (head==NULL)
    {
        head=temp;
        tail=temp;
        head->prev=NULL;
        tail->next=NULL;

    }
    else
    {
        head->prev=temp;
        temp->next=head;
        temp->prev=NULL;
        head=temp;

    }
    //cout << head->value << endl;

}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
    ListItem<T> *temp=new ListItem<T> (item);
   // int *c = static_cast<int*>(value);
    //temp->value=item;
    //temp->next=NULL;
    if(head==NULL)
    {

        head=temp;
        tail=temp;
    }
    else
    {
        tail->next=temp;
        temp->prev=tail;
        temp->next=NULL;
        tail=temp;
    }


}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat) //will check later
{
    ListItem<T> *newNode=new ListItem<T> (toInsert);
    ListItem<T> *temp;
    temp=head;

    if(head==NULL)
    {
        head=newNode;
    }
    else if(tail->value==afterWhat)
    {
        tail->next=newNode;
        newNode->next=NULL;
        newNode->prev=tail;
        tail=newNode;
    }
    else
    {
        while(temp!=NULL)
        {
            if(temp->value==afterWhat)
            {
                temp->next->prev=newNode;
                newNode->next=temp->next;
                temp->next=newNode;
                newNode->prev=temp;
                break;
            }
            else
            {
                temp=temp->next;
            }
        }
    }


}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
    ListItem<T> *newNode=new ListItem<T> (item);
    newNode->value=item;
    ListItem<T> *temp;

    if(head==NULL || (head->value)>item )
    {
        insertAtHead(item);
    }
    else if((tail->value)<=item)
    {
        insertAtTail(item);
    }
    else
    {
        temp=head;
        while(temp->next!=NULL)
            {
                if((temp->next)->value>item)
                {
                    insertAfter(item,temp->value);
                    break;
                }
                else
                {
                    temp=temp->next;
                }
            }

    }


}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
    if(head==NULL)
    {return NULL;}
    else
    {return head;}

}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    if(head==NULL)
    {return NULL;}
    else
    {
        ListItem<T> *temp;
        temp=head;
        while((temp->next)!=NULL)
        {
            temp=temp->next;
        }
        return temp;
    }


}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{

    ListItem<T> *temp;
    temp=head;
    bool check=false;

    while(temp!=NULL)
    {
        if(temp->value==item)
        {
            check=true;
            return temp;
            break;
        }
        temp=temp->next;
    }

    return NULL;

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
    ListItem<T> *temp;
    temp=head;

    if(head->value==item)
    {
        deleteHead();
    }
    else if(tail->value==item)
    {
        deleteTail();
    }
    else
    {
        while(temp!=NULL)
        {
            if(temp->value==item)
            {
                (temp->next)->prev=temp->prev;
                (temp->prev)->next=temp->next;
                delete temp;
                break;
            }
            else
            {
                temp=temp->next;
            }

        }
    }


}

template <class T>
void LinkedList<T>::deleteHead() //done
{

    if(head==NULL)
    {
        return;
    }
    else if(head->next==NULL)
    {
        ListItem<T> *temp;
        temp=head;
        delete temp;
        head=NULL;
    }
    else
    {
        ListItem<T> *temp;
        temp=head;
        head=head->next;
        head->prev=NULL;
        delete temp;
    }



}

template <class T>
void LinkedList<T>::deleteTail()
{

    if(tail==NULL)
    {return;}
    ListItem<T> *temp;
    temp=tail->prev;
    temp->next=NULL;

     delete tail;

     tail=temp;

}

template <class T>
int LinkedList<T>::length()
{
    ListItem<T> *temp;
    temp=head;
    int c=0;

    while(temp!=NULL)
    {
        c++;
        temp=temp->next;
    }
    return c;

}

template <class T>
void LinkedList<T>::reverse()//bad function
{

    ListItem<T> *temp;
    temp=head;

    ListItem<T> *exchangTemp=NULL;

    while(temp!=NULL)
    {
        exchangTemp=temp->next;
        temp->next=temp->prev;
        temp->prev=exchangTemp;
        temp=temp->prev;
    }
    if(head!=NULL)
    {
        exchangTemp=head;
        head=tail;
        tail=exchangTemp;
    }

}

template <class T>
void LinkedList<T>::parityArrangement()
{

}

template <class T>
void LinkedList<T>::printLL()
{
    ListItem<T> *temp;
    temp=head;


    while(temp!=NULL)
    {
        //cout << "hello \n";
        cout <<temp->value << endl;
        /*cout <<"prev: "<< temp->prev << endl;
        cout << "it: "<< temp<< endl;
        cout <<"next: "<< temp->next << endl;*/
        temp=temp->next;
    }

}

#endif
