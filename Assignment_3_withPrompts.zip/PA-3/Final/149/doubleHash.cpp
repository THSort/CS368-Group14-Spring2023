#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // make it 10000, you cant change this
    hashTable = new block* [tableSize]();
    loadFactor=0;
    q=tableSize-3;
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){

    return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return q-(hash1(value)%q) ;
}

void HashD::resizeTable(){
    block** temp_hashTable; //= new block* [tableSize]();
    temp_hashTable=hashTable;
    tableSize=2*tableSize;
    q=tableSize-5;
    hashTable=new block* [tableSize];
    for (int i = 0; i < tableSize; ++i)
    {
    	hashTable[i]=NULL;
    }
    for (int i = 0; i < (tableSize/2); ++i)
    {
    	if(temp_hashTable[i]!=NULL){
    		string tempvalue=temp_hashTable[i]->value;
    		unsigned long HashId=hash1(tempvalue);
    		HashId=(HashId%tableSize);
    		unsigned long key=HashId;
 			while(1)
			{
				if(hashTable[HashId]==NULL || hashTable[HashId]->value=="@RR$"){
					delete hashTable[HashId];
					hashTable[HashId]=new block(key,tempvalue);
					loadFactor++;
					break;
				}
				else
				{
					//HashId=(hash(value)+i)%tableSize;
					HashId=(HashId+(hash2(tempvalue)))%tableSize;
				}

			}

    	}
    }
    delete[] temp_hashTable;
    return;
}

void HashD::insert(string value){
	unsigned long HashId=hash1(value);
	HashId=HashId%tableSize;
	unsigned long key=HashId;

	while(1)
	{
		if(hashTable[HashId]==NULL || hashTable[HashId]->value=="@RR$"){
			delete hashTable[HashId];
			hashTable[HashId]=new block(key,value);
			loadFactor++;
			break;
		} 
		else
		{
			//HashId=(hash(value)+i)%tableSize;
			HashId=(HashId+(hash2(value)))%tableSize;
		}

	}
	
	
	if(loadFactor>(tableSize/3.2))
	{
		resizeTable();
	}

    return;
}

void HashD::deleteWord(string value){
	unsigned long HashId=hash1(value);
	HashId=HashId%tableSize;

	while(1)
	{
		if(hashTable[HashId]->value==value)
		{
			hashTable[HashId]->value="@RR$";
			hashTable[HashId]->key=0;
			loadFactor--;
			if(lookup(value)==NULL)
			{
				break;
			}
			else
			{
				HashId=(HashId+(hash2(value)))%tableSize;
			}
		}
		else if(hashTable[HashId]==NULL)
		{
			
			return;
		}
		else
		{
			//HashId=(HashId+1)%tableSize;
			HashId=(HashId+(hash2(value)))%tableSize;
		}
	}
    return;
}

block* HashD::lookup(string value){
	unsigned long HashId=hash1(value)%tableSize;

	while(hashTable[HashId]!=NULL)
	{
		if(hashTable[HashId]->value==value)
		{
			return hashTable[HashId];
		}
		else
		{
			//HashId=(HashId+1)%tableSize;
			HashId=(HashId+(hash2(value)))%tableSize;
		}
	}
    return NULL;
}

// void HashD::print()
// {
// 	cout << tableSize << endl; 
// 	for (int i = 0; i < tableSize; ++i)
// 	{
// 		if(hashTable[i]!=NULL){
// 			cout << "index:"<< i<<" ,key:"<< hashTable[i]->key<< " ,value:"<<hashTable[i]->value << endl;
// 		}
// 		else if(hashTable[i]==NULL)
// 		{
// 			cout << i << " " << hashTable[i] << endl;
// 		}
// //		cout << "index:"<< i<<" ,key:"<< hashTable[i]->key<< " ,value:"<<hashTable[i]->value << endl;
// 	}
// }

#endif