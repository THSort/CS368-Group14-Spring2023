#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000;// make it 1000; // you cant change this
    hashTable = new block* [tableSize]();
    loadFactor=0;	
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
    return bitHash(value);
}

void HashL::resizeTable(){

    block** temp_hashTable; //= new block* [tableSize]();
    temp_hashTable=hashTable;
    tableSize=2*tableSize;
    hashTable=new block* [tableSize]();
    for (int i = 0; i < (tableSize/2); ++i)
    {
    	if(temp_hashTable[i]!=NULL){
    		string tempvalue=temp_hashTable[i]->value;
    		unsigned long HashId=hash(tempvalue);
    		HashId=(HashId%tableSize);
    		unsigned long key=HashId;
    		while(1)
			{
				if(hashTable[HashId]==NULL || hashTable[HashId]->value=="@RR$"){
				hashTable[HashId]=new block(key,tempvalue);
				break;
				}
				else
				{
					//HashId=(hash(value)+i)%tableSize;
					HashId=(HashId+1)%tableSize;
				}

			}

    	}
    }
    delete[] temp_hashTable;
    return;
}

void HashL::insert(string value){
	unsigned long HashId=hash(value);
	HashId=HashId%tableSize;
	unsigned long key=(HashId);
	// while(1){
	// 	if(hashTable[HashId]==NULL || hashTable[HashId]->value=="@RR$"){
	// 		hashTable[HashId]=new block(key,value);
	// 		break;
	// 	}
	// 	//HashId++;
	// 	HashId=(HashId+1)%tableSize;

	// }

	while(1)
	{
		if(hashTable[HashId]==NULL || hashTable[HashId]->value=="@RR$"){
			hashTable[HashId]=new block(key,value);
			loadFactor++;
			break;
		}
		else
		{
			//HashId=(hash(value)+i)%tableSize;
			HashId=(HashId+1)%tableSize;
		}

	}	
	
	if(loadFactor>(tableSize/3))
	{
		resizeTable();
	}

    return;
}

void HashL::deleteWord(string value){
	unsigned long HashId=hash(value);
	HashId=HashId%tableSize;

	while(1)
	{
		if(hashTable[HashId]!=NULL && hashTable[HashId]->value==value)
		{
			hashTable[HashId]->value="@RR$";
			hashTable[HashId]->key=0;
			loadFactor--;
			if(lookup(value)==NULL)
			{
				break;
			}
		}
		else if(hashTable[HashId]==NULL)
		{
			
			return;
		}
		else
		{
			HashId=(HashId+1)%tableSize;
		}
	}


    return;
}
block* HashL::lookup(string value){
	unsigned long HashId=hash(value)%tableSize;

	while(hashTable[HashId]!=NULL)
	{
		if(hashTable[HashId]->value==value)
		{
			return hashTable[HashId];
		}
		else
		{
			HashId=(HashId+1)%tableSize;
		}
	}
	
	// while(hashTable[HashId]!=NULL)
	// {
	// 	if(hashTable[HashId]->value==value)
	// 	{
	// 		return hashTable[HashId];
	// 	}
	// 	HashId=(HashId+1)%tableSize;
	// }

    return NULL;
}
// void HashL::print()
// {
// 	cout << tableSize << endl; 
// 	for (int i = 0; i < tableSize; ++i)
// 	{
// 		if(hashTable[i]!=NULL){
// 			cout << "index:"<< i<<" ,key:"<< hashTable[i]->key<< " ,value:"<<hashTable[i]->value << endl;
// 		}
// 		else if(hashTable[i]==NULL)
// 		{
// 			cout << i << " " << hashTable[i] << endl;
// 		}
// //		cout << "index:"<< i<<" ,key:"<< hashTable[i]->key<< " ,value:"<<hashTable[i]->value << endl;
// 	}
// }
#endif
