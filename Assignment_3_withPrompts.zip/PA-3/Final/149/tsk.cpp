#include <iostream>
#include "hashfunctions.cpp"
//#include "linearProbing.cpp"
#include "doubleHash.cpp"



using namespace std;

int main(/*int argc, char const *argv[]*/)
{

    HashD hash;

    hash.insert("aa");
    hash.insert("bb");
    
    hash.insert("cc");
    hash.print();
    // hash.insert("ad");
    // hash.insert("bg");
    // hash.insert("cgc");
    // hash.insert("aa");
    // hash.insert("bhh");
    // hash.insert("ccd");
    // hash.print();
    // hash.deleteWord("aa");
    // cout << "*********" << endl;
    // hash.print();

    // hash.insert("aa");
    // hash.print();


    

	return 0;
}
