#ifndef __LIST_H
#define __LIST_H
#include <cstdlib>

/* This class just holds a single data item. */
template <class T>
struct ListItem
{
    T value;
    ListItem<T> *next;
    ListItem<T> *prev;

    ListItem(T theVal)
    {
        this->value = theVal;
        this->next = NULL;
        this->prev = NULL;
    }
};

/* This is the generic List class */
template <class T>
class LinkedList
{
    ListItem<T> *head;
    ListItem<T> *tail;

public:

    // Constructor
    LinkedList();//done

    // Copy Constructor
    LinkedList(const LinkedList<T>& otherList);

    // Destructor
    ~LinkedList();

    // Insertion Functions
    void insertAtHead(T item);//done
    void insertAtTail(T item);//done
    void insertAfter(T toInsert, T afterWhat);//done
    void insertSorted(T item);//done

    // Lookup Functions
    ListItem<T> *getHead();//done
    ListItem<T> *getTail();//done
    ListItem<T> *searchFor(T item);//done

    // Deletion Functions
    void deleteElement(T item);//done
    void deleteHead();//done
    void deleteTail();//done

    // Utility Functions
    int length();//done
    void reverse();//done
    void parityArrangement();

    //helper funcs
    void printLL();
};

#endif
