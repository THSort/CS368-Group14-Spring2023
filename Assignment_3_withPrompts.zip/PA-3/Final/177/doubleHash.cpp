#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize]();
}

HashD::~HashD(){
	delete [] hashTable;
}

unsigned long HashD :: hash1(string value){
	unsigned long hCode = bitHash(value);
	return divCompression(hCode, tableSize);
}

unsigned long HashD :: hash2(string value){
	unsigned long hCode = fastHash(value);
	return divCompression(hCode, tableSize);
}

void HashD::resizeTable(){
	block** tempTable = hashTable;
	long tempSize = tableSize;

	if(count> tableSize*0.75){
		tableSize = tableSize*18;
		hashTable = new block*[tableSize]();

		for (int i = 0; i < tempSize; ++i)
		{
			if(tempTable[i]){
				insert(tempTable[i]->value);
				count--;
				delete tempTable[i];
			}
		}
		delete []tempTable;

	}
	if (tableSize>10000 && count<0.25){
		tableSize = tableSize/2;
		hashTable = new block*[tableSize]();

		for (int i = 0; i < tempSize; ++i)
		{
			if(tempTable[i]){
				insert(tempTable[i]->value);
				count--;
				delete tempTable[i];
			}
		}
		delete []tempTable;		
	}


    return;

}

void HashD::insert(string value){
	int i = 0;
	long index = (hash1(value) + i*hash2(value)) % tableSize;
	while(hashTable[index]){

		if(hashTable[index]->value=="--1"){
			hashTable[index]->value=value;
			count++;
			resizeTable();
			return;
		}
		if(hashTable[index]->value==value){
			return;
		}
		index = (hash1(value) + (++i)*hash2(value)) % tableSize;
	}
	// if(!hashTable[index]){
		hashTable[index] = new block(index, value);
		count++;
		resizeTable();
	// }
    
    return;
}

void HashD::deleteWord(string value){
    int i=0;
    long index = (hash1(value) + i*hash2(value)) % tableSize;
    while(hashTable[index]){
		if(hashTable[index]->value==value){
			hashTable[index]->value = "--1";
			count--;
		    resizeTable();
		    return;
		}
		index = (hash1(value) + (++i)*hash2(value)) % tableSize;    	
    }
    return;
}

block* HashD::lookup(string value){
	int i = 0;
	long index = (hash1(value) + i*hash2(value)) % tableSize;
    while(hashTable[index] && hashTable[index]->value!="--1"){
		if(hashTable[index]->value==value){
			return hashTable[index];
		}
		index = (hash1(value) + (++i)*hash2(value)) % tableSize;	
    }
    return NULL;
}

#endif