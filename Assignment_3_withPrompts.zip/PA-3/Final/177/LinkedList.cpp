#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"




template <class T>
LinkedList<T>::LinkedList(){
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList){
	this->head = NULL;
	if(otherLinkedList.head){
	ListItem<T>* temp = otherLinkedList.head;
		while(temp){
			insertAtTail(temp->value);
			temp = temp->next;
		}
	}


}

template <class T>
LinkedList<T>::~LinkedList(){
	ListItem<T> *temp;
	while(head){
		temp=head->next;
		delete head;
		head=temp;
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item){
	ListItem<T> *temp = new ListItem<T>(item);
	if(head){
		temp->next = head;
		head->prev = temp;
		head = temp;	
	}
	else{
		head = temp;
	}
}

template <class T>
void LinkedList<T>::insertAtTail(T item){

	if(head){
		ListItem<T> *temp = new ListItem<T>(item);
		ListItem<T> *tail = getTail();
		temp->prev = tail;
		tail->next = temp;
		tail = temp;		
	}
	else{
		insertAtHead(item);
	}

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat){
	ListItem<T> *temp = head;

	ListItem<T> *after = searchFor(afterWhat);

	if(after){
		if(after==getTail()){
			insertAtTail(toInsert);
		}
		else{
			ListItem<T> *insert = new ListItem<T>(toInsert);
			insert->next = after->next;
			insert->prev = after;
			if(after->next){
				(after->next)->prev = insert;	
			}
			after->next = insert;	
		}	
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item){

	if(head){
		ListItem<T> *temp=head;
		if(item < head->value){
			insertAtHead(item);
			return;
		}

		while(temp){
			if(item < temp->value){
				ListItem<T> *insert = new ListItem<T>(item);
				insert->next = temp;
				insert->prev = temp->prev;
				if(temp->prev){
					(temp->prev)->next = insert;
				}
				temp->prev = insert;
				return;
			}
			temp = temp->next;
		}
		if(!temp){
			insertAtTail(item);
		}

	}
	else{
		insertAtHead(item);
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getHead(){
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail(){
	ListItem<T> *temp = head;
	while(temp && temp->next){
		temp = temp->next;
	}
	return temp;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item){
	ListItem<T> *temp = head;
	while(temp){
		if(temp->value == item){
			return temp;
		}
		temp = temp->next;
	}

	return temp;
}

template <class T>
void LinkedList<T>::deleteElement(T item){

	ListItem<T> *to_delete = searchFor(item);

	if(to_delete){
		if(to_delete==head){
			deleteHead();
		}
		else if (to_delete==getTail()){
			deleteTail();
		}
		else{
			(to_delete->prev)->next = to_delete->next;
            (to_delete->next)->prev = to_delete->prev;	
			delete to_delete;
            to_delete = NULL;

		}
	}
}

template <class T>
void LinkedList<T>::deleteHead(){

	if(head){	
		ListItem<T> *temp = head->next;
		delete head;
        if(temp){
            temp->prev = NULL;
        }
		head = temp;

	}
}

template <class T>
void LinkedList<T>::deleteTail(){
    
    if(head){
        if(length()==1){
            deleteHead();
        }
        else{
            ListItem<T> *tail = getTail();

            ListItem<T> *temp = tail->prev;

            delete tail;
            if(temp){
                temp->next =NULL;    
            }
            tail = temp;
                
        }
    }	
	
}

template <class T>
int LinkedList<T>::length(){
	ListItem<T> *temp = head;
	int len=0;
	while(temp){
		len++;
		temp = temp->next;
	}
	return len;
}

template <class T>
void LinkedList<T>::reverse(){
	ListItem<T> *here = head;
	ListItem<T> *tail = getTail();
	while(here!=NULL){
		ListItem<T> *temp=here;
		ListItem<T> *ahead = temp->next;
		here->next = here->prev;
		here->prev = temp->next;
		here = ahead;
	}
	head = tail;

}

template <class T>
void LinkedList<T>::parityArrangement(){
	if(head){
		ListItem<T> *temp,*odd,*even,*t_even;
		temp = head;
		odd = head;
		even = head->next;
		t_even = even;
		while(even){
			if(even->next){
				odd->next = even->next;
				odd = odd->next;
			}
			else{
				break;
			}
			if(odd->next){
				even->next = odd->next;
				even = even->next;
			}
			else{
				break;
			}
		}
		odd->next = t_even;

	}



}

template <class T>
bool LinkedList<T>::isPalindrome(){

	ListItem<T> *front = head;
	ListItem<T> *back = getTail();
	
	if(!head){
		return 0;
	}

	while(front && back){

		if(front->value!=back->value){
			return 0;
		}
		front = front->next;
		back = back->prev;
	}



	return 1;
}






#endif

