#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <math.h>


// #include <iostream>
// using namespace std;

unsigned long fastHash(string str)
{
    unsigned long hash = 5381;
    int len = str.length();
    for(int i=0; i<len; ++i)
        hash = ((hash << 5) + hash) + int(str[i]); /* hash * 33 + c */
    return hash;
}

// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a){
	unsigned long polywise_hash = 0;
	int length_input = value.length();
	for(int i=0; i<length_input; i++){
		polywise_hash += (int(value[i]) * pow(a, length_input-i));
	}

	return polywise_hash;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	unsigned long bitwise_hash = 0;
	int length_input = value.length();
	for(int i = 0; i<length_input ; i++){
		bitwise_hash ^= (bitwise_hash<<5) + (bitwise_hash>>2) + int(value[i]); 
	}
  	return bitwise_hash;  
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
	return (hash) % size;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m ,int a){
	return (m*hash + a) % size;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.

// int main(){

// 	unsigned long a = bitHash("mannan");
// 	cout<<divCompression(a, 10000)<<endl;
// 	cout<<madCompression(a, 10000, 1993, 1637)<<endl;
// }