#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count = 0;
    hashTable = new block*[tableSize]();
}

HashL::~HashL(){
    delete []hashTable;
}

unsigned long HashL :: hash(string value){
	unsigned long index = bitHash(value);
	index = divCompression(index, tableSize);
	return index;
}

void HashL::resizeTable(){
	block** tempTable = hashTable;
	long tempSize = tableSize;

	if(count> tableSize*0.75){
		tableSize = tableSize*16;
		hashTable = new block*[tableSize]();

		for (int i = 0; i < tempSize; ++i)
		{
			if(tempTable[i]){
				insert(tempTable[i]->value);
				count--;
				delete tempTable[i];
			}
		}
		delete []tempTable;

	}
	if (tableSize>1000 && count<0.25){
		tableSize = tableSize/2;
		hashTable = new block*[tableSize]();

		for (int i = 0; i < tempSize; ++i)
		{
			if(tempTable[i]){
				insert(tempTable[i]->value);
				count--;
				delete tempTable[i];
			}
		}
		delete []tempTable;
	}


    return;
}

void HashL::insert(string value){



	unsigned long i = hash(value);
	while(1){
		if(!hashTable[i] ){
			hashTable[i] = new block(i, value);
			count++;
			resizeTable();
			return;
		}
		if(hashTable[i]->value==value){
			return;
		}
		if(hashTable[i]->value=="--1"){
			hashTable[i]->value=value;
			count++;
			resizeTable();
			return;	
		}
		i = (i+1)%tableSize;
	}

    return;
}

void HashL::deleteWord(string value){
    unsigned long i = hash(value);
    while(1){
    	if(!hashTable[i]){
			return;
		}
		if (hashTable[i]->value == value ){
			hashTable[i]->value="--1";
			count--;
			resizeTable();
			return;
		}
		i = (i+1)%tableSize;
    }
	
    return;
}
block* HashL::lookup(string value){
	unsigned long i = hash(value);
	while(1){
		if(!hashTable[i]){
			return NULL;
		}
		if(hashTable[i]->value==value){
			return hashTable[i];
		}
		i = (i+1)%tableSize;
	}
	
	return NULL;
}
#endif
