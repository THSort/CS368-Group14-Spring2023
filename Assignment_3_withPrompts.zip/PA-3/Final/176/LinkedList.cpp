#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

//Copy constructor, takes a linkedlist and make an exact copy
template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	head = NULL;
	if (otherLinkedList.head != NULL)
	{
		ListItem<T> *temp = otherLinkedList.head;
		insertAtHead(temp->value);
		if (temp -> next != NULL)
		{
			temp = temp -> next;
			while (temp != NULL)
			{
				insertAtTail(temp->value);
				temp = temp -> next;
			}
		}
	}	

}

//Deleting Tail untill all elements are deleted
template <class T>
LinkedList<T>::~LinkedList()
{
	while (head != NULL)
	{
		deleteTail();
	}
}

//Creating a new node and adding that to head
template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if (head != NULL)
	{
		if (searchFor(item) == NULL)
		{
			ListItem<T> *temp;
			temp = new ListItem <T> (item);
			head -> prev = temp;
			temp -> next = head;
			head = temp;
		}
	}
	else if (head == NULL)
	{
		ListItem<T> *temp;
		temp = new ListItem <T> (item);
		head = temp;
	}
}

//Creating a new node and adding that to the tail
template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem <T> *tail = getTail();
	if (tail != NULL)
	{
		ListItem<T> *temp;
		temp = new ListItem <T> (item);
		tail -> next = temp;
		temp -> prev = tail;
		tail = temp;
	}
	else 
	{
		insertAtHead(item);
	}
}

//Checks few corner conditions and add element by using searchFor function
template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T> *temp;
	temp = new ListItem<T>(toInsert);
	ListItem<T> *Afterthis = searchFor(afterWhat);
	if (Afterthis != NULL && Afterthis -> next == NULL)
	{
		temp -> prev = Afterthis;
		temp -> next = NULL;
		Afterthis -> next = temp;
	}
	else if (Afterthis != NULL)
	{
		temp -> prev = Afterthis;
		Afterthis -> next -> prev = temp;
		temp -> next = Afterthis -> next;
		Afterthis -> next = temp;
	}

}

//Checks if value to insert is less than head or greater than the tail. If less than head then insertathead or If greater than tail so InsertAtTail
template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem <T> * temp = head;
	ListItem <T> * newnode = new ListItem <T> (item);
	if (head != NULL)
	{
		if (item <= temp -> value)
		{
			insertAtHead(item);
			return;
		}
		if (item >= getTail()-> value)
		{
			insertAtTail(item);
			return;
		}
		while (item > (temp -> value))
		{
			temp = temp -> next;
		}
		temp -> prev -> next = newnode;
		newnode -> prev = temp -> prev;
		temp -> prev = newnode;
		newnode -> next = temp;

	}
	else if (head == NULL)
	{
		insertAtHead(item);
	}

}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	if (head == NULL)
	{
		return NULL;
	}
	else{
		return head;
	}
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	ListItem <T> *temp = head;
	if (temp != NULL)
	{
	while (temp -> next != NULL)
	{
		temp = temp -> next;
	}

	return temp;
	}
	else if (temp == NULL)
	{
		return NULL;
	}
}

//Check if the value is at head and then search in the remaining list
template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem <T> *temp = head;
	if (temp != NULL)
	{
		if (temp -> value == item)
		{
			return temp;
		}
		while (temp != NULL)
		{
			if (temp -> value == item)
			{
				return temp;
			}
			temp = temp -> next;
		}	
	}

	return NULL;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem <T> *temp = searchFor(item);
	if (temp != NULL)
	{
		if (temp -> prev == NULL)
		{
			deleteHead();
			return;
		}
		if (temp -> next == NULL)
		{
			deleteTail();
			return;
		}
		temp -> prev -> next = temp -> next;
		temp -> next -> prev = temp -> prev;
		delete temp;
	}

}

template <class T>
void LinkedList<T>::deleteHead()
{
	ListItem <T> *newHead;
	if (head != NULL)
	{	
		if (head -> next != NULL)
		{
			newHead = head -> next;
			newHead -> prev = NULL;
			delete head;
			head = newHead;
		}
		else{
			delete head;
			head = NULL;
		}
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem <T> *temp = getTail();
	if (temp != NULL)
	{
		if (temp -> prev != NULL)
		{
			temp -> prev -> next = NULL;
			delete temp;
		}
		else{
			delete temp;
			head = NULL;
		}
	}
}

template <class T>
int LinkedList<T>::length()
{
	ListItem <T> *temp = head;
	int counter = 0;
	while (temp != NULL)
	{
		counter ++;
		temp = temp ->next;
	}

	return counter;
}


template <class T>
void LinkedList<T>::reverse()
{
	if (head != NULL)
	{
		ListItem <T> *rev = getTail();
		int originalLength = length();
		T arr [length()];
		for (int i=0; i < originalLength; i++)
		{
			ListItem <T> *current = rev;
			arr[i] =  rev -> value;
			rev = rev -> prev;
			delete current;
		}
		head = NULL;	
		for (int i=0; i<originalLength; i++)
		{	
			if (i==0)
			{
				insertAtHead (arr[0]);
			}
			else
			{
				insertAtTail (arr[i]);
			}
		}
	}


}

template <class T>
void LinkedList<T>::parityArrangement()
{

	if (head != NULL)
	{
		LinkedList <T> odd;
		LinkedList <T> even;
		ListItem <T> * temp = head;
		ListItem <T> * current;
		while (temp != NULL)
		{	
			current = temp;
			odd.insertAtTail(temp -> value);
			if (temp -> next != NULL)
			{
				temp = temp -> next;
				delete current;
				current = temp;
				even.insertAtTail(temp -> value);
			}
			temp = temp -> next;
			delete current;
		}
		head = NULL;
		ListItem <T> *oddptr = odd.head;
		while (oddptr != NULL)
		{
			insertAtTail (oddptr->value);
			oddptr = oddptr-> next;
		}
		ListItem <T> *evenptr = even.head;
		while (evenptr != NULL)
		{
			insertAtTail (evenptr->value);
			evenptr = evenptr -> next;
		}
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
	ListItem <T> * last = getTail();
	ListItem <T> * temp = head;
	if (temp != NULL)
	{
		while (temp != last)
		{
			if (temp -> value != last -> value)
			{
				return 0;
			}
			else{
				temp = temp -> next;
				last = last -> prev;
			}
		}
	return 1;
	}
	else{
		return 0;
	}
}
#endif
