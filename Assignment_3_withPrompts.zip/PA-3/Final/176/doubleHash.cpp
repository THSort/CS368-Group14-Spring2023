#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
#include <vector>

HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block* [tableSize];
    for (int i=0; i<tableSize; i++){
    	hashTable[i] = new block(0, "");
    }
    count = 0;
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){
    unsigned long toreturn = 0;
  	toreturn = bitHash (value);
  	toreturn = divCompression (toreturn, tableSize);
  return toreturn; 
}

unsigned long HashD :: hash2(string value){
    unsigned long toreturn = 0;
  	toreturn = bitHash (value);
  	toreturn = madCompression (toreturn, tableSize);
  return toreturn;
}

void HashD::resizeTable(){
    vector <string> newvect;    
	for (int i=0; i<tableSize; i++)
	{
		if (hashTable[i]->value != "")
		{
			newvect.push_back(hashTable[i]->value);
		}
	}

	tableSize = tableSize*4;
	delete hashTable;
	count = 0;

	hashTable = new block* [tableSize];
    for (int i=0; i<tableSize; i++){
    	hashTable[i] = new block(0, "");
    }

    for (int i=0; i<newvect.size(); i++){
    	insert(newvect[i]);
    }

}

void HashD::insert(string value){
	double ratio = count / double (tableSize);
	
	int counts = 0;
	if (ratio >= 0.4)		
	{
		resizeTable();
		insert(value);
		return;
	}
		unsigned long hashtemp1 = hash1 (value);
		unsigned long hashtemp2 = hash2 (value);
		
		if (hashtemp2 == 0)
		{
			hashtemp2 = tableSize;
		}
		if (hashTable[hashtemp1]->key == 0)
		{
			hashTable[hashtemp1]->key = hashtemp1;
			hashTable[hashtemp1]->value = value;
			count++;
			return;
		}
		if (hashTable[hashtemp1]->key== hashtemp1 && hashTable[hashtemp1]->value == value)
		{
			return;
		}
		else{
			unsigned long newhash = 0;
			for (int i=1; i<=tableSize; i++)
			{
				if (i>=10)
				{
					resizeTable();
					insert(value);
					return;
				}
				// cout << "in for loop" << endl;
				newhash = hashtemp1 + i*hashtemp2;
				newhash = divCompression(newhash,tableSize);
			
				if (newhash >= tableSize)
				{
					// cout << "going to resize" << endl;
					resizeTable();
					insert(value);
					return;
					break;
				}
				else{
					if (hashTable[newhash]->key == newhash && hashTable[newhash]->value == value)
					{
						return;
					}
					if (hashTable[newhash]->key == 0)
					{
						hashTable[newhash]->key = newhash;
						hashTable[newhash]->value = value;
						count++;
						
						return;
						break;
					}
				}
			}
		
		}
    return;
}

void HashD::deleteWord(string value){

	block* temp = lookup (value);
	if (temp != NULL)
	{
		temp -> value = "";
		count--;	
	}
    return;
}

block* HashD::lookup(string value){
    
    unsigned long hashtemp1 = hash1 (value);
	unsigned long hashtemp2 = hash2 (value);

	if (hashtemp2 == 0)
	{
		hashtemp2 = tableSize;		
	}
	if (hashTable[hashtemp1]->key==hashtemp1 && hashTable[hashtemp1]->value == value)
	{
		block* temp = hashTable[hashtemp1];
		return temp;
	}
	else if (hashTable[hashtemp1]->key == 0 && hashTable[hashtemp1]->value == ""){
		return NULL;
	}
	else{
		unsigned long newhash = 0;
		int k = 1;
		newhash = hashtemp1 + k*hashtemp2;
		newhash = divCompression(newhash,tableSize);
		
		while (newhash < tableSize && hashTable[newhash]->key != 0)
		{
			if (k == 10)
			{
				return NULL;
			}
			if (hashTable[newhash]->key == newhash && hashTable[newhash]->value == value)
			{
				block* temp = hashTable[newhash];
				return temp;
			}
			else if (hashTable[newhash]->key == 0 && hashTable[newhash]->value == "")
			{
				return NULL;
			}
			else{
				k++;
				newhash = hashtemp1 + k*hashtemp2;
				newhash = divCompression(newhash,tableSize);
			}
		}
		return NULL;
	}
}

#endif