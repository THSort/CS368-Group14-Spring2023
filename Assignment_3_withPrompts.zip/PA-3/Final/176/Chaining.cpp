#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    tableSize = size;
    hashTable = new LinkedList <string> [tableSize];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
  int toreturn = 0;
  int sizeofinput = input.size();
  toreturn = bitHash (input);
  toreturn = divCompression (toreturn, tableSize);

  return toreturn;  
}

void HashC::insert(string word){
  int index = hash(word);
  hashTable[index].insertAtHead(word);
}

ListItem<string>* HashC :: lookup(string word){
  int index = hash(word);
  ListItem <string>* temp2 = hashTable[index].searchFor(word);
  if (temp2 == NULL)
  {
  		return temp2;		  	
  }
  else{
  	return NULL;
  }
}

void HashC :: deleteWord(string word){
  int index = hash(word);
  hashTable[index].deleteElement(word);
}

#endif