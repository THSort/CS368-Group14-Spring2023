#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"
#include <vector>

HashL::HashL(){
    count = 0;
    tableSize = 1000; // you cant change this
    hashTable = new block* [tableSize];
    for (int i=0; i<tableSize; i++){
    	hashTable[i] = new block(0, "");
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
	unsigned long toreturn = 0;
  	toreturn = bitHash (value);
  	toreturn = divCompression (toreturn, tableSize);
  return toreturn; 
}

void HashL::resizeTable(){
	vector <string> newvect;    

	for (int i=0; i<tableSize; i++)
	{
		if (hashTable[i]->value != "")
		{
			newvect.push_back(hashTable[i]->value);
		}
	}

	tableSize = tableSize*2;
	delete hashTable;
	count = 0;
	hashTable = new block* [tableSize];
    for (int i=0; i<tableSize; i++){
    	hashTable[i] = new block(0, "");
    }

    for (int i=0; i<newvect.size(); i++){
    	insert(newvect[i]);
    }




    return;
}

void HashL::insert(string value){
    double ratio = count/double(tableSize);
    
    if (ratio >= 0.5){
    	resizeTable();
    	insert (value);
    }
    else{
    	unsigned long hashs = hash (value);
    	count++;
	    // if (lookup(value) == NULL){
	    	if (hashTable[hashs]->key != 0){
		    	while (hashs < tableSize && hashTable[hashs]->key != 0)
		    	{
		    		if (hashTable[hashs]->key == hashs && hashTable[hashs]->value == value)
		    		{
		    			return;
		    		}
		    		hashs++;
		    	}
		    	if (hashs >= tableSize){
		    		resizeTable();
		    		insert (value);
		    	}
		    	else if (hashs < tableSize && hashTable [hashs] -> key == 0){
		    		hashTable[hashs]->value = value;
		    		hashTable[hashs]->key = hashs;	
		    	}
		    	else{
		    		resizeTable();
		    		insert(value);
		    	}
		    	
		    }
		    else{
		    	hashTable[hashs]->key = hashs;
		    	hashTable[hashs]->value = value;
		    }
		    return;	
	    // }
    }
}

void HashL::deleteWord(string value){
    
    block* temp = lookup (value);
    if (temp != NULL)
    {
    	temp -> value = "";
    	count--;
    }

    return;
}
block* HashL::lookup(string value){
	int hashs = hash (value);

	if (hashTable[hashs]->key == hashs && hashTable[hashs]->value == ""){
		return NULL;
	}
	else if (hashTable[hashs]->key == 0 && hashTable[hashs]-> value == "")
	{
		return NULL;
	}
	else if (hashTable[hashs] -> key == hashs && hashTable[hashs]->value == value){
		block* temp = hashTable[hashs];
		return temp;
	}
	else{
		hashs++;
		if (tableSize <= hashs)
		{
			return NULL;
		}
		while (hashTable[hashs]->key != 0 || hashs > tableSize)
		{
			if (hashTable[hashs]->value == value){
				block* temp = hashTable[hashs];
				return temp;			
			}
			hashs++;
		}
    	return NULL;
	}
}
#endif
