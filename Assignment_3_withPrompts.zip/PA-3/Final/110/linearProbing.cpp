#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"
#include <iomanip>
#include <vector>
#include <fstream>
HashL::HashL()
{
   count=1;
    tableSize = 1000; // you cant change this

   this->hashTable= new block *[tableSize];

  for(int i=0;i<tableSize;i++)
  {
   hashTable[i]=new block(2000,"NULL");
  }
}

HashL::~HashL()
{

for(int i=0;i<tableSize;i++)
  {
   hashTable[i]=NULL;
  }
for(int i=0;i<tableSize;i++)
  {
   delete hashTable[i];
  }

    
}





unsigned long HashL :: hash(string value){

unsigned long hash1=0;
int x=0; int j=1;

for(int i=0;i<value.length();i++)
{
hash1+=(value[x]+0)*pow(17,j);
x++;j++;

}

hash1=hash1%tableSize;

    return hash1;
}


void HashL::resizeTable()
{
//cout<<"RESIZING"<<endl;

block** temp=new block*[tableSize];
  for(int i=0;i<tableSize;i++)
  {
   temp[i]=new block(2000,"NULL");
  }

 for(int i=0;i<tableSize;i++)
  {
   temp[i]->value= hashTable[i]->value;
  }

  

int prev_size=tableSize;

tableSize=tableSize*2;

this->hashTable=new block *[tableSize]; //create new hash table of double size

//cout<<"table size is now: "<<tableSize<<endl;
for(int i=0;i<tableSize;i++)
{hashTable[i]=new block (2000,"NULL");} //give "NULL" value to all hashtable indexes 
  
for(int i=0;i<prev_size;i++) //copy previous hash table elements in new table
{
  hashTable[i]->value=temp[i]->value;
}
    return;
}

void HashL::insert(string value1)
{

float loadfactor= (float)count/(float)tableSize;

//cout<<"load factor: "<<loadfactor<<endl;
//cout<<"table Size: "<<tableSize<<endl;


 if (loadfactor>0.8) //resize table if needed
   { 
      //cout<<"1"<<endl;
     resizeTable();
    // cout<<"2"<<endl;
   } 
  //cout<<"3"<<endl;
 int hash1=hash(value1); //calculate hash
 //cout<<"4"<<endl;

if(hashTable[hash1]->value=="NULL") //if index is empty insert at index
{//cout<<"1. hash = "<<hash1<<endl;
 hashTable[hash1]->value=value1;
//cout<<"5"<<endl;
}



else 
{
  //cout<<"6"<<endl;
  while(hash1<tableSize-10 && hashTable[hash1]->value!="NULL") //if index is not empty, probe the hashtable
     
    {//cout<<"7"<<endl;
     hash1++; 
    //cout<<"hash1 is: "<<hash1<<endl;}
         //  cout<<"7.5"<<endl;
    }
   if(hashTable[hash1]->value=="NULL")
    { // cout<<"2. hash = "<<hash1<<endl;
   hashTable[hash1]->value=value1;
   //cout<<"8"<<endl;
    }       //overwrites if "NULL" found

    else 
   {
    //cout<<"noooooo"<<endl;
    resizeTable();
    insert(value1);
   }


}

 count++; 
 return;
}



void HashL::deleteWord(string value)
{
int hash1=hash(value);

if(hashTable[hash1]->value==value)
  {hashTable[hash1]=NULL;}
 

else {

   while(hashTable[hash1]->value!=value && hash1<tableSize)
      hash1++;
   
    if(hashTable[hash1]->value==value)
    hashTable[hash1]=NULL;
    
 
}
return;

    
}
block* HashL::lookup(string value)
{


int hash1=hash(value);

if(hashTable[hash1]->value==value) //if value is found at this index, return index
  return hashTable[hash1];

else
{
for(int i=hash1;i<tableSize;i++) //keep probing till value is found
{
  if(hashTable[i]->value==value)  
  return hashTable[i];
}

}
}









/*int main()

{

HashL o;
cout<<"inserting"<<endl;
int h=0;
vector<string> allWords;
   ifstream file;
    file.open("words.txt");
    cout << "LOADING THE FILE" << endl;
    string temp;
  
   for(int i=0;i<100000;i++)
    {
        file >> temp;
        allWords.push_back(temp); 
    }

    for(int i=0;i<allWords.size();i++)
     {o.insert(allWords[i]); h++;}


  
 cout<<h<<" insertions"<<endl;

cout<<"inserted"<<endl<<endl;


//cout<<"searching"<<endl;
o.lookup("O"); 
o.lookup("OS");
o.lookup("OSA");
o.lookup("OSAM");
o.lookup("OSAMA");
o.lookup("OSAMAA");
o.lookup("OSAMAAA");
o.lookup("N");
o.lookup("WWWWWWWWWWWWWWWRRRRRRRRRRRRRRRRRRRRRRRRRR");
cout<<"searched"<<endl<<endl;
cout<<"deleting"<<endl;
o.deleteWord("O");
o.deleteWord("OS");
o.deleteWord("OSA");
o.deleteWord("OSAM");
o.deleteWord("OSAMA");
o.deleteWord("OSAMAA");
o.deleteWord("OSAMAAA");
cout<<"deleted"<<endl<<endl;
cout<<"searching after deleting"<<endl;
o.lookup("O"); 
o.lookup("OS");
o.lookup("OSA");
o.lookup("OSAM");
o.lookup("OSAMA");
o.lookup("OSAMAA");
o.lookup("OSAMAAA");
cout<<"successful"<<endl;







return 0;
}*/













#endif
