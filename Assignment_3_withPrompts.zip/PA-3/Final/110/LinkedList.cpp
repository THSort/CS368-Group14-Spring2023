#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"
#include <iostream>
#include <string>
using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{ 
head=NULL;
tail=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
head=NULL;tail=NULL;
*this=otherLinkedList;
head=getHead();tail=getTail();
}

template <class T>
LinkedList<T>::~LinkedList()
{
 head=NULL;
 tail=NULL;
 delete head;
 delete tail;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
 if(head==NULL)
{ListItem<T> *temp = new ListItem<T> (item);
 head=temp;
 tail=temp;
 temp->prev=NULL;}
 
 else{ListItem<T> *temp = new ListItem<T> (item);
 temp->next=head;
 head->prev=temp;
 temp->prev=NULL;
 head=temp;}


// else removed



}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
 if(tail==NULL)
{ListItem<T> *temp = new ListItem<T> (item);
 head=temp;
 tail=temp;
 temp->prev=NULL;}
  else{ListItem<T> *temp = new ListItem<T> (item);
  tail->next=temp;
  temp->prev=tail;
  temp->next=NULL;
  tail=temp;}

//else removed

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
 if(tail->value==afterWhat)
  {insertAtTail(toInsert);}
 else{
  ListItem<T> *temp = new ListItem<T> (toInsert);
  ListItem<T> *prev_pointer = head;
  while(prev_pointer->value!=afterWhat)
   {prev_pointer=prev_pointer->next;}
  ListItem<T> *next_pointer = prev_pointer->next;
  prev_pointer->next=temp;
  temp->prev=prev_pointer;
  temp->next=next_pointer;
  next_pointer->prev=temp;}
   
   
}

template <class T>
T LinkedList<T>::check(T item)                                               //CHECK
{
 ListItem<T> *temp16=head;
if(head==NULL)
return 0;
else{
 
 while(temp16!=NULL)
 {if(temp16->value==item)
  {return 1;break;}
  temp16=temp16->next; 
 }}
  //if(temp16->value!=item)
  return 0;
  
}

template <class T>
void LinkedList<T>::insertSorted(T item)                                     //SORTED
{
/*if(head==NULL)
{insertAtHead(item);}
else if(head->next=NULL)
{
if(head->value>item)
{insertAtHead(item);}
 else {insertAtTail(item);}
}
 else{*/
 insertAtHead(item);
  T temp_val;
   
   ListItem<T> *temp11;
   ListItem<T> *temp12;
  
   //sorting the list
     for(temp11=head;temp11->next!=NULL;temp11=temp11->next)
     {
     for(temp12=temp11->next;temp12!=NULL;temp12=temp12->next)
     {
      if(temp11->value>temp12->value)
      {
        temp_val=temp12->value;
        temp12->value=temp11->value;
        temp11->value=temp_val; 
      }
}}
   
  /*  ListItem<T> *temp13=head;
    ListItem<T> *temp14=new ListItem<T> (item);
    ListItem<T> *temp15;
    
 if(temp13->value>temp14->value)
   LinkedList<T>::insertAtHead(item);

else if(temp14->value>tail->value)
{LinkedList<T>::insertAtTail(item);}
 
 else
    
   {while(temp13->next->value<item)
    {temp13=temp13->next;
     temp15=temp13->next;}
   temp14->next=temp13->next;
   temp15->prev=temp14;
   temp13->next=temp14;
   temp14->prev=temp13;}
   
   
  
   
}  */ 

}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
 
  return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
 
 return tail;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)             //SEARCH 
{ 
ListItem<T> *temp16=head;
if(head==NULL)
return NULL;
else{
 
 while(temp16!=NULL)
 {if(temp16->value==item)
  {return temp16;break;}
  temp16=temp16->next; 
 }}
  //if(temp16->value!=item)
  return NULL;
}

template <class T>
T LinkedList<T>::isEmp()                                                       //EMPTY
{
if(head==NULL && tail==NULL)
return 1;
else return 0;
}
template <class T>
void LinkedList<T>::deleteElement(T item)
{
 ListItem<T>* temp=head;
 ListItem<T>* temp1=tail;
 if(temp->value==item)
 {deleteHead();}
 else if(temp1->value==item)
 {deleteTail();}
else{
 while(temp->next->value!=item)
{temp=temp->next;}
 temp->next=temp->next->next;}
}

template <class T>
void LinkedList<T>::deleteHead()
{
  
   ListItem<T> *temp =head;
   if(head->next==NULL)
   {head=NULL;tail=NULL;delete head;delete tail;}
   else{
   head=head->next;
   head->prev=NULL;
   delete temp;}
}

template <class T>
void LinkedList<T>::deleteTail()
{
  int length1=LinkedList<T>::length();
  if(length1==1)
  {head=NULL;tail=NULL;}
  else{
   ListItem<T> *temp =tail;
   temp=tail->prev;
   temp->next=NULL;
   tail=temp;}
   
}

template <class T>
int LinkedList<T>::length()
{
  int count=0;
  ListItem<T> *temp =head;
  while(temp!=NULL)
  {temp=temp->next;
   count++;}
   return count;
}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T> *temp1;
        ListItem<T> *temp2;
        temp1=head;
        while(temp1!=NULL)
        {
          temp2=temp1->prev; //saving the prev node while traversing
          temp1->prev=temp1->next;
          temp1->next=temp2;
          temp1=temp1->prev;
         }
     if(temp2!=NULL)
      temp2=temp2->prev;
      head=temp2;
}

template <class T>
void LinkedList<T>::parityArrangement()                   //PARITY
{
 T size=length();

T array[size];
 ListItem<T> *temp3=head;
for(int i=0;i<size;i++) //copying elements in the array
{
   array[i]=temp3->value;
   temp3=temp3->next;   
}

if((size%2)!=0) //odd size, size/2 even size-size/2 odd
{
T array1[size/2];//even ones
T array2[size-(size/2)];//odd ones
int j=0;
for(int i=0;i<size;i+=2)
{array2[j]=array[i];j++;}

int k=0;
for(int l=1;l<size;l+=2)
{array1[k]=array[l];k++;}

head=NULL;
tail=NULL;
for(int m=0;m<(size-size/2);m++)
insertAtTail(array2[m]);
for(int n=0;n<(size/2);n++)
insertAtTail(array1[n]);


}

else //even size, size/2 odd size/2 even
{
T array3[size/2];//even
T array4[size/2];//odd
int jj=0;
for(int i=0;i<size;i+=2)
{array4[jj]=array[i];jj++;}
int kk=0;
for(int l=1;l<size;l+=2)
{array3[kk]=array[l];kk++;}

head=NULL;
tail=NULL;
for(int m=0;m<(size/2);m++)
insertAtTail(array4[m]);
for(int n=0;n<(size/2);n++)
insertAtTail(array3[n]);



}




	
}

template <class T>
T LinkedList<T>::isPalindrome()
{ 
if(head==NULL)
return 0;
else{
int count=0;
T size=length();
T array[size];
ListItem<T> *temp3=head;
for(int i=0;i<size;i++) //copying elements in the array
{
   array[i]=temp3->value;
   temp3=temp3->next;   
}

if((size%2)!=0)
{
 size=size-1;
 for(int j=0;j<size/2;j++)
{if(array[j]==array[size-j])
  {count++;}
}
//cout<<"count is: "<<count;
int temp=(size-1)/2;
if(count==temp)
return 0;
else return 1;
}

else 
{

for(int j=0;j<size/2;j++)
{if(array[j]==array[size-j-1])
  {count++;}
}
//cout<<"count is: "<<count;
if(count==size/2)
return 1;
else return 0;

}








  /*int arraysize=LinkedList<T>::length();
   T array[arraysize];    
ListItem<T> *temp3=head;
for(int i=0;i<arraysize;i++)
{
   array[i]=temp3->value;
   temp3=temp3->next;   
}
int count=0;
if((arraysize%2)!=0)
  {arraysize=arraysize-1;

int j=0;
 while(j<arraysize/2)
 {if(array[j]==array[arraysize-j])
    {count++;j++;}
 }
  if(count==arraysize/2)
   {return 1;}
  else {return 0;}//this
}

else {

int j=0;
 while(j<arraysize/2)
 {if(array[j]==array[arraysize-j-1])
    {count++;j++;}
 }
  if(count==arraysize/2)
   {return 1;}
  else {return 0;}//this


}*/

}

}


template <class T>
T LinkedList<T>::print()
{
ListItem<T> *temp5=head;
int i=0;
while(temp5!=NULL)
{
cout<<temp5->value<<" ";;
temp5=temp5->next;i++;
}return i;}

/*int main()
{

LinkedList<int>object;


 
//cout<<endl;
//l.print();

object.insertAtHead(1);
object.insertAtHead(2);
object.insertAtHead(3);

object.insertAtHead(4);   
object.insertAtHead(5);
//object.insertAtHead(0);
//object.insertAfter(6,1);
//object.getHead()
//object.getTail();

//object.deleteElement(3);
//object.deleteHead();
//object.deleteTail();
//object.length();
//object.reverse();
//object.insertSorted(12);
//object.insertSorted(11);
//object.insertSorted(13);
//object.insertSorted();
//object.insertSorted();
//object.insertSorted(4);
//for(int i=0;i<25000;i++)
//{object.insertSorted(i);}
object.parityArrangement();
object.print();	cout<<endl;
//object.searchFor(1);
//cout<<object.isPalindrome();
//int c=object.check(300);cout<<endl;

cout<<endl;




	



return 0;
}*/

#endif























