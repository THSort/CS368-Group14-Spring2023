#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
#include <iostream>
#include <string>
#include <cmath>
using namespace std;


HashC::HashC(int size)
{
 this->tableSize=size;
 this->hashTable=new LinkedList<string>[tableSize];
 for(int i=0;i<size;i++)
  hashTable[i]="NULL";
}

HashC::~HashC()
{


}

unsigned long HashC :: hash(string input)
{ 
int hash1=polyHash(input,tableSize);
   return hash1;  
}


void HashC::insert(string word)
{


}



ListItem<string>* HashC :: lookup(string word){
  return NULL;
}

void HashC :: deleteWord(string word){
  return;
}

int main()
{
HashC o(5);


return 0;
}
#endif
