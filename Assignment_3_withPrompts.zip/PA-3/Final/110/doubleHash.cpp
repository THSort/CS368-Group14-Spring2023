#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
#include <vector>
#include <fstream>
HashD::HashD(){
    tableSize = 10000; // you cant change this
    this->hashTable= new block *[tableSize];
   for(int i=0;i<tableSize;i++)
  {
   hashTable[i]=new block(2000,"NULL");
  }
 count=1;
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){

unsigned long h1=bitHash(value);

    return (h1%tableSize);
}

unsigned long HashD :: hash2(string value){

int h2=polyHash1(value,tableSize);
 
    return h2;
}

void HashD::resizeTable(){

cout<<"RESIZING"<<endl;
block** temp=new block*[tableSize];
  for(int i=0;i<tableSize;i++)
  {
   temp[i]=new block(2000,"NULL");
  }

 for(int i=0;i<tableSize;i++)
  {
   temp[i]->value= hashTable[i]->value;
  }

  

int prev_size=tableSize;

tableSize=tableSize*2;

this->hashTable=new block *[tableSize]; //create new hash table of double size

//cout<<"table size is now: "<<tableSize<<endl;
for(int i=0;i<tableSize;i++)
{hashTable[i]=new block (2000,"NULL");} //give "NULL" value to all hashtable indexes 
  
for(int i=0;i<prev_size;i++) //copy previous hash table elements in new table
{
  hashTable[i]->value=temp[i]->value;
}
  
  
 
}

void HashD::insert(string value){

float loadfactor= (float)count/(float)tableSize;
int hash13=0;
if(loadfactor>0.8)
{resizeTable();}

int hash11=hash1(value);

if(hashTable[hash11]->value=="NULL")  //use first hash function
 {
 hashTable[hash11]->value=value;
 }

else 
{

int hash12=hash2(value);

if(hashTable[hash12]->value=="NULL")  //use second hash function
{
hashTable[hash12]->value=value;
}

else{   //if both hash funtions result in collision, use third hash function
   
     int i=1; int hash6;
      while(hash13<tableSize-500 && hashTable[hash13]->value!="NULL")
     {  
      hash13=hash11+i*hash12;
      i++;
     } 
     int w=1;
     if(hashTable[hash13]->value=="NULL")
    { hashTable[hash13]->value=value;}
     else
      { 
       resizeTable();
       insert(value);
      }
   
       
     
}
}
count++;}

void HashD::deleteWord(string value){

for(int i=0;i<tableSize;i++)
{
if(hashTable[i]->value==value)
   hashTable[i]=NULL;return;
}
    
}

block* HashD::lookup(string value){

for(int i=0;i<tableSize;i++)
{
if(hashTable[i]->value==value)
   return hashTable[i];
}
    return NULL;
}

/*int main()
{

HashD o;
vector<string> allWords;
   ifstream file;
    file.open("words.txt");
    cout << "LOADING THE FILE" << endl;
    string temp;
  
   for(int i=0;i<500;i++)
    {
        file >> temp;
        allWords.push_back(temp); 
    }

    for(int i=0;i<allWords.size();i++)
     {o.insert(allWords[i]);}









return 0;
}*/


#endif
