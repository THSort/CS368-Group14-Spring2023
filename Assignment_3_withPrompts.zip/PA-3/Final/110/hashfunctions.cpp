#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <iostream>
#include <cmath>
using namespace std;

// this takes in a string and returns a 64bit hash.
unsigned long polyHash1(std::string value,int a){

unsigned long hash;
int x=0; int j=1;

for(int i=0;i<value.length();i++)
{
hash+=(int)value[x]*pow(17,j);
x++;j++;
//cout<<"hash is: "<<hash<<endl;
}

hash=hash%a;

	return hash;
}

unsigned long polyHash(std::string value,int a){

unsigned long hash;
int x=0; int j=1;

for(int i=0;i<value.length();i++)
{
hash+=(int)value[x]*pow(31,j);
x++;j++;
//cout<<"hash is: "<<hash<<endl;
}

hash=hash%a;

	return hash;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){

int bitwise_hash=0; int x=0;
for(int i=0;i<value.length();i++)
{
 bitwise_hash^=(bitwise_hash<<5)+(bitwise_hash>>2)+value[x];
 x++;
}
	return bitwise_hash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){

hash=hash%size;

    return hash;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){

hash=(hash*m)+a;
if(hash<0)
hash=hash*-1;
hash=hash%size;


    return hash;
}
// 'm' and 'a' can take any value


/*int main()
{
cout<<"polyhash: "<<polyHash("ABCD",5)<<endl;
cout<<"bithash: "<<bitHash("ONSLtttttttttttffffffdsssssssssssssssskqoopsk")<<endl;
cout<<"divCompression: "<<divCompression(40000000000000000,100000000)<<endl;
cout<<"madCompression: "<<madCompression(40000000000000000,100000000,1993,1637)<<endl;


return 0;
}*/
#endif
// you may write your own program to test these functions.
