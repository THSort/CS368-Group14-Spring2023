#ifndef HASHBST_CPP
#define HASHBST_CPP
#include "HashBST.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize=size;

	hashTable= new BST<string>[size];
    
}
HashC::~HashC(){
	delete [] hashTable;

}

unsigned long HashC :: hash(string input){
	unsigned long k=bitHash(input);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;  
}

void HashC::insert(string word){
	unsigned long c=hash(word);
	if(!(hashTable[c].search(word))) // not in list
	{
		hashTable[c].insert(c,word);
	}

  return;
}

node<string>* HashC :: lookup(string word){
	unsigned long c=hash(word);

  return hashTable[c].search(word);
}

void HashC :: deleteWord(string word){
	unsigned long c=hash(word);
	hashTable[c].delete_node(word);

  return;
}

// Analysis:

// The general structure of BST takes up more space than  a LL. many nodes can be placed in different locations of the memory. The bst node also has an extra parent pointer so the 
// node takes up more space.

// In search and time of a bst is in O(log n) but since i am implementing a balanced AVL tree it takes time to balance the nodes after insertion and after deletion. Furthermore, the 
// insert time is O(nlogn) Hence the run time goes to 1.9 seconds so it takes longer than just using LL chaining. If we use unbalanced tree then the memory footprint would increase 
// but the running time would be reduced. The loading time is more as compared to LL and vectors since it is in O(log n) and not O(1).



#endif
