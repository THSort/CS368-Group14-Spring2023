#ifndef HASHVECTOR_CPP
#define HASHVECTOR_CPP
#include "HashVector.h"
#include "hashfunctions.cpp"
#include <algorithm>

HashC::HashC(int size){
	tableSize=size;

	hashTable= new vector<string>[size];
    
}
HashC::~HashC(){
	delete [] hashTable;
}

unsigned long HashC :: hash(string input){
	unsigned long k=bitHash(input);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;  
}

void HashC::insert(string word){

	unsigned long c=hash(word);
	if(find(hashTable[c].begin(),hashTable[c].end(),word)!=hashTable[c].end()) // item not present
	{
		hashTable[c].push_back(word);
	}

  return;
}

string* HashC :: lookup(string word){
	unsigned long c=hash(word);

	vector <string >::iterator answer;
	answer = find(hashTable[c].begin(), hashTable[c].end(),word);

	if(answer==hashTable[c].end()) return NULL;

  	else
  	{
  		string* ret;
  		*ret=*answer;

  		return ret;
  	}
}

void HashC :: deleteWord(string word){
	unsigned long c=hash(word);

	vector <string >::iterator answer;
	answer = find(hashTable[c].begin(), hashTable[c].end(),word);

	if(answer!=hashTable[c].end())//word present
	{
		hashTable[c].erase(answer);
	}

  return;
}

// Analysis:

// This program runs faster than the program with linked list as it takes about 0.4 while linked list takes about 1 second. Perhaps because we can 
// use predefined functions and algorithms such as find, erase and etc. However, in terms of time complexity, to search for an element we still have to traverse
// the vector, same as linked list. To insert, its O(n) as we simply push back and can ncrease the size dynamically. this is also the same as using DLL. Deleting
// in both cases is also O(n) since we use a traverse the container to find the item and then use the erase member function to delete the item, in LL we
// also traverse the list and because it is double linked we can easily delete nodes.

// As for the space requirement, i feel a vector is more efficient as it requires less space than a node in the LL ehich contains two data types and pointers as well.
// Vector simply contains a value and can easily be expanded. 


#endif
