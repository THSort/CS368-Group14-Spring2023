#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this

    hashTable= new block*[tableSize];

    for(int i=0; i<tableSize; i++)
    {
    	hashTable[i]=new block(0," ");
    }
    count=0;
}

HashL::~HashL(){
	for(int i=0; i<tableSize; i++)
	{
		delete [] hashTable[i];
	}

    delete [] hashTable;
}

unsigned long HashL :: hash(string value){
	unsigned long k=bitHash(value);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;
}

void HashL::resizeTable(){
	
	double alpha=count/tableSize;

	// increase size
	if(alpha>0.7)	
	{	
		unsigned long new_size=30*tableSize;
		block** temp= new block*[new_size];

		for(int i=0; i<new_size; i++)
		{
			temp[i]= new block(0," ");
		}

		unsigned long temp_size=tableSize;
		tableSize=new_size;

		count=0;

		for(int i=0; i<temp_size; i++)
		{
			if(hashTable[i]->value!=" " && hashTable[i]->value!="DeL")
			{
				unsigned long c=hash(hashTable[i]->value);
				unsigned long  index=c%tableSize;

				unsigned long key=c;

				while(temp[index]->value!=" ")
				{
					c++;
					index=c%tableSize;
				}

				temp[index]->key=key;
				temp[index]->value=hashTable[i]->value;

				count++;
			}
		}

		hashTable=temp;

	    return;
	}

	else if (alpha<0.3)
	{
		int new_size=tableSize/3;
		block** temp= new block*[new_size];

		for(int i=0; i<new_size; i++)
		{
			temp[i]= new block(0," ");
		}

		int temp_size=tableSize;
		tableSize=new_size;

		count=0;

		for(int i=0; i<temp_size; i++)
		{
			if(hashTable[i]->value!=" " && hashTable[i]->value!="DeL")
			{
				unsigned long c=hash(hashTable[i]->value);
				unsigned long  index=c%tableSize;

				unsigned long key=c;

				while(temp[index]->value!=" ")
				{
					c++;
					index=c%tableSize;
				}

				temp[index]->key=key;
				temp[index]->value=hashTable[i]->value;

				count++;
			}
		}

		hashTable=temp;

	    return;
	}
}

void HashL::insert(string value){
	unsigned long c=hash(value);
	unsigned long index=c%tableSize;

	unsigned long key=c;

	double alpha=count/tableSize;

	if(alpha>0.7)
	{
		resizeTable();
	}

	while(hashTable[index]->value!=" " && hashTable[index]->value!= "DeL")
	{
		c++;
		index=c%tableSize;
	}

	hashTable[index]->key=key;
	hashTable[index]->value=value;

	count++;
    return;
}

void HashL::deleteWord(string value){
	block* target=lookup(value);

	if(target)
	{
		target->value="DeL";
		count--;
	}

	double count1 = count;
	double tableSize1 = tableSize;
	double alpha=count1/tableSize1;

	if(alpha<0.3)
	{
		resizeTable();
	}

	return;
}
block* HashL::lookup(string value){
	unsigned long c=hash(value);
	unsigned long index=c%tableSize;
	unsigned long key=c;

	int counter=0;

	while(counter<=tableSize)
	{
		if(hashTable[index]->value==value)
		{
			return hashTable[index];
		}

		else if(hashTable[index]->value!="DeL")
		{
			c++;
			index=c%tableSize;
		}
		else
		{
			return NULL;
		}

		counter++;
	}

    return NULL;
}
#endif
