#include "Chaining.cpp"
#include "HashHash.cpp"
#ifndef HASHHASH__H
#define HASHHASH__H
#include <string>
using namespace std;
class HashD
{
	private:
		long tableSize;
		HashC** hashTable;
		unsigned long hash(string input); // Given a String, return its hash
	public:
		HashD(int size);
		~HashD(); // Destructor
		void insert(string word); // Takes a hash of 'word' and inserts it into hashTable accordingly
		void deleteWord(string word);
		ListItem<string>* lookup(string word);
};
#endif
