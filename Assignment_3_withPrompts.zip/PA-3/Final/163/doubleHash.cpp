#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this

    hashTable= new block*[tableSize];

    for(int i=0; i<tableSize; i++)
    {
    	hashTable[i]=new block(0," ");
    }
    count=0;
}

HashD::~HashD(){
	for(int i=0; i<tableSize; i++)
	{
		delete [] hashTable[i];
	}

    delete [] hashTable;
}

unsigned long HashD :: hash1(string value){

    unsigned long k=bitHash(value);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;
}

unsigned long HashD :: hash2(string value){
    unsigned long k=polyHash(value);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;
}

void HashD::resizeTable(){
	
    double count1 = count;
	double tableSize1 = tableSize;
	double alpha=count1/tableSize1;

	// increase size
	if(alpha>0.7)	
	{	
		unsigned long new_size=11*tableSize;
		block** temp= new block*[new_size];

		for(int i=0; i<new_size; i++)
		{
			temp[i]= new block(0," ");
		}

		unsigned long temp_size=tableSize;
		tableSize=new_size;

		count=0;

		for(int i=0; i<temp_size; i++)
		{
			if(hashTable[i]->value!=" " && hashTable[i]->key!=-111)
			{
				unsigned long hashA=hash1(hashTable[i]->value);
				unsigned long hashB=hash2(hashTable[i]->value);

				int j=0;
				//unsigned long key=hashA+hashB;
				unsigned long index=(hashA+(j*hashB))%tableSize;

				while(temp[index]->value!=" ")
				{
					j++;
					index=(hashA+(j*hashB))%tableSize;
				}

				temp[index]->key=index;
				temp[index]->value=hashTable[i]->value;

				count++;
			}
		}

		hashTable=temp;

	    return;
	}

	else if (alpha<0.3)
	{
		int new_size=tableSize/3;
		block** temp= new block*[new_size];

		for(int i=0; i<new_size; i++)
		{
			temp[i]= new block(0," ");
		}

		int temp_size=tableSize;
		tableSize=new_size;

		count=0;

		for(int i=0; i<temp_size; i++)
		{
			if(hashTable[i]->value!=" " && hashTable[i]->key!=-111)
			{
				unsigned long hashA=hash1(hashTable[i]->value);
				unsigned long hashB=hash2(hashTable[i]->value);

				int j=0;
				//unsigned long key=hashA+hashB;
				unsigned long index=(hashA+(j*hashB))%tableSize;

				while(temp[index]->value!=" ")
				{
					j++;
					index=(hashA+(j*hashB))%tableSize;
				}

				temp[index]->key=index;
				temp[index]->value=hashTable[i]->value;

				count++;
			}

		}

		hashTable=temp;

	    return;
	}
}

void HashD::insert(string value){
	unsigned long hashA=hash1(value);
	unsigned long hashB=hash2(value);


	double count1 = count;
	double tableSize1 = tableSize;
	double alpha=count1/tableSize1;

	if(alpha>0.7)
	{
		resizeTable();
	}

	int i=0;
	//unsigned long key=hashA+hashB;
	unsigned long index=(hashA+(i*hashB))%tableSize;

	while(hashTable[index]->value!=" " && hashTable[index]->key!=-111)
	{
		i++;
		index=(hashA+(i*hashB))%tableSize;
	}
	

	hashTable[index]->key=index;
	hashTable[index]->value=value;

	count++;
    return;
}

void HashD::deleteWord(string value){
    block* target=lookup(value);

	if(target)
	{
		target->key=-111;
		count--;
	}

	double count1 = count;
	double tableSize1 = tableSize;
	double alpha=count1/tableSize1;

	if(alpha<0.3)
	{
		resizeTable();
	}

	return;
}

block* HashD::lookup(string value){

	unsigned long hashA=hash1(value);
	unsigned long hashB=hash2(value);

	int i=0;
	//unsigned long key=hashA+hashB;
	unsigned long index=(hashA+(i*hashB))%tableSize;

	while(i<tableSize)
	{
		if(hashTable[index]->value==value && hashTable[index]->key!=-111)
		{
			return hashTable[index];
		}

		else if(hashTable[index]->key!=-111)
		{
			i++;
			index=(hashA+(i*hashB))%tableSize;
		}
		else
		{
			return NULL;
		}
	}

 	return NULL;
}

#endif
