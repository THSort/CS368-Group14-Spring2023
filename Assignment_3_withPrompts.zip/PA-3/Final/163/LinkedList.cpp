#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include <stack>
#include <queue>
#include <iostream>
#include "LinkedList.h"

using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	
	head=NULL;

	ListItem<T>* temp3=otherLinkedList.head;  //other list tracking pointer

	LinkedList<T>* newlist=new LinkedList<T>;

	if(temp3==NULL) 
	{ 
		head=NULL;
	}

   else 
   {

	   	//insert head

		while(temp3!=NULL)
		{
			newlist->insertAtTail(temp3->value);
			temp3=temp3->next;
		}

		head=newlist->getHead();


	}	

}

template <class T>
LinkedList<T>::~LinkedList()
{
	ListItem<T>* temp1=NULL;
	ListItem<T>* temp2=NULL;

	temp1=head;					//pointer to track list
	while(temp1!=NULL)
	{
		temp2=temp1->next;		// save next node
		delete temp1;			// delete node
		temp1=NULL;
		temp1=temp2; 			//move to next node
	}

	//now temp1 and temp2 are NULL

	head=NULL;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	ListItem<T>* temp= new ListItem<T> (item);

	//enter data in node
	temp->value=item;
	if(head!=NULL) head->prev=temp;
	temp->next=head;
	temp->prev=NULL;

	//make that node the head
	head=temp;
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	ListItem<T>* temp= new ListItem<T> (item);


	ListItem<T>* temp2=head; //tracking pointer
	if(temp2==NULL)
	{
		//enter data in node
		temp->value=item;
		temp->next=head;
		temp->prev=NULL;

		//make that node the head
		head=temp;
	}

	else
		{
			while(temp2->next!=NULL)
			{
				temp2=temp2->next;// go to the last node
			}

			//enter data in node
			temp->value=item;
			temp->next=NULL;
			temp->prev=temp2;	

			temp2->next=temp;
		}
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T>* temp1=head; //tracking pointer
	ListItem<T>* temp2= new ListItem<T> (toInsert);

	while(temp1->value!=afterWhat && temp1->next!=NULL) //search till find the value or till the last node
	{
		temp1=temp1->next;
	}

	if(temp1->next==NULL && temp1->value==afterWhat)
	{
		temp2->value=toInsert;
		temp2->next=NULL;
		temp2->prev=temp1;
		temp1->next=temp2;
	}

	else if(temp1->value==afterWhat)
	{
		temp2->value=toInsert;
		temp2->next=temp1->next;
		temp1->next->prev=temp2;
		temp2->prev=temp1;
		temp1->next=temp2;
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem<T>* temp1=head; //tracking pointer
	
	if(temp1==NULL)
	{
		ListItem<T>* temp= new ListItem<T> (item);

		//enter data in node
		temp->value=item;
		temp->next=NULL;
		temp->prev=NULL;

		//make that node the head
		head=temp;
		return;
	}


	ListItem<T>* temp2= new ListItem<T> (item);
	
	while(temp1->next!=NULL && (item>(temp1->value))) //search till find the value or till the last node
	{
		temp1=temp1->next;
	}
	
	
	if(temp1->next==NULL && (temp1->value)<item)
	{
		temp2->value=item;
		temp2->next=NULL;
		temp2->prev=temp1;
		temp1->next=temp2;
	}


	else if(temp1->next==NULL && item<=(temp1->value))
	{

		temp2->value=item;
		temp2->next=temp1;
		temp2->prev=temp1->prev;
		if(temp1->prev!=NULL)
			{
				(temp1->prev)->next=temp2;
				temp1->prev=temp2;
			}
		
		else 
			{
				temp1->prev=temp2;
				head=temp2;
			}
	}

	else  // not at last node so item<= temp1->value
	{

		temp2->value=item;
		temp2->next=temp1;
		temp2->prev=temp1->prev;

		if(temp1->prev!=NULL)
			{
				(temp1->prev)->next=temp2;
				temp1->prev=temp2;
			}
		
		else 
			{
				temp1->prev=temp2;
				head=temp2;
			}
	}

}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	ListItem<T>* temp1=head; //tracking pointer

	if(head==NULL)
	{
		return NULL;
	}

	while(temp1->next!=NULL)
	{
		temp1=temp1->next;
	}

	return temp1;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T>* temp1=head; //tracking pointer

	while(temp1!=NULL && temp1->value!=item)
	{
		temp1=temp1->next;
	}

	return temp1;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T>* temp1=head; //tracking pointer

	if(head==NULL)
	{
		return ;
	}

	while(temp1!=NULL && (temp1->value)!=item)
	{
		temp1=temp1->next;
	}

	if(temp1==NULL)
	{
		return;
	}

	else if(temp1!=NULL)
	{
		if(head->value==item)
		{
			if(temp1->next!=NULL){ (temp1->next)->prev=temp1->prev;} //node ater the deletion node
			
			head=temp1->next;

			delete temp1;
			temp1=NULL;

			return;

		}


		if(temp1->prev!=NULL)(temp1->prev)->next=temp1->next;
		if(temp1->next!=NULL){ (temp1->next)->prev=temp1->prev;} //node ater the deletion node

		delete temp1;
		temp1=NULL;
	}

}

template <class T>
void LinkedList<T>::deleteHead()
{
	
	ListItem<T>* temp1=head; //tracking pointer
	ListItem<T>* temp2=head->next; //tracking pointer

	delete temp1;
	temp1=NULL;

	head=temp2;
	if(head!=NULL) head->prev=NULL;

}

template <class T>
void LinkedList<T>::deleteTail()
{
	ListItem<T>* tail=this->getTail();
	 if(tail->prev!=NULL)
	 	{
	 		ListItem<T>* temp1= tail->prev;
	 		delete tail;
			
			tail=NULL;

			temp1->next=NULL;

			return;

	 	}

	else
	{
		this->deleteHead();
		return;
	}

}

template <class T>
int LinkedList<T>::length()
{
	int counter=0;

	ListItem<T>* temp1=head; //tracking pointer

	while(temp1!=NULL)
	{
		temp1=temp1->next;
		counter++;
	}

	return counter;
}

template <class T>
void LinkedList<T>::reverse()
{

		ListItem<T>* temp=head;
		ListItem<T>* temp1;

		{
			while(temp!=NULL)
			{
				temp1=temp->next;
				temp->next=temp->prev;
				temp->prev=temp1;

				temp=temp1;
			}
		}

		temp=head;

		while(temp->prev!=NULL)
		{
			temp=temp->prev;
		}

		head=temp;
 
}

template <class T>
void LinkedList<T>::parityArrangement()
{
	LinkedList<T>* EvenList= new LinkedList;
	LinkedList<T>* OddList=new LinkedList;

	ListItem<T>* temp1=head;
	ListItem<T>* temp2= new ListItem<T> (0);

	int counter=1;

	while(temp1!=NULL)
	{
		temp2->value=temp1->value;
		temp2->next=temp1->next;
		temp2->prev=temp1->prev;

		if((counter%2)==0)
		{
			EvenList->insertAtTail(temp1->value);
		}

		else
		{
			OddList->insertAtTail(temp1->value);
		}

		temp1=temp1->next;
		counter++;
	}

	ListItem<T>* temp3=OddList->getTail();
	ListItem<T>* temp4=EvenList->getHead();

	temp3->next=temp4;
	temp4->prev=temp3;

	head=OddList->getHead();

}

template <class T>
bool LinkedList<T>::isPalindrome()
{

	ListItem<T>* start = head;
	ListItem<T>* tail= getTail();
	cout<<"yaen"<<endl;

	if(head==NULL)
	{
		return 0;
	}

	int counter=0;

	while(start!=NULL)
	{
		if(start->value==tail->value)
		{
			counter++;
			start=start->next;
			tail= tail->prev;
		}

		else
		{
			break;
		}
	}

	if (counter ==length())
	{
		return 1;
	}

	else
	{
		return 0;
	}
}

template <class T>
void LinkedList<T>::setHead(ListItem<T>* ele)
{
	head=ele;
}

#endif
