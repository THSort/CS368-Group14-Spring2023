#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
	tableSize=size;

	hashTable= new LinkedList<string>[size];
    
}
HashC::~HashC(){
	delete [] hashTable;

}

unsigned long HashC :: hash(string input){
	unsigned long k=bitHash(input);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;  
}

void HashC::insert(string word){
	unsigned long c=hash(word);
	if(!(hashTable[c].searchFor(word))) // not in list
	{
		hashTable[c].insertAtHead(word);
	}

  return;
}

ListItem<string>* HashC :: lookup(string word){
	unsigned long c=hash(word);
	ListItem<string>* val = hashTable[c].searchFor(word);
  return val;
}

void HashC :: deleteWord(string word){
	unsigned long c=hash(word);
	hashTable[c].deleteElement(word);

  return;
}

#endif
