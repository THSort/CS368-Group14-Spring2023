#ifndef HASHHASH_CPP
#define HASHHASH_CPP
#include "HashHash.h"
#include "hashfunctions.cpp"

HashD::HashD(int size){
	tableSize=size;

	hashTable= new HashC* [size];

	for(int i=0; i<size; i++)
	{
		hashTable[i]=new HashC(4);
	}
    
}
HashD::~HashD(){

    delete [] hashTable;
}



unsigned long HashD :: hash(string input){
	unsigned long k=bitHash(input);
	unsigned long c=madCompression(k,tableSize,1993,1637);

  return c;  
}

void HashD::insert(string word){
	unsigned long c=hash(word);
	hashTable[c]->insert(word);

  return;
}

ListItem<string>* HashD :: lookup(string word){
	unsigned long c=hash(word);

  return hashTable[c]->lookup(word);
}

void HashD:: deleteWord(string word){
	unsigned long c=hash(word);
	hashTable[c]->deleteWord(word);

  return;
}

// Analysis:

// The space footprint of this implement is more as compared to implementing with a BST, vector or LL. since in initialization, we have to initialize a hash Table and
// it needs to be of some size, even if it is of the size 3 or 4. This means at each location in a hashtable, there are a couple of indexes empty. so a lot of wasted 
// spaces in a large hash tabe while a LL, vectors and BST are all dynamic and increase as need be.

// In terms of time it roughly ran in the same time as LL in the average case however it did go a bit fast , usually around 1.04 seconds. This is because in LL, insert at 
// head is O(1) and inserting in a Hash table is also roughly around O(1) is the size is chosen carefully. However a bad value of hashtable size can increase the time. 
// The overall time of constants is also increased in using hashtable to implement a hashtable as we hash to compute the hash for each word twice. The look up and delete 
// are also of the same magnitude because essentially there is just an extra added level of a hashtable and in the end chaining is done by LL. and operations in hashTable
// on average can be made around O(1), then the time for LL and hashtable is basically same. So it will be faster than BST, but still slower than vectors.

#endif
