#include <string>
#include "hashfunctions.cpp"

#include "doubleHash.h"
#include <iostream>

using namespace std;

int main()
{
//    unsigned long a=polyHash("bithcin");
//    cout<<a<<endl;
//    unsigned long b=divCompression(a, 10);
//    cout<<b<<endl;

HashD a;
/*HashL b;
a.insert("hello");
cout<<a.hashTable[2]->value<<endl;
a.insert("why");
cout<<a.hashTable[5]->value<<endl;
a.insert("amal");
cout<<a.hashTable[3]->value<<endl;
a.insert("lashari");
cout<<a.hashTable[8]->value<<endl;
a.insert("summer");
cout<<a.hashTable[4]->value<<endl;
a.insert("power");
a.insert("hello");
a.insert("hello");
cout<<a.hashTable[19]->value<<endl;

//a.deleteWord("hello");
//cout<<a.hashTable[2]->value<<endl;


a.deleteWord("hello");
block *temp=a.lookup("power");
cout<<temp->value<<endl;
cout<<temp->key<<endl;
cout << "----" << endl;*/
for(int i=0;i<60;i++)
{
 a.insert("adil");
}
a.print();

//cout<<temp->value<<endl;
//cout<<a.hash("summer")<<endl;

//why 5
//hello 2
//amal 3
//lashari 8
//summer 4
//cs 8
//assignment 4
//discreet 6
//fundamental 6
//a 7
//apple 1
//power 9
//ponder 5
//cout<<b.hash("ponder"); //returns 122



//cout<<temphash<<endl;
//block* temp=a.lookup("hello");
//a.deleteWord("hello");


}

