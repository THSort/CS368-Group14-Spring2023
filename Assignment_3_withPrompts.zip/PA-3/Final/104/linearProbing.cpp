#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable= new block* [tableSize];
    count=0;
    for (int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
}

HashL::~HashL()
{

}

unsigned long HashL :: hash(string value)
{
   unsigned long a= bitHash(value);
   unsigned long b= divCompression(a,tableSize);
   return b;
}

void HashL::resizeTable()
{
    block** old; //copy of the old hashtable
    old= new block* [tableSize];
    old=hashTable;

    long sizeold=tableSize; //copy of the old tablesize

    tableSize=tableSize*2; //new tablesize

    block** newtable; //new table
    newtable= new block * [tableSize];
    //hashtable is now set to newtable
    //hashTable=newtable;

    for (int i=0; i<tableSize; i++)
    {
       newtable[i]=NULL;
    }

    int i=0;
    long saveoldcount=count;
    while (i<sizeold)
    {

        if (old[i] ==NULL)
        {
            i++;
        }
        else if (old[i]->value=="stupidMarker")
        {
            i++;
        }
        else
        {
            string val= old[i]->value;
            unsigned long temp=hash(val);
            unsigned long temp2=temp;
            if (newtable[temp2]==NULL)
            {
              newtable[temp2]=new block(temp, val);
            i++;
            }
            else if (newtable[temp2] != NULL)
            {
                while (temp2 <tableSize)
                {
                   if (newtable[temp2]==NULL)
                    {
                         newtable[temp2]=new block(temp, val);
                         i++;
                         break;
                    }
                    else
                    {
                        temp2++;
                        if (temp2==tableSize)
                        {
                            temp2=0;
                        }
                    }
                }
            }
        }
    }
     hashTable = newtable;
     count=saveoldcount;

}

void HashL::insert(string value)
{
   unsigned long temp=hash(value);
   if (hashTable[temp]==NULL)
   {
       hashTable[temp]=new block(temp, value);
       count++;
       if (count>=(0.5)*tableSize)
       {   resizeTable();
           return;
       }
       else
       {
           return;
       }

   }
   else if (hashTable[temp]->value=="stupidMarker")
   {
       hashTable[temp]=new block(temp, value);
       count++;
       if (count>= (0.5)*tableSize)
       {
           resizeTable();
           return;
       }
   }
   else
   {
       unsigned long i= temp;
       while (hashTable[i] != NULL)
       {
          if (hashTable[i]->value=="stupidMarker")
          {
              temp=i;
              break;
          }
           else
           {
                i++;
            if (i==tableSize)
           {
               i=0;
           }

           }
       }
       hashTable[i]=new block(temp, value);
       count++;
       if (count>= (0.5)*tableSize)
       {
           resizeTable();
           return;
       }

   }
}

//void HashL::deleteWord(string value)
//{
//    unsigned long temp=hash(value);
//    long tempcount=0;
//    if (hashTable[temp]->value==value)
//    {
//        hashTable[temp]->value= "stupidMarker";
//        count--;
//        while (hashTable[temp]!= NULL)
//                {
//                hashTable[temp]->value=="stupidMarker";
//                count--;
//                if (temp==tableSize)
//                {
//                    temp=0;
//                }
//                temp++;
//                }
//        return;
//    }
//    else
//    {
//        unsigned long i=temp;
//
//        while (i<tableSize)
//        {
//
//            if (hashTable[i]==NULL)
//            {
//                i++;
//
//            }
//            else if (hashTable[i]->value==value)
//            {
//                hashTable[i]->value=="stupidMarker";
//                count--;
//                while (hashTable[i]!= NULL)
//                {
//                hashTable[i]->value=="stupidMarker";
//                count--;
//                i++;
//                if (temp==tableSize)
//                {
//                    temp=0;
//                }
//                }
//                return;
//            }
//            else if (tempcount==count)
//            {
//                break;
//            }
//            else
//            {
//                i++;
//                if (i==tableSize)
//                {
//                    i=0;
//                }
//                tempcount++;
//            }
//        }
//    }
//}
void HashL::deleteWord(string value)
{
    unsigned long index=hash(value);
    while (1)
    {
        if (hashTable[index]==NULL)
        {
            //cout<<"yes"<<endl;
            break;
        }
        else if (hashTable[index]->value==value)
        {
            count--;
            hashTable[index]->value="stupidMarker";
        }
        index++;
        index=index%tableSize;
    }
    return;
}





block* HashL::lookup(string value)
{
    unsigned long index=hash(value);
    unsigned long indexog=index;
    //long tempcount=0;
    while(1)
    {
        if(hashTable[index]==NULL)
        {
            //index++;
            break;
        }
        else if (hashTable[index]->value==value && hashTable[index]->key==indexog)
        {
            return hashTable[index];
        }
       /* else if (tempcount==count)
        {
            break;
        }*/
        else
        {
          index++;
          if (index==tableSize)
          {
              index=0;
          }
          //tempcount++;
         }
}
return NULL;
}

void HashL:: print ()
{
    for(int i=0;i<tableSize;i++)
    {
        if(hashTable[i] != 0)
        {
        cout << i << "- Value " << hashTable[i]->value << " Key "  << hashTable[i]->key << endl;
        }

    }
}


//    long i=0;
//    long counttemp=0;
//    unsigned long index = hash(value);
//    if (hashTable[index]==NULL)
//    {
//        return NULL;
//    }
//    else if (hashTable[index]->value==value && hashTable[index]->key == index)
//    {
//        return hashTable[index];
//    }
//   else
//   {
//       index++;
//       counttemp++;
//       while(1)
//    {
//        if (hashTable[index]==NULL)
//        {
//           // cout<<"null"<<endl;
//            break;
//        }
//         else if (hashTable[index]->value==value && hashTable[index]->key == index)
//        {
//           // cout<<"found"<<endl;
//            return hashTable[index];
//        }
//
//
//        else if(index ==tableSize-1)
//        {
//           // cout<<"go back to start"<<endl;
//            index =0;
//        }
//        else if (counttemp==count)
//        {
//            //cout<<"not found"<<endl;
//            break;
//        }
//        else
//        {
////            cout<<"increment"<<endl;
////            cout<<"index:"<<index<<endl;
////            cout<<"counttemp:"<<counttemp<<endl;
////            cout<<"count:"<<count<<endl;
//            index++;
//            counttemp++;
//        }
//    }
//}
//return NULL;
//}
//    else if (hashTable[index]->value==value && hashTable[index]->key == index)
//    {
//        return hashTable[index];
//    }
//    else
//    {
//        i=index;
//        int tempcount;
//        while (i<tableSize)
//        {
//            if (tempcount==tableSize)
//            {
//                //cout<<"exit cond"<<endl;
//                return NULL;
//                break;
//            }
//
//            else if (hashTable[i]==NULL)
//            {
//               // cout<<"equal to NULL"<<endl;
//                i++;
//                tempcount++;
//                if (i==tableSize)
//                {
//                    i=0;
//                }
//            }
//            else if (hashTable[i]->value==value)
//            {
//                // cout<<"value found"<<endl;
//                index=i;
//                break;
//            }
//            else
//            {
//                 //cout<<"not our value"<<endl;
//                i++;
//                tempcount++;
//                if (i==tableSize)
//                {
//                    i=0;
//                }
//            }
//        }
//    }
//    return hashTable[index];
//
//}

#endif
