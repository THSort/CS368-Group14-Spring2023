#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
 tableSize=size;
 hashTable=new LinkedList <string> [tableSize];

}
HashC::~HashC()
{

}

unsigned long HashC :: hash(string input){
    unsigned long temp= bitHash(input);
    unsigned long temp2= divCompression(temp,tableSize);
    return temp2;
}

void HashC::insert(string word){
  unsigned long temp= hash(word);
  hashTable[temp].insertAtHead(word);

}

ListItem<string>* HashC :: lookup(string word)
{
  unsigned long temp= hash(word);
  return hashTable[temp].searchFor(word);

}

void HashC :: deleteWord(string word){
  unsigned long temp= hash(word);
  while(lookup(word)!=NULL)
  {
    hashTable[temp].deleteElement(word);
  }
}

#endif
