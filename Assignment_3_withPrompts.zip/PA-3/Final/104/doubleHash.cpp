#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD()
{
    tableSize = 10000; // you cant change this
    hashTable= new block* [tableSize];
    count=0;
    for (int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
}

HashD::~HashD()
{

}

unsigned long HashD :: hash1(string value)
{
   unsigned long a= bitHash(value);
   unsigned long b= divCompression(a,tableSize);
   return b;
}

unsigned long HashD :: hash2(string value)
{
  long tempval=tableSize-5;
  unsigned long b=(tableSize-5)+value[0];
  unsigned long a=tempval-(b %tempval);
  return a;

}

void HashD::resizeTable()
{
    block** old; //copy of the old hashtable
    old= new block* [tableSize];
    old=hashTable;

    long sizeold=tableSize; //copy of the old tablesize

    tableSize=tableSize*20; //new tablesize

    block** newtable; //new table
    newtable= new block * [tableSize];
    //hashtable is now set to newtable
    //hashTable=newtable;

    for (int i=0; i<tableSize; i++)
    {
       newtable[i]=NULL;
    }

    int i=0;
    int j;
    long saveoldcount=count;
    while (i<sizeold)
    {
        j=0;
        if (old[i] ==NULL)
        {
            i++;
        }
        else if (old[i]->value=="stupidMarker")
        {
            i++;
        }
        else
        {
            string val= old[i]->value;
            unsigned long hash11=hash1(val);
            unsigned long hash22=hash2(val);
            unsigned long temp=hash11 + j*(hash22);
            temp=temp%tableSize;
            unsigned long tempog=temp;
            if (newtable[temp]==NULL)
            {
              newtable[temp]=new block(tempog, val);
               i++;
            }
            else if (newtable[temp] != NULL)
            {
                while (1)
                {
                   if (newtable[temp]==NULL)
                    {
                         newtable[temp]=new block(tempog, val);
                         i++;
                         break;
                    }
                    else
                    {
                        j++;
                        temp=(hash11) + j*(hash22);
                        temp=temp%tableSize;
                    }
                }
            }
        }
    }
     hashTable = newtable;
     count=saveoldcount;

}

void HashD::insert(string value)
{
   unsigned long j=0;
   unsigned long hash11=hash1(value);
   unsigned long hash22=hash2(value);
   unsigned long temp=hash11;
   temp=temp%tableSize;
   unsigned long tempog=temp;
   while(1)
   {
       if (hashTable[temp]==NULL)
       {
            hashTable[temp]=new block(tempog, value);
            count++;
        if (count >= (0.2)*tableSize)
         {
           resizeTable();
           break;
         }
         break;
       }
       else if (hashTable[temp]->value=="stupidMarker")
       {
            hashTable[temp]=new block(tempog, value);
            count++;
        if (count>= (0.2)*tableSize)
       {
           resizeTable();
           break;
       }
       break;
       }
       j++;
       temp=hash11+(j*hash22);
       temp=temp%tableSize;
   }
   return;
}

void HashD::deleteWord(string value)
{
    unsigned long hash11=hash1(value);
    unsigned long hash22=hash2(value);
    unsigned long j=0;
    unsigned long index=(hash11)+(j*(hash22));
    index=index%tableSize;
    while (1)
    {
        if (hashTable[index]==NULL)
        {
            //cout<<"yes"<<endl;
            break;
        }
        else if (hashTable[index]->value==value)
        {
            count--;
            hashTable[index]->value="stupidMarker";
        }
        j++;
        index=(hash11)+(j*(hash22));
        index=index%tableSize;
    }
    return;
}

block* HashD::lookup(string value)
{
   unsigned long j=0;
   unsigned long index=(hash1(value))+(j*(hash2(value)));
   index=index%tableSize;
   unsigned long indexog=index;
    //long tempcount=0;
    while(1)
    {
        if(hashTable[index]==NULL)
        {
            //index++;
            break;
        }
        else if (hashTable[index]->value==value)//hashTable[index]->key==indexog)
        {
            return hashTable[index];
            break;
        }
       /* else if (tempcount==count)
        {
            break;
        }*/
          j++;
          index=hash1(value)+(j*(hash2(value)));
          index=index%tableSize;
          //tempcount++
}
return NULL;
}
void HashD:: print ()
{
    for(int i=0;i<tableSize;i++)
    {
        if(hashTable[i] != 0)
        {
        cout << i << "- Value " << hashTable[i]->value << " Key "  << hashTable[i]->key << endl;
        }

    }
}

#endif
