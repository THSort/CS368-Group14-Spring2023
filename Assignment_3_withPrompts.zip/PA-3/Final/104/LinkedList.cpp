#ifndef __LIST_CPP
#define __LIST_CPP
using namespace std;
#include<iostream>
#include <cstdlib>

#include "LinkedList.h"


template <class T>
LinkedList<T>::LinkedList()
{
    head=NULL;

}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
ListItem<T> *temp;
temp=otherLinkedList.getHead();


if (temp==NULL)
{
	head=NULL;
}

else
{
	head = NULL;
	while (temp != NULL)
	{
		insertAtTail(temp->value);
		temp=temp->next;

	}
}
}

template <class T>
LinkedList<T>::~LinkedList()
{
  while (head!=NULL)
  {
  	deleteHead();
  }
}


template <class T>
void LinkedList<T>::insertAtHead(T item)
{
  ListItem<T> *temp= new ListItem<T>(item);
  if (head == NULL)
  {   temp->prev=NULL;
      temp->next=NULL;
      head=temp;
  }
  else if (head !=NULL)
  {
      ListItem<T> *temp2;
      temp2=head;
      temp->prev=NULL;
      temp->next=temp2;
      temp2->prev = temp;
      head=temp;
  }


}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{

  ListItem<T> *temp;
  temp=head;
  bool check=true;
  if (head==NULL)
  {
      insertAtHead(item);
      return;
  }

  else
{
  while (check==true)
   {
       if (temp-> next==NULL)
       {
           check=false;
       }
       else
       {
           temp=temp->next;
       }
    }
}
  ListItem<T> *temp2=new ListItem<T> (item);
  temp2->prev=temp;
  temp->next=temp2;
  temp2->next=NULL;
  return;

}


template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
  int len= length();
  if (len==0)
  {
    insertAtHead(toInsert);
    return;
  }
  else if (len==1)
  {
    ListItem<T> *temp=searchFor(afterWhat);
    if (temp != NULL)
    {
        insertAtTail(toInsert);
        return;
    }
    else
    {
        return;
    }
  }
  else
  {
      ListItem<T> *temp2=searchFor(afterWhat);
      if (temp2 != NULL)
    {
      if (temp2->next==NULL)
      {
          insertAtTail(toInsert);
      }
       else
       {ListItem<T> *temp= new ListItem<T> (toInsert);
   		ListItem<T> *temp3;
   		temp3=temp2->next;
   		temp2->next=temp;
   		temp->prev=temp2;
   		temp->next=temp3;
   		temp3->prev=temp;
   		return;
    }
    }
    else
    {
        return;
    }

  }
}




//
//template <class T>
//void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
//{
//   ListItem<T> *temp2;
//   temp2=head;
//   if (head==NULL)
//   {
//       insertAtHead(toInsert);
//   }
//
//   temp2=searchFor(afterWhat);
//
//   if (temp2==NULL)
//   {
//    return;
//   }
//   else if (temp2->next==NULL)
//   {
//       insertAtTail(toInsert);
//   }
//   else if (temp2->value==afterWhat)
//   {    ListItem<T> *temp= new ListItem<T> (toInsert);
//   		ListItem<T> *temp3;
//   		temp3=temp2->next;
//   		temp2->next=temp;
//   		temp->prev=temp2;
//   		temp->next=temp3;
//   		temp3->prev=temp;
//
//   }
//   else
//   {
//    return;
//   }
//}


template <class T>
void LinkedList<T>::insertSorted(T item)
{

   ListItem<T> *temp;
   temp=head;

   if (head==NULL)
   {
       insertAtHead(item);
       return;
   }
   ListItem<T> *tail=getTail();
   if (length()==1)
   {
       if (temp->value >= item)
       {
           insertAtHead(item);
           return;
       }
       else if (temp->value <= item)
       {
           insertAtTail(item);
           return;
       }
   }
   else if (tail->value <= item)
   {
       insertAtTail(item);
        return;
   }
   else if (temp->value >= item)
   {
       insertAtHead(item);
        return;
   }
   else
   {
        ListItem<T> *prevnode= head;
        temp=head->next;
        while (temp->next != NULL)
        {

           if (prevnode->value <= item && temp->value > item)
            {
                  break;
            }
            else
            {temp=temp->next;
            prevnode=prevnode->next;
            }



   }
   insertAfter(item,prevnode->value);
   return;
}
}









//
//template <class T>
//void LinkedList<T>::insertSorted(T item)
//{
//
//   ListItem<T> *temp;
//   temp=head;
//
//   if (head==NULL)
//   {
//       insertAtHead(item);
//       return;
//   }
//   ListItem<T> *tail=getTail();
//   if (length()==1)
//   {
//       if (temp->value >= item)
//       {
//           insertAtHead(item);
//           return;
//       }
//       else
//       {
//           insertAtTail(item);
//           return;
//       }
//   }
//   else if (tail->value <= item)
//   {
//       insertAtTail(item);
//        return;
//   }
//   else if (temp->value >= item)
//   {
//       insertAtHead(item);
//        return;
//   }
//   else
//   {
//        ListItem<T> *prevnode= head;
//        temp=temp->next;
//        while (temp->next != NULL)
//        {
//
//           if (prevnode->value <= item && temp->value > item)
//            {
//                  insertAfter(item,prevnode->value);
//                    return;
//                    break;
//            }
//            temp=temp->next;
//            prevnode=prevnode->next;
//
//
//   }
//
//   return;
//}
//}
//
//template <class T>
//void LinkedList<T>::insertSorted(T item)
//{
//
//   ListItem<T> *temp;
//   temp=head;
//
//   if (temp==NULL)
//   {
//   	insertAtHead(item);
//   }
//  else
//  {
//   ListItem <T> *ptr;
//   ptr=getTail();
//
//   if (head->value >= item)
//   {
//    insertAtHead(item);
//   }
//   else if (ptr->value <= item)
//   		{
//   			insertAtTail(item);
//   		}
//    else
//   		{
//   			ListItem<T> *prevnode= head;
//   			temp=temp->next;
//   			while (temp!= NULL)
//   			{
//               if (prevnode->value <item && temp->value >item)
//   				{
//   					insertAfter(item, prevnode->value);
//   					break;
//   				}
//   		       	temp=temp->next;
//   				prevnode=prevnode->next;
//   			}
//        }
//   	}
//}


template <class T>
ListItem<T>* LinkedList<T>::getHead() const
{
  return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    ListItem<T> *temp;
    temp=head;
    if (temp==NULL)
    {
    	return NULL;
    }
    else if (head->next==NULL)
        {
            temp=head->next;
        }
    else
    {
    while (temp->next!=NULL)
    {
        temp=temp->next;
    }
}
return temp;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
   ListItem<T> *temp;
   temp=head;
   if (head==NULL)
   {
   	return NULL;
   }

   else if (temp->value==item)
   {
   	return temp;
   }

  else
  {
  	while (temp != NULL)
  	{
  		if (temp->value==item)
  		{
  			return temp;
  		}
  		else
  		{
  			temp=temp->next;
  		}

  	}
  	return NULL;
  }
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
   ListItem<T> *temp=searchFor(item);
   if (temp==NULL)
   {

   	temp=NULL;
   	return;
   }
   else if (temp->prev==NULL)
   {
   	deleteHead();
   }
   else if (temp->next==NULL)
   	{
   		if (temp->prev==NULL)
   		{
   			deleteHead();
   		}
   		else
   		{
   			deleteTail();
   		}
   	}
   	else
   	{
   		ListItem<T> *nextnode;
   		nextnode=temp->next;
   		ListItem<T> *prevnode;
   		prevnode=temp->prev;
   		prevnode->next=nextnode;
   		nextnode->prev=prevnode;
   		delete temp;
   	}

}

template <class T>
void LinkedList<T>::deleteHead()
{
   if (head==NULL)
   {
   	head=NULL;
   	return;
   }
   else
   {
   	if (head->next==NULL)
   	{
     ListItem<T> *temp=head;
     head=NULL;
     delete temp;
     return;
   	}
   ListItem<T> *temp=head;
   head=head->next;
   head->prev=NULL;
   delete temp;
   }
}

template <class T>
void LinkedList<T>::deleteTail()
{

  ListItem<T> *temp=getTail();

  if (temp==NULL)
  {
  	temp=NULL;
  	return;
  }
  else
  {
  	if (temp->prev==NULL)
  	{
  		deleteHead();
  	}
  	else
  	{ ListItem<T> *temp2=temp;
  	temp=temp->prev;
  	temp->next=NULL;
  	delete temp2;


  }
}
}
template <class T>
int LinkedList<T>::length()
{
	ListItem <T> *temp;
	temp=head;
	int count =1;
	if (temp==NULL)
	{
		return 0;
	}
	else
	{
		while (temp->next !=NULL)
		{
			temp=temp->next;
			count++;
		}
		return count;
	}

}
template <class T>
void LinkedList<T>::reverse()
{

ListItem<T> *temp=head;
ListItem<T> *temp2=getTail();
ListItem<T> *temp3;

if (temp==NULL)
{
  return;
}
else if (temp==temp2)
{
  return;
}
else
{
  head=temp2;
  temp=head;

  while (temp!= NULL)
 {
  temp3=temp->next;
  temp->next=temp->prev;
  temp->prev=temp2;
  temp=temp->next;

 }
}



}

template <class T>
bool LinkedList<T>::isPalindrome()
{
ListItem<T> *first=head;
if (first==NULL)
{
  return false;
}
  else
  {
   ListItem<T> *end=getTail();
    int len=length();
    int check=5;
    if (len==1)
    {
      if (first==end)
      {
        return true;
      }
    }
    else
    {
      for (int i=0; i<len/2; i++)
    {
      if (first->value==end->value)
      {
        check==5;
        first=first->next;
        end=end->prev;
      }
      else
      {
        return false;
      }
    }
    if (check==5)
    {
      return true;
    }
  }
  }
}





template <class T>
void LinkedList<T>::parityArrangement()
{
//  ListItem<T> *odd=head;
//  if (odd==NULL)
//  {
//    return;
//  }
//  else if (length()==1)
//  {
//    return;
//  }
//  else
//  {
//    ListItem<T> *oddfirst=head;
//    ListItem<T> *even= odd->next;
//    ListItem<T> *connec=even;
//    bool check=true;
//    while (check==true)
//    {
//      odd->next=even->next;
//      odd=even->next;
//      odd->prev=even->prev;
//
//      if (odd->next==NULL)
//      {
//        even->next=NULL;
//        odd=connec;
//        check=false;
//      }
//      even->next=odd->next;
//      even=odd->next;
//      even->prev=odd->prev;
//      if (odd==NULL || even==NULL || (even->next)==NULL)
//      {
//        odd->next=connec;
//        check=false;
//      }
//  }
//  }
}














template <class T>
void LinkedList<T>::print()
{
	ListItem<T> * temp=head;
	if(temp==NULL)
	{
		cout <<"List is empty" << endl;
	}
	while(temp!=NULL)
	{
		cout << temp->value<< endl;
		temp = temp ->next;
	}

}

#endif
