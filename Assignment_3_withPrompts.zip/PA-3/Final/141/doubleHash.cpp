#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000;
    hashTable = new block * [tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
    count=0; 
}

HashD::~HashD(){
 
   delete [] hashTable;
}

unsigned long HashD :: hash1(string value){
     return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return polyHash(value);
}

void HashD::resizeTable(){
    block * temp[tableSize];
    for(int i=0; i<tableSize; i++)
    {
        temp[i]=hashTable[i];
    }
    long s = tableSize;
    tableSize =  tableSize *50;
    hashTable= new block * [tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
    count=0;
    for(int i=0; i<s; i++)
    {
        insert(temp[i]->value);
        
       
        delete temp[i];
    }
}

void HashD::insert(string value){
    if( count > 0.65*tableSize)
    {       
    	    //cout<<"yaaaaar"<<endl;
            resizeTable();
            
    }
    int ind = 0;
    unsigned long a = hash1(value)+ind*hash2(value);
    a= divCompression(a,tableSize);
    if( hashTable[a]==NULL)
    {
        hashTable[a] = new block(a,value);
        count++;
       // cout<<a<<endl;
    }
    else
    {  
      // int ct=0;
       while(hashTable[a] != NULL)
       {   
           ind++; 
           //ct++;
           a= hash1(value)+ind*hash2(value);
           a=divCompression(a,tableSize);

         /* if(ind >tableSize)

           {
           	 // resizeTable();
              //break;
           }*/
           if(a> tableSize)
           {
           	 a=a%tableSize;


           }
           
           cout<<a<<"     "<<ind<<" "<<count<<" "<<tableSize<<endl;
           //break;

       }
     
        hashTable[a] = new block(a,value);
        count++;
      

    }
}

void HashD::deleteWord(string value){
    return;
}

block* HashD::lookup(string value){
    return NULL;
}

#endif