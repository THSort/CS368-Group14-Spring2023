#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    hashTable = new LinkedList <string> [size];
    tableSize= size;
}
HashC::~HashC(){
    
   delete [] hashTable;
}

unsigned long HashC :: hash(string input){
   /* unsigned long l = bitHash(input);
    l=divCompression(l,tableSize);
    return l;*/
    return divCompression(bitHash(input),tableSize);

}

void HashC::insert(string word){
   unsigned long a = hash(word);
 // a= divCompression(a,tableSize);
  //if( hashTable[a]==NULL)
   
   	hashTable[a].insertAtHead(word);
   
   
}

ListItem<string>* HashC :: lookup(string word){
  unsigned long a = hash(word);
  //a= divCompression(a,tableSize);
  return hashTable[a].searchFor(word);
	//return NULL;
}

void HashC :: deleteWord(string word){
	unsigned long a = hash(word);
 // a= divCompression(a,tableSize);
  hashTable[a].deleteElement(word);
  //return;
}

#endif