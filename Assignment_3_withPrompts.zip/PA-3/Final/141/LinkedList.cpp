#ifndef __LIST_CPP
#define __LIST_CPP

#include<iostream>
using namespace std;
#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{ 
    
 	
  			 ListItem <T> * listptr = otherLinkedList.head;
  			 head=NULL;
  ListItem<T> * headptr= head;
  if(listptr==NULL)
  {
      headptr=NULL;
  }
  else
  {	
  	while( listptr != NULL)
  	{
  	 
  		insertAtTail(listptr->value);
  		listptr=listptr->next;

  	}
  }			
 
  
}

template <class T>
LinkedList<T>::~LinkedList()
{ 
	delete head;
  
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{ 
   ListItem<T> *NewN = new ListItem<T>(item);
   if(head==NULL)
   {
     head = NewN;
   }
   else
   {
    head->prev=NewN;
    NewN->next=head;
    head = NewN;
   }
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
               if(head==NULL)
              {
                   ListItem<T> * NewN = new ListItem<T>(item);
                   head= NewN;


              }

               else
              {
                   ListItem<T> * NewN = new ListItem<T>(item);
                   ListItem<T> * temp=head;
                   ListItem<T> * ptr=NULL;
                   while(temp!= NULL)
                   {  
                   	  ptr=temp;
                      temp= temp->next;


                   }
    // NewN->prev=temp->prev;
                   ptr->next= NewN;
                   NewN->prev=ptr;
              }


     



  
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{  
	
    if(head==NULL)
    {
    	//cout<<"ERROR"<<endl;
    }
    else
    {
      ListItem<T> * NewN= new ListItem<T>(toInsert);
      ListItem<T> *temp =head;
      ListItem<T> *ptr = NULL;
      while( temp != NULL)
      {
       if(temp->value == afterWhat )
       {  
       	  if(temp->next==NULL)
       	  {
       	  	insertAtTail(toInsert);
       	  }
       	  else
       	  {	
       	   ptr=temp;
           ptr=ptr->next;
           temp->next=NewN;
           NewN->prev=temp;
           NewN->next=ptr;
           ptr->prev=NewN;
          }


       }
         temp=temp->next;



      }
    

     }


}

template <class T>
void LinkedList<T>::insertSorted(T item)
{  
	 if(head==NULL)
	 {
         insertAtHead(item);
	 }	
	 else
	 {
          ListItem<T> * ptr = head;
          ListItem<T> * tail = getTail();
          if((item > ptr->value) && (item <  tail->value)  )
          {
          		 while( ptr!= NULL)
     			 {
      	            ptr= ptr->next;
      				if( item <= ptr-> value)
      				{
          
        			   ListItem<T> * NewN = new ListItem<T>(item);
        			   ListItem<T> * point = ptr;
        			   point= point->prev;
        			   point->next=NewN;
        			   NewN->prev = point;
        			   ptr->prev =NewN;
        			   NewN->next = ptr;
        			   
        			   

        			  break;


      				}
      				//ptr= ptr->next;

      



      			}	
          }
          else
          {
          	ListItem<T> * temp =head;
          	if(item <= temp->value)
          	{
          		insertAtHead(item);
          	}
          	else
          	{
          		insertAtTail(item);
          	}	



          }	


	 }	


}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	if(head==NULL)
	{
		return NULL;
	}
	else
	{
      return head;

    }  
}    

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{  
	if(head==NULL)
	{
		return NULL;
	}
	else
	{

	ListItem<T> * ptr = head;
	while(ptr->next != NULL)
	{

      ptr = ptr->next;


	}
	return ptr;

	}	

}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
   if(head==NULL)
   {

     return NULL;

   }
   else
   {

     ListItem<T> * ptr = head;
     while( ptr != NULL)
     {
        
       if(ptr->value== item)
       {
       	return ptr;
       }
       ptr= ptr->next;
       


      




     }
     return NULL;
     





   }

}

template <class T>
void LinkedList<T>::deleteElement(T item)
{ 
	if(head==NULL)
	{

	}	
    else
    {
         //int l= length();

         if( head->value == item)
         {
            deleteHead();
         }	
         else
         {
            ListItem<T> * search= searchFor(item);
            if(search != NULL)
            {
               ListItem<T> * tail = getTail();
               if( search != tail)
               {
               	 ListItem<T> * temp = search->prev;
               	 ListItem<T> * ptr = search->next;
               	 temp->next = ptr;
               	 ptr->prev = temp;
               	 delete search;

               }
               else
               {
                 deleteTail();

               }

            }
            else
            {





            }	
              

         }	





    }
}

template <class T>
void LinkedList<T>::deleteHead()
{ 
	if(head==NULL)
	{

	}
	else
	{ 
		int L= length();
		if(L==1)
		{ 
			ListItem<T> * ptr = head;
			head=NULL;
			delete ptr;

		}
		else
		{	
		 ListItem<T> * ptr = head;
		 head= head->next;
		 head->prev= NULL;
		 delete ptr;
		} 
	}	

}

template <class T>
void LinkedList<T>::deleteTail()
{
    if(head==NULL)
    {

    }
    else
    { 
      int L= length();
      if(L==1)
      {
      	ListItem<T> * ptr = head;
			head=NULL;
			delete ptr;
      }	
      else
      { 
      	ListItem<T> * ptr=head;
      	while(ptr->next != NULL)
      	{
      		ptr = ptr->next;
      	}
      	ListItem<T> * temp;
      	temp= ptr->prev;
      	temp->next=NULL;
      	delete ptr;



      }	

    }	
}

template <class T>
int LinkedList<T>::length()
{
	int l=0;
   if(head==NULL)
   {
   
   	return l;
   }
   else
   {
   	ListItem<T> * ptr=head;
   	
    while(ptr != NULL)
    {
      ptr=ptr->next;
      l++;

    }
     return l;
   }
}

template <class T>
void LinkedList<T>::reverse()
{   
	int size = length();
    		ListItem<T> * ptr = head;
    		T nodes[size];
    		for( int i=0; i<size; i++)
    		{
    			nodes[i]=ptr->value;
    			ptr=ptr->next;
    		}
    		for( int i=0; i<size; i++)
    		{
    			deleteHead();
    		}
    		for( int i=0; i<size; i++)
    		{
    			insertAtHead(nodes[i]);
    		}
}
template <class T>
bool LinkedList<T>::isPalindrome()
{ 
  if(head==NULL)
  {

  }
  else
  {  
  ListItem<T> * ptr = head;
  ListItem<T> * tail = getTail();
  while( ptr != NULL)
  {
    if(ptr->value == tail->value)
    { 
      ptr=ptr->next;
      tail=tail->prev;

    }
    else
    {
      return false;
    }
  }
  return true;
  }
}

template <class T>
void LinkedList<T>::parityArrangement()
{
			int size = length();
    		ListItem<T> * ptr = head;
    		ListItem<T> * temp = head;
    		T nodes[size];
    		int i=0;
    		int count=0;
    		while( ptr != NULL)
    		{
    			nodes[i]=ptr->value;
    			ptr=ptr->next;
    			ptr=ptr->next;
    			i=i+1;
    			count++;
    		}
    		//i=0;
    		while( temp != NULL)
    		{   
    			temp=temp->next;
                nodes[count]=temp->value;
    			temp=temp->next;
    			count++;

    		}	
    		for( int i=0; i<size; i++)
    		{
    			deleteHead();
    		}
    		for( int i=0; i<size; i++)
    		{
    			insertAtTail(nodes[i]);
    		}
}

#endif
