#include<iostream>
#include <string>
#include<cmath>
using namespace std;
unsigned long bitHash(string value){
	//int bitwise_hash = 0;
    unsigned long bitwise_hash = 0;
	int l = value.length();
	for(int i=0; i<l; i++)
	{
		bitwise_hash= (bitwise_hash<< 5)+(bitwise_hash>>2)+value[i];
	}
	return bitwise_hash;
}
unsigned long polyHash(string value,int a = 5){
	
	unsigned long poly_hash = 0;
	int l = value.length();
	for(int i=0; i<l; i++)
	{
		poly_hash = poly_hash+ pow(a,l-(i+1))*value[i];
	}
	return poly_hash;
}
unsigned long divCompression(unsigned long hash,long size){
	unsigned long div = hash % size;
    return div;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
	unsigned long mad = (a*hash + m) % size;

    return mad; 
}
int main()
{
	string b = "hello";
	//unsigned long q = polyHash(b);
	unsigned long q = polyHash(b);

	cout<<q<<endl;
	cout<<"After==="<<endl;
	//q=madCompression(q,663197);
	cout<<q<<endl;

    














	return 0;
}