#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block * [tableSize]();
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
    count=0;

}

HashL::~HashL(){
    delete [] hashTable;
}

unsigned long HashL :: hash(string value){

    return divCompression(bitHash(value),tableSize);
}

void HashL::resizeTable(){
    block * temp[tableSize];
    for(int i=0; i<tableSize; i++)
    {
        temp[i]=hashTable[i];
    }
    long s = tableSize;
    tableSize =  tableSize *50;
    hashTable= new block * [tableSize];
    for(int i=0; i<tableSize; i++)
    {
        hashTable[i]=NULL;
    }
    count=0;
    for(int i=0; i<s; i++)
    {
        insert(temp[i]->value);
        delete temp[i];
    }
    //return;
}

void HashL::insert(string value){

    //unsigned long a = hash(value);
    if((count/tableSize)>0.7)
    {
            resizeTable();
            
    }
    unsigned long a = hash(value);

    if(hashTable[a]== NULL)
    {
        hashTable[a] = new block(a,value);
        count++;
    }
    else
    {
        while(hashTable[a] != NULL)
        {  
            a++;
            if(a>tableSize-1)
            {
                a= 0;
            }
             //a++;
        }
        hashTable[a] = new block(a,value);
        count++;
        
    }
    //return;
}

void HashL::deleteWord(string value){
    block * temp = lookup(value);
    if(temp==NULL)
    {

    }
    else
    {
        temp->key =-1;
    }


    return;
}
block* HashL::lookup(string value){
    unsigned long a = hash(value);
    if(hashTable[a]==NULL)
    { 
           
            return hashTable[a];
        
    }
    else
    {   if(hashTable[a]->key==-1 && hashTable[a]->value == value)
        {
            return NULL;
        }
        else if(hashTable[a]->value == value)
        {
            return hashTable[a];
        }
        else
        {
            int ct=0;
            int b=0;
            while( hashTable[a]->value != value)
            {
                a++;
                if(a>tableSize-1)
                {
                    a=0;
                }
                ct++;
                if(ct>tableSize)
                {
                    b=1;
                    break;
                }
            }
            if(b==0)
            {
              if(hashTable[a]->value ==value && hashTable[a]->key == -1)
              {
                return NULL;
              }
              else
              {
                return hashTable[a];
              }
            }
            else
            {
              return NULL;
            }
        }
    }
}
#endif
