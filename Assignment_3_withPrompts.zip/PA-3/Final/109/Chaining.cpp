#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    tableSize = size;
    hashTable = new LinkedList <string> [tableSize];

}
HashC::~HashC(){
    for (int i=0 ; i<tableSize ; i++)
    {
        hashTable[i].~LinkedList();
    }
    delete [] hashTable;
    hashTable = NULL;


}

unsigned long HashC :: hash(string input){

    return bitHash(input);
}

void HashC::insert(string word){
    unsigned long index = hash(word);
    hashTable[index].insertAtHead(word);
  return;
}

ListItem<string>* HashC :: lookup(string word){
    unsigned long ind = hash(word);
    return hashTable[ind].searchFor(word);

}

void HashC :: deleteWord(string word){
    unsigned long i = hash(word);
    hashTable[i].deleteElement(word);

  return;
}

#endif


