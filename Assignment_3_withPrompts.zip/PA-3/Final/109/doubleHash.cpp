//I Took help from my friend for lookup in this part..
#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block* [tableSize]();
    count=0;
}

HashD::~HashD(){
    for (int i=0;i<tableSize; i++)
    {
        delete hashTable[i];
    }
    delete[] hashTable;

}

unsigned long HashD :: hash1(string value){
    return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return polyHash(value, 39);
}

void HashD::resizeTable(){
    if(count >= tableSize/2)
    {
        int old_size=tableSize;
        tableSize=tableSize*10;
        count = 0;
        block ** dup = hashTable;
        hashTable = new block*[tableSize]();
        for(int i=0 ; i<old_size;i++)
        {
            if(dup[i]!= NULL)
            {
                if(dup[i]->key != -1)
                {
                    insert(dup[i]->value);
                }
            }
        }


}
    return;
}

void HashD::insert(string value){
    int rand=1;
    unsigned long h1=hash1(value);
    unsigned long h2=hash2(value);
    unsigned long ind = h1 % tableSize;
    resizeTable() ; //checks before insertion
    block* entry = new block (h1,value);
    if(hashTable[ind]==NULL || hashTable[ind]->key == -1)
    {
        hashTable[ind]=entry;
        count++;
    }
    while (hashTable[ind] != NULL && hashTable[ind]->key != -1)
    {
        ind=(h1+(rand*h2)) % tableSize;
        rand++;

    }
        if(hashTable[ind] == NULL || hashTable[ind]->key == -1)
        {
        hashTable[ind] = entry;
        count++;
        }

    return;
}

void HashD::deleteWord(string value){
     block* desired = lookup(value);
    desired->key=-1;
    desired->value="";
    count--;
    return;
}

block* HashD::lookup(string value){
    unsigned long h1 = hash1(value);
    unsigned long h2 = hash2(value);
    unsigned long index = h1%tableSize;
    int rand = 1;

    while(hashTable[index] != NULL && hashTable[index]->value != value)
    {
        index=(h1+(rand*h2)) % tableSize;
        rand++;

    }
        if(hashTable[index]->value == value)
        {
            return hashTable[index];
        }

    return NULL;

}

#endif
