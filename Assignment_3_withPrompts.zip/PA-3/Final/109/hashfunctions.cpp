#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>

// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a){
    unsigned long res=0;
    int power= value.length();
    for(int i=0; i<power; i++)
    {
        if(i<(power-1))
        {res=(res+value[i])*(a);}
        else
        {res=res+value[i];}
    }
    return res;

}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
    unsigned long bitwise_hash = 0;
    int loop=value.length();
    for(int i=0;i<loop;i++)
    {
        bitwise_hash ^= (bitwise_hash << 5) + (bitwise_hash >> 2) + value[i];
    }

	return bitwise_hash;
}
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    unsigned long div = hash % size;

    return div;
}
// multiplication addition and division compression.
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    unsigned long mad = (a*hash + m) % size;
    return mad;
}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
