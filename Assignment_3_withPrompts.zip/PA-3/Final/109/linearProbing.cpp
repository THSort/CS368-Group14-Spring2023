#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count = 0;
    hashTable = new block* [tableSize]();

}

HashL::~HashL(){
    for(int i=0;i<tableSize;i++)
    {
        delete hashTable[i];
    }
    delete[] hashTable;

}

unsigned long HashL :: hash(string value){
    return bitHash(value);
}

void HashL::resizeTable(){
    if(count >= tableSize/2)
    {
        int old_size=tableSize;
        tableSize=tableSize*10;
        count = 0;
        block ** dup = hashTable;
        hashTable = new block*[tableSize]();
        for(int i=0 ; i<old_size;i++)
        {
            if(dup[i]!= NULL)
            {
                if(dup[i]->key != -1)
                {
                    insert(dup[i]->value);
                }
            }
        }


}
    return;
}

void HashL::insert(string value){
    resizeTable(); //to check before insertion so that it makes everything smooth...
    unsigned long i =hash(value);
    block* p = new block(i,value);
    int ind = madCompression(i,tableSize,1993,1637);
    
    if(hashTable[ind] == NULL || hashTable[ind]->key == -1)
        {
        hashTable[ind] = p;
        count++;
        }
        else {
    while (hashTable[ind] != NULL && hashTable[ind]->key != -1)
    {
        ind++;
        ind=ind%tableSize;
    }
        if(hashTable[ind] == NULL || hashTable[ind]->key == -1)
        {
        hashTable[ind] = p;
        count++;
        }
    }

    return;
}

void HashL::deleteWord(string value){
    block* desired = lookup(value);
    desired->key=-1;
    desired->value="ThisValueGotDeleted";
    count--;
    return;
}
block* HashL::lookup(string value){
    unsigned long h = hash(value);
    unsigned long index = divCompression(h,tableSize);
    //for 1st index
    if(hashTable[index] == NULL)
        {return NULL;}
    else if (hashTable[index]->value==value)
        {return hashTable[index];}
    else {

    while(hashTable[index] != NULL && hashTable[index]->value != value)
    {
        index++;
        index= index % tableSize;
    }
        if(hashTable[index]->value == value)
        {
            return hashTable[index];
        }
        else 
            {return NULL;}
    }

    
}
#endif
