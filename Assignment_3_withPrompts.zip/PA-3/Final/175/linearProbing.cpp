#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    count=0;
    hashTable=new block*[tableSize]();
    
}

HashL::~HashL(){

	for(int i=0;i<tableSize;i++)
	{
		delete hashTable[i];
	}
	delete[] hashTable;
    
}

unsigned long HashL :: hash(string value){
	unsigned long hashvalue=bitHash(value);
    return hashvalue;
}

void HashL::resizeTable(){

	if(count>=tableSize/2)
	{
		count=0;
		int size=tableSize;
		tableSize=tableSize*15;
		block** temp=hashTable;

		hashTable=new block*[tableSize]();
		for(int i=0;i<size;i++)
		{
			if(temp[i]!=NULL)
			{
				if(temp[i]->key!=-5)
				insert(temp[i]->value);
			}
		}

	}

	
    return;
}

void HashL::insert(string value){
	resizeTable();
	unsigned long hashvalue=hash(value);
	block* temp=new block(hashvalue,value);
	int index=madCompression(hashvalue,tableSize,1993,1637);
	//cout<<index;
	//std::cout<<"add:"<<endl;
	if(hashTable[index]==NULL||hashTable[index]->key==-5)
	{
		hashTable[index]=temp;
		count++;
	}
	else
	{
		//std::cout<<"loop:"<<endl;
		while(hashTable[index]!=NULL&&hashTable[index]->key!=-5)
		{
			index++;
			index=index%tableSize;
		}
		if(hashTable[index]==NULL||hashTable[index]->key==-5)
		{
			hashTable[index]=temp;
			count++;
		}
	}
	
	
	

    return;
}

void HashL::deleteWord(string value){
	//std::cout<<"a ";
	block* temp=lookup(value);
	//std::cout<<"b"<<std::endl;
	temp->value="sfghjjhj";
	temp->key=-5;
	count--;


    return;
}
block* HashL::lookup(string value){
	unsigned long hashvalue=hash(value);
	int index=madCompression(hashvalue,tableSize,1993,1637);

	if(hashTable[index]==NULL)
	{
		return NULL;

	}
	else
	{
		if(hashTable[index]->value==value)
		{
			return hashTable[index];
		}
	}
	while(hashTable[index]!=NULL&&hashTable[index]->value!=value)
	{
		index++;
		index=index%tableSize;
	}
	//std::cout<<std::endl<<index;
	if(hashTable[index]==NULL)
	{
		return NULL;
	}
	else
	{
		if(hashTable[index]->value==value)
		{
			return hashTable[index];
		}
	}
	
	
		//std::cout<<"not found";
		return NULL;


    
}

void HashL::printTable()
{
	for(int i=0;i<tableSize;i++)
	{
		if(hashTable[i]!=NULL&&hashTable[i]->key!=-5)
		{
			std::cout<<hashTable[i]->key<< " " <<hashTable[i]->value<<std::endl;
		}
	}
}



#endif
