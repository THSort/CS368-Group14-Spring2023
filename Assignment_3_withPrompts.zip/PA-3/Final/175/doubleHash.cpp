#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    count=0;
    hashTable=new block*[tableSize]();
}

HashD::~HashD(){
	for(int i=0;i<tableSize;i++)
	{
		delete hashTable[i];
	}
	delete[] hashTable;

}

unsigned long HashD :: hash1(string value){
	unsigned long hashvalue=cyclic_shift(value,5);
    return hashvalue;
    
}

unsigned long HashD :: hash2(string value){
	unsigned long hashvalue=polyHash(value,5);
    return hashvalue;
    
}

void HashD::resizeTable(){
	if(count>=tableSize/2)
	{
		count=0;
		int size=tableSize;
		tableSize=tableSize*15;
		block** temp=hashTable;
		hashTable=new block*[tableSize]();
		for(int i=0;i<size;i++)
		{
			if(temp[i]!=NULL)
			{
				if(temp[i]->key!=-5)
				insert(temp[i]->value);
			}
		}

	}
    return;
}

void HashD::insert(string value){
	resizeTable();
	int i=1;
	unsigned long index,hsh1,hsh2;
	hsh1=hash1(value);
	hsh2=hash2(value);
	index=hsh1%tableSize;
	block* temp=new block(hsh1,value);
	if(hashTable[index]==NULL||hashTable[index]->key==-5)
	{
		hashTable[index]=temp;
		count++;
	}
	else
	{
		while(hashTable[index]!=NULL)
		{
			index=(hsh1+(i*hsh2))%tableSize;
			i++;
		}
		//std::cout<<index<<std::endl;
		
		if(hashTable[index]==NULL||hashTable[index]->key==-5)
		{
			hashTable[index]=temp;
			count++;
		}
	}
	
    return;
}

void HashD::deleteWord(string value){
	/*int i=1;
	unsigned long index,hsh1,hsh2;
	hsh1=hash1(value);
	hsh2=hash2(value);
	index=hsh1%tableSize;*/
	block* temp=lookup(value);
	temp->value="dsgfhsdfjks";
	temp->key=-5;
	count--;
	/*if(hashTable[index]!=NULL)
	{
		if(hashTable[index]->value==value)
		{
			hashTable[index]->key=-5;
			hashTable[index]->value="shdahda";
			count--;
		}
		
	}
	else
	{
		while(hashTable[index]->value!=value)
		{
			index=(hsh1+(i*hsh2))%tableSize;
			i++;
		}
		if(hashTable[index]!=NULL)
		{
			if(hashTable[index]->value==value)
			{
				hashTable[index]->key=-5;
				hashTable[index]->value="shdahda";
				count--;
			}
		}

	}*/
	


    return;
}

block* HashD::lookup(string value){
	int i=1;
	unsigned long index,hsh1,hsh2;
	hsh1=hash1(value);
	hsh2=hash2(value);
	index=hsh1%tableSize;
	if(hashTable[index]==NULL)
    {
    	return NULL;
    }
    else
    {
    	if(hashTable[index]->value==value)
    	{
    		return hashTable[index];
    	}
    	
    }
    while(hashTable[index]!=NULL&&hashTable[index]->value!=value)
	{
		index=(hsh1+(i*hsh2))%tableSize;
		i++;
	}
	if(hashTable[index]==NULL)
	return NULL;
    if(hashTable[index]->value==value)
    {
    	return hashTable[index];
    }
    return NULL;
	
}

unsigned long HashD::cyclic_shift(string given,int length)
{	
	unsigned long hash=0;
	for(int i=0;i<length;i++)
	{
		hash=(hash<<5)|(hash>>27);
		hash=hash+(unsigned int) given[i];
	}
	return hash;

}



void HashD::printTable()
{
	for(int i=0;i<tableSize;i++)
	{
		if(hashTable[i]!=NULL)
		{
			std::cout<<hashTable[i]->key<< " " <<hashTable[i]->value<<std::endl;
		}
	}
}


#endif