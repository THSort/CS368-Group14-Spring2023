#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
	hashTable=new LinkedList<string>[size];
	tableSize=size; 
    
}
HashC::~HashC(){
	for(int i=0;i<tableSize;i++)
	{
		hashTable[index].~LinkedList();
	}
	delete[] hashTable;

}

unsigned long HashC :: hash(string input){
	unsigned long hashvalue;
	hashvalue=bitHash(input);
  return hashvalue;  
}

void HashC::insert(string word){
	unsigned long hashvalue,index;
	hashvalue=hash(word);
	index=madCompression(hashvalue,tableSize,1993,1637);
	hashTable[index].insertAtHead(word);
  return;
}

ListItem<string>* HashC :: lookup(string word){
	
	
		unsigned long hashvalue,index;
		hashvalue=hash(word);
		index=madCompression(hashvalue,tableSize,1993,1637);
		ListItem<string>* temp;
		temp=hashTable[index].searchFor(word);
		/*temp=hashTable[index].getHead();
		while(temp->value!=word&&temp->next!=NULL)
		{
			temp=temp->next;
		}
		if(temp->value==word)
		{
			return temp;
		}
		else
		{
			return NULL;
		}*/
	  	return temp;

	
	
}

void HashC :: deleteWord(string word){
	unsigned long hashvalue,index;
	hashvalue=hash(word);
	index=madCompression(hashvalue,tableSize,1993,1637);
	hashTable[index].deleteElement(word);
	/*ListItem<string>* temp=lookup(word);
	if(temp!=NULL)
	{
		if(temp->next==NULL)
		{
			(temp->prev)->next==NULL;
			delete temp;
		}
		else
		{
			(temp->prev)->next=temp->next;
			(temp->next)->prev=temp->prev;
			delete temp;
		}
	}
	*/


  return;
}

#endif