#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <cmath>
#include <time.h>
#include <cstdlib>
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
    unsigned long sum=0;
    int size = value.length();
    for(int i=0; i<size; i++){
        sum=a*sum+(int)value[i];
    }


	return sum;
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
    unsigned long sum=0;
    int size= value.length();
    for(int i=0; i<size; i++){
            sum^=(sum<<5)+(sum>>3)+(int)value[i];
    }

	return sum;
}

unsigned long h2(std::string value){
    unsigned long sum=0;
    int size= value.length();
    for(int i=0; i<size; i++){
            sum^=(sum<<5)+(sum>>3)+(int)value[i];
    }

	if(sum%2){
        return sum;
	}
	else{
        return (sum+1);
	}
}





// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){
    return (hash%size)
     ;
}
// multiplication addition and division compression.
unsigned long madCompression(unsigned long hash,long size,int m = 1900,int a = 16307){
    return ((a*hash+m)%981439)%size;


}
// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
