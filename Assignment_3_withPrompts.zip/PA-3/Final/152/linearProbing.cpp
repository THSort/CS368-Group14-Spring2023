#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP
#include <climits>
#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable=new block*[tableSize];
    for(int i=0; i<tableSize; i++){
        hashTable[i]=new block(INT_MAX);
    }
    count=0;
    counter=0;
    probe_length=0;
    ///0.72
    ///0.45 for factor 2
    ///0.34 for factor 2
    ///0.39 for factor 3
    ///0.76 for factor 4
    ///0.47, 49 for 5
    critical=0.45;

}

HashL::~HashL(){

for(int i=0; i<tableSize; i++){
    delete hashTable[i];
}

}

unsigned long HashL :: hash(string value){

    return divCompression(bitHash(value), tableSize);

}

void HashL::resizeTable(){
    int num=(tableSize);
    int sise=tableSize+tableSize;
    block**temp=new block*[sise];

    for(int i=0; i<sise; i++){
        temp[i]=new block(INT_MAX);
    }
     tableSize=sise;

    for(int i=0; i<num; i++){
        if(hashTable[i]->key!=INT_MAX){

        rehash(hashTable[i]->value, temp);
        delete hashTable[i];
        }
        }



delete hashTable;

hashTable=temp;


}

void HashL::rehash( string bro, block** nnn){

unsigned long ind=hash(bro);

if(nnn[ind]->key==INT_MAX){
    nnn[ind]->key=ind;
    nnn[ind]->value=bro;

}
else{

    unsigned long broo=nnn[ind]->key;

    int hey=0;
    while(broo!=INT_MAX){
        ind++;
        hey++;
        broo=nnn[ind%tableSize]->key;
    }



        nnn[ind%tableSize]->key=ind%tableSize;
    nnn[ind%tableSize]->value=bro;


}

}


void HashL::insert(string value){


    unsigned long bro=hash(value);
    if(hashTable[bro]->key==INT_MAX){
        hashTable[bro]->key=bro;
        hashTable[bro]->value=value;
    }
    else{
        int hey=0;
        unsigned long yup=hashTable[bro]->key;
        while(yup!=INT_MAX){
            bro++;
            hey++;
            yup=hashTable[bro%tableSize]->key;
        }
         probe_length=hey;
        hashTable[bro%tableSize]->key=bro%tableSize;
        hashTable[bro%tableSize]->value=value;

    }
    count++;
    counter++;
    load=counter/tableSize;

    if(load>=critical){
         ///cout<<"load = "<<load<<endl;
        resizeTable();

    }



    return;
}

void HashL::deleteWord(string value){
     block* temp=lookup(value);

     if(temp!=NULL){

     temp->key=INT_MAX;

     count--;
     counter--;
     load=counter/tableSize;

     }



}
/*
void HashL::smallerize(){

    int num_new = 2*counter;
    int num_old=tableSize;
    block** temp=new block*[num_new];

    for(int i=0; i<num_new; i++){
        temp[i]=new block(INT_MAX);
    }
    tableSize=num_new;
    for(int i=0; i<num_old; i++){
        if(hashTable[i]->key!=INT_MAX){

            rehash(hashTable[i]->value, temp);
        }
    }

    delete hashTable;
    hashTable=temp;

}


*/



block* HashL::lookup(string value){
    unsigned long hasher=hash(value);
    string temp= hashTable[hasher]->value;
    if(hashTable[hasher]->key!=INT_MAX){
    int hey=0;
    while(temp!=value){
        hasher++;
        hey++;
        temp=hashTable[hasher%tableSize]->value;
        if(hashTable[hasher%tableSize]->key==INT_MAX){
            return NULL;
        }
    }
    probe_length=hey;
    return hashTable[hasher%tableSize];
    }
    else{
        return NULL;
    }
}
#endif
