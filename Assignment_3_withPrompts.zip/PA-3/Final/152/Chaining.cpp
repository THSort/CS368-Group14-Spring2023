#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp" //UN-Comment this later

HashC::HashC(int size){
 tableSize=size;
 hashTable=new LinkedList<string>[tableSize];
 load=0;
 counter=0;
 critical=0.5;
 max_hash=0;

}
/*
void HashC::Resize(){

int old=tableSize;
tableSize=tableSize<<1;
LinkedList<string>* temp=new LinkedList<string>[tableSize];




}
*/

HashC::~HashC(){
    delete hashTable;

}

unsigned long HashC :: hash(string input){

   unsigned long sum=0;
    int size= input.length();
    for(int i=0; i<size; i++){
            sum^=(sum<<5)+(sum>>3)+(int)input[i];
    }

	return sum%tableSize;



}

void HashC::insert(string word){
    unsigned long hashV=hash(word);
    if(hashV>max_hash){max_hash=hashV;}
   hashTable[(hash(word))].insertAtHead(word);
   counter++;
   load=counter/tableSize;

   /*if(load>=critical){
         cout<<"attempting a resize"<<endl;
        ///cout<<"load = "<<load<<endl;
        Resize();
   }
*/

}

ListItem<string>* HashC :: lookup(string word){

    ListItem<string>* temp=hashTable[hash(word)].getHead();
while(temp!=NULL){
    if((temp->value)==word){
        break;
    }
    temp=temp->next;
}
return temp;







}

void HashC :: deleteWord(string word){
   hashTable[hash(word)].deleteElement(word);
   counter--;
   if(this->lookup(word)!=NULL){
    deleteWord(word);
   }

}

#endif
