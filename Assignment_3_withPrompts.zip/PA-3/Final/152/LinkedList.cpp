#ifndef __LIST_CPP
#define __LIST_CPP
#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{

head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{

head=NULL;
ListItem<T>* temp=otherLinkedList.head;
while(temp!=NULL){
        this->insertAtTail(temp->value);
        temp=temp->next;
}


}

template <class T>
LinkedList<T>::~LinkedList()
{

while(head!=0){
    this->deleteHead();
}




}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
ListItem<T>* temp=new ListItem<T>;
temp->value=item;



if(head==NULL){
    temp->prev=NULL;
    temp->next=NULL;
    head=temp;
}
else{

    temp->prev=NULL;
    temp->next=head;
    head->prev=temp;
    head=temp;
}

}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{

int num=this->length();

if(num==0){
    this->insertAtHead(item);

}
else{


    ListItem<T>* temp=new ListItem<T>;
    ListItem<T>* temp2=this->getTail();
    temp->value=item;
    temp->next=NULL;
    temp->prev=temp2;
    temp2->next=temp;


}


}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{

ListItem<T>* temp=this->searchFor(afterWhat);
if(temp!=NULL){
    ListItem<T>* temp2=new ListItem<T>;
    temp2->value=toInsert;
    temp2->prev=temp;
    temp2->next=temp->next;
    temp->next=temp2;
}


}

template <class T>
void LinkedList<T>::insertSorted(T item)
{


ListItem<T>* temp=head;
if(head!=NULL){
    while(temp!=NULL){
        if(item<=temp->value){
            break;
        }
        else{temp=temp->next;}
    }



if(temp==NULL){
    this->insertAtTail(item);
}
else{
    if(temp->prev==NULL){

        this->insertAtHead(item);
    }
    else{

        ListItem<T>* hi=new ListItem<T>;
        hi->value=item;
        hi->next=temp;
        hi->prev=temp->prev;
        (temp->prev)->next=hi;
        temp->prev=hi;


    }

}




}
else{
    this->insertAtHead(item);
}


}

template <class T>
ListItem<T>* LinkedList<T>::getHead() const
{

return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail() const
{
int num=this->length();
if(num==0){
    return NULL;
}
else{
    ListItem<T>* temp=head;
    while(temp->next!=NULL){

        temp=temp->next;
    }

    return temp;
}





}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item) const
{

ListItem<T>* temp=head;
while(temp!=NULL){
    if((temp->value)==item){
        break;
    }
    temp=temp->next;
}
return temp;


}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
int num=this->length();
if(num!=0){
ListItem<T>* temp=head;

while(temp!=NULL){
    if(temp->value==item){
        break;
    }
    else{
        temp=temp->next;
    }
}

if(temp==head){
    this->deleteHead();
}
else if(temp==this->getTail()){
    this->deleteTail();
}
else if(temp==NULL){
    ///do nothing
}
else{
    ListItem<T>* forw=temp->next;
    ListItem<T>* backk=temp->prev;
    backk->next=forw;
    forw->prev=backk;
    delete temp;
}


}

}

template <class T>
void LinkedList<T>::deleteHead()
{

if(this->length()!=0){
    if(this->length()==1){
        delete head;
        head=NULL;
    }
    else{
        ListItem<T>* temp=head;
        (temp->next)->prev=NULL;
        head=temp->next;
        delete temp;
    }
}


}

template <class T>
void LinkedList<T>::deleteTail()
{
if(this->length()!=0){
    if(this->length()==1){
        delete head;
        head=NULL;
    }
    else{
        ListItem<T>* temp=this->getTail();
        (temp->prev)->next=NULL;
        delete temp;
    }
}



}

template <class T>
int LinkedList<T>::length() const
{

if(head==NULL){

    return 0;
}
else{

 int countt=0;
 ListItem<T>* temp=head;
 while(temp!=NULL){
    temp=temp->next;
    countt++;
 }

 return countt;




}

}

template <class T>
void LinkedList<T>::reverse()
{
if(head!=NULL){
    ListItem<T>* temp=head;
    ListItem<T>*temp2;

    head=this->getTail();

    while(temp!=NULL){
        temp2=temp->next;
        temp->next=temp->prev;
        temp->prev=temp2;
        temp=temp2;
    }





}





}

template<class T>
void LinkedList<T>::display(){
cout<<"display "<<endl;
ListItem<T>* temp=head;
while(temp!=NULL){
    cout<<temp->value<<endl;
    temp=temp->next;

}


}


template <class T>
void LinkedList<T>::parityArrangement()
{
int num=this->length();
if(num%2==0){

   ListItem<T>* temp=head;
   ListItem<T>* tail=this->getTail();
    ListItem<T>* LastOdd;
    ListItem<T>* LastEven;
    ListItem<T>* temp2;
    ListItem<T>* FirstEven=head->next;

    while(1){

        if(temp->next->next==NULL){
            temp->next=FirstEven;
            LastOdd=temp;
            break;
        }

        temp2=temp->next;
        temp->next=temp2->next;
        temp=temp2;
    }

    temp=tail;

    while(1){

        if(temp->prev->prev==NULL){
            temp->prev=LastOdd; break;
        }
        temp2=temp->prev;
        temp->prev=temp2->prev;
        temp=temp2;




    }





}
else{

    ListItem<T>* temp=head;
    ListItem<T>* tail=this->getTail();
    ListItem<T>* FirstEven=head->next;
    ListItem<T>* temp2;
    ListItem<T>* LastOdd;

    while(1){

        if(temp->next==NULL){
            LastOdd=temp;
            temp->next=FirstEven;
            break;
        }

        temp2=temp->next;
        temp->next=temp2->next;
        temp=temp2;

    }

    temp=tail;
    while(1){
        if(temp->prev->prev==NULL){
            temp->prev=LastOdd; break;
        }
        temp2=temp->prev;
        temp->prev=temp2->prev;
        temp=temp2;
    }








}









}


template <class T>
bool LinkedList<T>::isPalindrome(){
if(this->length()!=0){
ListItem<T>* aage=head;
ListItem<T>* peeche=this->getTail();
bool hi=true;
while(aage!=NULL||peeche!=NULL){
    if(aage->value!=peeche->value){
        hi=false;
        break;
    }
    else{
        aage=aage->next;
        peeche=peeche->prev;
    }

}
return hi;
}
else
{
   return false;

}
}









#endif
