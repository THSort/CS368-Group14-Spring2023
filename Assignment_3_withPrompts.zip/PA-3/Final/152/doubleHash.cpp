#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include <climits>
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
tableSize=10000;
hashTable=new block*[tableSize];

for(int i=0; i<tableSize; i++){
    hashTable[i]=new block(INT_MAX);
}

counter=0;
count=0;
critical=0.53;
load=0;


}

HashD::~HashD(){



}


/*
unsigned long HashD :: hash1(string value){
     unsigned long sum=0;
    int sizee= value.length();
    for(int i=0; i<sizee; i++){
            sum^=(sum<<5)+(sum>>6)+(int)value[i];
    }

	return sum;
}

*/
/*
unsigned long HashD :: hash2(string value){

    unsigned long sum=0;
    int sizee= value.length();
    for(int i=0; i<sizee; i++){
            sum^=(sum<<5)+(sum>>3)+(int)value[i];
    }

	if(sum%2){
        return sum;
	}
	else{
        return (sum+1);
	}


}
*/


unsigned long HashD::hasher(string value, unsigned long i){

unsigned long sum=0;
    int sizee= value.length();
    for(int i=0; i<sizee; i++){
            sum^=(sum<<5)+(sum>>6)+(int)value[i];
    }
unsigned long sum1=sum;

    unsigned long sum2=0;

    for(int i=0; i<sizee; i++){
            sum2^=(sum2<<3)+(sum2>>3)+(int)value[i];
    }

	if(sum2%2){

	}
	else{
        sum2=(sum2+1);
	}











return (sum1+i*sum2 )%tableSize;


}


void HashD::resizeTable(){



int old=tableSize;

tableSize= tableSize<<1;

block** temp=new block*[tableSize];

for(int i=0; i<tableSize; i++){

    temp[i]=new block(INT_MAX);

}




for(int i=0; i<old; i++){

    if(hashTable[i]->key!=INT_MAX&&hashTable[i]->key!=INT_MIN){
        string word=hashTable[i]->value;
        int j=0;
int hashV=hasher(word, j);
block* temp1=temp[hashV];



while(temp[hashV]->key!=INT_MAX){

    ++j;
    hashV=hasher(word, j);
}



temp[hashV]->key=hashV;
temp[hashV]->value=word;




        ///rehash(hashTable[i]->value, temp);
    }
    delete hashTable[i];///ersaing this improves time waisey

}




delete hashTable;
hashTable=temp;

}

/*
void HashD::rehash(string word, block** temp){



int i=0;
int hashV=hasher(word, i);
block* temp1=temp[hashV];



while(temp[hashV]->key!=INT_MAX){

    i++;
    hashV=hasher(word, i);
}



temp[hashV]->key=hashV;
temp[hashV]->value=word;


}
*/




void HashD::insert(string value){

    int i=0;
    unsigned long hashV=hasher(value, i);



    while(hashTable[hashV]->key!=INT_MAX){
        ++i;
        hashV=hasher(value, i);
    }

    hashTable[hashV]->key=hashV;
    hashTable[hashV]->value=value;


     ++count;
    ++counter;
    load=counter/tableSize;
    if(load>=critical){

        resizeTable();
    }

}

void HashD::deleteWord(string value){















block* temp=lookup(value);
if(temp!=NULL){
    ///temp->value="NIL";
    temp->key=INT_MIN;
    count--; counter--;
}



}

block* HashD::lookup(string value){

int i=0;
unsigned long hashV=hasher(value, i);
if(hashTable[hashV]->key==INT_MAX){
    return NULL;
}
while(hashTable[hashV]->value!=value){
    i++;

    hashV=hasher(value, i);
    if(hashTable[hashV]->key==INT_MAX){
        return NULL;
    }

}

if(hashTable[hashV]->key==INT_MIN){

    return NULL;
}

return hashTable[hashV];
}

#endif
