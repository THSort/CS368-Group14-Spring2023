#include <iostream>
#include "doubleHash.h"
#include <fstream>
#include <vector>
#include <time.h>
#include <thread>
#include <chrono>
#include <future>
#include <algorithm>    // std::sort
#include <vector>       // std::vector
using namespace std;
bool timeOut;

promise<bool> done;
void timer(future<bool> done_future){
    std::chrono::seconds span (4);
    if(done_future.wait_for(span) == std::future_status::timeout) {
        timeOut = true;
    }
}



int main()
{

    vector<string> allWords;
    vector<string> queries;
    srand(time(NULL));
    ifstream file;
    file.open("words.txt");
    cout << "LOADING THE FILE" << endl;
    string temp;
    while(!file.eof()){
        file >> temp;
        allWords.push_back(temp);
    }
    file.close();

cout<<"why"<<endl;
int size=allWords.size();
cout<<"size = "<<size<<endl;
 int* arr=new int[size];
///size=10000 ;




for(int i=0; i<size; i++){
    arr[i]=0;
}
int temp1=0;
int collisions=0;
for(int i=0; i<size; i++){
        temp1=polyHash(allWords[i], 41 )%(size);
        if(arr[temp1]==1){collisions++;}
    if(arr[temp1]==0){arr[temp1]=1;}

}
 ofstream hile;
 hile.open("words2.txt");
for(int i=0; i<size; i++){
    hile<<arr[i]<<endl;
}
float sizee=size;
float coll=collisions;
cout<<"collisions = "<<collisions<<endl;
cout<<"collisions / size = "<<coll/sizee<<endl;
hile.close();

}
