#include "Chaining.cpp"
#ifndef CHAINING__H
#define CHAINING__H
#include <string>
#include "LinkedList.cpp" // Your Own Implementation
using namespace std;
class HashC
{
	private:


		unsigned long hash(string input); // Given a String, return its hash
	public:
	    long tableSize;///Place this later back
	    LinkedList<string>* hashTable; /// Bro Place this later back
		HashC(int);
		~HashC(); // Destructor
		void insert(string word); // Takes a hash of 'word' and inserts it into hashTable accordingly
		void deleteWord(string word);
		ListItem<string>* lookup(string word);
		 ///void Resize();
		float load;
		float counter;
		float critical;
		int max_hash;
};
#endif
