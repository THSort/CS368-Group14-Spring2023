#ifndef __LIST_CPP
#define __LIST_CPP

#include <iostream>
#include <cstdlib>
#include "LinkedList.h"

using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
    head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
    if (otherLinkedList.head == NULL)
    {
        head = NULL;
    }
    else
    {
        head = new ListItem<T> (otherLinkedList.head->value);
        ListItem<T> *current = head;
        ListItem<T> *otherLinkedList_current = otherLinkedList.head->next;
        while (otherLinkedList_current != NULL)
        {
            current->next = new ListItem<T> (otherLinkedList_current->value);
            current->next->prev = current;
            otherLinkedList_current = otherLinkedList_current->next;
            current = current->next;
        }
    }
}

template <class T>
LinkedList<T>::~LinkedList()
{
    if (head != NULL)
    {
        ListItem<T> *current = head;
        ListItem<T> *temp;
        while (current != NULL) //current->next
        {
            temp = current->next;
            delete current;
            current = temp;
        }
    }
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
    if (head == NULL)
    {
        head = new ListItem<T> (item);
    }
    else
    {
        ListItem<T> *temp = new ListItem<T> (item);
        temp->next = head;
        head->prev = temp;
        head = temp;
    }
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
    if (head == NULL)
    {
        insertAtHead(item);
    }
    else
    {
    ListItem<T> *temp = new ListItem<T> (item);
    ListItem<T> *current = head;
    //go to tail
    while (current->next != NULL)
    {
        current = current->next;
    }
    current->next = temp;
    temp->prev = current;
    }
}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
    ListItem<T> *current = head;
    //go to ListItem containing afterWhat
    while (current->value != afterWhat && current->next != NULL)
    {
        current = current->next;
    }
    if (current->value != afterWhat)
    {
        cout << "afterWhat not found. toInsert not inserted." << endl;
    }
    else
    {
        ListItem<T> *temp = new ListItem<T> (toInsert);
        temp->next = current->next;
        if (current->next != NULL)
        {
            current->next->prev = temp;
        }
        current->next = temp;
        temp->prev = current;
    }
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
    int success = 0;
    if (head == NULL || head->value > item)
    {
        insertAtHead(item);
    }
    else
    {
        ListItem<T> *current = head;
        ListItem<T> *afterme = head->next;
        while (current->next != NULL)
        {
            if (afterme->value > item) //insert at back of afterme
            {
                ListItem<T> *temp = new ListItem<T> (item);
                temp->prev = current;
                temp->next = afterme;
                current->next = temp;
                afterme->prev = temp;
                success = 1;
                break;
            }
            current = afterme;
            afterme = afterme->next;
        }
        if (success != 1)
        {
            insertAtTail(item);
        }
    }
}
template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
    return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    ListItem<T> *current = head;
    if (head == NULL)
    {
        return head;
    }
    //go to tail
    else
    {
        while (current->next != NULL)
        {
            current = current->next;
        }
        return current;
    }
}

template <class T>
ListItem<T>* LinkedList<T>::searchFor(T item)
{
    if (head == NULL)
    {
        return NULL;
    }
    ListItem<T> *current = head;
    while (current->value != item && current->next != NULL)
    {
        current = current->next;
    }
    if (current->value != item)
    {
        return NULL;
    }
    else
    {
        return current;
    }
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
    ListItem<T> *item_pos = searchFor(item);
    if (item_pos == NULL)
    {
        cout << "item not found." << endl;
    }
    else if (item_pos == head)
    {
        deleteHead();
    }
    else if (item_pos->next == NULL)
    {
        deleteTail();
    }
    else
    {
        item_pos->next->prev = item_pos->prev;
        item_pos->prev->next = item_pos->next;
        delete item_pos;
    }
}

template <class T>
void LinkedList<T>::deleteHead()
{
    if (head == NULL)
    {
        cout << "Empty List." << endl;
    }
    else if (head->next == NULL)
    {
        delete head;
        head = NULL;
    }
    else if (head != NULL)
    {
        ListItem<T> *current = head;
        head = head->next;
        head->prev = NULL;
        delete current;
    }
}

template <class T>
void LinkedList<T>::deleteTail()
{
    ListItem<T> *tail = getTail();
    if (tail == NULL)
    {
        cout << "Empty List." << endl;
    }
    else if (tail->prev == NULL)
    {
        deleteHead();
    }
    else
    {
        ListItem<T> *newTail = tail->prev;
        newTail->next = NULL;
        delete tail;
    }
}

template <class T>
int LinkedList<T>::length()
{
    ListItem<T> *current = head;
    if (head == NULL)
    {
        return 0;
    }
    else
    {
        int len = 1; //to accomomodate the ListItem at tail
        while (current->next != NULL) //to count all ListItems except tail
        {
            len++;
            current = current->next;
        }
        return len;
    }
}

template <class T>
void LinkedList<T>::reverse()
{
    //interchange all next with previous, then make the Last ListItem of initial list the head
    if (head == NULL)
    {
        cout << "Empty list." << endl;
    }
    else
    {
        ListItem<T> *current = head;
        ListItem<T> *next_traversal;
        //if one ListItem list then reverse operation unnecessary so not taken care of as a special case
        do
        {
            next_traversal = current->next; //for correct traversal
            ListItem<T> *temp = current->prev;
            current->prev = current->next;
            current->next = temp;
            if (next_traversal != NULL)
            {
                current = next_traversal;
            }
        }
        while (next_traversal != NULL);
        head = current;
    }
}

template <class T>
void LinkedList<T>::parityArrangement()
{
    ListItem<T> *current = head;
    for (int i = 0; i < length()/2; i++)
    {
        insertAtTail(current->next->value);
        deleteElement(current->next->value);
        current = current->next;
    }
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
    if (length()==0)
    {
        return false;
    }
    bool isP = true;
    ListItem<T> *current = head;
    ListItem<T> *tail = getTail();
    for (int i=0; i<length()/2; i++)
    {
        if (current->value != tail->value)
        {
            isP = false;
            break;
        }
        current = current->next;
        tail = tail->prev;
    }
    return isP;
}

#endif
