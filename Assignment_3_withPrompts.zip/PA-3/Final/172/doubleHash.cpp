#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD()
{
    tableSize = 10000; // you cant change this
    hashTable = new block* [tableSize];
    //for loop to point every pointer to NULL
    for (int i = 0; i < tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
    count = 0;
}

HashD::~HashD(){
	delete [] hashTable;
}

unsigned long HashD :: hash1(string value){
	unsigned long hashB = bitHash(value); 
    return divCompression(hashB, tableSize);
}

unsigned long HashD :: hash2(string value){
    unsigned long hashB = bitHash(value); 
    return 23-(hashB%23); //started from 7-(hashB%7) as done in class and made it faster using another prime number experimentally
}

void HashD::resizeTable()
{
	if (count >= tableSize*0.3) //tableSize*0.3 more time efficient here (checked experimentally) although not as space efficient
	{
		block **temp = hashTable;
		long oldTableSize = tableSize;
		tableSize *= 2.0;

		hashTable = new block* [tableSize]; //larger hashtable created
	    for (int i = 0; i < tableSize; i++)
	    {
	    	hashTable[i] = NULL;
    	}
		
		count = 0;
		for (int i = 0; i < oldTableSize; i++)
		{
			if (temp[i] != NULL	&& temp[i]->value != "deletedMe")
			{
				//new hash would be generated and placed to stay within new tableSize
				insert(temp[i]->value);
			}
		}
		delete [] temp;
	}
}

void HashD::insert(string value)
{
	unsigned long i = 0;
	unsigned long hashh = hash1(value); //+0*hash2(value)
	unsigned long pos = hashh;

    while (hashTable[pos] != NULL && hashTable[pos]->value != "deletedMe")
    {
        i++;
        pos = (hash1(value) + i*hash2(value))%tableSize;
    }
	hashTable[pos] = new block (hashh, value);
    count++;
    resizeTable();
}

void HashD::deleteWord(string value)
{
	unsigned long pos = hash1(value);
	unsigned long i = 0;

    while (hashTable[pos] != NULL && hashTable[pos]->value != value) 
    {
        i++;
        pos = (hash1(value) + i*hash2(value))%tableSize;
    }
    if (hashTable[pos] != NULL) //value found
    {
    	hashTable[pos]->value = "deletedMe";
    	//hashTable[pos]->key = 0; can check deleted throught the key too
    	count--;
    }
	resizeTable();
}

block* HashD::lookup(string value)
{
	unsigned long pos = hash1(value);
	unsigned long i = 0;
	while (hashTable[pos] != NULL && hashTable[pos]->value != value)
	{
        i++;
        pos = (hash1(value) + i*hash2(value))%tableSize;
    }
	if (hashTable[pos] == NULL)
    {
    	return NULL;
    }
    else 
    {
    	return hashTable[pos];
    }
}

#endif