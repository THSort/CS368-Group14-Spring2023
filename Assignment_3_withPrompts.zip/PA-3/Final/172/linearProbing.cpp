#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block* [tableSize];
    //for loop to point every pointer to NULL
    for (int i = 0; i < tableSize; i++)
    {
    	hashTable[i] = NULL;
    }
    count = 0;
}

HashL::~HashL(){
    delete [] hashTable;
}

unsigned long HashL :: hash(string value){
	unsigned long hashB = bitHash(value); 
    return divCompression(hashB, tableSize);
}

void HashL::resizeTable(){
    if (count >= tableSize*0.7)
	{
		block **temp = hashTable;
		long oldTableSize = tableSize;
		tableSize *= 2.0;

		hashTable = new block* [tableSize]; //larger hashtable created
	    for (int i = 0; i < tableSize; i++)
	    {
	    	hashTable[i] = NULL;
    	}
		
		count = 0;
		for (int i = 0; i < oldTableSize; i++)
		{
			if (temp[i] != NULL	&& temp[i]->value != "deletedMe")
			{
				//new hash would be generated and placed to stay within new tableSize
				insert(temp[i]->value);
			}
		}
		delete [] temp;
	}
}

void HashL::insert(string value){
	unsigned long hashh = hash(value);
	unsigned long pos = hashh;

    while (hashTable[pos] != NULL && hashTable[pos]->value != "deletedMe")
    {
    	pos++;
    	pos = pos % tableSize;
    }
	hashTable[pos] = new block (hashh, value);
    count++;
    resizeTable();
}

void HashL::deleteWord(string value){
    unsigned long pos = hash(value);

    while (hashTable[pos] != NULL && hashTable[pos]->value != value) 
    {
    	pos++;
    	pos = pos%tableSize;
    }
    if (hashTable[pos] != NULL) //value found
    {
    	hashTable[pos]->value = "deletedMe";
    	//hashTable[pos]->key = 0; 
    	count--;
    }
	resizeTable();
}


block* HashL::lookup(string value){
	unsigned long pos = hash(value);
	while (hashTable[pos] != NULL && hashTable[pos]->value != value)
	{
		pos++;
		pos = pos %tableSize;
	}
	if (hashTable[pos] == NULL)
    {
    	return NULL;
    }
    else 
    {
    	return hashTable[pos];
    }
}
#endif	