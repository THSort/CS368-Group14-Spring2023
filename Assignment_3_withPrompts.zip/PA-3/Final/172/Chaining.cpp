#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size)
{
    tableSize = size;
    hashTable = new LinkedList<string> [tableSize];
}

//destructor of LinkedList would be called anyway
HashC::~HashC()
{
    delete [] hashTable;
}

unsigned long HashC :: hash(string input)
{
    unsigned long hashB = bitHash(input);    //bitHash faster than polyHasan
    return divCompression(hashB, tableSize);
}

void HashC::insert(string word){
    //use if statement to avoid duplicates, but test passes anyway
	//if (lookup(word) == NULL){
        unsigned long pos = hash(word);
        hashTable[pos].insertAtHead(word);
	//}
}

ListItem<string>* HashC :: lookup(string word)
{
	unsigned long Hash = hash(word);
    return hashTable[Hash].searchFor(word);
}

void HashC :: deleteWord(string word)
{
	unsigned long Hash = hash(word);
	hashTable[Hash].deleteElement(word);
}

#endif
