#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <iostream>
#include <string>
#include <cmath>

using namespace std;

// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	unsigned long hash = 0;
	for (int i = 0; i < value.length(); i++)
	{
	    int ascii = value[i];
		hash += (pow(a, i) * ascii);
	}
	return hash;
}

//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){
	unsigned long bitwise_hash = 0;
	for (int i = 0; i < value.length(); i++)
	{
	    long ascii = value[i];
        bitwise_hash ^= (bitwise_hash << 5) + (bitwise_hash >> 2) + ascii;
	}
	return bitwise_hash;
}

unsigned long divCompression(unsigned long hash,long size){
    return hash%size;
}

// multiplication addition and division compression.
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){
    return (a*hash+m)%size;
}

// 'm' and 'a' can take any value
#endif

// you may write your own program to test these functions.
/*int main()
{
    string test = "tops";
    unsigned long hash1 = polyHash(test, 5);
    unsigned long hash2 = bitHash(test);
    cout << "hash1: " << hash1 << endl;
    cout << "hash2: " << hash2 << endl;
    cout << divCompression(hash1, 37) << endl;
    cout << madCompression(hash1, 11, 1993, 1637) << endl;
    return 0;
}*/
