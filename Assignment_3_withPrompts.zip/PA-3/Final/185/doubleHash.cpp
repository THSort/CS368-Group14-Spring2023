#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
HashD::HashD(){
    tableSize = 10000; // you cant change this
    block** b = new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
    	b[i]=NULL;
    }
    count=0;
    hashTable = b;
}

HashD::~HashD(){
	for(int i=0;i<tableSize;i++)
	{
		delete hashTable[i];
	}
	delete[] hashTable;
}

unsigned long HashD :: hash1(string value){
	int s= value.size();
	unsigned long h=0;
	for(int i=0;i<s;i++)
	{
		h = (h<<5)|(h>>27);
		h += (unsigned int) value[i];
	}
	unsigned long c = ((unsigned long )sqrt(h*h) % tableSize);
	//cout<<"Hash value: "<< c<<endl;
  return c;
}

unsigned long HashD :: hash2(string value){
	int s=value.size();
	unsigned long r=0;
	unsigned long aa=33;
	unsigned long a=aa;

	for(int i=0;i<s;i++)
	{	
		for(int j=0;j<(s-((i+1)));j++)
		{
			a=a*aa;
		}
		//cout<<"a: "<<a<<" value: "<<value[i]<<endl;
		r += value[i] * a;
		a=33;
	}
		//cout<<"r is: "<<r<<endl;
	unsigned long c = (r % tableSize);
	c = 113-(c%113);
    return c;
}

void HashD::resizeTable(){
    block** b;
	if(count > 0.5*tableSize )
	{ 
		b = new block*[tableSize*2];
		int oldSize=tableSize;
		tableSize*=2;
		for(int i=0;i<tableSize;i++)
	    {
	    	b[i]=NULL;
	    }
		//bool reachedEnd;
	    for(int i=0;i<oldSize;i++)
	    {	
	    	//reachedEnd=0;
	    	if(hashTable[i]!=NULL && hashTable[i]->key!=-1)
	    	{	//cout<<"In if"<<endl;
	    		int ii=0;
	    		unsigned long hash_1= hash1(hashTable[i]->value);
				unsigned long hash_2= hash2(hashTable[i]->value);
				int k = (hash_1 + (ii*(hash_2)))  % tableSize;
	    		
	    		while(b[k]!=NULL && b[k]->value!="_d_")
				{
					ii++;
					k = (hash_1 + (ii*(hash_2))) % tableSize;
					
				}
				b[k] = hashTable[i];
	    	}
	 
	    }

	}
	else if(count < 0.1*tableSize )
	{ 
		b = new block*[tableSize/2];
		int oldSize=tableSize;
		tableSize/=2;
		for(int i=0;i<tableSize;i++)
	    {
	    	b[i]=NULL;
	    }
		//bool reachedEnd;
	    for(int i=0;i<oldSize;i++)
	    {	
	    	//reachedEnd=0;
	    	if(hashTable[i]!=NULL && hashTable[i]->key!=-1)
	    	{	//cout<<"In if"<<endl;
	    		int ii=0;
	    		unsigned long hash_1= hash1(hashTable[i]->value);
				unsigned long hash_2= hash2(hashTable[i]->value);
				int k = (hash_1 + (ii*(hash_2)))  % tableSize;

	    		while(b[k]!=NULL && b[k]->value!="_d_")
				{
					ii++;
					k = (hash_1 + (ii*(hash_2))) % tableSize;
					
				}
				b[k] = hashTable[i];
				//cout<<"Inserted: "<<b[k]->value<<endl;
	    	}
	 
	    }

	}
	//delete[] hashTable;
	hashTable=b;
	//cout<<"Resize Done"<<endl;
    return;
}

void HashD::insert(string value){
    if(lookup(value))
	{
		return;
	}
	if(count > 0.5*tableSize)
	{
		resizeTable();
	}
	int i=0;
	unsigned long hash_1= hash1(value);
	unsigned long hash_2= hash2(value);
	int k = ((hash_1) + (i*(hash_2))) % tableSize;

	while(hashTable[k]!=NULL && hashTable[k]->value!="_d_")
	{
		i++;
		k = (hash_1 + (i*(hash_2)))   % tableSize;

	}

	hashTable[k] = new block(k,value);
	count++;
	
    return;
}

void HashD::deleteWord(string value){
    int i=0;
    unsigned long hash_1= hash1(value);
	unsigned long hash_2= hash2(value);
	int k = (hash_1 + (i*(hash_2))) % tableSize;

	while(hashTable[k]!=NULL && hashTable[k]->value!=value)
	{
		i++;
		k = (hash1(value) + (i*(hash2(value))))   % tableSize;
	}
	if(hashTable[k]!=NULL && hashTable[k]->value==value )
	{
			hashTable[k]->value="_d_";
			hashTable[k]->key=-1;
			count--;
			if(count < 0.1*tableSize)
			{
				resizeTable();
			}
	}
	else
	{
    	return ;
	}
}

block* HashD::lookup(string value){
	int i=0;
	unsigned long hash_1= hash1(value);
	unsigned long hash_2= hash2(value);
	int k = (hash_1+ (i*(hash_2))) % tableSize;

	while(hashTable[k]!=NULL && hashTable[k]->value!=value)
	{
		i++;
		k = (hash_1 + (i*(hash_2)))   % tableSize;
	}
	if(hashTable[k]!=NULL && hashTable[k]->value==value )
	{
		return hashTable[k];
	}
	else
	{
    	return NULL;
	}
}

#endif