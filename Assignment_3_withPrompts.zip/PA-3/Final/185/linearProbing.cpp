#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"


HashL::HashL(){
    tableSize = 1000; //  cant change this
    block** b = new block*[tableSize];
    for(int i=0;i<tableSize;i++)
    {
    	b[i]=NULL;
    }
    count=0;
    hashTable = b;
}

HashL::~HashL(){
	for(int i=0;i<tableSize;i++)
	{
		delete hashTable[i];
	}
    delete[] hashTable;
}

unsigned long HashL :: hash(string value){
	int s= value.size();
	unsigned long h=0;
	for(int i=0;i<s;i++)
	{
		h = (h<<5)|(h>>27);
		h += (unsigned int) value[i];
	}
	unsigned long c = ((unsigned long )sqrt(h*h) % tableSize);
	//cout<<"Hash value: "<< c<<endl;
  return c;
}

void HashL::resizeTable(){
	block** b;
	if(count > 0.7*tableSize)
	{ 
		//cout<<"................Resizing..................."<<endl;
		b = new block*[tableSize*2];
		int oldSize=tableSize;
		tableSize*=2;
		for(int i=0;i<tableSize;i++)
	    {
	    	b[i]=NULL;
	    }
		//cout<<"................Made new array..................."<<endl;
		bool reachedEnd;
	    for(int i=0;i<oldSize;i++)
	    {	
			//cout<<"................In for loop..................."<<endl;
	    	reachedEnd=0;
	    	if(hashTable[i]!=NULL && hashTable[i]->key!=-1)
	    	{
	    		int k = hash(hashTable[i]->value);
	    		int table_size_minus_one = tableSize-1;
	    		while(b[k]!=NULL && k<tableSize)
				{
					if(k == table_size_minus_one && !reachedEnd){
						reachedEnd=true;
						k=0;
						continue;
					}
					k++;
				}
				b[k] = hashTable[i];
				// b[k].key=k;
				// b[k].value=hashTable[i].value;
				//cout<<"Value inserted: "<<b[k].value<<" at value: "<<k<<endl;
	    	}
	 
	    }

	}
	else if(count < 0.3*tableSize)
	{ 
		//cout<<"................Resizing..................."<<endl;
		b = new block*[tableSize/2];
		int oldSize=tableSize;
		tableSize/=2;
		for(int i=0;i<tableSize;i++)
	    {
	    	b[i]=NULL;
	    }
		//cout<<"................Made new array..................."<<endl;
		bool reachedEnd;
	    for(int i=0;i<oldSize;i++)
	    {	
			//cout<<"................In for loop..................."<<endl;
	    	reachedEnd=0;
	    	if(hashTable[i]!=NULL && hashTable[i]->key!=-1)
	    	{
	    		int k = hash(hashTable[i]->value);
	    		int table_size_minus_one = tableSize-1;
	    		while(b[k]!=NULL && k<tableSize)
				{
					if(k == table_size_minus_one && !reachedEnd){
						reachedEnd=true;
						k=0;
						continue;
					}
					k++;
				}
				b[k] = hashTable[i];
				// b[k].key=k;
				// b[k].value=hashTable[i].value;
				//cout<<"Value inserted: "<<b[k].value<<" at value: "<<k<<endl;
	    	}
	 
	    }

	}
	delete[] hashTable;
	hashTable=b;
    return;
}

void HashL::insert(string value){
	if(lookup(value))
	{
		return;
	}
	if(count > 0.7*tableSize)
	{
		resizeTable();
	}
	int k = hash(value);
	bool reachedEnd=0;
	int table_size_minus_one = tableSize-1;
	while(hashTable[k]!=NULL && hashTable[k]->key!=-1 && k<tableSize)
	{
		if(k == table_size_minus_one && !reachedEnd){
			reachedEnd=true;
			k=0;
			continue;
		}
		k++;
	}
	//if(k >= tableSize)
	
	hashTable[k] = new block(k,value);
	count++;
	//cout<<"Value : "<<hashTable[k]->value<<" at k: "<<k<<endl;
	// hashTable[k].key=k;
	// hashTable[k].value=value;
    return;
}

void HashL::deleteWord(string value){
	int k = hash(value);
	bool reachedEnd=0;
	int table_size_minus_one = tableSize-1;
	//cout<<"lol"<<endl;
	//cout<<"K was "<<k<<endl;
	while(hashTable[k]!=NULL && hashTable[k]->value!=value && k<tableSize)
	{
		if(k == table_size_minus_one && !reachedEnd){
			reachedEnd=true;
			k=0;
			continue;
		}
		k++;
	}
	if(k<tableSize && hashTable[k]!=NULL && hashTable[k]->value==value )
		{	
			//cout<<hashTable[k]->value<<" returned" <<endl;
			hashTable[k]->value="_d_";
			hashTable[k]->key=-1;
			count--;
			if(count < 0.3*tableSize)
			{
				resizeTable();
			}
			//hashTable[k]->value=4000000000;
		}
		else
		{
			return;
		}
	
 //    return;
}
block* HashL::lookup(string value){
	int k = hash(value);
	bool reachedEnd=0;
	int table_size_minus_one = tableSize-1;
	//cout<<"lol"<<endl;
	//cout<<"K was "<<k<<endl;
	while(hashTable[k]!=NULL && hashTable[k]->value!=value && k<tableSize)
	{
		if(k == table_size_minus_one && !reachedEnd){
			reachedEnd=true;
			k=0;
			continue;
		}
		k++;
	}
	// cout<<"lol2"<<endl;
	// cout<<"K: "<<k<<" and table size: "<<tableSize<<"and count: "<<count<<endl;
	//cout<<hashTable[k]<<endl;
		if(k<tableSize && hashTable[k]!=NULL && hashTable[k]->value==value )
		{	
			//cout<<hashTable[k]->value<<" returned" <<endl;
			return hashTable[k];
		}
		else
		{
			return NULL;
		}
    //return NULL;
}
#endif
