#ifndef HASHFUNCTIONS_CPP
#define HASHFUNCTIONS_CPP
#include <string>
#include <iostream>
#include <cmath>
using namespace std;
// Size is the size of array maintained by the hashtable.
unsigned long divCompression(unsigned long hash,long size){

		unsigned long c = (hash % size);

		return c;
}
// multiplication addition and division compression. 
unsigned long madCompression(unsigned long hash,long size,int m = 1993,int a = 1637){

	unsigned long h = ( (a*(unsigned long)sqrt(hash*hash)+m)  % size  );
    return h;
}
// this takes in a string and returns a 64bit hash.
unsigned long polyHash(std::string value,int a = 5){
	int s=value.size();
	unsigned long r=0;
	unsigned long aa=a;
	for(int i=0;i<s;i++)
	{	
		for(int j=0;j<(s-((i+1)));j++)
		{
			a=a*aa;
		}
		//cout<<"a: "<<a<<" value: "<<value[i]<<endl;
		r += value[i] * a;
		//cout<<"r is: "<<r<<endl;
		a=aa;
	}
	//cout<<"P: "<<r<<endl;
	return divCompression(r, 10000);
}
//does some bitwise operation and generates a 64bit hash.
unsigned long bitHash(std::string value){

	int s= value.size();
	unsigned long h=0;
	for(int i=0;i<s;i++)
	{
		h = (h<<5)|(h>>27);
		h += (unsigned int) value[i];
	}
	return divCompression(r, 10000);
}

// 'm' and 'a' can take any value
#endif
// you may write your own program to test these functions.
// int main()
// {
// 	string c= "aafaq";
// 	int a=5;
// 	unsigned long h = polyHash(c, a);
// 	unsigned long h2 = bitHash(c);
// 	cout<<h<<endl;
// 	cout<<h2<<endl;
// }