#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
#include <cmath>

HashC::HashC(int size){
	LinkedList<string>* h = new LinkedList<string>[size];
	tableSize=size;
	hashTable=h;
	//cout<<"Table size: "<<tableSize<<endl;
}
HashC::~HashC(){
	for(int i=0;i<tableSize;i++)
	{
		hashTable[i].~LinkedList();
	}
	delete[] hashTable;
}

unsigned long HashC :: hash(string input){
	int s= input.size();
	unsigned long h=0;
	for(int i=0;i<s;i++)
	{
		h = (h<<5)|(h>>27);
		h += (unsigned int) input[i];
	}
	unsigned long c = ((unsigned long )sqrt(h*h) % tableSize);
	//cout<<"Hash value: "<< c<<endl;
  return c;
}

void HashC::insert(string word){
	int index = hash(word);
	//cout<<"index was: "<<index<<endl;
	//cout<<"Head value: "<<hashTable[index].getHead()<<endl;
	if(!hashTable[index].searchFor(word))
	{
	hashTable[index].insertAtHead(word);
	}
	
	//cout<<"Value inserted"<<endl;
  return;
}

ListItem<string>* HashC :: lookup(string word){
	int index = hash(word);
	return hashTable[index].searchFor(word);
}

void HashC :: deleteWord(string word){
	int index = hash(word);
	hashTable[index].deleteElement(word);
  return;
}

#endif