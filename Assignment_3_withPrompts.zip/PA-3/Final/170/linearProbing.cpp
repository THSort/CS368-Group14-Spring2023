#ifndef LINEARPROBING_CPP
#define LINEARPROBING_CPP

#include "linearProbing.h"
#include "hashfunctions.cpp"

long resizeEncoding;
HashL::HashL(){
    tableSize = 1000; // you cant change this
    hashTable = new block* [tableSize];
    for(int i =0; i<tableSize; i++)
    {
    	hashTable[i]=NULL;
    }
}

HashL::~HashL(){
    
}

unsigned long HashL :: hash(string value){
    return divCompression(hash(value),tableSize);
}

void HashL::resizeTable(){
	if(resizeEncoding==1)
	{
		int oldTableSize = tableSize;
		tableSize = tableSize*2;
		block** oldHashTable = hashTable;
		count = 0;
		hashTable = new block* [tableSize];

		for(int i =0; i<tableSize; i++)
		{
			hashTable[i]=NULL;
		}
		for(int i =0; i<tableSize; i++)
		{
			if(oldHashTable[i]!=NULL)
			{
				insert(oldHashTable[i]->value);
			}
		}

	}
    return;
}

void HashL::insert(string value){
	if(lookup(value)!=NULL)
	{
		return;
	}
	else
	{
		unsigned long here = hash(value);
		unsigned long current = 0;
		current = here;
		while(hashTable[here] != NULL || hashTable[here]->key != -10)
		{
			here = (here+1) % tableSize;
		}
		hashTable[here] = new block(current,value);
		count++;

		if(count >= tableSize*(30/100))
		{
			resizeTable();
			resizeEncoding=1;
		}
	}
	 
}

void HashL::deleteWord(string value){
	block* delptr = lookup(value);
	delptr->value="deleted";
	delptr->key=-10;


    return;
}
block* HashL::lookup(string value){
	unsigned long here = hash(value);
	while(hashTable[here] != NULL)
	{
		if(hashTable[here]->value == value)
		{
			return hashTable[here];
		}
		here = (here+1) % tableSize;
	}
   
}
#endif
