#ifndef DOUBLEHASH_CPP
#define DOUBLEHASH_CPP
#include "doubleHash.h"
#include "hashfunctions.cpp"
long resizeEncoding=1;
HashD::HashD(){
    tableSize = 10000; // you cant change this
    hashTable = new block*[tableSize];
    count = 0;
}

HashD::~HashD(){

}

unsigned long HashD :: hash1(string value){

    return bitHash(value);
}

unsigned long HashD :: hash2(string value){
    return polyHash(value);
}

void HashD::resizeTable(){
		if(resizeEncoding==1)
	{
		int oldTableSize = tableSize;
		tableSize = tableSize*2;
		block** oldHashTable = hashTable;
		count = 0;
		hashTable = new block* [tableSize];

		for(int i =0; i<tableSize; i++)
		{
			hashTable[i]=NULL;
		}
		for(int i =0; i<tableSize; i++)
		{
			if(oldHashTable[i]!=NULL)
			{
				insert(oldHashTable[i]->value);
			}
		}

	}
    return;
}

void HashD::insert(string value){
	int check = 0;
	long orignalHashValue = divCompression((hash2(value)+(hash1(value)*count)),tableSize);

	while(check < tableSize)
	{
		long hashValue = divCompression((hash2(value)+(hash1(value)*count)),tableSize);

		if(!hashTable[hashValue])
		{
			hashTable[hashValue] = new block(orignalHashValue, value);
			count++;
			return;
		}
		check++;
	}
	if(check>tableSize)
	{
		resizeTable();
		insert(value);
	}
    return;
}

void HashD::deleteWord(string value){
	block* delptr = lookup(value);
	delptr->value="deleted";
	delptr->key=-10;
    return;
}

block* HashD::lookup(string value){
	int check = 0;
	long hashValue = divCompression((hash2(value)+(hash1(value)*check)),tableSize);
	while(hashTable[hashValue])
	{
		long hashValue = divCompression((hash2(value)+(hash1(value)*check)),tableSize);

		if(hashTable[hashValue]->value==value){
			return hashTable[hashValue]
		}
		check++;
	}
    return NULL;
}

#endif