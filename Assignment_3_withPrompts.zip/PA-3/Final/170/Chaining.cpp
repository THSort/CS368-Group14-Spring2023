#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"
#include "LinkedList.cpp"
#include <iostream>

using namespace std;

HashC::HashC(int size){
	tableSize = size;
    hashTable = new LinkedList<string> [size];
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
  return bitHash(input);  
}

void HashC::insert(string word){
	long key = hash(word);
	if(lookup(word)==NULL)
	{
		hashTable[divCompression(key,tableSize)].insertAtHead(word);
  	}
  return;
}

ListItem<string>* HashC :: lookup(string word){
	long key = hash(word);
	key = divCompression(key,tableSize);

	return (hashTable[divCompression(key,tableSize)].searchFor(word));

}

void HashC :: deleteWord(string word){
	long key = hash(word);
	key = divCompression(key,tableSize);
	(hashTable[divCompression(key,tableSize)].deleteElement(word));
}

#endif