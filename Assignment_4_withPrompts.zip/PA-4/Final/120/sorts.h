#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);
vector<long> MergeSort(vector<long> nums);
List<long> Merge(List<long> nums1, List<long> nums2);
List<long> Split(List<long> nums);
vector<long> QuickSortArray(vector<long> nums);
long* Qsort(long* arr, long size);
long* Concat(long* l, long* m, long* r, long sl, long sm, long sr);
vector<long> QuickSortList(vector<long> nums);
List<long> ConactList(List<long> l, List<long> m, List<long> r);
List<long> QsortList(List<long> nums);
vector<long> HeapSort(vector<long> nums);

#endif