#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <math.h>


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	heap_size = 0;
	harr = new int[capacity];
}

void MinHeap :: MinHeapify(int i){

	int l = left(i);
	int r = right(i);

	if(i < heap_size && i >= 0){
		if(l != -1 && r != -1){
			
			long min = i;
			if(harr[r] < harr[min]){
				min = r;
			}
			if(harr[l] < harr[min]){
				min = l;
			}
			if(min != i) {
				long temp = harr[i];
				harr[i] = harr[min];
				harr[min] = temp;

				MinHeapify(min);
			}

		}
		else if(l!= -1){
			if(harr[l] < harr[i]){
				int temp = harr[l];
				harr[l] = harr[i];
				harr[i] = temp;
				
				MinHeapify(l);

			}
		}
		else if(r != -1){
			if(harr[r] < harr[i]){
				int temp = harr[r];
				harr[r] = harr[i];
				harr[i] = temp;
				
				MinHeapify(r);
			}
		}
	}
	//display();


}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	int ans = 2*i+1;
	if(ans < heap_size) return ans;
	else return -1;
}
 
int MinHeap::right(int i)
{
	int ans = 2*i+2;
	if(ans < heap_size) return ans;
	else return -1;
}
 
int MinHeap::extractMin()
{
	if(heap_size > 0){
		int index = 0;
		int min = harr[0];
		int left_index = left(0);
		int right_index = right(0);

		//switch min and last
		harr[0] = harr[heap_size-1];
		heap_size--;

		MinHeapify(index);
		return min;
	}


}

void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	MinHeapify(i);
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i < heap_size){
		int temp = harr[heap_size-1];
		harr[i] = temp;
		heap_size--;

		MinHeapify(i);
		//display();
	}

}
 
void MinHeap::insertKey(int k)
{
	if(heap_size+1 <= capacity){
		harr[heap_size] = k;
		heap_size++;
		
		int index = heap_size-1;
		while(index){
			int p = parent(index);
			if(harr[p] > harr[index]){
				
				int temp = harr[p];
				harr[p] = harr[index];
				harr[index] = temp;

				index = p;
			}
			else break;

		}
	/*display();
	cout << endl;*/

	}
	//display();
}

int* MinHeap::getHeap()
{
	return harr;
}

void MinHeap:: display(){
	for (int i = 0; i < heap_size; ++i)
	{
		cout << harr[i]<< " ";
	}
	cout << endl;
}

#endif