#include <fstream>
#include <sys/time.h>
#include "sorts.cpp"

using namespace std;


int timeval_subtract (struct timeval *result, struct timeval *x, struct timeval *y);
// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    std::vector<long> v = HeapSort(nums);
    //cout << "made it out" << endl;
    std::vector<std::vector<long>> ans;
    long left = 0;
    long right = nums.size()-1;

    while(left != right && left < nums.size() && right >= 0){
        if(v[left] + v[right] == k){
            std::vector<long> s;
            s.push_back(v[left]);
            s.push_back(v[right]);
            ans.push_back(s);
            left++;
            right--;
        }
        else if(v[left] + v[right] < k){ //meaning need to increase left
            left++;
        }
        else if(v[left] + v[right] > k){ //meaning need to decrease right
            right--;
        }
    }
    return ans;

}


int main()
{
    struct timeval start, end, diff;

    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    gettimeofday(&start, NULL);
    vector< vector<long> > result = smartSearch(nums, k);
    gettimeofday(&end, NULL);
    timeval_subtract(&diff, &end, &start);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout<<endl<<"Result in "<<diff.tv_sec<<" seconds and "<<diff.tv_usec<<" microseconds."<<endl<<endl;
    
    return 0;
}

int timeval_subtract (struct timeval *result, struct timeval *x, struct timeval *y)
{

        // Perform the carry for the later subtraction by updating y.
        if (x->tv_usec < y->tv_usec)
        {
                int nsec = (y->tv_usec - x->tv_usec) / 1000000 + 1;
                y->tv_usec -= 1000000 * nsec;
                y->tv_sec += nsec;
        }
        if (x->tv_usec - y->tv_usec > 1000000)
        {
                int nsec = (x->tv_usec - y->tv_usec) / 1000000;
                y->tv_usec += 1000000 * nsec;
                y->tv_sec -= nsec;
        }

        // Compute the time remaining to wait.
        // tv_usec is certainly positive. 
        result->tv_sec = x->tv_sec - y->tv_sec;
        result->tv_usec = x->tv_usec - y->tv_usec;

        // Return 1 if result is negative.
        return x->tv_sec < y->tv_sec;
}