#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long size = nums.size();
	long arr[size];

	for (long i = 0; i < size; ++i){
		long x = nums[i]; 
		arr[i] = x;
		
		long j = i;
		while(j && arr[j-1] > x){
			arr[j] = arr[j-1];
			j--;
		}
		arr[j] = x;
		
	}
	std::vector<long> v;
	for (long i = 0; i < size; ++i)
	{
		v.push_back(arr[i]);
	}
	return v;
}

//=====================================================================================
List<long> Split(List<long> nums){
	long size = nums.length();
	if(size == 1) return nums;
	else{
		List<long> left;
		List<long> right;

		ListItem<long>* temp = nums.getHead();

		long mid = size/2;
		for (int i = 0; i < mid; ++i)
		{
			left.insertAtTail(temp->value);
			temp = temp->next;
		}
		for (int i = mid; i < size; ++i)
		{
			right.insertAtTail(temp->value);
			temp = temp->next;
		}

		return Merge(Split(left),Split(right));
	}
}

List<long> Merge(List<long> nums1, List<long> nums2){
	ListItem<long>* temp1 = nums1.getHead();
	ListItem<long>* temp2 = nums2.getHead();

	List<long> ans;

	while(temp1 != NULL && temp2 != NULL){
		if(temp1->value < temp2->value){
			ans.insertAtTail(temp1->value);
			temp1 = temp1->next;
		}
		else{
			ans.insertAtTail(temp2->value);
			temp2 = temp2->next;
		}
	}
	while(temp1){
		ans.insertAtTail(temp1->value);
		temp1 = temp1->next;
	}
	while(temp2){
		ans.insertAtTail(temp2->value);
		temp2 = temp2->next;
	}
	return ans;

}

vector<long> MergeSort(vector<long> nums)
{
	List<long> l;
	long size = nums.size();

	for (int i = 0; i < size; ++i)
	{
		l.insertAtTail(nums[i]);
	}
	List<long> v = Split(l);
	std::vector<long> ans;
	ListItem<long>* temp = v.getHead();

	while(temp != NULL)
	{
		ans.push_back(temp->value);
		temp= temp->next;
	}

	return ans;
}

//=====================================================================================
long* Concat(long* l, long* m, long* r, long sl, long sm, long sr){
	
	long* ans = new long[sl+sm+sr];

	for (int i = 0; i < sl; ++i)
	{
		ans[i] = l[i];
	}
	for (int i = 0; i < sm; ++i)
	{
		ans[sl+i] = m[i];
	}
	for (int i = 0; i < sr; ++i)
	{
		ans[sl+sm+i] = r[i];
	}
	return ans;
}

long* Qsort(long* arr, long size){
	//cout << size << " ";
	if(size <= 1){
		return arr;
	}
	else {

		long pivot = arr[size/2];
		long counter_left = 0;
		long counter_right = 0;
		long counter_middle =0;
		long* left;
		long* right;
		long* middle;

		for (int i = 0; i < size; ++i)
		{
			if(arr[i] < pivot){
				counter_left++;
			}
			else if(arr[i] > pivot){
				counter_right++;
			}
			else{
				counter_middle++;
			}
		}

		left = new long[counter_left];
		right = new long[counter_right];
		middle = new long[counter_middle];

		counter_left = 0;
		counter_right = 0;
		counter_middle =0;

		for (int i = 0; i < size; ++i)
		{
			if(arr[i] < pivot){
				left[counter_left] = arr[i];
				counter_left++;
			}
			else if(arr[i] > pivot){
				right[counter_right] = arr[i];
				counter_right++;
			}
			else{
				middle[counter_middle] = arr[i];
				counter_middle++;
			}
		}


		return Concat(Qsort(left, counter_left),middle,Qsort(right, counter_right), counter_left, counter_middle, counter_right);
	}

}

vector<long> QuickSortArray(vector<long> nums)
{
	long size = nums.size();
	long arr[size];
	for (int i = 0; i < size; ++i)
	{
		arr[i] = nums[i];
	}
	long* ans = Qsort(arr,size);
	std::vector<long> v;
	for (int i = 0; i < size; ++i)
	{
		v.push_back(ans[i]);
	}
	return v;
}

//=====================================================================================
List<long> ConactList(List<long> l, List<long> m, List<long> r){
	
	/*l.display_list();
	m.display_list();
	r.display_list();
	cout << endl;*/

	ListItem<long>* temp = m.getHead();
	while(temp != NULL){
		r.insertAtHead(temp->value);
		temp = temp->next;
	}
	temp = l.getHead();
	long sl = l.length();
	long arr[sl];
	for (int i = 0; i < sl; ++i)
	{
		arr[i]= temp->value;
		temp = temp->next;
	}
	for (int i = sl-1; i >=0; --i)
	{
		r.insertAtHead(arr[i]);
	}
	return r;
}

List<long> QsortList(List<long> nums){

	long size = nums.length();
	//cout << size << " ";
	if(size <= 1){
		return nums;
	}
	else {
		List<long> left;
		List<long> middle;
		List<long> right;
		
		ListItem<long>* temp = nums.getHead();
		srand(time(NULL));
		long ra = rand()% size;
		//cout << "ra: "<<ra << endl;
 		for (int i = 0; i < ra; ++i)
		{
			temp = temp->next;
		}
		//cout << "here" << endl;
		long pivot = temp->value;
		//cout << "pivot: " << pivot << endl;
		temp = nums.getHead();
		
		for (int i = 0; i < size; ++i)
		{
			if(temp->value < pivot){
				left.insertAtHead(temp->value);
			}
			else if(temp->value > pivot){
				right.insertAtHead(temp->value);
			}
			else{
				middle.insertAtHead(temp->value);
			}
			temp = temp->next;
		}

		return ConactList(QsortList(left),middle, QsortList(right));
	}
}

vector<long> QuickSortList(vector<long> nums)
{
	long size = nums.size();
	List<long> l;
	for (int i = size-1 ; i >=0 ; --i)
	{
		l.insertAtHead(nums[i]);
	}
	//cout << "here" << endl;
	List<long> ans = QsortList(l);
	//cout << "ot" << endl;
	ListItem<long>* temp = ans.getHead(); 
	std::vector<long> v;
	for (int i = 0; i < size; ++i)
	{
		v.push_back(temp->value);
		temp = temp->next;
	}
	
	return v;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	long size = nums.size();
	MinHeap h(size);
	for (int i = 0; i <size ; ++i)
	{
		h.insertKey(nums[i]);
	}
	//h.display();
	std::vector<long> v;
	for (int i = 0; i < size; ++i)
	{
		v.push_back(h.extractMin());
		//h.display();
	}
	return v;
}

#endif