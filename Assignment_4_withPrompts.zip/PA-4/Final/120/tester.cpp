#include <iostream>
#include <vector>
#include "sorts.cpp"


int main(int argc, char const *argv[])
{

	std::vector<long> v= {5,3,8,2,7,6,23, 0,23,-12,123,-123,-34};
	for (int i = 0; i < v.size(); ++i)
	{
		cout << v[i] << " ";
	}
	cout << endl;

	std::vector<long> a = QuickSortList(v);
	for (int i = 0; i < a.size(); ++i)
	{
		cout << a[i] << " ";
	}
	cout << endl;
	return 0;
}