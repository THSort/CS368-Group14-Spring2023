#include <fstream>
#include "sorts.cpp"
//#include "list.cpp"


using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
bool blazeIt(long complement, long* list, int start, int last)
{
	long listmidval = list[(start+last) / 2];

	if(listmidval == complement)
		return true;
	else
	{
		if (start == last)
			return false;

		int newval = (start + last)/2;

		if (listmidval > complement)
			last = newval;
		else
		{	
			if (start == newval)
				start++;
			else
				start = newval;
		}

		return blazeIt(complement, list, start, last);
	}
}
bool checkRepeat(long query, vector<vector<long> > vect)
{
	for (int i=0; i<vect.size(); i++)
	{
		if (vect[i][0] == query)
			return true;
	}
	return false;
}
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
	vector<long> sortd = HeapSort(nums);

	int length = nums.size();
	long* sorted = new long[length];
	for (int i=0; i<length; i++)
		sorted[i] = sortd[i];

	vector<vector<long> > ret;
	for (int i=0; i<length; i++)
	{
		vector<long> pair;
		long complement = k- sortd[i];

		if (blazeIt(complement, sorted, 0, length-1) == true && checkRepeat(complement, ret) == false)
		{
			pair.push_back(sortd[i]);
			pair.push_back(complement);
			ret.push_back(pair);
		}
	}
	return ret;
}

int main()
{
	vector<long> nums;
	ifstream in("random.txt");
	long n;
	while(in >> n)
		nums.push_back(n);
	in.close();

	long k;
	cout << "Enter the value of K: ";
	cin >> k;

	vector< vector<long> > result = smartSearch(nums, k);

	for(int i = 0; i < result.size(); i++)
		cout << result[i][0] << ", " << result[i][1] << endl;

	return 0;
}