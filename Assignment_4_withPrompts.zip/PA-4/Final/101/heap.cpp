#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	harr = new int[cap];
	capacity = cap;
	heap_size = 0;
}

void MinHeap::MinHeapify(int i)
{	
	int temp;
	if (i*2+2 > heap_size)
	{
		return;
	}
	else if (i*2+3 > heap_size)
	{
		temp = harr[left(i)];
		if (temp < harr[i])
		{
			harr[left(i)] = harr[i];
			harr[i] = temp;
		}		
	}
	else
	{
		if (harr[left(i)] < harr[right(i)])
		{
			temp = harr[left(i)];
			if (temp < harr[i])
			{
				harr[left(i)] = harr[i];
				harr[i] = temp;
				MinHeapify(left(i));
			}
		}
		else
		{
			temp = harr[right(i)];
			if (temp < harr[i])
			{
				harr[right(i)] = harr[i];
				harr[i] = temp;
				MinHeapify(right(i));
			}
		}
	}
}
 
int MinHeap::parent(int i)
{
	if (i==0)
		return -1;
	else
		return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i+1);
}
 
int MinHeap::right(int i)
{
	return (2*i+2);

}
 
int MinHeap::extractMin()
{
	if (heap_size == 0)
	{
		cout << "ERRROR heap empty%#$%@$%\n";
			return -1;
	}
	int ret = harr[0];
	heap_size--;
	harr[0] = harr[heap_size];
	harr[heap_size] = 0;
	MinHeapify(0);
	return ret;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	while (i>=0)
	{
		i = (parent(i));
		MinHeapify(i);
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{

	harr[i] = harr[heap_size-1];
	heap_size--;
	harr[heap_size] = 0;
	MinHeapify(i);
}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size] = k;
	heap_size++;
	for (int i=heap_size-1; i>=0;)
	{
		MinHeapify(i);
		i=parent(i);		
	}	

}

int* MinHeap::getHeap()
{
	return harr;
}

void MinHeap::printHeap(int i, int j)
{
	if (i+1 > heap_size)
		return;
	else
	{
		printHeap(right(i), j+4);
		for (int x=0; x<j; x++)
			cout << " ";
		cout << harr[i] << endl;
		printHeap(left(i), j+4);
	}
}

#endif
/*
int main()
{
	MinHeap dher(18);
	dher.insertKey(7);
	dher.insertKey(71);
	dher.insertKey(17);
	dher.insertKey(70);
	dher.insertKey(2);
	dher.insertKey(1);
	dher.insertKey(12);
	dher.insertKey(20);
	dher.insertKey(5);
	dher.printHeap(0,0);
	cout << "___\n" << dher.getMin() <<"___\n" << endl;
	dher.decreaseKey(3, 4);
	dher.printHeap(0,0);

return 0;
}

*/