#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	if (nums.size() < 2)
		return nums;
	int len = nums.size();
	long arr[len];
	for (int i=0; i<len; i++)
		arr[i] = nums[i];

	for (int i=1; i<len; i++)
	{
		long temp = arr[i];
		int j = i-1;
		while (j>=0 && temp<arr[j])
		{
			arr[j+1] = arr[j];
			j--;
		}
		arr[j+1] = temp;
	}
	vector<long> ret;
	for (int i=0; i<len; i++)
		ret.push_back(arr[i]);

	return ret;
}

//=====================================================================================
List<long> merge(List<long> left, List<long> right)
{
	List<long> ret;

	while(left.isEmpty() == false || right.isEmpty() == false)
	{
		long rightval;
		long leftval;
		if (left.isEmpty() == true)
		{
			while (right.isEmpty() == false)
			{
				rightval = (right.getTail())->value;
				ret.insertAtHead(rightval);
				right.deleteTail();
			}
			break;
		}
		if (right.isEmpty() == true)
		{
			while (left.isEmpty() == false)
			{
				leftval = (left.getTail())->value;
				ret.insertAtHead(leftval);
				left.deleteTail();
			}
			break;
		}
		rightval = (right.getTail())->value;
		leftval = (left.getTail())->value;
		if (rightval > leftval)
		{
			ret.insertAtHead(rightval);
			right.deleteTail();
		}
		else
		{
			ret.insertAtHead(leftval);
			left.deleteTail();
		}

	}
	return ret;
}
List<long> mergesShadow(List<long> nums)
{

	int xlength = nums.length();
	if (xlength > 1)	
	{
		int hlength = xlength/2;
		List<long> left, right;
		for (int i=0; i<hlength; i++)
		{
			long leftval = (nums.getHead())->value;
			left.insertAtHead(leftval);
			nums.deleteHead();
		}
		while (nums.isEmpty() == false)
		{
			long rightval = (nums.getHead())->value;
			right.insertAtHead(rightval);
			nums.deleteHead();
		}
		left = mergesShadow(left);
		right = mergesShadow(right);
		return merge(left, right);
	}
	else
		return nums;
}
vector<long> MergeSort(vector<long> nums)
{
	if (nums.size() < 2)
		return nums;

	cout << "MergeSortie invoked\n" << endl;
	List<long> llist;
	for (int i=0; i<nums.size(); i++)
		llist.insertAtHead(nums[i]);

	// cout << "MeregSortie invoked\n" << endl;

	llist = mergesShadow(llist);
	vector<long> ret;
	ListItem<long> *ptr = llist.getHead();
	while (ptr)
	{
		ret.push_back(ptr->value);
		ptr = ptr->next;
	}
	return ret;
}

//=====================================================================================
long* quickieSortie(long* arr, int left, int right)
{
	if (left >= right)
		return arr;

//	cout << "No segmentesh fault " << endl;
	long pivot = arr[right];
	long lindex = left;
	long rindex = right-1;
	while (lindex <= rindex)
	{
		while (arr[lindex] <= pivot && lindex <= rindex)
			lindex++;
		while (arr[rindex] >= pivot && rindex >= lindex)
			rindex--;

//		cout << "rindex-> " << rindex << endl;
		if (lindex<rindex)
		{
			long temp = arr[lindex];
			arr[lindex] = arr[rindex];
			arr[rindex] = temp;
		}
	}
	long temp = arr[lindex];
	arr[lindex] = arr[right];
	arr[right] = temp;
	arr = quickieSortie(arr, left, lindex-1);
//	return arr;
	arr = quickieSortie(arr, lindex+1, right);
	return arr;
}
vector<long> QuickSortArray(vector<long> nums)
{
	int length = nums.size();
	long* arr = new long [length];
	for (int i=0; i<length; i++)
	{
		arr[i] = nums[i];
	}

	long *ptr = quickieSortie(arr, 0, length-1);
	
	vector<long> ret;
	for (int i=0; i<length; i++)
		ret.push_back(ptr[i]);

	return ret;
}

//=====================================================================================
List<long>* QSortShadow(List<long>* input)
{
//	cout << "qsort werkin" << endl;
	if (input->length() < 2)
		return input;
	ListItem<long> *ptr = input->getHead();
	
	long pivot = ptr->value;

	List<long> *lesser = new List<long>;
	List<long> *equal = new List<long>;
	List<long> *greater = new List<long>;
	while (ptr)
	{
		if (ptr->value < pivot)
			lesser->insertAtHead(ptr->value);
		else if (ptr->value > pivot)
			greater->insertAtHead(ptr->value);
		else
			equal->insertAtHead(ptr->value);

		ptr = ptr->next;
	}
	lesser = QSortShadow(lesser);
	greater = QSortShadow(greater);

	ptr = equal->getHead();
	long append;
	// ListItem<long> *trvrsr = equal.getTail();
	while (ptr)
	{
		append = ptr->value;
		lesser->insertAtTail(append);
		// trvrsr->next = new ListItem<long>(append);
		// trvrsr->next->prev = trvrsr;
		// lesser.lengthplus();
		// trvrsr = trvrsr->next;
		ptr = ptr->next;
	}
	ptr = greater->getHead();
	ListItem<long>* trvrsr = lesser->getTail();
	while (ptr)
	{
		append = ptr->value;
		// lesser.insertAtTail(append);
		trvrsr->next = new ListItem<long>(append);
		trvrsr->next->prev = trvrsr;
		lesser->lengthplus();
		trvrsr = trvrsr->next;
		ptr = ptr->next;
	}
	return lesser;
}
	
vector<long> QuickSortList(vector<long> nums)
{
	if (nums.size() < 2)
		return nums;

	int lengthy = nums.size();
	List<long>* llist = new List<long>;
	for (int i=0; i<lengthy; i++)
		llist->insertAtHead(nums[i]);

	llist = QSortShadow(llist);

	vector<long> ret;
	ListItem<long> *ptr = llist->getHead();
	while (ptr)
	{
		ret.push_back(ptr->value);
		ptr = ptr->next;
	}
	return ret;

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap dher(nums.size());
	for (int i=0; i<nums.size(); i++)
	{
		dher.insertKey(nums[i]);
	}
	vector<long> ret;
	for (int i=0; i<nums.size(); i++)
	{
		ret.push_back(dher.extractMin());
	}

	return ret;
}

#endif


/*
int main()
{
	vector<long> v;
	v.push_back(1);
	v.push_back(20);
	v.push_back(5);
	v.push_back(7);
	// v.push_back(5);
	// v.push_back(7);
	v.push_back(0);
	v.push_back(10);
	v.push_back(12);
	v.push_back(11);
	v.push_back(4);
	// v.push_back(18);
	vector<long> vc = QuickSortArray(v);
	for (int i=0; i<vc.size(); i++)
		cout << "\n->" << vc[i];

	// List<long> a, b;
	// a.insertAtHead(303);
	// a.insertAtHead(31);
	// b.insertAtHead(300);
	// b.insertAtHead(30);
	// b.insertAtHead(13);
	// b.insertAtHead(4);
	// b.insertAtHead(3);

	// b = merge(a, b);
	// b.display_list();
// 	a.display_list();
// //	List<long> bc = merge(a, b);
// 	a = mergesShadow(a);
// 	a.display_list();
	return 0;
}*/