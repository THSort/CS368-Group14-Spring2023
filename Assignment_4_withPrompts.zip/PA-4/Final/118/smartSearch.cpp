#include <fstream>
#include "sorts.cpp"

using namespace std;


//====================================================================================================

// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    vector< vector<long> > result;
    // Write your code in this function
    vector<long> sorted = QuickSortArray(nums);
    int i=0;
    int j=sorted.size()-1;
    while(j-i>1){
        //cout << "i:" << i << endl;
        int sum=sorted[i]+sorted[j];
        if(sum==k){
            vector<long> row;
            vector<long> row1;
            row.push_back(sorted[i]);
            row.push_back(sorted[j]);
            row1.push_back(sorted[j]);
            row1.push_back(sorted[i]);
            result.push_back(row);
            result.push_back(row1);
            j--;
        }else if(sum<k){
            i++;
        }else{
            j--;
        }
    }
    return result;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();
    
    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}