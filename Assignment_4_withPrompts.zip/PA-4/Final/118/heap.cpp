#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	harr = new int[cap];
	// for(int i=0;i<capacity;i++){
	// 	harr[i]=0;
	// }
	heap_size=0;

}

void MinHeap::MinHeapify(int i)
{
	//repalce the key at index i with the min of child recursively
	//code percolate down
	//printHeap();
	if(heap_size<=1){
		return;
	}
	else if(i>=heap_size){
		return;
	}else{
		if(harr[left(i)]>harr[i] && harr[right(i)]>harr[i]){
			return;
		}else{
			if(harr[left(i)]<harr[right(i)] && left(i)<heap_size){
				//swap with left
				int temp=harr[i];
	  			harr[i]=harr[left(i)];
	  			harr[left(i)]=temp;
				MinHeapify(left(i));
			}else if(harr[right(i)]<harr[left(i)] && right(i)<heap_size){
				int temp=harr[i];
	  			harr[i]=harr[right(i)];
	  			harr[right(i)]=temp;
				MinHeapify(right(i));
			}
		}

	}
	
}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;

}
 
int MinHeap::left(int i)
{
	return ((2*i)+1);
}
 
int MinHeap::right(int i)
{
	return ((2*i)+2);
}
 
int MinHeap::extractMin()
{
	if(harr!=NULL){
		//swap
		int min=harr[0];
		harr[0]=harr[heap_size-1];
		//percolate down
		heap_size--;
		MinHeapify(0);
		return min;
	}
	
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	if(harr==NULL){
		return;
	}else{
		while(i>0){
			if(harr[parent(i)]>harr[i]){
			//swap
			int temp=harr[parent(i)];
			harr[parent(i)]=harr[i];
			harr[i]=temp;
			}else{
				return;
			}
		}
	}

}
 
int MinHeap::getMin()
{
	return harr[0];

}
 
void MinHeap::deleteKey(int i)
{
	if(i>heap_size-1){
		return;
	}else{
		harr[i]=harr[heap_size-1];
		heap_size--;
		MinHeapify(i);
	}
	
}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size]=k;
	heap_size++;
	int i=heap_size-1;
	while(i>0){
		if(harr[parent(i)]<harr[i]){
			return;
		}else{
			//swap
			int temp=harr[i];
			harr[i]=harr[parent(i)];
			harr[parent(i)]=temp;
			i=parent(i);
		}
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

void MinHeap::printHeap(){
	if(harr==NULL){
		return;
	}else{
		for(int i=0;i<heap_size;i++){
			cout << harr[i] << " "; 
		}
	}
	
	cout << endl;
}
// int main(){
// 	MinHeap obj(10);
// 	obj.insertKey(4);
// 	obj.insertKey(5);
// 	obj.insertKey(9);
// 	cout << "//////////////" << endl;
// 	obj.insertKey(1);
// 	obj.insertKey(2);
// 	obj.insertKey(3);
// 	obj.insertKey(7);
// 	obj.insertKey(10);
// 	obj.insertKey(-10);
// 	obj.insertKey(-3);
// 	obj.insertKey(-5);
	
// 	obj.printHeap();
// 	int min=obj.extractMin();
// 	cout << "min:" << min << endl;int min1=obj.extractMin();
// 	cout << "min:" << min1 << endl;
// 	obj.printHeap();
// }

#endif