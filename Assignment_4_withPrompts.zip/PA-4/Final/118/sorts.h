#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.h"
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);
vector<long> MergeSort(vector<long> nums);
vector<long> QuickSortArray(vector<long> nums);
vector<long> QuickSortList(vector<long> nums);
vector<long> HeapSort(vector<long> nums);
void swap(int *a,int *b);
void QuickSortA(long arr[],int start,int end);
int getIndex(long arr[],int i,int j);
void Msort(long arr[],int left,int right);
void merge(long arr[],int left,int mid,int right);
void QuickSortL(List<int> obj,ListItem<int>* i,ListItem<int>* j);
struct ListItem<int>* getNode(ListItem<int>* low,ListItem<int>* high);
void mergeLists(List<int> list1,List<int> mid,List<int> list2);
#endif