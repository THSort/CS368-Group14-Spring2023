#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include <array>
#include "list.h"
#include "list.cpp"
#include <fstream>
//====================================================================================================
// struct ListItem<int>* getNode(ListItem<int>* low,ListItem<int>* high){
// 	int pivot=high->value;
// 	ListItem<int> *a=low->prev;
// 	ListItem<int> *b=low;
// 	while(b!=high){
// 		//cout << "herere" << endl;
// 		if(b->value<=pivot){
// 			if(a==NULL){
// 				a=low;
// 			}else{
// 				a=a->next;
// 			}
// 			int temp=a->value;
// 			a->value=b->value;
// 			b->value=temp;
// 			//swap(&(a->value),&(b->value));

// 		}
// 		b=b->next;
// 	}
// 	//cout << "out" << endl;
// 	if(a==NULL){
// 		a=low;
// 	}else{
// 		a=a->next;
// 	}
// 	int temp=a->value;
// 	a->value=high->value;
// 	high->value=temp;
// 	//swap(&(a->value),&(high->value));
// 	return a;
// }
// 
// void QuickSortL(ListItem<int>* low,ListItem<int>* high){
// 	if(high != NULL && low!=high && low != high->next){
// 		struct ListItem<int>* mid = getNode(low,high);
// 		QuickSortL(low,mid->prev);
// 		QuickSortL(mid->next,high);
// 	}	
// }
//================================================================================================


void QuickSortL(List<int> list){
	ListItem<int>* i=list.getHead();
	ListItem<int>* j=list.getTail();
	int pivot = j->value;
	cout << "pivot:"<< pivot << endl;
	List<int> list1;
	List<int> mid;
	List<int> list2;
	ListItem<int>* temp;
	while(temp->next!=NULL){
		if(temp->value<pivot){
			list1.insertAtHead(temp->value);
		}else if(temp->value==pivot){
			mid.insertAtHead(temp->value);
		}else{
			list2.insertAtHead(temp->value);
		}
		temp=temp->next;
	}
	QuickSortL(list1);
	QuickSortL(list2);
}

//====================================================================================================

void merge(long arr[],int left,int mid,int right){
	int size1=(mid-left)+1;
	int size2=right-mid;
	int array1[size1];
	int array2[size2];
	//int a=0;
	for(int i=0;i<size1;i++){
		array1[i]=arr[left+i];
	}
	for(int i=0;i<size1;i++){
		array2[i]=arr[mid+1+i];
	}
	int a=0;
	int b=0;
	int mInd=left;
	while(a<size1 && b < size2){
		if(array1[a]>array2[b]){
			arr[mInd]=array1[a];
			a++;
		}else{
			arr[mInd]=array2[b];
			b++;
		}
		mInd++;
	}

	if(a==size1){
		while(b<size2){
			arr[mInd]=array2[b];
			b++;
			mInd++;
		}
	}else{
		while(a<size1){
			arr[mInd]=array1[a];
			a++;
			mInd++;
		}
	}

}
//=================================================================================================
void Msort(long arr[],int left,int right){
	if(left>=right){
		return;
	}else{
		int mid=left+(right-left)/2;
		Msort(arr,left,mid);
		Msort(arr,mid+1,right);
		merge(arr,left,mid,right);
	}
	
	// int size=length(arr)arr.size();
	// if(size<2){
	// 	return ;
	// }
	// int mid=size/2;
	// int array1[mid];
	// int array2[size-mid];
	// for(int i=0;i<mid;i++){
	// 	array1[i]=arr[i];
	// }
	// for(int i=mid+1;i<size;i++){
	// 	array2[i]=arr[i];
	// }
	// size=size/2;
	// Msort(array1);
	// Msort(array2);

}
//====================================================================================================
int getIndex(long arr[],int i,int j){
	int pivot=arr[j];
	int pIndex=i;
	for(int n=i;n<j;n++){
		if(arr[n]<=pivot){
			//swap arr[i] and arr[j]
				int temp=arr[n];
				arr[n]=arr[pIndex];
				arr[pIndex]=temp;
			pIndex++;
		}
	}
	int temp=arr[pIndex];
	arr[pIndex]=arr[j];
	arr[j]=temp;
	return pIndex;


	// int pivot=arr[j];
	// while(i!=j){
	// 	while(arr[i]<pivot){
	// 		i++;
	// 	}
	// 	while(arr[j]>pivot){
	// 		j--;
	// 	}
	// 	//swap arr[i] and arr[j]
	// 	int temp=arr[i];
	// 	arr[i]=arr[j];
	// 	arr[j]=temp;	
	// }
	// return i;

}
//=====================================================================================
void QuickSortA(long arr[],int low,int high){
	//QuickSortA(arr,0,i-1);
	//int size=(sizeof(arr)/sizeof(arr[0]));

	if(low>high){
		return;
	}
	int pIndex=getIndex(arr,low,high);
	QuickSortA(arr,low,pIndex-1);
	QuickSortA(arr,pIndex+1,high);	

}

// }
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long arr[nums.size()];
	for(int i=0;i<nums.size();i++){
		arr[i]=nums[i];
	}
	int index=0;
	while(index < nums.size()-1){
		index++;
		int toShift=arr[index];
		int temp=index-1;
		while(arr[temp]>toShift && temp>=0){
			arr[temp+1]=arr[temp];
			temp--;
			}
			arr[temp+1]=toShift;			
		}
	for(int i=0;i<nums.size();i++){
		nums[i]=arr[i];
	}
	return nums;

}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	int size=nums.size();
	long arr[size];
	for(int i=0;i<size;i++){
		arr[i]=nums[i];
	}
	int left=0;
	int right=nums.size()-1;
	Msort(arr,left,right);
	for(int i=0;i<size;i++){
		nums[i]=arr[size-i-1];
	}
	//cout << "done" << endl;
	return nums;
}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
	long arr[nums.size()];
	for(int i=0;i<nums.size();i++){
		arr[i]=nums[i];
	}
	int i=0;
	int j=nums.size()-1;
	QuickSortA(arr,i,j);
	for(int i=0;i<nums.size();i++){
		nums[i]=arr[i];
	}
	return nums;

}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	List<int> obj;
	for(int i=0;i<nums.size();i++){
		obj.insertAtTail(nums[i]);
	}
	ListItem<int>* i=obj.getHead();
	ListItem<int>* j=obj.getTail();
	//QuickSortL(i,j);
	QuickSortL(obj);
	//List<int> result=mergeLists(List<int> list1,List<int> mid,List<int> list2);
	ListItem<int>* head=obj.getHead();
	for(int i=0;i<nums.size();i++){
		nums[i]=head->value;
		head=head->next;
	}
	return nums;

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap harr(nums.size());
	for(int i=0;i<nums.size();i++){
		harr.insertKey(nums[i]);
	}
	int i=0;
	while(i<nums.size()){
		int min=harr.extractMin();
		nums[i]=min;
		i++;
	}
	return nums;
}

void swap(int *a ,int *b){
	int temp=*a;
	*a=*b;
	*b=temp;

}
// int main(){
// 	std::vector<long> vec;
// 	vec.push_back(4);
// 	vec.push_back(5);
// 	vec.push_back(9);
// 	vec.push_back(1);
// 	vec.push_back(2);
// 	vec.push_back(3);
// 	vec.push_back(10);
// 	vec.push_back(7);


// 	//vec.push_back(10);
// 	//vec.push_back(-10);
// 	//vec.push_back(0);
// 	//vec.push_back(1);


// 	for(int i=0;i<vec.size();i++){
// 		cout << vec[i] << " ";
// 	}
// 	//cout << endl;
// 	// vector<long> new_vec=InsertionSort(vec);
// 	// for(int i=0;i<vec.size();i++){
// 	// 	cout << new_vec[i] << " ";
// 	// }
// 	// cout << endl;
// 	// cout << "heap sort" << endl;
// 	// vector<long> heap_vec=HeapSort(vec);
// 	// for(int i=0;i<vec.size();i++){
// 	// 	cout << heap_vec[i] << " ";
// 	// }
// 	// cout << endl;
// 	// vector<long> QSA=QuickSortArray(vec);
// 	// cout << endl;
// 	// cout << "merge sorted" << endl;
// 	// vector<long> MSA=MergeSort(vec);
// 	// for(int i=0;i<vec.size();i++){
// 	// 	cout << MSA[i] << " ";
// 	// }
// 	cout << endl;
// 	cout << "quick sorted list" << endl;
// 	vector<long> QSL=QuickSortList(vec);
// 	for(int i=0;i<vec.size();i++){
// 		cout << QSL[i] << " ";
// 	}
// 	cout << endl;



// }



#endif