#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.h"
#include <vector>

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
  long numsAr[nums.size()];

  for(int i=0; i<nums.size(); i++)
  {
  	numsAr[i] = nums[i];
  }

  long ValToCheck;
  for(int i = 1; i < nums.size(); i++)
  {
     ValToCheck = numsAr[i];
     int j = i;
     while(j > 0 && numsAr[j-1] > ValToCheck)
     {
        numsAr[j] = numsAr[j-1];
        j--;
     }
     numsAr[j] = ValToCheck;
  }

  for(int i=0; i<nums.size(); i++)
  {
  	nums[i] = numsAr[i];
  }

  return nums;
}

//=====================================================================================

vector<long> MergeSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{

}

#endif