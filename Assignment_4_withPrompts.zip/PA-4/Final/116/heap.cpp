#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"

int swaper(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

MinHeap::MinHeap(int cap)
{
	capacity = cap;
	heap_size = 0;
	harr = new int[capacity];
}

void MinHeap::MinHeapify(int i)
{
    int parent = i;
	int leftC = left(i);
    int rightC = right(i);
    if (leftC < heap_size && harr[leftC] < harr[i])
    {
        parent = leftC;
    }
    if (rightC < heap_size && harr[rightC] < harr[parent])
    {
        parent = rightC;
    }

    if (parent != i)
    {
        swaper(&harr[i], &harr[parent]);
        MinHeapify(parent);
    }
}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i + 1);
}
 
int MinHeap::right(int i)
{
	return (2*i + 2);
}
 
int MinHeap::extractMin()
{
    int minV = getMin();
   	harr[0] = harr[heap_size-1];
	heap_size--;
	if(heap_size > 0)
	{
		MinHeapify(0);
	}
    return minV;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	while (i != 0 && harr[parent(i)] > harr[i])
    {
       swaper(&harr[i], &harr[parent(i)]);
       i = parent(i);
    }
}
 
int MinHeap::getMin()
{
	if(heap_size == 0)
	{
		return INT_MAX;
	}
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i >= heap_size)
	{
		return;
	}
	decreaseKey(i, INT_MIN);
	extractMin();
}
 
void MinHeap::insertKey(int k)
{
	if(heap_size == capacity)
	{
		return;
	}
	harr[heap_size] = k;
	heap_size++;
	int x = heap_size - 1;
	while (x != 0 && harr[parent(x)] > harr[x])
    {
       swaper(&harr[x], &harr[parent(x)]);
       x = parent(x);
    }
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif