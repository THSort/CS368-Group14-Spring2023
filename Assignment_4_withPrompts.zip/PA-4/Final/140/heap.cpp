#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
    capacity = cap;
    heap_size = 0;
    harr = new int [capacity];
}

void MinHeap::MinHeapify(int i)
{
    //compare harr[i] with children and swap with smaller child. Continue doing so recursively
    if (left(i) < heap_size && harr[left(i)] < harr[i])
    {
        if (right(i) < heap_size && harr[right(i)] < harr[left(i)])
        {
            int temp = harr[i];
            harr[i] = harr[right(i)];
            harr[right(i)] = temp;
            MinHeapify(right(i));
        }
        else
        {
            int temp = harr[i];
            harr[i] = harr[left(i)];
            harr[left(i)] = temp;
            MinHeapify(left(i));
        }
    }

    else if (right(i) < heap_size && harr[right(i)] < harr[i])
    {
        int temp = harr[i];
        harr[i] = harr[right(i)];
        harr[right(i)] = temp;
        MinHeapify(right(i));
    }
}

int MinHeap::parent(int i)
{
    int prnt = ((i-1)/2); //return type int so prnt is automatically the "floor" of (i-1)/2
    return prnt;
}

int MinHeap::left(int i)
{
    int lft = (2*i) + 1;
    return lft;
}

int MinHeap::right(int i)
{
    int rt = (2*i) + 2;
    return rt;
}

int MinHeap::extractMin()
{
    int OriginalRoot = harr[0]; //storing temporary value to return even after it is deleted. return type of function is int
    harr[0] = harr[heap_size-1]; //swap value with last element in array, as discussed in class
    MinHeapify(0);
    heap_size--;
    return OriginalRoot;
}

void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i] = new_val;
    RestoreHeapOrder(i);
}

int MinHeap::getMin()
{
    return harr[0];
}

void MinHeap::deleteKey(int i)
{
    if (i<heap_size)
    {
        harr[i] = harr[heap_size-1];
        heap_size--;
        MinHeapify(i);
    }

    //OR use implementation below, but choosing a very small number isn't foolproof
    /*if (i<heap_size)
    {
        int PotentialRoot = -9999999; //very very small number
        harr[i] = PotentialRoot; //original number at index i now replaced (practically "deleted") by a very small number.
        RestoreHeapOrder(i); //very small number i.e. potential root should become the root
        extractMin();
    }*/
}

void MinHeap::insertKey(int k)
{
    if (heap_size != capacity) //will have to first increase capacity before key can be inserted
    {
        harr[heap_size] = k; //heap structure is such that heap_size would be the first index where array empty (indexing starts from 0)
        RestoreHeapOrder(heap_size);
        heap_size++;
    }
}

int* MinHeap::getHeap()
{
	return harr;
}

//Recursively compares key at index with that at parent and makes necessary swaps to eliminate violation of heap order property
void MinHeap::RestoreHeapOrder (int index)
{
    while (index > 0 && harr[index] < harr[parent(index)]) //when index == 0, root reached so stop
    {
        {
            int temp = harr[index];
            harr[index] = harr[parent(index)];
            harr[parent(index)] = temp;
            index = parent(index);
        }
    }
}

#endif
