#include <fstream>
#include "sorts.cpp"
#include "bst.cpp"
#include <ctime> //to measure time

using namespace std;

/*bool binarySearch (vector<long> sorted, long num, long start, long finish)
{
    if (start >= finish)
    {
        return false;
    }
    int mid = (start+finish)/2;
    if (sorted[mid] == num)
    {
        return true;
    }
    else if (sorted[mid] > num) //check left half of vector only
    {
        return binarySearch(sorted, num, start, mid-1);
    }
    else if (sorted[mid] < num)
    {
        return binarySearch(sorted, num, mid+1, finish);
    }
}

// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    vector<long> sortedNums = HeapSort(nums);
    vector<vector<long>> pairs;
    for (int i=0; i<nums.size(); i++) //traverse whole vector
    {
        if (nums[i] <= k) //if it isn't less than or equal to k then no pair can be formed from it. Assumption: Addition of positive numbers
        {
            long NumsPair = k - nums[i];
            if (binarySearch(sortedNums, NumsPair, 0, sortedNums.size())) //NumsPair present
            {
                vector<long> onePair;
                onePair.push_back(nums[i]);
                onePair.push_back(NumsPair);

                pairs.push_back(onePair); //add above one pair to main vector to return
            }
        }
    }
    return pairs;
}*/

vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    time_t start, end;
    time(&start);

    vector<vector<long>> pairs;
    BST<long> numbers;
    for (int i=0; i<nums.size(); i++) //traverse whole vector
    {
        numbers.insert("0", nums[i]);
    }
    for (int i=0; i<nums.size(); i++) //traverse whole vector
    {
        long NumsPair = k - nums[i];
        if (numbers.search(NumsPair) != NULL)
        {
            vector<long> onePair;
            onePair.push_back(nums[i]);
            onePair.push_back(NumsPair);

            pairs.push_back(onePair); //add above one pair to main vector to return
        }
    }

    time(&end);
    double dif = difftime (end,start);
    cout << "Time Taken for SmartSearch to execute: " <<  dif << " seconds" << endl;

    return pairs;
}

int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}
