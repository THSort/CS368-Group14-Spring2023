#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include <cstdlib>

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
    //create array from vector
    long arr [nums.size()];
    for (int i=0; i<nums.size(); i++)
    {
        arr[i] = nums[i];
    }

    for (int j=1; j<nums.size(); j++) //look at every element of the array
    {
        for (int k=j; k>0 && arr[k-1] > arr[k]; k--) //insert arr[j] in sorted order in array preceding its index
        {
                int temp = arr[k-1];
                arr[k-1] = arr[k];
                arr[k] = temp;
        }
    }

    //recreate vector
    vector<long> sorted;
    for (int i=0; i<nums.size(); i++)
    {
        sorted.push_back(arr[i]);
    }

    return sorted;
}

//=====================================================================================
//Can be made A LOT faster by passing ListItem instead of List as argument but test being passed anyway so won't make the change
vector<long> MergeSort(vector<long> nums)
{
    List<long>* LL = new List<long>;
    for (int i=0; i<nums.size(); i++)
    {
        LL->insertAtHead(nums[i]);
    }

    List<long>* sortedList = MergeSortList(LL);

    ListItem<long>* current = sortedList->getHead();
    vector<long> sorted;
    for (int i=0; i<nums.size(); i++)
    {
        sorted.push_back(current->value);
        current = current->next;
    }

    return sorted;
}


//breaks one list into two from middle
List<long>* middle (List<long>* LL)
{
    ListItem<long>* mid = LL->getHead();
    ListItem<long>* justBeforeMid = new ListItem<long> (0); //this ptr would be the tail of first list
    for (int i=0; i<(LL->length()/2); i++)
    {
        if (i == (LL->length()/2)-1)
        {
            justBeforeMid = mid;
        }
        mid = mid->next;
    }
    justBeforeMid->next = NULL; //LL is half of the original list now
    List<long>* fromMiddle = new List<long>;
    fromMiddle->setHead(mid); //fromMiddle the other half list now
    return fromMiddle;
}

List<long>* MergeLists (List<long>* listOne, List<long>* listTwo)
{
    List<long>* sortedList = new List<long>;
    ListItem<long> *currentOne = listOne->getHead();
    ListItem<long> *currentTwo = listTwo->getHead();

    while (currentOne != NULL && currentTwo != NULL)
    {
        if (currentOne->value > currentTwo->value)
        {
            sortedList->insertAtHead(currentTwo->value);
            currentTwo = currentTwo->next;
        }
        else if (currentTwo->value > currentOne->value)
        {
            sortedList->insertAtHead(currentOne->value);
            currentOne = currentOne->next;
        }
        else if (currentOne->value == currentTwo->value)
        {
            sortedList->insertAtHead(currentOne->value);
            sortedList->insertAtHead(currentTwo->value);
            currentOne = currentOne->next;
            currentTwo = currentTwo->next;
        }
    }

    //now check which list traversal complete
    if (currentOne == NULL && currentTwo != NULL)    //all listOne elements in sortedList now. Only need to add listTwo elements now.
    {
        while (currentTwo != NULL)
        {
            sortedList->insertAtHead(currentTwo->value);
            currentTwo = currentTwo->next;
        }
    }
    else if (currentTwo== NULL && currentOne!= NULL)
    {
        while (currentOne!= NULL)
        {
            sortedList->insertAtHead(currentOne->value);
            currentOne = currentOne->next;
        }
    }

    sortedList->reverse(); //added reverse implementation to use insertAtHead instead of insertAtTail. Using same reverse in list.cpp that I used in my LinkedList.cpp implementation
    return sortedList;
}

List<long>* MergeSortList (List<long>* LL)
{
    ListItem<long>* ListHead = LL->getHead();
    if (LL->length() == 0 || LL->length() == 1) //or simply use if (LL->length > 1) ??
    {
        return LL;
    }
    List<long>* secondHalf = middle(LL); //LL now first half bc of how middle() is implemented
    LL = MergeSortList(LL);
    secondHalf = MergeSortList(secondHalf);

    return MergeLists(LL, secondHalf);
}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
    //srand(time(NULL));
    long* arr = new long [nums.size()];
    for (int i=0; i<nums.size(); i++)
    {
        arr[i] = nums[i];
    }

    QuickSortArr(arr, 0, nums.size()-1);

    vector<long> sorted;
    for (int i=0; i<nums.size(); i++)
    {
      sorted.push_back(arr[i]);
    }

    return sorted;
}

//using last element fastest experimentally, although difference was minor
void QuickSortArr(long arr[], int low, int high)
{
    if (high - low < 1)
    {
        return;
    }

    int i = low;
    int j = high-1;
    long pivot = arr[high];
    //arr[high] = arr[high];
    arr[high] = pivot;

    while (i <= j)
    {
        while (arr[i] <= pivot && i <= j)
        {
            i++;
        }
        while (arr[j] >= pivot && i <= j)
        {
            j--;
        }
        //swap if i has not crossed j
        if (i<=j)
        {
            long temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }

    //swap the pivot back to i
    arr[high] = arr[i];
    arr[i] = pivot;

    QuickSortArr(arr, low, i-1);
    QuickSortArr(arr, i+1, high);
}

//using median of 3
/*void QuickSortArr(long arr[], int low, int high)
{
    //if (high - low <= 1)
    if (low > high)
    {
        return;
    }

    int i = low;
    int j = high-1;

    long pivot;
    if (low != 0)
    {
        int indices = high - low;
        int pos1 = rand() % low + indices; //if low = 0 then issue
        int pos2 = rand() % low + indices;
        int pos3 = rand() % low + indices;
        if (arr[pos1] > arr[pos3])
        {
            long temp = arr[pos1];
            arr[pos1] = arr[pos3];
            arr[pos3] = temp;
        }
        if (arr[pos1] > arr[pos2])
        {
            long temp1 = arr[pos1];
            arr[pos1] = arr[pos2];
            arr[pos2] = temp1;
        }
        //Now the smallest element is at pos1
        if (arr[pos2] > arr[pos3])
        {
            long temp2 = arr[pos2];
            arr[pos2] = arr[pos3];
            arr[pos3] = temp2;
        }
        pivot = arr[pos2];
        arr[pos2] = arr[high];
        arr[high] = pivot;
    }
    else
    {
        int mid = (high+low)/2;
        pivot = arr[mid];
        arr[mid] = arr[high];
        arr[high] = pivot;
    }
    while (i <= j)
    {

        while (arr[i] <= pivot && i <= j)
        {
            i++;
        }
        while (arr[j] >= pivot && i <= j)
        {
            j--;
        }
        if(i > j)
        {
            break;
        }
        long temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    //swap the pivot back to i
    arr[high] = arr[i];
    arr[i] = pivot;

    QuickSortArr(arr, low, i-1);
    QuickSortArr(arr, i+1, high);
}*/

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
    srand(time(NULL));
    List<long>* LL = new List<long>;
    for (int i=0; i<nums.size(); i++)
    {
        LL->insertAtHead(nums[i]);
    }

    ListItem<long>* sortedListHead = QuickSortLL(LL->getHead());

    vector<long> sorted;
    for (int i=0; i<nums.size(); i++)
    {
        sorted.push_back(sortedListHead->value);
        sortedListHead = sortedListHead->next;
    }

    return sorted;
}

ListItem<long>* QuickSortLL (ListItem<long>* ListHead)
{
    if (ListHead == NULL || ListHead->next == NULL)
    {
        return ListHead;
    }
    else
    {
        long ListLength = 0;
        ListItem<long>* traverse = ListHead;
        while (traverse != NULL)
        {
            ListLength++;
            traverse = traverse->next;
        }

        long pivot_pos = rand() % ListLength; //choose random pivot
        ListItem<long>* pivotPtr = ListHead;
        for (int i=0; i<pivot_pos; i++)
        {
            pivotPtr = pivotPtr->next;
        }
        long pivot = pivotPtr->value;

        List<long>* LessThanPivot = new List<long>;
        List<long>* GreaterThanPivot = new List<long>;
        List<long>* EqualToPivot = new List<long>;
        ListItem<long>* current = ListHead;
        while (current != NULL)
        {
            if (current->value < pivot)
            {
                LessThanPivot->insertAtHead(current->value);
            }
            else if (current->value > pivot)
            {
                GreaterThanPivot->insertAtHead(current->value);
            }
            else
            {
                EqualToPivot->insertAtHead(current->value);
            }
            current = current->next;
        }

        ListItem<long>* currentLess = QuickSortLL(LessThanPivot->getHead());
        ListItem<long>* currentGreater = QuickSortLL(GreaterThanPivot->getHead());
        ListItem<long>* currentEqual = EqualToPivot->getHead();

        //link Less, EqualToPivot and Greater
        List<long>* sortedLL = new List<long>;

        while (currentLess != NULL)
        {
            sortedLL->insertAtHead(currentLess->value);
            currentLess = currentLess->next;
        }
        while (currentEqual != NULL)
        {
            sortedLL->insertAtHead(currentEqual->value);
            currentEqual = currentEqual->next;
        }
        while (currentGreater != NULL)
        {
            sortedLL->insertAtHead(currentGreater->value);
            currentGreater = currentGreater->next;
        }
        sortedLL->reverse(); //using insertAtHead instead of insertAtTail so sortedLL previously in descending order

        return sortedLL->getHead();
    }
}
//=====================================================================================

vector<long> HeapSort(vector<long> nums)
{
    MinHeap h1 (nums.size());
    for (int i=0; i<nums.size(); i++)
    {
        h1.insertKey(nums[i]);
    }

    vector<long> sorted;
    for (int i=0; i<nums.size(); i++)
    {
        sorted.push_back(h1.extractMin());
    }

    return sorted;
}

#endif
