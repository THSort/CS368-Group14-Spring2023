#ifndef __BST_CPP
#define __BST_CPP
#include "bst.h"
#include <iostream>
#include <queue>
// HELPER FUNCTIONS HERE...
template <class T>
BST<T>::BST(){
	root = NULL;
}

template <class T>
BST<T>::BST(node<T>* p){
	root = p;
}


template <class T>
BST<T>:: ~BST(){

    // your destructor code goes here
}

template <class T>
bool BST<T> :: isLeaf(node<T>* p)
{
    if (p != NULL && p->left == NULL && p->right == NULL)
    {
        return true;
    }
    return false;
}

//height functions works (score = 5/5) for test2 individually but doesn't give result desired by test case once balancing has been implemented.
//Issue discussed with TA
template <class T>
int BST<T> :: height (node<T>* p)
{
    if (p == NULL) //height of leaf node is defined 1, thus when p==NULL, height taken as 0
    {
        return 0;
    }
    return p->height;
}

template <class T>
int BST<T> :: balanceFactor(node<T>* p){
    //height difference?
    // you can use this to find balance factor.
    if (p)
    {
        return height(p->left) - height(p->right);
    }
    return 0;
}

template <class T>
void BST<T> :: fixHeight(node<T>* p){
    // use this function to fix height of a node after insertion or deletion.
    if (p == NULL)
    {
        return;
    }
    if (isLeaf(p)) //unnecessary?
    {
        p->height = 1;
    }
    else
    {
        if (height(p->right) > height(p->left))
        {
            p->height = 1 + height(p->right);
        }
        else
        {
            p->height = 1 + height(p->left);
        }
    }
    return;
}

// ROTATING HELPERS
template <class T>
node<T>* BST<T> :: rotateleft(node<T>* p){
    // Rotate left code goes here.
    node<T>* temp = p->right->left; //right child, which would now be swapped, can have a left child and we do not want to lose that information
    node<T>* originalRightChild = p->right;
    p->right->left = p;
    p->right = temp;

    fixHeight(p);
    fixHeight(originalRightChild);

    return originalRightChild;
}

template <class T>
node<T>* BST<T> :: rotateright(node<T>* p){
    // Rotate right code goes here
    node<T>* temp = p->left->right; //left child, which would now be swapped, can have a right child and we do not want to lose that information
    node<T>* originalLeftChild = p->left;
    p->left->right = p;
    p->left = temp;

    fixHeight(p);
    fixHeight(originalLeftChild);

    return originalLeftChild;
}

template <class T>
node<T>* BST<T> :: balance(node<T>* p){
    //Case 1: R-R. Solution: Left rotate p.
    //Case 2: L-L. Solution: Right rotate p.
    //Case 3: R-L. Solution: Right rotate right child. Then left rotate p.
    //Case 4: L-R. Solution: Left rotate left child. Then right rotate p.
    int issue; //issue == case
    if (balanceFactor(p) < -1) //right heavy. Either case 1 or case 3.
    {
        if (balanceFactor(p->right) > 0) //right child is left heavy
        {
            issue = 3;
        }
        else
        {
            issue = 1;
        }
    }
    else if (balanceFactor(p) > 1) //left heavy. Either case 2 or case 4.
    {
        if (balanceFactor(p->left) < 0) //left child is right heavy
        {
            issue = 4;
        }
        else
        {
            issue = 2;
        }
    }
    switch (issue)
    {
        case 1:
            {
                p = rotateleft(p);
            }
            break;
        case 2:
            {
                p = rotateright(p);
            }
            break;
        case 3:
            {
                p->right = rotateright(p->right);
                p = rotateleft(p);
            }
            break;
        case 4:
            {
                p->left = rotateleft(p->left);
                p = rotateright(p);
            }
            break;
        default:
            {}
    }
    fixHeight(p);
    return p;
    // Balancing code goes here. You might need to find balance factor and call appropriate rotations.
}

// CLASS FUNCTIONS HERE
template <class T>
void BST<T> :: insert(string value,T k)
{
    if (search(k) == NULL)
    {
        if (root == NULL)
        {
            root = new node<T> (k, value);
        }
        else
        {
            root = insertHelper(value,k,root);
        }
    }
}

// insertion helper
template <class T>
node<T>* BST<T> :: insertHelper(string value,T k, node<T> *p) { // note we need a helper because we need recursive calls
    // Insertion code goes here.
    /*if (k == p->key) //key already present
    {
        return NULL;
    }*/ //this check redundant since similar check applied in insert function
    if (k > p->key)
    {
        if (p->right == NULL) //insert at right
        {
            node<T>* toInsert = new node<T> (k, value);
            p->right = toInsert;
        }
        else //recursively insert at right
        {
           p->right = insertHelper(value, k, p->right);
        }
    }
    else
    {
        if (p->left == NULL) //insert at left
        {
            node<T>* toInsert = new node<T> (k, value);
            p->left = toInsert;
        }
        else //recursively insert at left
        {
            p->left = insertHelper(value, k, p->left);
        }
    }
    return balance(p);
}

template<class T>
node<T>* BST<T> :: search(T key){
    node<T>* current = root;
    while (current != NULL)
    {
        if (key == current->key)
        {
            return current;
        }
        else if (key > current->key)
        {
            current = current->right;
        }
        else
        {
            current = current->left;
        }
    }
    return NULL;
    // Search code goes here.
}
// DELETE HELPER FUNCTIONS
template<class T>
node<T>* BST<T> :: findmin(node<T> *p){
    // This function finds the min node of the tree.
    node<T>* minNode = p;
    if (minNode != NULL)
    {
        while (minNode->left != NULL)
        {
            minNode = minNode->left;
        }
        return minNode;
    }
}

template<class T>
node<T>* BST<T>::removemin(node<T>* p) {
    if (p->left == NULL)
    {
        delete p;
    }
    else
    {
        removemin(p->left);
    }
    return p;
    // This function recursively finds the min node and deletes it.
}

template<class T>
void BST<T>::delete_node(T k){
    if(search(k) != NULL)
    {
        root = remove(root, k);
    }
}

template<class T>
node<T>*  BST<T>::remove(node<T>* p, T k) // k key deletion from p tree
{
    //0 children, just delete it
    //1 child, delete it, connect child to parent
    //2 children, copy the smallest key in the subtree and delete recursively
    if (p == NULL)
    {
        return p;
    }
    else if (k > p->key)
    {
        p->right = remove(p->right, k);
    }
    else if (k < p->key)
    {
        p->left = remove(p->left, k);
    }

    else //key is on current node
    {
        //Case 1: Leaf node
        if (p->left == NULL && p->right == NULL)
        {
            delete p; //p = NULL so don't need to take care about parent
            p = NULL;
        }

        //Case 2: One child
        //right child only
        else if (p->left == NULL && p->right != NULL)
        {
            node<T>* temp = p->right;
            p->key = temp->key;
            p->value = temp->value;
            p->right = temp->right;
            p->left = temp->left;
            delete temp;
        }
        //left child only
        else if (p->right == NULL && p->left != NULL)
        {
            node<T>* temp = p->left;
            p->key = temp->key;
            p->value = temp->value;
            p->right = temp->right;
            p->left = temp->left;
            delete temp;
        }

        //Case 3: 2 children
        else if (p->right != NULL && p->left != NULL)
        {
            node<T>* immediate_ancestor = findmin(p->right);
            p->key = immediate_ancestor->key;
            p->value = immediate_ancestor->value;
            p->right = remove(p->right, immediate_ancestor->key);
        }
	}
    return balance(p);
    // This function uses findmin and deletemin to delete arbitrary node in the tree.
}

template<class T>
node<T>* BST<T>::getRoot(){
    return root;
}

template<class T>
void BST<T>::print(node<T>* p){
    if (p == NULL)
        return;
    else
    {
        print(p->left);
        cout << "Key: " << p->key << ", Value: " << p->value << endl;
        print(p->right);
    }
}

#endif
