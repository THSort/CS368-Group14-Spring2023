#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);

vector<long> MergeSort(vector<long> nums);
List<long>* middle (List<long>* LL); //divides LL into two linked lists from middle
List<long>* MergeLists (List<long>* listOne, List<long>* listTwo); //makes on sorted list from two lists
List<long>* MergeSortList (List<long>* LL); //recursively mergesorts list

vector<long> QuickSortArray(vector<long> nums);
void QuickSortArr(long arr[], int start, int finish);

vector<long> QuickSortList(vector<long> nums);
//List<long>* QuickSortLL (List<long>* LL);
ListItem<long>* QuickSortLL (ListItem<long>* LL);

vector<long> HeapSort(vector<long> nums);

#endif
