#ifndef __BST_CPP
#define __BST_CPP
#include "bst.h"
#include <iostream>
#include <queue>
// HELPER FUNCTIONS HERE...
template <class T>
BST<T>::BST(){
    root = NULL;
}

template <class T>
BST<T>:: ~BST(){

    // your destructor code goes here

    while(root!=NULL)
    {
        root=remove(root, root->key);
    }


}


template <class T>
int BST<T> :: height (node<T>* p){
   // your find height code goes here
    if(p==NULL) 
        {
            return 0;
        }
    if(p->left==NULL && p->right==NULL) // leaf node
    {
        return 1;
    }

    else if(p->left==NULL && p->right!=NULL)
    {
        return (p->right->height +1);
    }

    else if(p->left!=NULL && p->right==NULL)
    {
        return (p->left->height +1);
    }
    
    else if(p->left!=NULL && p->right!=NULL)
    {
        int lefth=p->left->height;
        int righth=p->right->height;

        if(lefth>righth)
        {
            return lefth+1;
        }
        else
        {
            return righth+1;
        }
    }
    
}

template <class T>
int BST<T> :: balanceFactor(node<T>* p){
    // you can use this to find balance factor.

    if(p==NULL) return 0; 
    
    else if(p->height<2) return 1;// only leaf node

    int right_height=0;
    int left_height=0;


    if(p->right) right_height=p->right->height;
    if(p->left) left_height=p->left->height;


    int factor=left_height-right_height;

    return factor;
}

template <class T>
void BST<T> :: fixHeight(node<T>* p){
    // use this function to fix height of a node after insertion or deletion.
    if(p==NULL) return;
    int r = height(p->right);
    int l = height(p->left);

    if(r>l)
    {
        p->height=r+1;
    }

    else
    {
        p->height=l+1;
    }

}

template<class T>
void BST<T>::fix(node<T>* p)
{
    fixHeight(p);
}

// ROTATING HELPERS 
template <class T>
node<T>* BST<T> :: rotateleft(node<T>* p){
  
        if(p==NULL) return NULL;

        if(p->right==NULL) return NULL;

        node<T>* newroot=p->right;
        p->right=newroot->left;
        newroot->left=p;


        fixHeight(p);
        fixHeight(newroot);

        return newroot;

}

template <class T>
node<T>* BST<T> :: rotateright(node<T>* p){
    // Rotate right code goes here
    
       // cout<<"rotate right if left != NULL"<<endl;

         if(p==NULL) return NULL;

        if(p->left==NULL) return NULL;

        node<T>* newroot=p->left;
        p->left=newroot->right;
        newroot->right=p;

        fixHeight(p);
        fixHeight(newroot);

        return newroot;

}

template <class T>
node<T>* BST<T> :: balance(node<T>* p){    
    
    if(p==NULL) return NULL;
    
    //cout<<"balance before AVL"<<endl;
    fixHeight(p);

     if(balanceFactor(p)>1) //left heavy
    {
        //cout<<"left heavy"<<endl;

        if (height(p->left->right)>height(p->left->left)) // left-right case
        {
           // cout<<"let-right case"<<endl;
            
            p->left=rotateleft(p->left); //left rotate left child
            p=rotateright(p);

            return p;
        }

        else// neutral
        {
          //  cout<<"left case"<<endl;

            p=rotateright(p);

            return p;
        }

    }

    else if(balanceFactor(p)<-1) //right heavy
    {
        
        //cout<<"right heavy"<<endl;
        if(height(p->right->right)<height(p->right->left))// right-left case
        {

            p->right=rotateright(p->right); // right rotate right child
            p=rotateleft(p);

            return p;
        }


        else// neutral
        {
            p=rotateleft(p);
            return p;
        }

    }

    return p;
    // Balancing code goes here. You might need to find balance factor and call appropriate rotations.
}

// CLASS FUNCTIONS HERE
template <class T>
void BST<T> :: insert(unsigned long value,T k){
    if(root==NULL)
    {
        root=new node<T>(k,value);
        //root->height=0;
        return;
    }

    else {root=insertHelper(value,k,root);}
    //fixHeight(root);
    
    //balance(root);

}

// insertion helper
template <class T>
node<T>* BST<T> :: insertHelper(unsigned long value,T k, node<T> *p) { // note we need a helper because we need recursive calls
    // Insertion code goes here.
    
    // base cases

   // cout<<"insert  helper"<<endl;
    if(p==NULL)
    {
        p = new node<T>(k,value);
        return p;
    }


    else if(k<p->key)
    {
        p->left=insertHelper(value,k,p->left);
    }

    else if(k>p->key)
    {
        p->right=insertHelper(value,k,p->right);
    }

    return balance(p);
    
}

template<class T>
node<T>* BST<T>::search_help(T k, node<T>* nod)
{
    node<T>* ans = NULL;

    if(nod==NULL) return NULL;

    else if(nod->key==k) return nod;


    else if( k<nod->key)
    {
        return search_help(k,nod->left);
    }

    else if(k>nod->key)
    {
        return search_help(k, nod->right);
    }

    return ans;
}

template<class T>
node<T>* BST<T> :: search(T key){
    
    return search_help(key,root);
    // Search code goes here.
}

// DELETE HELPER FUNCTIONS
template<class T>
node<T>* BST<T> :: findmin(node<T> *p){
    // This function finds the min node of the tree.
    if(p==NULL) return NULL;

    while(p->left!=NULL)
    {
        p=p->left;
    }

    return p;
}

template<class T>
node<T>* BST<T>::removemin(node<T>* p) {
    node<T>* temp =p;


    if(temp->left!=NULL)temp->left=removemin(temp->left);

    //if(temp==NULL) return NULL;
    else if(temp->right==NULL && temp->left==NULL)
    {

        delete temp;
        temp=NULL;
        return temp;

    }

    else if (temp->right!=NULL)
    {
        node<T>*  shifted=temp->right; // shift the node to the one on the right
        delete temp;
        temp=NULL;

        return shifted;

    }

    if(temp==NULL) return NULL;

    return balance(p);
    // This function recursively finds the min node and deletes it.
}


template<class T>
void BST<T>::delete_node(T k){
    root = remove(root, k);
}

template<class T>
node<T>*  BST<T>::remove(node<T>* p, T k) // k key deletion from p tree
{
    node<T>* temp1=p;

    if(k<temp1->key) temp1->left=remove(temp1->left,k);
    else if(k>temp1->key) temp1->right=remove(temp1->right,k);


    else if(temp1->key==k) // found the node
    {
        // case 1: leaf node

        if(temp1->left==NULL && temp1->right==NULL)
        {
            //cout<<"deleting :"<<temp1->key<<endl;
            delete temp1;
            temp1=NULL;
            return temp1;
        }

        // case 2 : one child

        else if(temp1->left==NULL && temp1->right!=NULL)
        {

            node<T>* shift=temp1->right; // only one child. make that the node
            delete temp1;
            temp1=NULL;

            return shift;
            //balance(temp1);
        }

        else if(temp1->right==NULL && temp1->left!=NULL)
        {

            node<T>* shift=temp1->left; // only one child. make that the node
            delete temp1;
            temp1=NULL;

            return shift;


            //balance(temp1);
        }

        // case 3: two children

        else if(temp1->right!=NULL && temp1->left!=NULL)
        {
            node<T>* temp= findmin(temp1->right);

            temp1->value=temp->value;
            temp1->key= temp->key;
            temp1->right=removemin(temp1->right);
            //balance(temp1);
        }

        return balance(temp1);  
    }

    return balance(temp1);
    // This function uses findmin and deletemin to delete arbitrary node in the tree.
}
template<class T>
node<T>* BST<T>::getRoot(){
    return root;
}


template<class T>
void BST<T>:: print(node<T>* head)
{
    if(head==NULL) return;

    print(head->left);
    cout<<head->key<< " height: "<<head->height<<endl;
    print(head->right);
}


template<class T>
void BST<T>::setroot(node<T>* set)
{
    root=set;
}


#endif

