#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	harr=new int[cap];
	for(int i=0; i<cap; i++)
	{
		harr[i]=0;
	}

	capacity=cap;
	heap_size=0;

}

void MinHeap::MinHeapify(int i)
{

	int current = i;
	while(harr[parent(current)]>harr[current]) //while parent is greater, keep swapping.
	{
		int temp=harr[parent(current)];
		harr[parent(current)]=harr[current];
		harr[current]=temp;

		current=parent(current);
	}

	int left_c = left(i);
    int right_c = right(i);

    current = i;

    if(right_c<heap_size && left_c<heap_size) // both within range
    {
    	if(harr[left_c]<harr[right_c] && harr[left_c]<harr[current]) current = left_c;  //left smaller
    	else if(harr[right_c]<harr[i]) // right smaller
    	{
    		current = right_c;
    	}
    }
    else if(right_c<heap_size && harr[right_c]<harr[current]) //only right in range
    {
    	current=right_c;
    }
    else if(left_c<heap_size && harr[left_c]<harr[current]) //only left in range
    {
    	current=left_c;	
    }


    if (current ==right_c || current==left_c)
    {
        int temp=harr[i];
		harr[i]=harr[current];
		harr[current]=temp;
        MinHeapify(current);
    }
}
 
int MinHeap::parent(int i)
{
	if(i!=0) return ((i-1)/2);

	return 0;
}
 
int MinHeap::left(int i)
{
	return (2*i)+1;
}
 
int MinHeap::right(int i)
{
	return (2*i)+2;
}
 
int MinHeap::extractMin()
{
	
	if(heap_size==1)
	{
		heap_size--;
		return harr[0];
	}


	int min=harr[0];

	
	harr[0]=harr[heap_size-1];
	harr[heap_size-1]=0;
	//int k=0;

	//fix order of heap
	heap_size--;
	MinHeapify(0);

	return min;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;

	while(harr[parent(i)]>harr[i]) //while parent is greater, keep swapping.
	{
		int temp=harr[parent(i)];
		harr[parent(i)]=new_val;
		harr[i]=temp;

		i=parent(i);
	}

}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i<heap_size)
	{
		harr[i]=harr[heap_size-1];
		harr[heap_size-1]=0;
		heap_size--;

		MinHeapify(i);
	}
}

void MinHeap::insertKey(int k)
{
	if(heap_size==0) 
	{
		harr[0]=k;
		heap_size++;
		return;
	}


	int size=heap_size;
	harr[size]=k;

	while(harr[parent(size)]>harr[size]) //while parent is greater, keep swapping.
	{
		int temp=harr[parent(size)];
		harr[parent(size)]=k;
		harr[size]=temp;

		size=parent(size);
	}

	heap_size++;

}

int* MinHeap::getHeap()
{
	return harr;
}


#endif