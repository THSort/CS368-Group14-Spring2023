#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
#include <time.h>

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int size=nums.size();
	int *array=new int[size];
	for(int i=0; i<size; i++)
	{
		array[i]=nums[i];
	}

	int start=0;
	int prev=0;

	for(int j=1; j<size; j++)
	{
		start=array[j];
		prev=j-1;

		while(prev>=0 && start<array[prev]) // loop back til the start
		{
			array[prev+1]=array[prev];  //switch
			
			prev=prev-1;
		}

		array[prev+1]=start;
	}

	vector<long> ret;
	for(int i=0; i<size; i++)
	{
		ret.push_back(array[i]);
	}

	return ret;

}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{	
	int size=nums.size();
	List<int>* list=new List<int>();
	for(int i=0; i<size; i++)
	{
		list->insertAtHead(nums[i]);
	}
	ListItem<int>* head= list->getHead();
	//ListItem<int>** start=&head;


	MergeSortRecursive(list->_gethead());

	vector<long> ret;
	ListItem<int>* track=list->getHead();
	while(track)
	{
		ret.push_back(track->value);
		track=track->next;
	}

	return ret;

}

void MergeSortRecursive(ListItem<int>** head)
{

	ListItem<int>* start=*head;
	ListItem<int>* l1=NULL;//splited lists
	ListItem<int>* l2=NULL;//splited lists

	//base case
	if(start==NULL || start->next==NULL)
	{
		return;
	}

	split(start,&l1,&l2);

	MergeSortRecursive(&l1);
	MergeSortRecursive(&l2);

	*head=merge(l1,l2);


}

ListItem<int>* merge(ListItem<int>* l1,ListItem<int>* l2)
{
	if(!l2) return l1;
	if(!l1) return l2;

	ListItem<int>* ret=NULL;;

	if(l1->value<=l2->value)
	{
		ret=l1;
		ret->next=merge(l1->next,l2);
	}		

	else
	{
		ret=l2;
		ret->next=merge(l1,l2->next);
	}

	return ret;


}

void split(ListItem<int>* start, ListItem<int>** l1,ListItem<int>** l2)
{
	List<int>* temp=new List<int>();
	temp->sethead(start);

	int len=temp->length();
	int mid=len/2;

	ListItem<int>* temp1=start;
	//ListItem<int>* temp2;
	for(int i=1; i<mid; i++)
	{
		temp1=temp1->next;
	}

	*l2=temp1->next;
	temp1->next=NULL;
	*l1=start;

}


//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
	int size=nums.size();
	int *array=new int[size];
	for(int i=0; i<size; i++)
	{
		array[i]=nums[i];
	}


	QuickArrayRecursive(array,0,size-1);

	

	vector<long> ret;
	for(int k=0; k<size; k++)
	{
		ret.push_back(array[k]);
	}

	return ret;

}

int partition(int arr[], int start, int end)
{
	//chose pivot

	int pivot_index=start;
	int pivot=arr[pivot_index];
	



	//take pivot at the end
	int temp_swap=arr[end];
	arr[end]=pivot;
	arr[pivot_index]=temp_swap;

	int i=start-1;
	//cout<<i<<endl;

	for(int j=start; j<end; j++)
	{
		if(arr[j]<=pivot)
		{
			i++;

			int temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;

		}
	}

	//now all small at the left till index i and all large starting from i+1
	
	int temp=arr[i+1];
	arr[i+1]=pivot;
	arr[end]=temp;


	return (i+1);  //return centre value
	
}


void QuickArrayRecursive(int arr[],int start,int end)
{
	if(start<end)
	{
		int cent=partition(arr,start,end);

		QuickArrayRecursive(arr,start,cent-1);
		QuickArrayRecursive(arr,cent+1,end);
	}
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	int size=nums.size();
	List<int>* list=new List<int>();
	for(int i=0; i<size; i++)
	{
		list->insertAtHead(nums[i]);
	}

	QuickListRecursive(list,list->getHead(),list->getTail(),list->length());


	vector<long> ret;
	ListItem<int>* track=list->getHead();
	while(track)
	{
		ret.push_back(track->value);
		track=track->next;
	}

	return ret;

}

ListItem<int>* Listpartition(List<int>* list ,ListItem<int>* start, ListItem<int>* end,int size)
{
	
	ListItem<int>* p1=start;
	int counter=0;
	while(p1!=end)
	{
		counter++;
		p1=p1->next;
	}

	p1=start;
	srand(time(NULL));
	int target=  rand()%(counter+1);
	for(int i=0; i<target; i++)
	{
		p1=p1->next;
	}


	//chose pivot
	ListItem<int>* pivot_node=p1;

	int pivot=pivot_node->value;
	//cout<<pivot<<endl;

	//take pivot at the end
	int temp_swap=end->value;
	end->value=pivot;
	pivot_node->value=temp_swap;

	ListItem<int>* i=start->prev;
	//cout<<i<<endl;

	for(ListItem<int>* j=start; j!=end; j=j->next)
	{
		if(j->value <= pivot)
		{
			if(i) i=i->next;
			else
			{
				i=start;
			}
			int temp=i->value;
			i->value=j->value;
			j->value=temp;
		}
	}


	//now all small at the left till index i and all large starting from i+1
	if(i)
	{
		int temp=i->next->value;
		i->next->value=pivot;
		end->value=temp;
		return i->next;  //return centre value
	}
	else
	{
		i=start;

		int temp=i->value;
		i->value=pivot;
		end->value=temp;
		return i;
	}


	
}


void QuickListRecursive(List<int>* list, ListItem<int>* start, ListItem<int>* end,int size)
{
	if(start && end && end->next!=start)
	{
		ListItem<int>* cent=Listpartition(list,start,end,size);

		QuickListRecursive(list,start,cent->prev,size);
		QuickListRecursive(list,cent->next,end,size);
	}
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int size=nums.size();
	MinHeap *heap=new MinHeap(size);
	for(int i=0; i<size; i++)
	{
		heap->insertKey(nums[i]);
	}


	vector<long> ret;
	for(int i=0; i<size; i++)
	{
		ret.push_back(heap->extractMin());
	}

	return ret;

}

#endif