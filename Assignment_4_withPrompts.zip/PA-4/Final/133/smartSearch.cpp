#include <fstream>
#include <ctime>
#include "sorts.cpp"
#include "bst.h"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    int len=nums.size();
    BST<int>* tree= new BST<int>();
    for(int i=0; i<len;i++)
    {
        tree->insert(i,nums[i]);
    }

    //tree loaded.
    vector< vector<long> > ans;
    int j=0;

    for(int i=0; i<len; i++)
    {
        int target= k-nums[i];
        if(target>=0)
        {
            node<int>* lookup=tree->search(target);
            if(lookup!=NULL)
            {
                ans.push_back(vector<long>());
                ans[j].push_back(nums[i]);
                ans[j].push_back(target);
                j++;
            }
        }
    }

    return ans;
}


int main()
{
    
    int start_s=clock();
    // the code you wish to time goes here




    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    cout<<nums.size()<<endl;
    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    int stop_s=clock();
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout<<endl;
    cout<<endl;
    cout<<endl;

    cout << "time: " << (stop_s-start_s)/double(CLOCKS_PER_SEC) <<" seconds"<< endl;
    
    return 0;
}