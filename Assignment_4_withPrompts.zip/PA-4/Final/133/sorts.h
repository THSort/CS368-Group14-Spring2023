#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);
vector<long> MergeSort(vector<long> nums);
vector<long> QuickSortArray(vector<long> nums);
vector<long> QuickSortList(vector<long> nums);
vector<long> HeapSort(vector<long> nums);

//helper functions

int partition(int arr[], int start, int end);
void QuickArrayRecursive(int arr[],int start,int end);

ListItem<int>* Listpartition(List<int>* list, ListItem<int>* start, ListItem<int>* end,int size);
void QuickListRecursive(List<int>* list, ListItem<int>* start, ListItem<int>* end, int size);

void MergeSortRecursive(ListItem<int>** head);
void split(ListItem<int>* start, ListItem<int>** l1,ListItem<int>** l2);
ListItem<int>* merge(ListItem<int>* l1,ListItem<int>* l2);

#endif