#include "bst.cpp"
#ifndef __BST_H
#define __BST_H
#include <string>
#include <vector>
#include <utility>
using namespace std;

template <class T>
class node{
    public:
    
    unsigned long value; 
    T key;
    node *left;
    node *right;
    int height;
    
    node (T key, unsigned long value){
        this->key = key;
        this->value = value;
        left = NULL;
        right = NULL;
        height = 1;
    }

};


template <class T>
class BST {
    private:
    node<T> *root;
    
    // HELPER FUNCTIONS
    int balanceFactor(node<T>* p);
    void fixHeight(node<T>* p);
    node<T>* rotateleft(node<T>* p);
    node<T>* rotateright(node<T>* p);
    node<T>* balance(node<T>* p);
    node<T>* insertHelper(unsigned long value,T k, node<T> *p);
    node<T>* findmin(node<T> *p);
    node<T>* removemin(node<T> *p);
    node<T>* remove(node<T> *p,T k);

    //extra self made
    node<T>* search_help(T k, node<T>* nod);
   public:
    BST(); // CONSTRUCTOR 
    ~BST(); // DESTRUCTOR
    void insert(unsigned long val, T k); // inserts the given key value pair into the tree
    void delete_node(T k);    
    node<T>* search(T k); // takes key as an input and returns the node pointer if key exists and NULL pointer if key does not exists 
    node<T>* getRoot();
    int height (node<T>* p);
    
    //EXTRA self made
    void print(node<T>* head);
    void setroot(node<T>*);
    void fix(node<T>* p);
    
};


#endif
