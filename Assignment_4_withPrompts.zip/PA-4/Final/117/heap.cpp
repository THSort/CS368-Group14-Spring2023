#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity=cap;
	heap_size=0;
	harr=new int [cap];
}

void MinHeap::MinHeapify(int i)
{
	while (1)
	{
		int min=i;
		if (left(i)<heap_size && harr[left(i)]<harr[i])
		{
			min=left(i);
		}	
		if (right(i)<heap_size && harr[right(i)]<harr[min])
		{
			min=right(i);
		}
		if (min != i)
		{
			int temp;
			temp=harr[min];
			harr[min]=harr[i];
			harr[i]=temp;
			i=min;
		}

		else
		{
			break;
		}
	}
}
 
int MinHeap::parent(int i)
{
	int parent;
	parent= (i-1)/2;
	return parent;
}
 
int MinHeap::left(int i)
{
	int left_child;
	left_child=(2*i)+1;
	return left_child;
}
 
int MinHeap::right(int i)
{
	int right_child;
	right_child=(2*i)+2;
	return right_child;
}
 
int MinHeap::extractMin()
{

	int minimum_value=harr[0];
	harr[0]=harr[heap_size-1];
	heap_size--;
	MinHeapify(0);
	return minimum_value;	
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;
	while (1)
	{
		if (harr[parent(i)>harr[i]])
		{
			int temp;
			temp=harr[parent(i)];
			harr[parent(i)]=harr[i];
			harr[i]=temp;
			i=parent(i);
		}
		else 
		{
			break;
		}
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	harr[i]=getMin();
	while (1)
	{
		if (harr[i]<harr[parent(i)])
		{
			int temp;
			temp=harr[parent(i)];
			harr[parent(i)]=harr[i];
			harr[i]=temp;
			i=parent(i);
		}
		else
		{
			break;
		}
	}
	extractMin();
}
void MinHeap::insertKey(int k)
{
	heap_size=heap_size+1;
	int j;
	j=heap_size-1;
	harr[heap_size-1]=k;
	while (j>0 && harr[parent(j)]>harr[j])
	{
		int temp;
		temp=harr[parent(j)];
		harr[parent(j)]=harr[j];
		harr[j]=temp;
		j=parent(j);
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif

