#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int size=nums.size();
	long array[size];
	for (int i=0;i<size;i++)
	{
		array[i]=nums[i];
	}
	for (int i=1;i<size;i++)
	{
		if (array[i]<array[i-1])
		{
			long temp=array[i];
			array[i]=array[i-1];
			array[i-1]=temp;
			int k=i;
			k--;

			while (k>0 && array[k]<array[k-1])
				{
					long temp=array[k];
					array[k]=array[k-1];
					array[k-1]=temp;
					k--;
				}
		}
	}
	for (int i=0;i<size;i++)
	{
		nums[i]=array[i];
	}
	return nums;
}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
	int my_array[nums.size()];
	for (int i=0;i<nums.size();i++)
	{
		my_array[i]=nums[i];
	}

	int starting;
	int ending;
	starting=0;
	ending=nums.size()-1;
		if (starting<ending)
		{
			int answer;
			int pivot;
			pivot=my_array[ending];
			int smaller_element_index;
			smaller_element_index=(starting-1);

			for (int i=starting;i<=ending-1;i++)
			{
				if (my_array[i]<=pivot)
				{
					smaller_element_index++;
					long temp;
					temp=my_array[i];
					my_array[i]=my_array[smaller_element_index];
					my_array[smaller_element_index]=temp;
				}
			}
			int temp;
			temp=my_array[ending];
			my_array[ending]=my_array[smaller_element_index+1];
			my_array[smaller_element_index+1]=temp;
			answer=smaller_element_index+1;
		}
}
//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap* my_heap = new MinHeap(nums.size());
	for (int i=0;i<nums.size();i++)
	{
		(*my_heap).insertKey(nums[i]);
	}

	for (int i=0;i<nums.size();i++)
	{
		nums[i]=(*my_heap).extractMin();
	}
	return nums;
}

#endif