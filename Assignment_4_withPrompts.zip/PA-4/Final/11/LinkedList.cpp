#ifndef __LIST_CPP
#define __LIST_CPP
#include <iostream>
#include <cstdlib>
#include "LinkedList.h"

using namespace std;
template <class T>
LinkedList<T>::LinkedList()
{
 head=NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
 LinkedList<T> temp_list;
 ListItem<T> *here=otherLinkedList.head;

  while (here!=NULL)
  {
   temp_list.insertAtTail(here->value);
   here=here->next;
  }
}

template <class T>
LinkedList<T>::~LinkedList()
{
 ListItem<T> *second=head;
 ListItem<T> *here=head;
 while (here!=NULL)
 {
  second=here;
  here=here->next;
  delete second;
 }
 delete here;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
 ListItem<T> *temp=new ListItem<T>(item);
 if (head==NULL)
 {
  tail=temp;
  tail->next=NULL;
 }
 temp->next=head;
 temp->prev=NULL;
 head=temp;
 if (head->next!=NULL)
 {(head->next)->prev=head;}
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
 if (head==NULL)
 {
  ListItem<T> *temp=new ListItem<T>(item);
  head=temp;
  tail=temp;
  tail->next=NULL;
 }
 else
 {
 ListItem<T> *temp=new ListItem<T>(item);
 temp->prev=tail;
 tail=temp;
 }

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
 ListItem<T> *here=head;
 ListItem<T> *temp_ptr=new ListItem<T>(toInsert);
 if (head==NULL)
 {
  insertAtHead(toInsert);
 }
 while(here->next!=NULL && here->value!=afterWhat)
 {
  here=here->next;
 }
if(here->value==afterWhat)
{
temp_ptr->prev=here;
temp_ptr->next=here->next;
here->next=temp_ptr;
}
else
{
 insertAtTail(toInsert);
}
}


template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
 return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
return tail;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
 ListItem<T> *here=head;
 while (here!=NULL)
 {
  if(here->value==item)
  {
   return here;
  }
  here=here->next;
 }
 return 0;
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
  ListItem<T> *temp_head=head;
  ListItem<T> *temp_tail=tail;
 if (head->value==item)
 {
  if (head->next!=NULL)
  {head=head->next;}
  else
  {head=NULL;}
  delete temp_head;
 }
 else if (tail->value==item)
 {
   if (tail->prev!=NULL)
  {tail=tail->prev;
  }
  else
  {tail=NULL;}
  delete temp_tail;
  tail->next=NULL;
 }
 else
 {
  ListItem<T> *temp=searchFor(item);
  ListItem<T> *temp_prev=temp->prev;
  ListItem<T> *temp_next=temp->next;
  temp_prev->next=temp_next;
  temp_next->prev=temp_prev;
  delete temp;
 }
}

template <class T>
void LinkedList<T>::deleteHead()
{
 ListItem<T> *temp_head=head;
 if (head->next!=NULL)
  {head=head->next;}
  else
  {head=NULL;}
  delete temp_head;
}

template <class T>
void LinkedList<T>::deleteTail()
{
  if (tail==head)
  {
   deleteHead();
  }
  else
  {ListItem<T> *temp_tail=tail->prev;
  delete tail;
  tail=temp_tail;
  tail->next=NULL;}
}


#endif
