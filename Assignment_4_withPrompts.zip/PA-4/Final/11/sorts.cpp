#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
 int len=nums.size();
 int * arr=new int[len];
 for(int m=0; m<len; m++){
 	arr[m]=nums[m];
 }
 int i=1;
 while (i<len){		
 	int temp=i-1, temp1=0,counter=0,index=arr[i];

 	for(int j=i-1; (index<arr[j] && j>=0); j--){
 		arr[j+1]=arr[j];
 		temp=j-1;
 	}
 	arr[temp+1]=index;
 	i++;
 }
 vector<long int> vec;
for(int t=0; t<len; t++){
 vec.push_back(arr[t]);
}
return vec;
}
//=====================================================================================

 vector<long> l_vec;
 vector<long> r_vec;
 int counter=0;
vector<long> MergeSort(vector<long> nums)
{vector<long> vect;
/* if (counter==0 || l_vec.front()<r_vec.front()){*/
 for(int i=0; i<nums.size(); i++){
 	cout<<nums[i]<<endl;
 }
 if(nums.size()>1) 
 {List<long> source;
 int len=nums.size();
 for(int i=0; i<len; i++){

 source.insertAtTail(nums[i]);
 }
    ListItem<long> * fast;
    ListItem<long> * slow;
    slow = source.getHead();
    fast = (source.getHead())->next;
    while (fast != NULL){
    fast = fast->next;
    if (fast != NULL){
        slow = slow->next;
        fast = fast->next;
    }
    }

    List<long> frontRef;
    frontRef= source;
    ListItem<long> * backRef= slow->next;
    slow->next = NULL;

    vector<long> l_vec,r_vec;
    ListItem<long> * here=frontRef.getHead();
    while(here!=NULL){
    	l_vec.push_back(here->value);
    	here=here->next;
    }
    here=backRef;

    while(here!=NULL){
    	r_vec.push_back(here->value);
    	here=here->next;
    }
    cout <<"right: ";

 for (int g=0; g<r_vec.size(); g++){
 	cout<<r_vec[g]<<" ";
 }
 cout<<"left: ";
 for (int i=0; i<l_vec.size(); i++){
 	cout<<l_vec[i]<<" ";
 }
 cout<<endl;
    l_vec=MergeSort(l_vec);
	r_vec=MergeSort(r_vec);
	cout<<"vecs: ";
	 for (int i=0; i<l_vec.size(); i++){
 	cout<<l_vec[i]<<" ";
 }
 cout <<" n ";
  for (int g=0; g<r_vec.size(); g++){
 	cout<<r_vec[g]<<" ";
 } 
	vect=merge(l_vec,r_vec);
	 }
	 else{
	 	return nums;
	 }
	 return vect;

 /*cout <<"middle: "<<middle<<endl;
 for(int f=0; f<nums.size(); f++){
 	cout<<nums[f]<<" ";
 }
 cout<<endl;
 cout <<"right: ";
int g=0;
 for (int i=(len/2)+1; i<len; i++){
 	r_vec.push_back(nums[i]);
 	cout<<r_vec[g]<<" ";
 	g++;
 }
 cout<<"left: ";
 for (int i=0; i<=len/2; i++){
 	l_vec.push_back(nums[i]);
 	cout<<l_vec[i]<<" ";
 }
 cout<<endl;
  counter=1;
  l
  return merge(MergeSort(l_vec),MergeSort(r_vec),middle);
}*/
}

vector <long> merge(vector<long> l_vec, vector<long> r_vec){
	int i=1;
	cout<<"c"<<endl;
	vector<long> vec;
	int len_l=l_vec.size();
	int len_r=r_vec.size();

	while(l_vec.size()>0 && r_vec.size()>0){cout<<l_vec.front()<<" b "<<r_vec.front()<<endl;
		if(l_vec.front()>r_vec.front()){cout<<"v"<<endl;
			vec.push_back(l_vec[0]);
			l_vec.erase(l_vec.begin());
		}
		else if(l_vec.front()<=r_vec.front()){cout<<"s"<<endl;
			vec.push_back(r_vec[0]);
			r_vec.erase(r_vec.begin());
		}
		i++;
	}
	int j=i;
	while (i <=len_l){cout<<"g"<<endl;
        vec.push_back(l_vec[0]);
		l_vec.erase(l_vec.begin());
        i++;
    }
    while (j <len_r)
    {	cout<<"h"<<endl;
        vec.push_back(r_vec[0]);
		r_vec.erase(r_vec.begin());
        j++;
    }
    cout<<"arranged: ";
    for (int q=0; q<=vec.size(); q++){
    	cout<<vec[q]<<" ";
    }
    cout<<endl;
    return vec;
}
//=====================================================================================
int p_ind,s=0, e;
int partition(int e,int *nums,int s){
 p_ind=s;
 for(int i=s; i<e; i++){

 	if(nums[i]<=nums[e]){
 		int temp=nums[p_ind];
 		nums[p_ind]=nums[i];
 		nums[i]=temp; 
 		p_ind++;
 	}
 } 
 int temp=nums[p_ind];
 nums[p_ind]=nums[e];
 nums[e]=temp; 
 return p_ind;
}

void QuickSort(int s,int e,int *nums){

if(s<e){
p_ind=partition(e,nums,s);
QuickSort(s,p_ind-1,nums);
QuickSort(p_ind+1,e,nums);
}
}

vector<long> QuickSortArray(vector<long> nums)
{
 int * arr= new int[nums.size()];
 for(int i=0; i<nums.size(); i++){
 	arr[i]=nums[i];
 }
 e=nums.size()-1;
 QuickSort(s,e,arr);

 for(int i=0; i<nums.size(); i++){
 	nums[i]=arr[i];
 }
 return nums;
}

//=====================================================================================

vector<long> QuickSortList(vector<long> nums)
{
 
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
 MinHeap *londaybaaz=new MinHeap(nums.size());
 for (int i=0; i< nums.size(); i++){
 	londaybaaz->insertKey(nums[i]);
 }
 int i=0;
 while(i<nums.size()){
 	nums[i]=londaybaaz->extractMin();
 	i++;
 }
 return nums;
}

#endif