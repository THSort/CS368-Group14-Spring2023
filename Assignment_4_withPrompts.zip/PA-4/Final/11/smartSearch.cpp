#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
int binarySearch( int end, int k,vector<long> arr, int start)
{
   if (end >= start)
   {
    int middle = start + (end - start)/2;
    if (arr[middle] == k){
    return middle;
    }
    if (arr[middle] > k){
    return binarySearch( end, k,arr, middle+1);
}else{
    return binarySearch( middle-1, k,arr, start);
}
   }
   return -1;
}
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
vector< vector<long> > ret_vec;
int len=nums.size();
nums=QuickSortArray(nums);
for(int i=0; nums[i]<k; i++){
    if(binarySearch(len-1,k-nums[i],nums,0)){
        vector<long> new_vec;
        new_vec.push_back(nums[i]);
        new_vec.push_back(k-nums[i]);
        ret_vec.push_back(new_vec);
    }
}
return ret_vec;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}