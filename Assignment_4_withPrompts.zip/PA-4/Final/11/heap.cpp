#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"

MinHeap::MinHeap(int cap)
{
 harr=new int[cap];
 capacity=cap;
 heap_size=0;
}

void MinHeap::MinHeapify(int i)
{
 int little_one = i;
if (left(i) < heap_size){

if(harr[left(i)] < harr[i]){
little_one = left(i);
}}


if (right(i) < heap_size){

if(harr[right(i)] < harr[little_one]){
little_one = right(i);
}}

if (little_one != i)
{
    int temp=harr[i];
    harr[i]=harr[little_one];
    harr[little_one]=temp;
    MinHeapify(little_one);
}
}
 
int MinHeap::parent(int i)
{
 return((i-1)/2);
}
 
int MinHeap::left(int i)
{
 return(2*i+1);
}
 
int MinHeap::right(int i)
{
 return(2*i+2);
}
 
int MinHeap::extractMin()
{
 if (heap_size <= 0)
    return INT_MAX;
if (heap_size == 1)
{
    heap_size--;
    return harr[0];
}

int root = harr[0];
harr[0] = harr[heap_size-1];
heap_size--;
MinHeapify(0);

return root;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
 harr[i]=new_val;
for (int j=i; j != 0; j=parent(j))
    {	if(harr[parent(j)] > harr[j]){
    	int temp=harr[j];
    	harr[j]=harr[parent(j)];
    	harr[parent(j)]=temp;
   }
    }
}
 
int MinHeap::getMin()
{
 return(harr[0]);
}
 
void MinHeap::deleteKey(int i)
{
 if(i>=heap_size){
 	return;
 }
 decreaseKey(i, INT_MIN);
 extractMin();
}
 
void MinHeap::insertKey(int k)
{

 if (heap_size==capacity){
 	return;
 }
 else{
 	heap_size++;
 	harr[heap_size-1]=k;
 	  for (int i = heap_size - 1; i != 0; i=parent(i))
    {	if(harr[parent(i)] > harr[i]){
       int temp=harr[i];
    	harr[i]=harr[parent(i)];
    	harr[parent(i)]=temp;
   }
    }
    }
 }

int* MinHeap::getHeap()
{
	return harr;
}

#endif