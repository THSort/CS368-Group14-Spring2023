#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	harr = new int[cap];
	capacity = cap;
	heap_size = 0;
}

void MinHeap::MinHeapify(int i)
{
	int subroot = i;
	int theleft = left(i);
	int theright = right(i);
	int checker = 0;

	if(theleft > heap_size || theright > heap_size)
	{
		return;
	}
	
	if(harr[theleft] < harr[subroot])
	{
		subroot = theleft;
		checker++;
	}
	if(harr[theright] < harr[subroot])
	{
		subroot = theright;
		checker++;
	}

	if(checker != 0)
	{
		int temp = harr[i];
		harr[i] = harr[subroot];
		harr[subroot] = temp;
		MinHeapify(subroot);
	}
	return;
}
 
int MinHeap::parent(int i)
{
	int theparent = (i - 1)/2;
	return theparent;
}
 
int MinHeap::left(int i)
{
	int theleft = ((2*i) + 1);
	return theleft;
}
 
int MinHeap::right(int i)
{
	int theright = ((2*i) + 2);
	return theright;
}
 
int MinHeap::extractMin()
{
	if(heap_size == 1)
	{
		heap_size--;
		return harr[0];
	}

	int minval = harr[0];
	harr[0] = harr[heap_size - 1];
	heap_size--;
	MinHeapify(0);

	return minval;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	int currlocation = i;
	harr[currlocation] = new_val;

	while(currlocation != 0)
	{
		if(harr[parent(currlocation)] > harr[currlocation])
		{
			int temp = harr[currlocation];
			harr[currlocation] = harr[parent(currlocation)];
			harr[parent(currlocation)] = temp;
			currlocation = parent(currlocation);
		}

		else
		{
			break;
		}
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(heap_size == 0)
	{
		return;
	}

	if(heap_size == 1)
	{
		heap_size--;
		return;
	}

	if(i == heap_size - 1)
	{
		heap_size--;
		return;
	}

	if(i >= heap_size)
	{
		return;
	}

	int temp = harr[heap_size - 1];
	harr[heap_size - 1] = harr[i];
	harr[i] = temp; 
	heap_size--; 
	MinHeapify(i);	
}
 
void MinHeap::insertKey(int k)
{
	heap_size++;
	int currlocation = heap_size - 1;
	harr[currlocation] = k;

	while(currlocation != 0)
	{
		if(harr[parent(currlocation)] > harr[currlocation])
		{
			int temp = harr[currlocation];
			harr[currlocation] = harr[parent(currlocation)];
			harr[parent(currlocation)] = temp;
			currlocation = parent(currlocation);
		}

		else
		{
			break;
		}
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif