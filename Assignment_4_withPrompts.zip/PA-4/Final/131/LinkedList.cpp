#include <iostream>
using namespace std;

#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	ListItem<T>* thelist = otherLinkedList.head;

    head = NULL;

    	while(thelist != NULL)
    	{
    		this->insertAtTail(thelist->value);
    		thelist = thelist->next;
    	}
}

template <class T>
LinkedList<T>::~LinkedList()
{
	

	while(head != NULL)
	{
		deleteHead();
	}
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
	if(head == NULL)
	{
		
		ListItem<T>* newone = new ListItem<T>(item);
		newone->value = item; 
		newone->prev = NULL;
		newone->next = NULL;
		head = newone;
	}
	else
	{
		ListItem<T>* newone = new ListItem<T>(item);
		newone->value = item; 

		newone->next = head;
		newone->prev = NULL; 
		head->prev=newone;
		head = newone;
	}

	
}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{
	if(head == NULL)
	{
		insertAtHead(item);
	}
	
	else
	{
		ListItem<T>* newone = new ListItem<T>(item);
		newone->value = item;
		newone->next = NULL;

		ListItem<T>* here = head;

		while(here->next != NULL)
		{
			here = here->next;
		}

		here->next = newone;
		newone->prev = here;
	}

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T>* newone = new ListItem<T>(toInsert);
	newone->value = toInsert;

	ListItem<T>* here = head;

	if(here == NULL)
	{
		return;
	}

	else
	{
		while(afterWhat != here->value && here->next != NULL)
		{
			here = here->next;
		}

		if(afterWhat == here->value)
		{
			newone->next = here->next;
			newone->prev = here;
			here->next = newone;
		}

		else
		{
			return;
		}
	}
}

template <class T>
void LinkedList<T>::insertSorted(T item)
{
	ListItem<T>* here = head;

	if(head == NULL || item < head->value)
	{
		insertAtHead(item);
		return;
	}

	else
	{
		while(here->next != NULL)
		{
			
			if(item < here->next->value)
			{
				ListItem<T>* adder = new ListItem<T>(item);
				adder->value = item;
				adder->next = here->next;
				here->next->prev = adder;
				adder->prev = here;
				here->next = adder;
				return; 
			}

			here = here->next;
			
		}
		insertAtTail(item);
		return;
	}	
}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;
}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
	ListItem<T>* here = head;
	while(here->next != NULL)
	{
		here = here->next;
	}

	return here;
}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
	ListItem<T>* here = head;

	if(here == NULL)
	{
		return NULL;
	}

	else
	{
		while(item != here->value && here->next != NULL)
		{
			here = here->next;
		}

		if(item == here->value)
		{
			return here;
		}

		else
		{
			return NULL;
		}
	}
}

template <class T>
void LinkedList<T>::deleteElement(T item)
{
	ListItem<T>* here = head;

	if(here == NULL)
	{
		return;
	}

	else
	{
		if(here->value == item){
			deleteHead();
		}
		
		ListItem<T>* temp = searchFor(item);
		if(temp != NULL){
			if(temp->next != NULL) temp->next->prev = temp->prev;
			if(temp->prev != NULL) temp->prev->next = temp->next;
			delete temp;
			temp = NULL;
		}

	}
}

template <class T>
void LinkedList<T>::deleteHead()
{
	if(head != NULL)
	{
		ListItem<T>* temp = head;
		head = head->next;	
		if(head != NULL){
			head -> prev = NULL;
		}
		temp->next = NULL;
		temp->prev = NULL;
		delete temp;
		temp = NULL;
	}

	else
	{
		return;
	}
}

template <class T>
void LinkedList<T>::deleteTail()
{
	if(head != NULL)
	{
		if(head->next == NULL){
			deleteHead();
			return;
		}
		ListItem<T>* temp = head;

		ListItem<T>* here = head;

		while(here->next != NULL)
		{
			temp = here;
			here = here->next;
		}

		delete here;
		temp->next = NULL;

	}

	else
	{
		return;
	}	
}

template <class T>
int LinkedList<T>::length()
{
	if(head==NULL)
	{
		return 0;
	}

	ListItem<T>* here = head;
	
	int counter = 1;
	while(here->next != NULL)
	{
		here = here->next;
		counter++;
	}

	return counter;
}

template <class T>
void LinkedList<T>::reverse()
{
	
	ListItem<T>* temp = NULL;
	ListItem<T>* here = head; 
	if(head == NULL)
	{
		return;
	}

	else
	{
		while(here != NULL)
		{
			temp = here->prev;
			here->prev = here->next;
			here->next = temp;
			here = here->prev;
		}	
		
		if(temp!=NULL)
		{
			head=temp->prev;
		}

	}
	
}

template <class T>
void LinkedList<T>::parityArrangement()
{	
	ListItem<T>* odd = head; 
	ListItem<T>* even = head->next;


	if(head == NULL)
	{
		cout << "hello1" << endl;
		return;
	}

	else if(head->next == NULL)
	{
		return;
	}

	else
	{
		ListItem<T>* firste = even;

		
		while(true)
			{
				if(even->next == NULL)
				{
					odd->next = firste;
					firste->prev = odd;
					break;	
				}

				odd->next = even->next;
				even->next->prev = odd;
				odd = even->next;

				if(odd->next == NULL)
				{
					even->next = NULL;
					odd->next = firste;
					firste->prev = odd;
					break;
				}

				even->next = odd->next;
				odd->next->prev = even;
				even = odd->next;	
			}		
	} 
		
}


template<class T>
bool LinkedList<T>::isPalindrome()
{
	ListItem<T>* here = head;
	ListItem<T>* rev = head;

	if(head == NULL)
	{
		return 0;
	}

	else
	{
		while(rev->next != NULL)
		{
			rev = rev->next;
		}

		while(here->next != NULL)
		{
			if(here->value == rev->value)
			{
				here = here->next;
				rev = rev->prev;
			}
			else
			{
				return 0;
			}
		}
		return 1;
	}
}


#endif
