#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "LinkedList.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)

{
	long arrays[nums.size()];
	int size = nums.size();

	for(int i = 0; i < size; i++)
	{
		arrays[i] = nums[i];
	}

	for(int i = 1; i < size; i++)
	{
		int key = arrays[i];
		int j;

		for(j = i - 1; j >= 0; j--)
		{
			if(arrays[j] > key)
			{ 
				arrays[j + 1] = arrays[j];
			}
			else
			{
				break;
			}
		}
		arrays[j + 1] = key;
	}

	vector<long> newnums;
	for(int i = 0; i < size; i++)
	{
		newnums.push_back(arrays[i]);
	}

	return newnums;
}

//=====================================================================================
LinkedList<long>* merge(LinkedList<long>* lista, LinkedList<long>* listb)
{
	LinkedList<long>* finallist = new LinkedList<long>;
	ListItem<long>* aitem = lista->getHead();
	ListItem<long>* bitem = listb->getHead();

	while(aitem != NULL && bitem != NULL)
	{
		if(aitem->value > bitem->value)
		{
			finallist->insertAtTail(bitem->value);
			listb->deleteHead();
			bitem = listb->getHead();
		}
		else
		{
			finallist->insertAtTail(aitem->value);
			lista->deleteHead();
			aitem = lista->getHead();
		}

	}

	while(aitem != NULL)
	{
		finallist->insertAtTail(aitem->value);
		lista->deleteHead();
		aitem = lista->getHead();
	}

	while(bitem != NULL)
	{
		finallist->insertAtTail(bitem->value);
		listb->deleteHead();
		bitem = listb->getHead();
	}
	return finallist;
}

vector<long> MergeSort(vector<long> nums)
{
	int size = nums.size();
	LinkedList<long>* newlist = new LinkedList<long>;
	LinkedList<long>* firsthalf = new LinkedList<long>;
	LinkedList<long>* secondhalf = new LinkedList<long>;

	if(size == 1)
	{
		return nums;
	}

	for(int i = 0; i < size; i++)
	{
		newlist->insertAtHead(nums[i]);
	}

	ListItem<long>* thehead = newlist->getHead();
	ListItem<long>* thetail = newlist->getTail();

	int mycounter = 0;
	while(mycounter != size/2)
	{
		firsthalf->insertAtHead(thehead->value);
		secondhalf->insertAtHead(thetail->value);
		thehead = thehead->next;
		thetail = thetail->prev;
		mycounter++;
	}

	if((size % 2) != 0)
	{
		secondhalf->insertAtHead(thetail->value);
	}

	vector<long> vfirst;
	vector<long> vsecond;

	ListItem<long>* firsthead = firsthalf->getHead();
	ListItem<long>* secondhead = secondhalf->getHead();

	while(firsthead != NULL)
	{
		vfirst.push_back(firsthead->value);
		firsthead = firsthead->next;
	}

	while(secondhead != NULL)
	{
		vsecond.push_back(secondhead->value);
		secondhead = secondhead->next;
	}

	vector<long> firstbw = MergeSort(vfirst);
	vector<long> secondbw = MergeSort(vsecond);

	LinkedList<long>* msvfirst = new LinkedList<long>;
	LinkedList<long>* msvsecond = new LinkedList<long>;	

	for(int i = 0; i < size/2; i++)
	{
		msvfirst->insertAtTail(firstbw[i]);
	}

	if((size % 2) != 0)
	{
		for(int i = 0; i < ((size/2) + 1); i++)
		{
			msvsecond->insertAtTail(secondbw[i]);
		}
	}

	else
	{
		for(int i = 0; i < (size/2); i++)
		{
			msvsecond->insertAtTail(secondbw[i]);
		}
	}

	LinkedList<long>* finallist = merge(msvfirst, msvsecond);

	vector<long> fvector;
	ListItem<long>* fhead = finallist->getHead();

	while(fhead != NULL)
	{
		fvector.push_back(fhead->value);
		fhead = fhead->next;
	}

	return fvector;

}

//=====================================================================================
int partit(long* thearray, int low, int high)
{
	int pivot = thearray[high];
	int smallindex = low - 1;

	// int j = low;
	for(int j = low; j <= high - 1; j++)
	{
		if(thearray[j] <= pivot)
		{
			smallindex++;
			int temp = thearray[smallindex];
			thearray[smallindex] = thearray[j];
			thearray[j] = temp;
		}
	}
	
	int temp = thearray[smallindex + 1];
	thearray[smallindex + 1] = thearray[high];
	thearray[high] = temp;

	return (smallindex + 1);
}

long* QSArray(long* arrays, int low, int high)
{
	
	if(low < high)
	{
		int partindex = partit(arrays, low, high);
		QSArray(arrays, low, partindex - 1);
		QSArray(arrays, partindex + 1, high);
	}
	return arrays;
}

vector<long> QuickSortArray(vector<long> nums)
{
	int size = nums.size();

	int low = 0;
	int high = size - 1;
	long arrays[nums.size()];

	for(int i = 0; i < size; i++)
	{
		arrays[i] = nums[i];
	}


	long* sort = QSArray(arrays, low, high);

	for (int i = 0; i < size; ++i)
	{
		nums[i] = sort[i];
	}

	return nums;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	long arrays[nums.size()];
	int size = nums.size();
	MinHeap nheap(size);

	for(int i = 0; i < size; i++)
	{
		nheap.insertKey(nums[i]);
	}

	vector<long> newnums;
	for(int i = 0; i < size; i++)
	{
		newnums.push_back(nheap.extractMin());
	}
	return newnums;

}

#endif