#include <fstream>
#include <ctime>
#include "sorts.cpp"

using namespace std;

int binarySearch(long arrays[], int left, int right, int x)
{
    while (left <= right)
    {
        int middle = left + (right-left)/2;
 
        if (arrays[middle] == x)
        {
            return middle;
        }

        if (arrays[middle] < x)
        {
            left = middle + 1;
        }
 
        else
        {
            right = middle - 1;
        }
    }

    return -1;
}
vector< vector<long> > smartSearch(vector<long> nums, long k)
{  
    vector<long> sorted = QuickSortArray(nums);
    
    long arrays[sorted.size()];
    int size = sorted.size();
    //cout << "hello3" << endl;
    for(int i = 0; i < size; i++)
    {
        arrays[i] = sorted[i];
    }

    vector< vector<long> > bigvec;
    vector<long> smallvec;

    for(int i = 0; i < size; i++)
    {
        int difference = k - arrays[i];

        if(binarySearch(arrays, 0, size - 1, difference) != -1)
        {
            smallvec.push_back(arrays[i]);
            smallvec.push_back(difference);
            bigvec.push_back(smallvec);
            smallvec.clear();
        }
    }
    return bigvec;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    int start_s=clock();

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        {//cout << "why" << endl;
                cout << result[i][0] << ", " << result[i][1] << endl;}
    int stop_s=clock();

    cout << "Time: " << (stop_s-start_s)/double(CLOCKS_PER_SEC) << " seconds" << endl;

    return 0;
}