#include <fstream>
#include "sorts.cpp"
#include <ctime>

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   

    // Write your code in this function

    nums=QuickSortArray(nums);
    vector< vector<long> > result;

    //for(int i = 0; i < nums.size(); i++)
    //    cout << nums[i] << endl;
    int index=0;
    for(int i = 0; i < nums.size(); i++)
    {
        if (nums[i]<k)
            index=i;
    }
    //cout<<"index= "<<index<<endl;
    int putin=0;
    int in;
    for(int s=0;s<index+1;s++)
    {
        //cout<<s<<endl;
        for(int i=index;i>-1;i--)
        {
            in=i;
            if (nums[i]+nums[s]==k)
            {   
                //cout<<nums[s]<<"    "<<nums[i]<<endl;
                result.push_back(vector<long>());
                result[putin].push_back(nums[s]);
                result[putin].push_back(nums[i]);
                putin++;
            }
            if (nums[k]+nums[s]<k)
            {
                break;
            }
        }

    }




    return result;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: "<<endl;
    cin >> k;
  /*  nums.push_back(1);
    nums.push_back(6);
    nums.push_back(5);
    nums.push_back(4);
    nums.push_back(8);
    nums.push_back(2);
    nums.push_back(5);
    nums.push_back(1);*/
    clock_t begin = clock();
    vector< vector<long> > result = smartSearch(nums, k);
    clock_t end = clock();
    double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;

    //cout<<result.size()<<endl;
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;
    cout<<elapsed_secs<<" seconds"<<endl;
    return 0;
}