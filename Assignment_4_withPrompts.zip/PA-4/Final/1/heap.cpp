#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity=cap;
	harr=new int[capacity];
	heap_size=0;
}

void MinHeap::MinHeapify(int i)
{
	int temp;
	int r=right(i);
	int l=left(i);
	if (l>=heap_size)
	{
		return;
	}
	if (l<heap_size && r==heap_size)
	{
		if(harr[i]>harr[l])
		{
			temp=harr[l];
			harr[l]=harr[i];
			harr[i]=temp;
		}
		return;
	}
	if (r<heap_size && l<heap_size)
	{
		int smaller=harr[i];
		string check="";
		if (harr[l]<smaller)
		{
			smaller=harr[l];
			check="left";
		}
		if (harr[r]<smaller)
		{
			smaller=harr[r];
			check="right";
		}
		if(check=="right")
		{
			temp=harr[r];
			harr[r]=harr[i];
			harr[i]=temp;
			MinHeapify(r);
		}
		else if(check=="left")
		{
			temp=harr[l];
			harr[l]=harr[i];
			harr[i]=temp;
			MinHeapify(l);
		}
	}
}
/* 
void MinHeap::MinHeapify(int i)
{
    int l = left(i);
    int r = right(i);
    int smallest = i;
    if (l < heap_size && harr[l] < harr[i])
        smallest = l;
    if (r < heap_size && harr[r] < harr[smallest])
        smallest = r;
    if (smallest != i)
    {
        //swap(&harr[i], &harr[smallest]);
        int temp=harr[i];
        harr[i]=harr[smallest];
        harr[smallest]=temp;
        MinHeapify(smallest);
    }
}
*/
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i+1);
}
 
int MinHeap::right(int i)
{
	return (2*i+2);
}
 
int MinHeap::extractMin()
{
	//if (heap_size <= 0)
    //    return INT_MAX;
	if (heap_size == 1)
    {
        heap_size--;
        return harr[0];
    }
   	int min = harr[0];
   	harr[0] = harr[heap_size-1];
   	heap_size--;
   	MinHeapify(0);
    return min;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;
	int temp;
	while (i!=0)
	{
		if (harr[parent(i)]>harr[i])
		{
			temp=harr[parent(i)];
			harr[parent(i)]=harr[i];
			harr[i]=temp;
		}
		i=parent(i);
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if (i<heap_size)
	{
		decreaseKey(i,harr[0]-1);
		extractMin();
	}
}
 
void MinHeap::insertKey(int k)
{
	if (heap_size==capacity)
	{
		return;
	}
	heap_size++;
	int  index= heap_size-1;
	harr[index]=k;
	int temp;
	while (index!=0)
	{
		if (harr[parent(index)]>harr[index])
		{
			temp=harr[parent(index)];
			harr[parent(index)]=harr[index];
			harr[index]=temp;
		}
		index=parent(index);
	}
}
/*
void MinHeap::insertKey(int k)
{
    if (heap_size == capacity)
    {
        cout << "\nOverflow: Could not insertKey\n";
        return;
    }
 
    // First insert the new key at the end
    heap_size++;
    int i = heap_size - 1;
    harr[i] = k;
 
    // Fix the min heap property if it is violated
    while (i != 0 && harr[parent(i)] > harr[i])
    {
       
        int temp=harr[parent(i)];
		harr[parent(i)]=harr[i];
		harr[i]=temp;
        i = parent(i);
    }
}
*/
int* MinHeap::getHeap()
{
	return harr;
}

#endif