#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//=====================================================================================
List<long>* Merge(List<long>* list);
List<long>* MergeSorted(List<long>* list1, List<long>* list2);
void qsa(long arr[], int i, int j);
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	vector<long> result;
	long array[nums.size()];
	long temp;
	for(int i=0;i<nums.size();i++)
	{
		array[i]=nums[i];
	}
	for(int j=0;j<nums.size();j++)
	{
		for(int k=j;k>0;k--)
		{
			if (array[k]<array[k-1])
			{
				temp=array[k];
				array[k]=array[k-1];
				array[k-1]=temp;
			}
			else break;
		}
	}
	for(int l=0;l<nums.size();l++)
	{
		result.push_back(array[l]);
	}
	return result;
}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	List<long>* list=new List<long>;
	List<long>* result=new List<long>;
	for (int i=0;i<nums.size();i++)
	{
		list->insertAtTail(nums[i]);
	}
	result=Merge(list);
	int size=result->length();
	vector<long> res;
	for(int i=0;i<size;i++)
	{
		res.push_back(result->value(result->getHead()));
		result->deleteHead();
	}
	return res;
}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
	long* array=new long[nums.size()];
	vector<long> result;
	for(int i=0;i<nums.size();i++)
	{
		array[i]=nums[i];
	}
	qsa(array,0,nums.size()-1);
	for(int l=0;l<nums.size();l++)
	{
		result.push_back(array[l]);
	}
	return result;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	List<long>* list=new List<long>;
	for (int i=0;i<nums.size();i++)
	{
		list->insertAtTail(nums[i]);
	}
	list->qsl(0,nums.size()-1);
	int size=list->length();
	vector<long> res;
	for(int i=0;i<size;i++)
	{
		res.push_back(list->value(list->getHead()));
		list->deleteHead();
	}
	return res;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap* heap = new MinHeap(nums.size());
	for (int i=0;i<nums.size();i++)
	{
		heap->insertKey(nums[i]);
	}
	vector<long> result;
	for (int j=0;j<nums.size();j++)
	{
		result.push_back(heap->extractMin());
	}
	return result;
}
//======================================================================================
List<long>* Merge(List<long>* l)
{
	List<long>* list=new List<long>(*l);
	List<long>* list1=new List<long>;
	List<long>* list2=new List<long>;
	if(list->length()<=1)
	{
		return l;
	}
	int length=list->length();
	for(int i=0;i<length/2;i++)
	{
		list1->insertAtTail(list->value(list->getHead()));
		list->deleteHead();
	}
	for (int j=length/2;j<length;j++)
	{
		list2->insertAtTail(list->value(list->getHead()));
		list->deleteHead();
	}

	list=l;
	return MergeSorted(Merge(list1),Merge(list2));
}
List<long>* MergeSorted(List<long>* list10, List<long>* list20)
{
	List<long>* sorted=new List<long>;
	List<long>* list1=new List<long>(* list10);
	List<long>* list2=new List<long>(* list20);
    while(list1->length()>=1 && list2->length()>=1)
    {	
	    if (list1->value(list1->getHead())<=list2->value(list2->getHead()))
	    {
	    	sorted->insertAtTail(list1->value(list1->getHead()));
	    	list1->deleteHead();
	    }
	    else
	    {
	    	sorted->insertAtTail(list2->value(list2->getHead()));
	    	list2->deleteHead();
	    }
	}
    if(list1->length()>=1 && list2->length()==0)
    {
    	while(list1->length()!=0)
    	{
    		sorted->insertAtTail(list1->value(list1->getHead()));
    		list1->deleteHead();
    	}
    }
    if(list2->length()>=1 && list1->length()==0)
    {
    	while(list2->length()!=0)
    	{
    		sorted->insertAtTail(list2->value(list2->getHead()));
    		list2->deleteHead();
    	}
    }
    return sorted;
}
//======================================================================================
void qsa(long array[], int l, int h)
{
	//cout<<l<<"<-low   height->"<<h<<endl;
	if (l<h)
	{
		int j=h;
		int i=l;
		long pivot=array[h];
		//cout<<"pivot: "<<array[h]<<endl;
		long temp;
		while (l<j)
		{
			//cout<<l<<j<<endl;
			while(array[l]<=pivot && l<j)
			{
				l++;
			}
			while(array[j]>=pivot && l<j)
			{
				j--;
			}
			//if (i==j) break;
				temp=array[l];
				array[l]=array[j];
				array[j]=temp;
		}
		//cout<<i<<endl;
		temp=array[l];
		array[l]=array[h];
		array[h]=temp;

    	int index=l;
    	qsa(array,i,index-1);
    	qsa(array,index,h);
	}
}
template <class T>
void List<T>::qsl(int l, int h)
{
	//cout<<l<<"<-low   height->"<<h<<endl;
	if (l<h)
	{
		int j=h;
		int i=l;
		//cout<<h<<endl;
		ListItem<T> *temph=getHead();
		for (int d=0;d<h;d++) {temph=temph->next;}
		long pivot=temph->value;
		//cout<<"pivot: "<<temph->value<<endl;
		long temp;
		ListItem<T> *templ=getHead();
		for (int d=0;d<l;d++) templ=templ->next;
		ListItem<T> *tempj=getHead();
		for (int d=0;d<j;d++) tempj=tempj->next;
		while (l<j)
		{

			while(templ->value<=pivot && l<j)
			{
				l++;
				templ=templ->next;
			}

			
			while(tempj->value>=pivot && l<j)
			{
				j--;
				tempj=tempj->prev;
			}

				temp=templ->value;
				templ->value=tempj->value;
				tempj->value=temp;
		}

		
		temp=templ->value;
		templ->value=temph->value;
		temph->value=temp;
		
    	int index=l;
    	qsl(i,index-1);
    	qsl(index,h);
    }
}
#endif
/*
int main()
{
    vector<long> entries;
    
    entries.push_back(5000);
    entries.push_back(3456);
    entries.push_back(9876);
    entries.push_back(8921);
    entries.push_back(3287);
    entries.push_back(2168);
    entries.push_back(7443);
    entries.push_back(2315);
    entries.push_back(5000);
    entries.push_back(6547);

    vector<long> result = QuickSortList(entries);
    for(int i=0;i<entries.size();i++)
    {
        cout<<result[i]<<endl;     
    }
    return 0;
}*/