#include <fstream>
#include <time.h>
#include <thread>
#include <chrono>
#include <future>

#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    vector <vector <long> > pairs;
    vector <long> tempPair;

    nums = QuickSortArray (nums);

    int left = 0;
    int right = nums.size ()-1;

    while (left < right)
    {
        if (nums [left] + nums [right] > k)
        {
            right--;
        }

        else if (nums [left] + nums [right] < k)
        {
            left++;
        }

        else
        {
            tempPair.push_back (nums [left]);
            tempPair.push_back (nums [right]);
            pairs.push_back (tempPair);
            tempPair.clear ();
            left++;
        }
    }

    return pairs;
}

int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    using namespace std::chrono;
    high_resolution_clock::time_point timeStart = high_resolution_clock::now();;

    vector< vector<long> > result = smartSearch(nums, k);

    high_resolution_clock::time_point timeEnd = high_resolution_clock::now();;
    duration<double> totalTime = duration_cast<duration<double>>(timeEnd - timeStart);
    cout << "SEARCH COMPLETED IN : " << totalTime.count() << " SECONDS."<<endl << endl;

    cout << "Press 1 to display all pairs: ";
    int x;
    cin >> x;

    if (x == 1)
    {
        for(int i = 0; i < result.size(); i++)
        {
            cout << result[i][0] << ", " << result[i][1] << endl;
        }
    }

    return 0;
}
