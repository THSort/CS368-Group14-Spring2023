#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
    capacity = cap;
    heap_size = 0;
    harr = new int [capacity];
}

void MinHeap::MinHeapify(int i)
{
    int smallIndex = i;

    if (right (i) < heap_size && harr [i] > harr [right (i)])
    {
        smallIndex = right (i);
    }

    if (left (i) < heap_size && harr [smallIndex] > harr [left (i)])
    {
        smallIndex = left (i);
    }

    if (smallIndex != i)
    {
        int temp = harr [i];
        harr [i] = harr [smallIndex];
        harr [smallIndex] = temp;
        MinHeapify (smallIndex);
    }
}

int MinHeap::parent(int i)
{
    return (i-1)/2;
}

int MinHeap::left(int i)
{
    return (2*i) + 1;
}

int MinHeap::right(int i)
{
    return (2*i) + 2;
}

int MinHeap::extractMin()
{
    if (heap_size > 0)
    {
        int minimum = harr [0];
        harr [0] = harr [heap_size - 1];
        heap_size--;
        MinHeapify (0);

        return minimum;
    }
}

void MinHeap::decreaseKey(int i, int new_val)
{
    harr [i] = new_val;

    while (i > 0 && harr [i] < harr [parent (i)])
    {
        int temp = harr [i];
        harr [i] = harr [parent (i)];
        harr [parent (i)] = temp;
        i = parent (i);
    }
}

int MinHeap::getMin()
{
    return harr [0];
}

void MinHeap::deleteKey(int i)
{
    if (i < heap_size)
    {
        decreaseKey (i, -10000000);
        extractMin ();
    }
}

void MinHeap::insertKey(int k)
{
    if (heap_size <= capacity)
    {
        heap_size++;
        decreaseKey (heap_size - 1, k);
    }
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif
