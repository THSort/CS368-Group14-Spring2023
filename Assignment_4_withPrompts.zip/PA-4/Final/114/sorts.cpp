#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
#include <algorithm>

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
    long arr [nums.size ()];

    for (int i = 0; i < nums.size (); i++)
    {
        arr [i] = nums [i];
    }

    for (int i = 1; i < nums.size (); i++)
    {
        long temp = arr [i];
        int j = i-1;

        while (arr [j] > temp && j > -1)
        {
            arr [j+1] = arr [j];
            j = j - 1;
        }

        arr [j+1] = temp;
    }

    for (int i = 0; i < nums.size (); i++)
    {
        nums [i] = arr [i];
    }

    return nums;
}

//=====================================================================================
void Merge (List <long>& l1, List <long>& l2, List <long>& mainList)
{
    ListItem <long>* traverse1 = l1.getTail ();
    ListItem <long>* traverse2 = l2.getTail ();

    while (traverse1 != NULL && traverse2 != NULL)
    {
        if (traverse1 -> value < traverse2 -> value)
        {
            mainList.insertAtHead (traverse1 -> value);
            traverse1 = traverse1 -> prev;
        }

        else
        {
            mainList.insertAtHead (traverse2 -> value);
            traverse2 = traverse2 -> prev;
        }
    }

    while (traverse1 != NULL)
    {
        mainList.insertAtHead (traverse1 -> value);
        traverse1 = traverse1 -> prev;
    }

    while (traverse2 != NULL)
    {
        mainList.insertAtHead (traverse2 -> value);
        traverse2 = traverse2 -> prev;
    }
}

void sortMerge (List <long>& mainList)
{
    if (mainList.length () <= 1)
    {
        return;
    }

    List <long> l1;
    List <long> l2;
    ListItem <long>* traverse = mainList.getHead ();

    for (int i = 0; i < mainList.length () / 2; i++)
    {
        l1.insertAtHead (traverse -> value);
        traverse = traverse -> next;
    }

    for (int i = mainList.length () / 2; i < mainList.length (); i++)
    {
        l2.insertAtHead (traverse -> value);
        traverse = traverse -> next;
    }

    mainList.~List ();
    sortMerge (l1);
    sortMerge (l2);
    Merge (l1, l2, mainList);
}

vector<long> MergeSort(vector<long> nums)
{
    List <long> mainList;

    for (int x = 0; x < nums.size (); x++)
    {
        mainList.insertAtHead (nums [x]);
    }

    sortMerge (mainList);
    ListItem <long>* traverse = mainList.getHead ();

    for (int x = nums.size ()-1; x >= 0; x--)
    {
        nums [x] = traverse -> value;
        traverse = traverse -> next;
    }

    return nums;
}

//=====================================================================================
int medianOfThree (long arr [], int max, int min)
{
    int a, b, c;
    a = max;
    c = min;
    b = (max-min)/2;

    vector <long> temp;
    temp.push_back (arr [a]);
    temp.push_back (arr [b]);
    temp.push_back (arr [c]);

    sort (temp.begin (), temp.end ());

    if (temp [1] == arr [a])
    {
        return a;
    }

    else if (temp [1] == arr [b])
    {
        return b;
    }

    else
    {
       return c;
    }
}

void quickSortA (long arr [], int a, int b)
{
    if (a >= b)
    {
        return;
    }

    /*int index = medianOfThree (arr, b, a); // median of three method.
    long median = arr [index];
    arr [index] = arr [b];
    arr [b] = median;*/

    /*long first = arr [a]; // first element as pivot.
    arr [a] = arr [b];
    arr [b] = first;*/

    long pivot = arr [b]; // last element as pivot. Gives the lowest running-time.
    int left = a;
    int right = b - 1;

    while (left <= right)
    {
        while (left <= right && pivot >= arr [left])
        {
            left++;
        }

        while (right >= left && arr [right] >= pivot)
        {
            right --;
        }

        if (left < right)
        {
            long temp = arr [left];
            arr [left] = arr [right];
            arr [right] = temp;
        }
    }

    long temp = arr [left];
    arr [left] = arr [b];
    arr [b] = temp;

    quickSortA (arr, a, left-1);
    quickSortA (arr, left+1, b);
}

vector<long> QuickSortArray(vector<long> nums)
{
    long* arr = new long [nums.size ()];

    for (int x = nums.size (); x >= 0; x--)
    {
        arr [x] = nums [x];
    }

    quickSortA (arr, 0, nums.size ()-1);

    for (int x = 0; x < nums.size (); x++)
    {
        nums [x] = arr [x];
    }

    return nums;
}

//=====================================================================================
void quickSortB (ListItem <long>* a, ListItem <long>* b, int l, int r)
{
    if (l >= r)
    {
        return;
    }

    long pivot = b -> value;

    ListItem <long>* left = a;
    int x = l;

    ListItem <long>* right = b -> prev;
    int y = r - 1;

    while (x <= y)
    {
        while (x <= y && pivot >= left -> value)
        {
            left = left -> next;
            x++;
        }

        while (y >= x && right -> value >= pivot)
        {
            right = right -> prev;
            y--;
        }

        if (x < y)
        {
            long temp = left -> value;
            left -> value = right -> value;
            right -> value = temp;
        }
    }

    long temp = left -> value;
    left -> value = b -> value;
    b -> value = temp;

    quickSortB (a, left -> prev, l, x-1);
    quickSortB (left -> next, b, x+1, r);
}

vector<long> QuickSortList(vector<long> nums)
{
    List <long> mainList;

    for (int x = 0; x < nums.size (); x++)
    {
        mainList.insertAtHead (nums [x]);
    }

    ListItem <long>* a = mainList.getHead ();
    ListItem <long>* b = mainList.getTail ();

    quickSortB (a, b, 0, nums.size ()-1);

    ListItem <long>* traverse = mainList.getHead ();

    for (int x = 0; x < nums.size (); x++)
    {
        nums [x] = traverse -> value;
        traverse = traverse -> next;
    }

    return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
    MinHeap heap (nums.size ());

    for (int x = 0; x < nums.size (); x++)
    {
        heap.insertKey (nums [x]);
    }

    for (int x = 0; x < nums.size (); x++)
    {
        nums [x] = heap.extractMin ();
    }

    return nums;
}

#endif
