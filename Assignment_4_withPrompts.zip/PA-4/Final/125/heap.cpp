#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <cmath>

MinHeap::MinHeap(int cap)
{
	capacity =  cap;
	harr = new int[capacity]();
	heap_size = 0;
}

void MinHeap::swap(int a, int b){
	int temp = harr[a];
	harr[a] = harr[b];
	harr[b] = temp;
}

void MinHeap::MinHeapify(int i)
{
	if(i > heap_size-1)
		return;
	int leftChild = left(i);
	int rightChild = right(i);
	if(leftChild < heap_size || rightChild < heap_size){
		int temp;
		if(harr[leftChild] < harr[rightChild]){
			temp = leftChild;
		}
		else{
			temp = rightChild;
		}
		if(harr[temp] < harr[i]){
			swap(temp, i);
			MinHeapify(temp);
		}
		else{
			return;
		}
	}
}

int MinHeap::parent(int i)
{
	return ceil((i-1)/2);
}

int MinHeap::left(int i)
{
	return (2*i)+1;
}

int MinHeap::right(int i)
{
	return (2*i)+2;
}

int MinHeap::extractMin()
{
	int min = harr[0];
	deleteKey(0);
	return min;
}

void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	if(i != 0){
		int temp;
		while(i != 0){
			temp = i;
			i = parent(i);
			if(harr[i] > harr[temp])
				swap(i, temp);
		}
	}
}

int MinHeap::getMin()
{
	return harr[0];
}

void MinHeap::deleteKey(int i)
{
	if(i > heap_size-1)
		return;
	// int leftChild = left(i);
	// int rightChild = right(i);
	harr[i] = harr[heap_size-1];
	heap_size--;
	MinHeapify(i);
}

void MinHeap::insertKey(int k)
{
	if(heap_size >= capacity)
		return;
	harr[heap_size] = k;
	heap_size++;
	if(heap_size > 0){
		int temp = heap_size-1;
		int p = parent(heap_size-1);
		while(harr[temp] < harr[p]){
			swap(temp, p);
			temp = p;
			p = parent(temp);
		}
	}

}

int* MinHeap::getHeap()
{
	return harr;
}

// int main(){
// 	MinHeap a(100);
// 	// a.insertKey(0);
// 	a.insertKey(1);
// 	a.insertKey(4);
// 	a.insertKey(2);
// 	a.insertKey(123);
// 	a.insertKey(3);
// 	a.insertKey(-10);
// 	a.insertKey(15);
// 	a.insertKey(10);
// 	a.insertKey(6);
// 	a.insertKey(-1);
// 	a.insertKey(100);
// 	a.insertKey(153);
// 	a.insertKey(140);
// 	a.insertKey(180);
// 	a.insertKey(-2010);
// 	for(int i = 0; i < a.heap_size; i++){
// 		cout << a.harr[i] << " ";
// 	}
// 	cout << endl;
// 	// cout << a.extractMin() << endl;
// 	for(int i = a.heap_size; i > 0; i--){
// 		cout << a.extractMin() << " ";
// 		// cout << a.harr[i] << " ";
// 	}
// 	return 0;
// }

#endif