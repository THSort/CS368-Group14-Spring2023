#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
#include <ctime>

// #include <iostream>
// #include <cstdlib>
// #include <vector>

// using namespace std;

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int vectorSize = nums.size();
	long sortedArray[vectorSize];
	for(int i=0 ; i < vectorSize ;i++){
		sortedArray[i] = nums[i];
	}
	for(int i = 1; i < vectorSize; i++){
		if(sortedArray[i-1] > sortedArray[i]){
			long temp = sortedArray[i];
			for(int j = i-1; j >= 0; j--){
				sortedArray[j+1] = sortedArray[j];
				if(temp > sortedArray[j-1]){
					sortedArray[j] = temp;
					break;
				}
				else if(j == 0)
					sortedArray[j] = temp;
			}
		}
	}
	for(int i = 0; i < vectorSize; i++){
		nums[i] = sortedArray[i];
	} 
	return nums;
}

//=====================================================================================
void Merge(ListItem<long>* uS1, ListItem<long>* uS2 ,ListItem<long>**merged){
	List<long>* S = new List<long>;
	while(uS1 != NULL && uS2 != NULL){
		if(uS1->value < uS2->value){
			S->insertAtTail(uS1->value);
			uS1 = uS1->next;
		}
		else{
			S->insertAtTail(uS2->value);
			uS2 = uS2->next;
		}
	}
	ListItem<long>* temp = S->getTail();
	if(uS1 != NULL){
		temp->next = uS1;
	}
	if(uS2 != NULL){
		temp->next = uS2;
	}
	ListItem<long>* s = S->getHead();
	*merged = S->getHead();

}

ListItem<long>* MergeSortRecursive(ListItem<long>* uS, int t){
	ListItem<long>* merged;
	if(t <= 1)
		return uS;
	else{
	int t1 = t/2;
	ListItem<long> *temp1 = uS;
	for(int i = 0; i < (t1-1 ); i++){
		temp1 = temp1->next;
	}
	ListItem<long> *temp2 = temp1->next;
	temp1->next = NULL;
	temp2->prev = NULL;
	ListItem<long> *l = MergeSortRecursive(uS, t1);
	ListItem<long> *r = MergeSortRecursive(temp2, t-t1);
	Merge(l, r , &merged);
	return merged;
	}
}

vector<long> MergeSort(vector<long> nums)
{
	if(nums.size() <= 1)
		return nums;
	else{
		List<long> uS;
		int t = nums.size();
		for(int i = 0; i < t; i++){
			uS.insertAtHead(nums[i]);
		}
		ListItem<long>* temp = MergeSortRecursive(uS.getHead(), t);
		for(int i = 0; temp != NULL; i++){
			nums[i] = temp->value;
			temp = temp->next;
		}
		return nums;
	}
}

//=====================================================================================
void swap(long arr[], int a, int b){
	long temp = arr[b];
	arr[b] = arr[a];
	arr[a] = temp;
}

void QuickSortArrayRecursive(long arr[], int initial, int final){
	if(initial >= final)
		return;
	long pivot = arr[final];
	long l = initial;
	long r = final-1;
	while(l <= r){
		while(l <= r){
			if(arr[l] >= pivot){
				swap(arr, l, r);
				r--;
			}
			else{
				l++;
			}
		}
		while(l <= r){
			if(arr[r] <= pivot){
				swap(arr, l, r);
				l++;
			}
			else{
				r--;
			}
		}
	}
	swap(arr, l, final);
	QuickSortArrayRecursive(arr, initial, l-1);
	QuickSortArrayRecursive(arr, l+1, final);
}


vector<long> QuickSortArray(vector<long> nums)
{
	int s = nums.size();
	long arr[s];
	for(int i = 0; i < s; i++){
		arr[i] = nums[i];
	}
	QuickSortArrayRecursive(arr, 0, s-1);
	for(int i = 0; i < s; i++){
		nums[i] = arr[i];
	}
	return nums;
}

//=====================================================================================

void swap2(ListItem<long> *a, ListItem<long> *b){
	long temp = a->value;
	a->value = b->value;
	b->value = temp;
}

List<long> mergeList (ListItem<long> l, ListItem<long> e, ListItem<long> e1, ListItem<long> r){
	// List<long> sorted;
	// while (l!= NULL || r!=NULL){
	// 	if (l->value < r->value){
	// 		sorted.insertAtTail(l->value);
	// 		l = l->next;
	// 	}
	// 	else if(r->value < l->value){
	// 		sorted.insertAtTail(r->value);
	// 		r = r->next;
	// 	}
	// }
	// while(l!=NULL){
	// 	sorted.insertAtTail(l->value);
	// 	l=l->next;
	// }
	// while(r!=NULL){
	// 	sorted.insertAtTail(r->value);
	// 	r=r->next;
	// }
	// return sorted.getHead();
	// l->next = e;
	// e1->next = r;
}


void QuickSortListRecursive(ListItem<long>* H, ListItem<long>* T, int t){
	// if(H == T)
	// 	return;
	// else if(H == NULL || T == NULL)
	// 	return;
	// else{
	// 	// int index = rand()%t;
	// 	List<long> firstPart, equalPart, secondPart;
	// 	ListItem<long> *pivot = T;
	// 	// cout<< pivot->value << endl;
	// 	ListItem<long> *l = H;
	// 	ListItem<long> *r = T->prev;
	// 	while(l != r){
	// 		if(l->value < pivot->value){
	// 			firstPart.insertAtHead(l->value);
	// 			l++;
	// 		}
	// 		else if(r->value < pivot->value){
	// 			firstPart.insertAtHead(r->value);
	// 			r = r->prev;
	// 		}
	// 		else if(l->value == pivot->value){
	// 			equalPart.insertAtHead(l->value);
	// 			l = l->next;
	// 		}
	// 		else if(l->value > pivot->value){
	// 			secondPart.insertAtHead(l->value);
	// 			l = l->next;
	// 		}
	// 		else if(r->value > pivot->value){
	// 			secondPart.insertAtHead(l->value);
	// 			r = r->prev;
	// 		}
	// 	}
	// 	swap2(l, pivot);
	// 	ListItem<long>* l = QuickSortListRecursive(firstPart.getHead(), firstPart.getTail());
	// 	ListItem<long>* r = QuickSortListRecursive(secondPart.getHead(), secondPart.getTail());
	// 	mergeList(l.getTail(), equalPart.getHead(), equalPart.getTail(), r.getHead());
	// }
}


vector<long> QuickSortList(vector<long> nums)
{
	// if(nums.size() <= 1)
	// 	return nums;
	// else{
	// 	List<long> uS;
	// 	int t = nums.size();
	// 	for(int i = t-1; i >= 0; i--){
	// 		uS.insertAtHead(nums[i]);
	// 	}
	// 	srand(time(NULL));
	// 	ListItem<long>* temp = QuickSortListRecursive(uS.getHead(), uS.getTail(), uS.length());
	// 	for(int i = 0; temp != NULL; i++){
	// 		nums[i] = temp->value;
	// 		temp = temp->next;
	// 	}
	// 	return nums;
	// }
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int l = nums.size();
	MinHeap heap(l);
	for(int i = 0; i < l; i++){
		heap.insertKey(nums[i]);
	}
	for(int i = 0; i < l; i++){
		nums[i] = heap.extractMin();
	}
	return nums;
}


// int main(){
// 	vector<long> v;
// 	// for(int i =0;i<20;i++){
//  // 		v.push_back(rand()%156652315);
//  //    }
//     v.push_back(1);
//     v.push_back(6);
//     v.push_back(2);
//     v.push_back(4);
//     // v.push_back(3);
//     // v.push_back(7);
//     // v.push_back(8);
//     // v.push_back(5);
//     // v.push_back(0);
//     for(int i = 0; i < v.size(); i++){
//     	cout << v[i] << " ";
//     }cout << endl;
//     vector<long> a = QuickSortList(v);
//     for(int i = 0; i < a.size(); i++){
//     	cout << a[i] << " ";
//     }
//     cout << endl;
//     // for(int i = 0; i < v.size(); i++){
//     // 	cout << v[i] << endl;
//     // }
//     // v = MergeSort(v);
//     // List<long> a, b;
//     // a.insertAtTail(1);
//     // a.insertAtTail(3);
//     // a.insertAtTail(5);
//     // a.insertAtTail(7);
//     // a.insertAtTail(9);
//     // a.insertAtTail(4);
//     // a.insertAtTail(4);
//     // a.insertAtTail(6);
//     // a.insertAtTail(312);
//     // a.insertAtTail(8);
//     // a.insertAtTail(10);
//     // ListItem<long>* temp = a.getHead();
//     // while(temp != NULL){
// 	   //  cout << temp->value << " ";
// 	   //  temp = temp->next;
//     // }
//     // cout << endl;
//     // temp = MergeSortRecursive(a.getHead(), a.length());
//     // while(temp != NULL){
// 	   //  cout << temp->value << " ";
// 	   //  temp = temp->next;
//     // }
//     // cout << endl;
//     // ListItem<long>* temp = Merge(a.getHead(), b.getHead());
//     // while(temp != NULL){
// 	   //  cout << temp->value << endl;
// 	   //  temp = temp->next;
//     // }
//     // cout << endl <<endl <<endl <<endl << "-------------" << endl;
//     // for(int i = 0; i < v.size(); i++){
//     // 	cout << v[i] << endl;
//     // }
//     return 0;
// }

#endif