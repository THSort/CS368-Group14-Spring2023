#include <fstream>
#include "sorts.cpp"

using namespace std;


void binarySearch(long nums[], long n, int initial, int final, long k, vector< vector<long> >& pair){
    int mid = (initial+final)/2;
    if(initial <= final){
     
        if((n+nums[mid]) == k){
            vector<long> a;
            a.push_back(n);
            a.push_back(nums[mid]);
            pair.push_back(a);
            return;
        }
        else if((n+nums[mid]) < k){
            binarySearch(nums, n, mid+1, final, k, pair);
        }
        else if((n+nums[mid]) > k){
            binarySearch(nums, n, initial, mid-1, k, pair);
        }
    }
}


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    // Write your code in this function
    vector< vector<long> > pair;
    nums = QuickSortArray(nums);
    int s = nums.size();
    long arr[s];
    for(int i = 0; i < s; i++){
        arr[i] = nums[i];
    }
    for(int i = 0; ; i++){
        if(arr[i] <= k)
            binarySearch(arr, arr[i], 0, s-1, k, pair);
        else
            break;
    }
    return pair;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}