#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//===============================HELPER FUNCTIONS======================================

long* toArray(std::vector<long> v){
  long* array = new long[v.size()];
  for (int i = 0; i<v.size();i++){
    array[i] = v[i];
  }
  return array;
}

std::vector<long> fromArray(long* x, int size){
  std::vector<long> v;
  for (int i = 0; i < size; i++) {
    v.push_back(x[i]);
    /* code */
  }

  return v;
}

template <class T>
void toList(List<T> x, std::vector<long> v){

  for (int i = 0 ; i<v.size() ; i++) {
    x.insertAtTail(i);

  }

}

// void merge()


// void swap(int a, int b)
// {
//     int t = a;
//     a = b;
//     b = t;
// }



//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
  std::vector<long> v;
  long* x = toArray(nums);
  int y;
  int j;
  for (int i = 1; i < nums.size(); i++)
  {
      y = x[i];
      j = i-1;

      while (j >= 0 && x[j] > y)
      {
         x[j+1] = x[j];
         j = j-1;
      }
      x[j+1] = y;
  }
  v = fromArray(x,nums.size());

  return v;

}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
  List<long> x;
  toList(x,nums);



}

//=====================================================================================
int part(long arr[], int s, int e)
{
    long pivot = arr[s];
    int pi=s;
    
    long temp = arr[pi];
    arr[pi] = arr[s];
    arr[s] = temp;

    int i = s +1;
    int j = e;
    while (i <= j)
    {
      while(arr[j] > pivot && i <= j )
      {
        j--;
      }
      while(pivot >= arr[i] && i <= j)
      {
        i++;              
      }
      if (i <j)
      {
        long temp2=arr[i];
        arr[i]=arr[j];
        arr[j]=temp2;
      }
    }
    long temp3 = arr[s];
    arr[s]=arr[i-1];
    arr[i-1]=temp3;
    pi = j;
    return pi;
}

void q_help(long arr[], int start, int end){
    if(start>=end)
    {
      return;
    }
    else
    {
      int i = part(arr, start, end);
      q_help(arr, start, i - 1);
      q_help(arr, i + 1, end);
    }
}
vector<long> QuickSortArray(vector<long> nums)
{
  std::vector<long> v;
  long* x = toArray(nums);
  q_help (x,0,nums.size()-1);
  v = fromArray(x,nums.size());
  return v;

}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)

{
    
    MinHeap sherry(nums.size());
    
    for (int i=0; i<nums.size(); i++)
    
    {
        
        sherry.insertKey(nums[i]);
        
    }
    
vector<long> ans(nums.size());
    
    for(int i = 0; i< nums.size(); i++)
    
    {
        
        ans[i]=sherry.extractMin();
        
    }
    
    return ans;
    
}
// int main(){
//   std::vector<long> vec;
//   for (int i = 10; i > 0; i--) {
//     vec.push_back(i);
//   }

//   List<long> x;
//   toList(x,vec);
  // for (int i = 0; i < vec.size(); i++) {
  //   cout << vec[i] << '\n';
  //   /* code */
  // }
  // vec = InsertionSort(vec);
  //
  // for (int i = 0; i < vec.size(); i++) {
  //   cout << vec[i] << '\n';
  //   /* code */
  // }
// }
#endif
