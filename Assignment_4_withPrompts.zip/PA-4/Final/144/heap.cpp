#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
    heap_size = 0;
    capacity = cap;
    harr = new int[cap];
}

void MinHeap::MinHeapify(int i)
{
    int l = left(i);
    int r = right(i);
    int smallest = i;
    if (l < heap_size && harr[l] < harr[i])
    smallest = l;
    if (r < heap_size && harr[r] < harr[smallest])
    smallest = r;
    if (smallest != i)
    {
        int temp = harr[i];
        harr[i]  = harr[smallest];
        harr[smallest]=temp;
        MinHeapify(smallest);
    }
}

int MinHeap::parent(int i)
{
    return ((i-1)/2);
}

int MinHeap::left(int i)
{
    return (2*i + 1);
}

int MinHeap::right(int i)
{
    return (2*i + 2);
}

int MinHeap::extractMin()
{
    if (heap_size<=0)
    {
        return 0;
    }
    if (heap_size==1)
    {
        heap_size--;
        return harr[0];
    }
    int temp=harr[0];
    harr[0]=harr[heap_size-1];
    harr[heap_size-1]=temp;
    heap_size--;
    MinHeapify(0);
    return temp;
}

void MinHeap::decreaseKey(int i, int new_val)
{
    
}

int MinHeap::getMin()
{
    return harr[0];
}

void MinHeap::deleteKey(int i)
{
    if (i>=heap_size)
    {
        return;
    }
    harr[i]=INT_MAX;
    int temp = harr[i];
    harr[i]=harr[heap_size-1];
    harr[heap_size-1]=temp;
    heap_size--;
    MinHeapify(i);
}

void MinHeap::insertKey(int k)
{
    if (capacity==heap_size)
    {
        return;
    }
    heap_size++;
    harr[heap_size-1]=k;
    int i = heap_size-1;
    while(harr[parent(i)]>harr[i])
    {
        int temp = harr[parent(i)];
        harr[parent(i)]=harr[i];
        harr[i]=temp;
        i = parent(i);
    }
}

int* MinHeap::getHeap()
{
    return harr;
}

#endif

