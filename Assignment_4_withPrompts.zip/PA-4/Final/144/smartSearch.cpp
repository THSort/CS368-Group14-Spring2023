#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    vector<long> temp = HeapSort(nums);
    int i =0;
    int j=nums.size()-1;
    vector< vector<long> > yolo;
    while(1)
    {
        if (j<i){
            return yolo;
        }
        else if(temp[i]+temp[j]==k)
        {   
            vector<long> row;
            row.push_back(temp[i]);
            row.push_back(temp[j]);
            yolo.push_back(row); 
            j--;
            i++;
        }
        else if(temp[i]+temp[j]>k){
            j--;
        }
        else if(temp[i]+temp[j]<k){
            i++;
        }
    }
    return yolo;
    // Write your code in this function
}


int main()
{
        clock_t tStart = clock();

    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;
    printf("Time taken: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);

    return 0;
}
