#include <fstream>
#include "sorts.cpp"
#include <ctime>

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   

    // Write your code in this function
    vector< vector<long> >result;
    vector<long>sorted=QuickSortArray(nums);
    // cout<<"here"<<endl;
    int l=0;
    int r=sorted.size()-1;
    long sum;
    int element=0;
    while(r>l)
    {
        // sum=sorted[l]+sorted[l];
        // if(sum==k)
        // {
        //     vector<long>pair;
        //     pair.push_back(l);
        //     pair.push_back(l);
        //     result.push_back(pair);
        //     l++;
        // }
        // sum=sorted[r]+sorted[r];
        // if(sum==k)
        // {
        //     vector<long>pair;
        //     pair.push_back(r);
        //     pair.push_back(r);
        //     result.push_back(pair);
        //     r--;
        // }
        sum=sorted[l]+sorted[r];
        if(sum>k)
        {
            r--;
        }
        else if(sum<k)
        {
            l++;
        }
        else
        {
            //equal to k
            vector<long>pair;
            pair.push_back(sorted[l]);
            pair.push_back(sorted[r]);
            result.push_back(pair);
            pair.clear();
            pair.push_back(sorted[r]);
            pair.push_back(sorted[l]);
            result.push_back(pair);
            r--;
            l++;
        }
    }
    return result;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    clock_t begin=clock();
    vector< vector<long> > result = smartSearch(nums, k);
    cout<<endl;
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout<<"time taken: "<<double(clock()-begin)/CLOCKS_PER_SEC;

    return 0;
}
