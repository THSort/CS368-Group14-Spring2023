#include <iostream>
#include "list.cpp"
#include <stdlib.h>

using namespace std;

void mergelists(List<long>*a, List<long>*b, List<long>*result)
{
	ListItem<long>*trav_a=a->getHead();
	ListItem<long>*trav_b=b->getHead();

	while(trav_a!=NULL && trav_b!=NULL)
	{
		if(trav_a->value < trav_b->value)
		{
			result->insertAtTail(trav_a->value);
			trav_a=trav_a->next;
		}
		else
		{
			result->insertAtTail(trav_b->value);
			trav_b=trav_b->next;
		}	
	}

	while(trav_a!=NULL)
	{
		result->insertAtTail(trav_a->value);
		trav_a=trav_a->next;
	}

	while(trav_b!=NULL)
	{
		result->insertAtTail(trav_b->value);
		trav_b=trav_b->next;
	}
}



void mergesort(List<long>*primary)
{
	int size=primary->length();
	if(size<=1)
		return;
	List<long>*a=new List<long>();
	List<long>*b=new List<long>();


	ListItem<long>*trav_prime=primary->getHead();
	for(int i=0; i<(size/2); i++)
	{
		a->insertAtHead(trav_prime->value);
		trav_prime=trav_prime->next;
	}
	for(int i=(size/2); i<size; i++)
	{
		b->insertAtHead(trav_prime->value);
		trav_prime=trav_prime->next;
	}
	
	while(primary->getHead()!=NULL)
	{
		primary->deleteHead();
	}

	mergesort(a);
	mergesort(b);
	mergelists(a,b,primary);
}









int main()
{
	List<int>*what=new List<int>();
	what->insertAtTail(3);
	what->insertAtTail(7);
	what->insertAtTail(5);
	what->insertAtTail(1);
	what->insertAtTail(9);
	what->insertAtTail(2);
	what->display_list();

	//sending the entire list for mergesorting 
	mergesort(what);
	cout<<endl;
	what->display_list();
	return 0;
}

