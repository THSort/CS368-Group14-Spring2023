#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <cstdlib>


MinHeap::MinHeap(int cap)
{
	capacity=cap;
	harr=new int[capacity];
	heap_size=0;
}

void MinHeap::MinHeapify(int i)
{
	int l=left(i);
	int r=right(i);
	int temp;
	int smallest=i;
	if(l<=heap_size && harr[l]<=harr[i])
	{
		smallest=l;
	}
	if(r<=heap_size && harr[r]<=harr[smallest])
	{
		smallest=r;
	}

	if(i!=smallest)
	{
		temp=harr[i];
		harr[i]=harr[smallest];
		harr[smallest]=temp;
		MinHeapify(smallest);
	}
}

int MinHeap::parent(int i)
{
	return ((i-1)/2);
}

int MinHeap::left(int i)
{
	//left child of ith root
	return (2*i)+1;
}

int MinHeap::right(int i)
{
	return (2*i)+2;
}

int MinHeap::extractMin()
{
	//the min value will always be the root
	if(heap_size<=0)
	{
		return INT_MAX;
	}
	if(heap_size==1)
	{
		heap_size--;
		return harr[0];
	}
	int min=harr[0];
	harr[0]=harr[heap_size-1];
	heap_size--;
	MinHeapify(0);
	return min;
}

void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;
	int temp,par=parent(i);
	while(i>0 && harr[i]<harr[parent(i)])
	{
		temp=harr[i];
		harr[i]=harr[parent(i)];
		harr[parent(i)]=temp;
		i=parent(i);
	}
}

int MinHeap::getMin()
{
	return harr[0];
}

void MinHeap::deleteKey(int i)
{
	if(i<heap_size)
	{
		decreaseKey(i,INT_MIN);
		extractMin();
	}
}

void MinHeap::insertKey(int k)
{
	//insert normal key k, then perculate up
	if(heap_size<capacity)
	{
		harr[heap_size]=k;
		int index=heap_size;
		int par;
		int temp;
		heap_size++;
		while(index!=0 && harr[parent(index)]>harr[index])
		{
			par=parent(index);
			temp=harr[parent(index)];
			harr[parent(index)]=harr[index];
			harr[index]=temp;
			index=parent(index);
		}
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

void MinHeap::print()
{
	for(int i=0; i<heap_size; i++)
	{
		cout<<harr[i]<<" ";
	}
}

// int main()
// {
	
//     MinHeap h(11);
//     h.insertKey(1);
//     h.insertKey(5);
//     h.insertKey(6);
//     h.insertKey(9);
//     h.insertKey(11);
//     h.insertKey(8);
//     h.insertKey(15);
//     h.insertKey(17);
//     h.insertKey(21);
//     h.print();
//     cout<<endl;
//     h.deleteKey(1);
//     h.print();	
//     return 0;
// }

#endif
