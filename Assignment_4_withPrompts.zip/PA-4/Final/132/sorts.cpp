#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include <stdlib.h>
#include <algorithm>
#include "list.cpp"

void qsort(long *arr, int low, int high);
ListItem<long>* _quicksort(List<long>*primary);
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int size=nums.size();
	long *arr=new long[nums.size()];
	for(int i=0; i<size; i++)
	{
		arr[i]=nums[i];
	}

	int i;
	int j;
	int value;
   	for (i=0; i<size; i++)
   	{
   		if(i==0)
   			continue;
   	    value=arr[i];
   	    j=i-1;
    	while (arr[j]>value && j>=0)
       	{
        	arr[j+1]=arr[j];
          	j=j-1;
       	}
       	arr[j+1]=value;
   	}

	vector<long>result;
	for(int i=0; i<nums.size(); i++)
	{
		result.push_back(arr[i]);
	}
	return result;
}

void mergelists(List<long>*a, List<long>*b, List<long>*result)
{
	ListItem<long>*trav_a=a->getHead();
	ListItem<long>*trav_b=b->getHead();

	while(trav_a!=NULL && trav_b!=NULL)
	{
		if(trav_a->value < trav_b->value)
		{
			result->insertAtTail(trav_a->value);
			trav_a=trav_a->next;
		}
		else
		{
			result->insertAtTail(trav_b->value);
			trav_b=trav_b->next;
		}	
	}

	while(trav_a!=NULL)
	{
		result->insertAtTail(trav_a->value);
		trav_a=trav_a->next;
	}

	while(trav_b!=NULL)
	{
		result->insertAtTail(trav_b->value);
		trav_b=trav_b->next;
	}
}



void mergesort(List<long>*primary)
{
	int size=primary->length();
	if(size<=1)
		return;
	List<long>*a=new List<long>();
	List<long>*b=new List<long>();


	ListItem<long>*trav_prime=primary->getHead();
	for(int i=0; i<(size/2); i++)
	{
		a->insertAtHead(trav_prime->value);
		trav_prime=trav_prime->next;
	}
	for(int i=(size/2); i<size; i++)
	{
		b->insertAtHead(trav_prime->value);
		trav_prime=trav_prime->next;
	}
	
	while(primary->getHead()!=NULL)
	{
		primary->deleteHead();
	}

	mergesort(a);
	mergesort(b);
	mergelists(a,b,primary);
}


//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	int size=nums.size();
	List<long>*convert=new List<long>();
	for(int i=0; i<size; i++)
	{
		convert->insertAtHead(nums[i]);
	}

	mergesort(convert);
	vector<long>resultant;
	ListItem<long>*temp=convert->getHead();
	for(int i=0; i<size; i++)
	{
		resultant.push_back(temp->value);
		temp=temp->next;
	}
	return resultant;
}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
    vector<long>resultant;
    long *arr=new long[nums.size()];
    for(int i=0; i<nums.size(); i++)
    {
        arr[i]=nums[i];
    }

    qsort(arr,0,nums.size()-1);

    for(int i=0; i<nums.size(); i++)
    {
    	resultant.push_back(arr[i]);
    }
    return resultant;
}

int medianOfThree(long *arr, int low, int high)
{
	vector<long>a;
	int x,y,z;
	x=low;
	y=(high-low)/2;
	z=high;
	a.push_back(arr[x]);
	a.push_back(arr[y]);
	a.push_back(arr[z]);

	sort(a.begin(),a.end());
	if(a[1]==arr[x])
		return x;
	else if(a[1]==arr[y])
		return y;
	else
	{
		return z;
	} 
}

int divide(long *arr, int low, int high)
{
	int i=low-1;
	int j=low;
	long pivot,temp;
	//first value is the pivot

	// temp=arr[low];
	// arr[low]=arr[high];
	// arr[high]=temp;
	// pivot=arr[high];

	//last value as the pivot
	pivot=arr[high];

	//median of three as the pivot
	// int index=medianOfThree(arr,low,high);
	// temp=arr[index];
	// arr[index]=arr[high];
	// arr[high]=temp;
	// pivot=arr[high];


	while(j<=high)
	{
		if(arr[j]<pivot)
		{
			i++;
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
		j++;
	}
	i++;
	temp=arr[i];
	arr[i]=arr[high];
	arr[high]=temp;

	return i;
}

void qsort(long *arr, int low, int high)
{
	if(low<high)
	{
		int division=divide(arr,low,high);
		qsort(arr,low,division-1);
		qsort(arr,division+1,high);
	}
	else
		return;
}


//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	int size=nums.size();
	List<long>*convert=new List<long>();
	for(int i=0; i<size; i++)
	{
		convert->insertAtHead(nums[i]);
	}

	mergesort(convert);
	vector<long>resultant;
	ListItem<long>*temp=convert->getHead();
	for(int i=0; i<size; i++)
	{
		resultant.push_back(temp->value);
		temp=temp->next;
	}
	return resultant;
}

ListItem<long>* _quicksort(List<long>*primary)
{
	int size=primary->length();

	if(size<=0)
	{
		return NULL;
	}
	List<long>*a=new List<long>();
	List<long>*b=new List<long>();

	long pivot=primary->getHead()->value;
	

	ListItem<long>*trav=primary->getHead();

	for(int i=0; i<size; i++)
	{
		if(trav->value<pivot)
		{
			a->insertAtHead(trav->value);
		}
		else
		{
			b->insertAtHead(trav->value);
		}
		trav=trav->next;
	}
	ListItem<long>*tail_a=_quicksort(a);
	ListItem<long>*tail_b=_quicksort(b);

	List<long>*answer=new List<long>();
	
	for(ListItem<long>*iter=tail_b;iter!=NULL;iter=iter->prev){
		answer->insertAtHead(iter->value);
	}
	for(ListItem<long>*iter=tail_a;iter!=NULL;iter=iter->prev){
		answer->insertAtHead(iter->value);
	}


	return answer->getTail();

}

// int partition(first,last_node)
// {
// 	long pivot=last_node->value;

// 	ListItem<long>*i=first->prev;

// 	long temp;
// 	for(j=first; j!=last_node; j=j->next)
// 	{
// 		if(j->value < pivot)
// 		{
// 			if(i==NULL)
// 			{
// 				i=first;
// 			}
// 			else
// 			{
// 				i=i->next;
// 			}
// 			temp=i->value;
// 			i->value=j->value;
// 			j->value=temp;
// 		}
// 	}
// 	if(i==NULL)
// 	{
// 		i=first;
// 	}
// 	else
// 	{
// 		i=i->next;
// 	}
// 	//swap i->value and last_node value
// 	temp=i->value;
// 	i->value=last_node->value;
// 	last_node->value=temp;
// }

// void _quicksort(List<long>*primary, int first, int last)
// {

// 	if(primary->getHead()!=NULL && first!=last && first!=last->next)
// 	{
// 		node p=partition(first,last);
// 		_quicksort(first,p->prev);
// 		_quicksort(p->next,last);
// 	}
// }

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int size=nums.size();
	MinHeap prime(size+1);
	for(int i=0; i<size; i++)
	{
		prime.insertKey(nums[i]);
	}
	vector<long>resultant;
	for(int i=0; i<size; i++)
	{
		resultant.push_back(prime.extractMin());
	}
	return resultant;
}


#endif
