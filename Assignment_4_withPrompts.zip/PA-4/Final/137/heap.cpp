#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	harr = new int [cap];
	capacity = cap;
	heap_size =0;
}

void MinHeap::MinHeapify(int i)
{
	int root = i;
	int l_r = (2*i) +1;
	int r_r = (2*i) +2;

	if(l_r<heap_size)
	{
		if(harr[l_r]<harr[i])
		{
			root =l_r;
		}
	}

	if(r_r<heap_size)
	{
		if(harr[r_r]<harr[root])
		{
			root =r_r;
		}
	}


	if(root!=i)
	{
		int temp = harr[root];
		harr[root]=harr[i];
		harr[i]=temp;
		MinHeapify(root);
	}
	
}
 
int MinHeap::parent(int i)
{
	int par = (i-1)/2;
	return par;

}
 
int MinHeap::left(int i)
{
	int lef = (2*i)+1;
	return lef;

}
 
int MinHeap::right(int i)
{
	int rig = (2*i)+2;
	return rig;

}
 
int MinHeap::extractMin()
{
	if(heap_size<0)
	{
		return INT_MIN;
	}
	
	if(heap_size<=1)
	{
		heap_size--;
		int back = harr[0];
		return back;
	}
	
	int back = harr[0];

	harr[0] = harr[heap_size-1];
	heap_size--; 
	
	MinHeapify(0);

	return back;
}

void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;	
	int lol =i;
	while(lol != 0)
	{
		if(harr[lol] < harr[parent(lol)])
		{
			int temp = harr[lol];
			harr[lol]=harr[parent(lol)];
			harr[parent(lol)] = temp;
		}
		lol = parent(lol);
	}

}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	cout<<"deleting "<<i<<endl;
	decreaseKey(i, INT_MIN);
	extractMin();	
}
 
void MinHeap::insertKey(int k)
{
	if(heap_size==capacity)
	{
		return;
	}
	
	heap_size++;
	int lol =heap_size-1;
	harr[lol]=k;
	cout<<harr[lol]<<endl;	
	
	
	while(lol!=0)
	{
		if(harr[lol]<harr[parent(lol)])
		{
			int temp = harr[lol];
			harr[lol]=harr[parent(lol)];
			harr[parent(lol)] = temp;
		}
		lol = parent(lol);
	}
	


}

int* MinHeap::getHeap()
{
	return harr;
}

#endif