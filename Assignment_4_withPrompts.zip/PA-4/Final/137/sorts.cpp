#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{

	int cap = nums.size();
	int arr[cap];

	for(int i = 0;i<cap;i++)
	{
		arr[i]=nums[i];
	}

	int where =1;
	while(where<nums.size())
	{
		if(nums[where]<nums[where-1])
		{
			int k =where;
			while(nums[k]<nums[k-1])
			{
				int temp =nums[k];
				nums[k]=nums[k-1];
				nums[k-1]=temp;
				k--;
			}
		}
		where++;
	}

	vector<long> sorted(cap);
	for(int i = 0;i<cap;i++)
	{
		sorted[i]=arr[i];
	}
	return sorted;

}

//=====================================================================================


vector<long> merging(vector<long> rig, vector<long>lef)
{
	vector<long> who;
	while(1)
	{
		if(rig.size()==0 && lef.size()==0)
		{
			break;
		}
		if(rig.size()==0)
		{
			who.push_back(lef[0]);
			lef.erase(lef.begin());
		}
		if(lef.size()==0)
		{
			who.push_back(rig[0]);
			rig.erase(rig.begin());
		}
		if(rig[0]<lef[0])
		{
			who.push_back(rig[0]);
			rig.erase(rig.begin());
		}
		else
		{
			who.push_back(lef[0]);
			lef.erase(lef.begin());
		}
	}

	return who;

}

void splitlist(List<long> list, List<long> &r, List<long>&l)
{
	ListItem<long> *where= list.getHead();
	for(int i=0;i<list.length();i++)
	{
		if(i%2==0)
		{
			r.insertAtTail(where->value);
			where=where->next;
		}
		else
		{
			l.insertAtTail(where->value);
			where=where->next;
		}
	}
}

vector<long> MergeSort(vector<long> nums)
{
	int cap = nums.size();
	List<long> to_return;
	for(int i =0;i<nums.size();i++)
	{
		to_return.insertAtTail(nums[i]);
	}
	int k = to_return.length();
	if(to_return.length()<=1)
	{
		
		vector<long> vecR;
		ListItem<long>  *ptr= to_return.getHead();
		for(int i=0;i<to_return.length();i++)
		{
			vecR.push_back(ptr->value);
			ptr=ptr->next;
		}
		return vecR;
	}
	else
	{
		List<long> to_right;
		List<long> to_left;

		splitlist(to_return,to_right,to_left);
		vector<long> r_vector;
		vector<long> l_vector;
		ListItem<long>  *R1= to_right.getHead();
		ListItem<long> *L1= to_left.getHead();

		for(int i=0;i<to_right.length();i++)
		{
			r_vector.push_back(R1->value);
			R1=R1->next;

		}
		for(int i=0;i<to_left.length();i++)
		{
			l_vector.push_back(L1->value);
			L1=L1->next;

		}

		vector<long> la1= MergeSort(r_vector);
		vector<long> la2= MergeSort(l_vector);
		return merging(la1,la2);
	}

}




//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
	int cap = nums.size();
	int arr[cap];

	for(int i = 0;i<cap;i++)
	{
		arr[i]=nums[i];
	}

	int pivot = arr[0];
	int a,b,c;
	srand(time(NULL));
	a=rand()%cap;
	b=rand()%cap;
	c=rand()%cap;

	List <int> pivotarr;
	pivotarr.insertSorted(a);
	pivotarr.insertSorted(b);
	pivotarr.insertSorted(c);
	int pivot2 = pivotarr.getHead()->next->value;
	int pivot_is= arr[pivot2];

	int pivot3 = cap-1;

	int end= cap-1;
	int start =0;
	int move =1;

	for(int i = 0;i<cap;i++)
	{
		if(arr[i]<pivot_is)
		{
			if(arr[move]<arr[start])
			{
			int temp= arr[move];
			arr[move]=arr[start];
			arr[start]=temp;
			}
			move++;
			start++;
		}
		
	}











	


}

//=====================================================================================


void qssplit(List<long> list, List<long> &r, List<long>&l,int p)
{
	ListItem<long> *where= list.getHead();
	for(int i=0;i<list.length();i++)
	{
		if(where->value>p)
		{
			r.insertAtTail(where->value);
			where=where->next;
		}
		else
		{
			l.insertAtTail(where->value);
			where=where->next;
		}
	}
}
vector<long> qsmerging(vector<long> rig, vector<long>lef)
{
	vector<long> who;
	while(1)
	{
		if(rig.size()==0 && lef.size()==0)
		{
			break;
		}
		if(rig.size()==0)
		{
			who.push_back(lef[0]);
			lef.erase(lef.begin());
		}
		if(lef.size()==0)
		{
			who.push_back(rig[0]);
			rig.erase(rig.begin());
		}
		if(rig[0]<lef[0])
		{
			who.push_back(rig[0]);
			rig.erase(rig.begin());
		}
		else
		{
			who.push_back(lef[0]);
			lef.erase(lef.begin());
		}
	}

	return who;

}


vector<long> QuickSortList(vector<long> nums)
{
	List<long> to_return;
	for(int i =0;i<nums.size();i++)
	{
		to_return.insertAtTail(nums[i]);
	}

	srand(time(NULL));
	int pivot=rand()%(nums.size()-1);

	if(to_return.length()<=1)
	{
		
		vector<long> vecR;
		ListItem<long>  *ptr= to_return.getHead();
		for(int i=0;i<to_return.length();i++)
		{
			vecR.push_back(ptr->value);
			ptr=ptr->next;
		}
		return vecR;
	}

	else
	{
		List<long> to_right;
		List<long> to_left;

		qssplit(to_return,to_right,to_left,pivot);

		vector<long> r_vector;
		vector<long> l_vector;
		
		ListItem<long>  *R1= to_right.getHead();
		ListItem<long> *L1= to_left.getHead();

		for(int i=0;i<to_right.length();i++)
		{
			r_vector.push_back(R1->value);
			R1=R1->next;
		}

		for(int i=0;i<to_left.length();i++)
		{
			l_vector.push_back(L1->value);
			L1=L1->next;
		}

		vector<long> la1= QuickSortList(r_vector);
		vector<long> la2= QuickSortList(l_vector);
		return qsmerging(la1,la2);
	}


}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int cap = nums.size();

	MinHeap* heap = new MinHeap(cap);
	for(int i=0;i<cap;i++)
	{
		heap->insertKey(nums[i]);
	}
	vector <long>sorted;
	int cp = nums.size();
	while(cap>0)
	{
		sorted.push_back(heap->extractMin());
		cp--;
	}


}

#endif