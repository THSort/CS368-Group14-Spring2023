#include "heap.cpp"
#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

int main()
{
	MinHeap* heap = new MinHeap(6);

	heap->insertKey(1);
	heap->insertKey(3);
	heap->insertKey(4);
	heap->insertKey(12);
	heap->insertKey(14);
	heap->insertKey(30);



	int *head = heap->getHeap();

	for(int i=0;i<6;i++)
	{
		cout<<"heap "<<head[i]<<endl;
	}

	heap->extractMin();

	
	for(int i=0;i<5;i++)
	{
		cout<<"heap "<<head[i]<<endl;
	}
	heap->extractMin();

	
	for(int i=0;i<4;i++)
	{
		cout<<"heap2 "<<head[i]<<endl;
	}

	heap->extractMin();

	
	for(int i=0;i<3;i++)
	{
		cout<<"heap3 "<<head[i]<<endl;
	}

	heap->extractMin();

	
	for(int i=0;i<2;i++)
	{
		cout<<"heap4 "<<head[i]<<endl;
	}

	heap->extractMin();

	
	for(int i=0;i<1;i++)
	{
		cout<<"heap5 "<<head[i]<<endl;
	}
	heap->insertKey(87);
	heap->insertKey(10);
	heap->insertKey(45);
	heap->insertKey(2);
	for(int i=0;i<5;i++)
	{
		cout<<"heap6 "<<head[i]<<endl;
	}

}