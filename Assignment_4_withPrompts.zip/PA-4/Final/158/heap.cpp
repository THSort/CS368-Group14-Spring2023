#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <climits>


MinHeap::MinHeap(int cap)
{
	capacity=cap;
	harr=new int[cap]();
	heap_size=0;
}

void MinHeap::MinHeapify(int i)
{
	int lefty=left(i);
	int righty=right(i);

	int min=i;

	if(lefty==-1 )
		return;

	if(harr[lefty]<harr[i])
		min=lefty;
	if(righty != -1 && harr[righty]<harr[min])
		min=righty;

	if(min!=i) {
		swap(harr[min],harr[i]);
		MinHeapify(min);
	}	

}
 
int MinHeap::parent(int i)
{
	if(i<=0)
		return -1;

	return (i-1)/2;
}

int MinHeap::left(int i)
{
	if(i*2+1>=heap_size)
		return -1;

	return i*2+1;
}
 
int MinHeap::right(int i)
{
	if(i*2+2>=heap_size)
		return -1;
	return i*2+2;
}
 
int MinHeap::extractMin()
{
	if(heap_size==0)
		return 10000000;

	if(heap_size==1)
	{
		heap_size--;
		return harr[heap_size];
	}

 	int element = harr[0];
    harr[0] = harr[heap_size-1];
    heap_size--;
    MinHeapify(0);
 
    return element;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;
	if(parent(i)!=-1)
	{
		while(harr[i]<harr[parent(i)])
		{
			swap(harr[i],harr[parent(i)]);
			i=parent(i);
		}

		return;
		
	}

	else if(left(i)>heap_size)
	{
		
		while(harr[i]>harr[left(i)])
		{
			swap(harr[i],harr[left(i)]);
			i=left(i);
		}

		return;
		
	}

	return;

}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if (i < heap_size){
		decreaseKey(i,INT_MIN);
		extractMin();		
	}

}
 
void MinHeap::insertKey(int k)
{
	if(heap_size==capacity)
		return;

	heap_size++;

	harr[heap_size-1]=k;

	int z=heap_size-1;

	   while (z!= 0 && harr[parent(z)] > harr[z])
	    {
	       swap(harr[z], harr[parent(z)]);
	       z = parent(z);
	    }
}

int* MinHeap::getHeap()
{
	return harr;
}

void MinHeap::printHeap()
{
	cout<<"[";
	for(int i=0;i<heap_size;i++) {
		cout<<harr[i]<<" ";
	}
	cout<<"]";
	cout<<endl;
}


// int main() 
// {
// 	MinHeap* heap = new MinHeap(100);
// 	heap->insertKey(77);
// 	heap->insertKey(89);
// 	heap->insertKey(16);
// 	heap->insertKey(20);
// 	heap->insertKey(35);
// 	heap->insertKey(43);
// 	heap->insertKey(47);
// 	heap->insertKey(57);
// 	heap->insertKey(66);
// 	heap->insertKey(88);
// 	heap->insertKey(2);
// 	heap->insertKey(9);
// 	heap->insertKey(64);

// 	heap->printHeap();

// 	heap->deleteKey(9); //deleting 88
// 	heap->deleteKey(4); //deleting 20
// 	heap->deleteKey(11); //deleting 77


	

// 	// cout<<heap->extractMin()<<endl;
// 	heap->printHeap();


// 	return 0;
// }



#endif