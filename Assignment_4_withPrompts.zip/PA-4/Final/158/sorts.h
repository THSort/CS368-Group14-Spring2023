#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);
void mergeSRecur(List<long>& l,long size);
void merging(List<long>& l1,List<long>& l2,List<long>& l,long &size1,long &size2);
vector<long> MergeSort(vector<long> nums);
void quickSRecur(long size,long array[]);
vector<long> QuickSortArray(vector<long> nums);
vector<long> QuickSortList(vector<long> nums);
vector<long> HeapSort(vector<long> nums);

#endif