#include <fstream>
#include "sorts.cpp"
#include <time.h>

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.

long bsearch(const vector<long> &vec,long start,long end, long num);
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
	vector<long> sorted=QuickSortArray(nums);

	cout<<endl<<endl;

	vector< vector<long> > pairing;
	
	long size=sorted.size();


	long i;

	for(i=0;i<size;i++)
	{
		long temp=k;
		temp=temp-sorted[i];
		if(bsearch(sorted,0,size-1,temp)!=-1)
		{
			vector<long> pair;
			pair.push_back(sorted[i]);
			pair.push_back(temp);
			pairing.push_back(pair);
		}


	}

	

	return pairing;
}


long bsearch(const vector<long> &vec,long start,long end, long num)
{


	if(start>end)
		return -1;
	
	long mid=(start+end)/2;

	if(vec[mid]==num)
	{
		return mid;
	}

	if(vec[mid]>num)
	{
		return bsearch(vec,start,mid-1,num);
	}

	else if(vec[mid]<num)
	{
		return bsearch(vec,mid+1,end,num);
	}

}


int main()
{
	int start=clock();
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);
    int stop=clock();

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout<<"Time: "<<(stop-start)/double(CLOCKS_PER_SEC)<<endl;

    return 0;
}