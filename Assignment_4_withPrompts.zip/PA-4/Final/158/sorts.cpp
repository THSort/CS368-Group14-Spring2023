#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"


#include <iostream>

using namespace std;

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{

	long sizo=nums.size();
	long arr[sizo];

	for(long k=sizo-1;k>=0;k--)
	{
		arr[k]=nums[k];
		nums.pop_back();
	}

	for(long i=1;i<sizo;i++)
	{
		long temp=arr[i];
		long j=i;

		while(j>0 && temp<arr[j-1])
		{
			arr[j]=arr[j-1];
			j--;
		}

		arr[j]=temp;

	}


	for(long z=0;z<sizo;z++)
	{
		nums.push_back(arr[z]);
	}


	return nums;
}

//=====================================================================================

void mergeSRecur(List<long>& l,long size)
{
	if(size<=1)
		return;
	
	List<long> l1;
	List<long> l2;

	long size1=size/2;
	long size2=size-size/2;

	for(int i=0;i<size1;i++)
	{
		
		l1.insertAtHead(l.getHead()->value);
		l.deleteHead();
	}


	for(int j=0;j<size2;j++)
	{
		
		l2.insertAtHead(l.getHead()->value);
		l.deleteHead();
	}


	mergeSRecur(l1,size1);
	mergeSRecur(l2,size2);
	merging(l1,l2,l,size1,size2);


}

void merging(List<long>& l1,List<long>& l2,List<long>& l,long &size1,long &size2)
{
	ListItem<long>* temp1 = l1.getTail();
	ListItem<long>* temp2 = l2.getTail();
	
	while(temp1!=0 && temp2!=0)
	{
		

		if(temp1->value  >= temp2->value)
		{

			l.insertAtHead(temp1->value);
			temp1 = temp1->prev;
		}

		else {
			l.insertAtHead(temp2->value);
			temp2 = temp2->prev;
		}
	}

	

	
	while(temp1!=NULL)
	{
		l.insertAtHead(temp1->value);
		temp1 = temp1->prev;
	}	


	while(temp2!=NULL)
	{
		l.insertAtHead(temp2->value);
		temp2 = temp2->prev;;
	}
	
}

vector<long> MergeSort(vector<long> nums)
{
	List<long> mylist;
	long sizo=nums.size();
	for(long k=sizo-1;k>=0;k--)
	{
		mylist.insertAtHead(nums[k]);
		nums.pop_back();
	}


	mergeSRecur(mylist,sizo);

	ListItem<long>* temp=mylist.getHead();

	while(temp!=NULL)
	{
		nums.push_back(temp->value);
		temp=temp->next;
	}
	
	return nums;

}

void quickSRecur(long array[],long start,long end)
{
	if(start>=end)
		return;
	

	long pivot=array[end];

	long first=start;
	long last=end-1;


	while(first<=last) {
		
		while(first<=last && array[first]<=pivot) first++;
		while(last>=first && array[last]>=pivot) last--;

	if(first< last)
		swap(array[first],array[last]);	
	}

	swap(array[first],array[end]);
	quickSRecur(array,start,first-1);
	quickSRecur(array,first+1,end);	


}

//===================================i=========-+++========================================
vector<long> QuickSortArray(vector<long> nums)
{

	long sizo=nums.size();
	long *arr=new long[sizo];

	if(sizo<=1) return nums;

	for(long k=sizo-1;k>=0;k--)
	{
		arr[k]=nums[k];
		nums.pop_back();
	}

	quickSRecur(arr,0,sizo-1);
	

	for(long l=0;l<sizo;l++)
	{
		nums.push_back(arr[l]);
	}

	return nums;

}


//=====================================================================================

void quickSListRecur(List<long>& l,long size) {

	if (size<=1) return;

	long i=rand() % size;
	long pivot;

	ListItem<long>* tt=l.getHead();
	long counter=0;
	while(tt!=NULL)
	{
		if(i==counter)
		{
			pivot=tt->value;
			break;
		}

		counter++;

	}



	List<long> temp1;
	List<long> temp2;
	List<long> temp3;

	long length1=0;
	long length2=0;
	long length3=0;

	long tempSize=size;

	while(tempSize>0)
	{
		if(l.getHead()->value<pivot)
		{
			temp1.insertAtHead(l.getHead()->value);
			l.deleteHead();
			length1++;
		}

		else if(l.getHead()->value==pivot)
		{
			temp2.insertAtHead(l.getHead()->value);
			l.deleteHead();
			length2++;
		}

		else {
			temp3.insertAtHead(l.getHead()->value);
			l.deleteHead();
			length3++;
		}

		tempSize--;
	}


	quickSListRecur(temp1,length1);
	quickSListRecur(temp3,length3);

	ListItem<long>* t1=temp1.getTail();
	ListItem<long>* t2=temp2.getTail();
	ListItem<long>* t3=temp3.getTail();

	
	while(length3>0) {
		l.insertAtHead(t3->value);
		t3=t3->prev;
		length3--;
	}

	while(length2>0) {
		l.insertAtHead(t2->value);
		t2=t2->prev;
		length2--;
	}

	while(length1>0) {
		l.insertAtHead(t1->value);
		t1=t1->prev;
		length1--;
	}

	return;

}

vector<long> QuickSortList(vector<long> nums)
{
	List<long> mylist;
	long sizo=nums.size();
	for(long k=sizo-1;k>=0;k--)
	{
		mylist.insertAtHead(nums[k]);
		nums.pop_back();
	}


	quickSListRecur(mylist,sizo);

	ListItem<long>* temp=mylist.getHead();

	while(temp!=NULL)
	{
		nums.push_back(temp->value);
		temp=temp->next;
	}
	
	return nums;

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	long size=nums.size();
	MinHeap *myheap=new MinHeap(size);
	for(long i=size-1;i>=0;i--)
	{
		myheap->insertKey(nums[i]);
		nums.pop_back();

	}

	for(long j=0;j<size;j++)
	{
		nums.push_back(myheap->extractMin());
	}

	return nums;
}

// int main()
// {
// 	std::vector<long> v;
// 	v.push_back(3);
// 	v.push_back(9);
// 	v.push_back(4);
// 	v.push_back(1);
// 	v.push_back(13);
// 	v.push_back(-4);
// 	v.push_back(0);
// 	 v.push_back(6);

// 	for(int i=0;i<v.size();i++)
// 	{
// 		cout<<v[i]<<" ";
// 	}

// 	cout<<endl;

// 	std::vector<long> sorted=HeapSort(v);

// 	for(int i=0;i<sorted.size();i++)
// 	{
// 		cout<<sorted[i]<<" ";
// 	}

// 	cout<<endl;
// 	return 0;
// }

#endif