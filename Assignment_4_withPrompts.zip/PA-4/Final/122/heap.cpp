#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	harr=new int[cap]();
	capacity=cap;
	heap_size=0;
}

MinHeap::MinHeap(int* cap,int size)
{
	harr=cap;
	capacity=size;
	heap_size=size;
}



//Parent = ceiling((child-1)/2)
//child = (parent*2)+1 and +2

void MinHeap::MinHeapify(int i)
{
	int r = right(i);
	int l=left(i);
	
	if(l<heap_size && harr[l]<harr[i] && harr[l]<harr[r]){
		swap(harr[l],harr[i]);
		MinHeapify(l);
	}
	else if(r<heap_size && harr[r]<harr[i] && harr[r]<=harr[l]){
		swap(harr[r],harr[i]);
		MinHeapify(r);
	}
}

int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i)+1;
}
 
int MinHeap::right(int i)
{
	return (2*i)+2;
}
 
int MinHeap::extractMin()
{
	int temp=harr[0];
	deleteKey(0);
	return temp;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	if(i<heap_size){
		harr[i]=new_val;
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i<0 || i>=heap_size){
		return;
	}
	harr[i]=harr[heap_size-1];
	heap_size--;
	MinHeapify(i);

}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size]=k;
	heap_size++;
	int p=heap_size-1;
	int j=0;
	while(p){
		j=parent(p);
		if(harr[j] > harr[p]){
			swap(harr[j],harr[p]);
			p=j;
		}else{
			return;
		}

	}
	//MinHeapify(0);
}

int* MinHeap::getHeap()
{
	return harr;
}


// int main(){
// 	//int *arr = new int[5];
// 	MinHeap a(100);
// 	a.insertKey(101);
// 	a.insertKey(90);
// 	a.insertKey(100);
// 	a.insertKey(110);
// 	a.insertKey(200);
// 	a.insertKey(70);
// 	a.insertKey(11);
// 	a.insertKey(143);
// 	// arr[0]=3
// 	// arr[0]=2
// 	// arr[0]=13
// 	// arr[0]=-2
// 	// arr[0]=50
// 	// arr[0]=-5
// 	// a.insertKey(88);
// 	// a.insertKey(230);
// 	// a.insertKey(-230);
// 	// a.insertKey(13);
// 	a.extractMin();
// 	cout << a.getHeap()[0] << endl;
// 	cout << a.getHeap()[1] << endl;
// 	cout << a.getHeap()[2] << endl;
// 	cout << a.getHeap()[3] << endl;
// 	cout << a.getHeap()[4] << endl;
// 	cout << a.getHeap()[5] << endl;
// 	cout << a.getHeap()[6] << endl;
// 	// cout << a.getHeap()[5] << endl;
// 	//cout << a.getHeap()[6] << endl;
// 	// cout << a.getHeap()[7] << endl;
// 	// cout << a.getHeap()[8] << endl;
// 	// cout << a.getHeap()[9] << endl;
// 	// cout << a.getHeap()[10] << endl;
// 	// cout << a.getHeap()[10] << endl;
// }

#endif