#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{	

	int s= nums.size();
	int *arr=new int[s];
	for(int i=0;i<s;i++){
		arr[i]=nums[i];
	}
	for(int i=1;i<s;i++){
		for(int j=0;j<i;j++){
			if(arr[i]<arr[j]){
				int temp=arr[i];
				for(int k=i;k>j;k--){
					arr[k]=arr[k-1];
				}
				arr[j]=temp; 
				break;
			}
		}
	}
	for(int i=0;i<s;i++){
		nums[i]=arr[i];
	}
	return nums;
}

//=====================================================================================

List<int>* sort(List<int> *a,int size){
	ListItem<int> *temp=a->getHead();
	List<int> *ar1=new List<int>;
	List<int> *ar2=new List<int>;
	for(int i=0;i<size/2;i++){
		ar1->insertAtHead(temp->value);
		temp=temp->next;
	}
	if(size>1){
		sort(ar1,size/2);
	}
	else{
		return a;
	}
	
	for(int i=size/2;i<size;i++){
		ar2->insertAtHead(temp->value);
		temp=temp->next;
	}
	if(size>1){
		sort(ar2,size-(size/2));
	}
	else{
		return a;
	}
	temp=a->getHead();
	ListItem<int> *a1=ar1->getHead();
	ListItem<int> *a2=ar2->getHead();
	while(a1 && a2){
		if(a1->value < a2->value){
			temp->value=a1->value;
			temp=temp->next;
			a1=a1->next;
		}else{
			temp->value=a2->value;
			temp=temp->next;
			a2=a2->next;
		}
	}
	while(a1){
			temp->value=a1->value;
			temp=temp->next;
			a1=a1->next;
	}
	while(a2){
		temp->value=a2->value;
		temp=temp->next;
		a2=a2->next;
	}
	return a;

}

vector<long> MergeSort(vector<long> nums)
{
	int s= nums.size();
	List<int> *arr=new List<int>;
	for(int i=0;i<s;i++){
		arr->insertAtHead(nums[i]);
	}
	sort(arr,s);
	ListItem<int> *temp=arr->getHead();
	for(int i=0;i<s;i++){
		nums[i]=temp->value;
		temp=temp->next;
	}
	return nums;

}

//=====================================================================================

void qsort(int* arr,int left,int right){
	if((right-left)>1){
		int l=left;
		int r=right;
		int pivot=arr[left];
		swap(arr[left],arr[right]);
		r--;
		while(l<=r){
			if(arr[l]>=pivot){
				swap(arr[l],arr[r]);
				r--;
				while(l<r){
					if(arr[r]<=pivot){
						swap(arr[r],arr[l]);
						l++;
						break;
					}
					else{
						r--;
					}
				}
			}
			else{
				l++;
			}
		}
		swap(arr[right],arr[l]);
		qsort(arr,left,l-1);
		qsort(arr,l+1,right);
	}else if(right-left==1 && arr[left]>arr[right]){
			swap(arr[left],arr[right]);
		}
}

vector<long> QuickSortArray(vector<long> nums)
{
	int s= nums.size();
	int *arr=new int[s];
	for(int i=0;i<s;i++){
		arr[i]=nums[i];
	}
	qsort(arr,0,s-1);
	for(int i=0;i<s;i++){
		nums[i]=arr[i];
	}
	return nums;

}

//=====================================================================================
List<long>* qsortl(List<long>* list){
	if(list->length()>1){
	ListItem<long> *temp=list->getHead();
	ListItem<long> *trav=temp;
	List<long> *left=new List<long>;
	List<long> *right=new List<long>;
	List<long> *middle=new List<long>;
	long r = rand()%list->length();
	while(r){
		temp=temp->next;
		r--;
	}
	long pivot=temp->value;
	while(trav){
		long val=trav->value;
		if(val<pivot){
			left->insertAtHead(val);
		}
		else if(val>pivot){
			right->insertAtHead(val);
		}else{
			middle->insertAtHead(val);
		}
		trav=trav->next;
	}
	List<long> *le=qsortl(left);
	List<long> *ri=qsortl(right);
	if(le->getHead()){
		le->getTail()->next=middle->getHead();
	middle->getTail()->next=ri->getHead();
	return le;
	}	else	{
	middle->getTail()->next=ri->getHead();
	return middle;
	}
	
	}else{
		return list;
	}	
} 

vector<long> QuickSortList(vector<long> nums)
{
	int s= nums.size();
	List<long> *arr=new List<long>;
	for(int i=0;i<s;i++){
		arr->insertAtHead(nums[i]);
	}
	List<long> *arr1=qsortl(arr);
	ListItem<long> *temp=arr1->getHead();
	for(int i=0;i<s;i++){
		nums[i]=temp->value;
		temp=temp->next;
	}
	return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int s= nums.size();
	MinHeap a(s);
	for(int i=0;i<s;i++){
		a.insertKey(nums[i]);
	}
	for(int i=0;i<s;i++){
		nums[i]=a.extractMin();
	}
	return nums;
}



// int main(){
// 	srand(time(0));
// 	vector<long int> v;
// 	v.push_back(3);
// 	v.push_back(-2);
// 	v.push_back(-5);
// 	v.push_back(13);
// 	v.push_back(50);
// 	v.push_back(2);
// 	v.push_back(11);
// 	v.push_back(-15);
// 	v.push_back(25);
// 	v=MergeSort(v);
// 	for(int i=0;i<v.size();i++){
// 		cout << v[i]  << endl; 
// 	}

// }
#endif



// int r=0;
// 	ListItem<long>* left=l;
// 	ListItem<long>* right=r;
// 	List<long>* p=list;
// 	//int count=0;
// 	while(r){
// 		p=p->next;
// 		r--;
// 	}
// 	long pivot=p->value;
// 	while(left->prev!=right){
		
// 		p->value=right->value;
// 		right->value=i;
// 		right=right->prev;
// 		long le=left->value;
// 		if(le>=pivot){
// 			left->value=right->value;
// 			right->value=le;
// 			right=right->prev;
// 			while(left!=right){
// 				long ri=right->value;
// 				if(ri<=pivot){
// 					right->value=left->value;
// 					left->value=ri;
// 					left=left->next;
// 				}else{
// 					right=right->prev;
// 				}
// 			}

// 		}else{
// 			left=left->next;
// 		}
// 	}
// 	qsortl(list,l,left->prev);
// 	qsortl(list,left->next,r);
