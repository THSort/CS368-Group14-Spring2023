#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
   heap_size = 0 ;
   capacity = cap;
   harr = new int[cap];
}

void MinHeap::MinHeapify(int i)
{
	if(i >= heap_size)
		return;
	int min =  left(i);
	if(min < heap_size && right(i) < heap_size && harr[min] > harr[right(i)]){
		min = right(i);
	}
	if(min < heap_size && harr[min] < harr[i]){
		swap(harr[min] , harr[i]);
		MinHeapify(min);
	}

}

int MinHeap::parent(int i)
{
	return (i-1) / 2 ;

}

int MinHeap::left(int i)
{
	return (2*i + 1);

}

int MinHeap::right(int i)
{
	return (2*i + 2);

}

int MinHeap::extractMin()
{
	if(!heap_size)
		return 0;
	int min = harr[0];
	deleteKey(0);
	return min;
}

void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	while(i && harr[parent(i)] > harr[i]){

		int temp = harr[i];
		harr[i] = harr[parent(i)];
		harr[parent(i)] = temp ;
		i = parent(i);
	}
	return;
}

int MinHeap::getMin()
{
	return harr[0];

}

void MinHeap::deleteKey(int i)
{
	if(i >= heap_size)
		return;

	else{
		swap(harr[i] , harr[heap_size-1]);
		heap_size--;
		MinHeapify(i);
		}
}

void MinHeap::insertKey(int k)
{
	if(heap_size < capacity){
		harr[heap_size] = k;
		int i = heap_size;
		while(i && harr[parent(i)] > harr[i]){
			int temp = harr[i];
			harr[i] = harr[parent(i)];
			harr[parent(i)] = temp ;
			i = parent(i);
		}
		heap_size++;
	}
	else
		cout << "overflowing\n" << endl;


}

int* MinHeap::getHeap()
{
	return harr;
}

#endif