#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "list.cpp"
#include "heap.cpp"

ListItem<long>* merge(ListItem<long>*left ,ListItem<long>* right);
ListItem<long>* hlpsort(ListItem<long>* list , int len);
int hlprqsort(long data[] , int lo ,int hi );
void HlpqsOrt(long data[] , int lo ,int hi);
ListItem<long>* hp2(ListItem<long>*lo ,ListItem<long>* hi);
void Hp1(ListItem<long>* lo , ListItem<long>*hi);

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{

	int len = nums.size();
	long Array[len];

	//copy to array
	for(int i=0 ; i < len; i++){
		Array[i] = nums[i];
	}


	int sorted = 0;
	while(sorted <= len){
		int iterator = sorted;
		long val = Array[iterator+1];
		while(iterator && val < Array[iterator]){
			Array[iterator+1] = Array[iterator];
			iterator--;
		}
		Array[iterator+1] = val;
		sorted++;
	}

	// copy back to vect
	for(int i=0 ; i < len; i++){
		nums[i] = Array[i];
	}
	return nums;
}

//=====================================================================================



vector<long> MergeSort(vector<long> nums)
{
	int size = nums.size();
	List<long>* list = new List<long>;

	int i = 0;
	while( i < size){
		list->insertAtHead(nums[i]);
		i++;
	}
	int len = list->length();
	ListItem<long>* lst = list->getHead();
	ListItem<long>* sorted = hlpsort(lst,len);
	std::vector<long> sortedVect;

	while(sorted){
		sortedVect.push_back(sorted->value) ;
		sorted= sorted->next;
	}
	return sortedVect;
}


ListItem<long>* merge(ListItem<long>*left ,ListItem<long>* right){
	List<long>* lsptr = new List<long>;
	while(left && right){
		if(left->value >= right->value){
			lsptr->insertAtTail(right->value);
			right = right->next;

		}
		else{
			lsptr->insertAtTail(left->value);
			left = left->next;
		}
	}

		while(right){
			lsptr->insertAtTail(right->value);
			right = right->next;
		}

		while(left){
			lsptr->insertAtTail(left->value);
			left = left->next;
		}


	ListItem<long>* temp = lsptr->getHead();
	return temp;
}

ListItem<long>* hlpsort(ListItem<long>* list , int len){
	if( len > 1){

		int len1 = len / 2;
		int mid = len1;
		int len2 = len - len1;
		ListItem<long>* leftHalf = list;

		int i = 0;
		while(i < mid){
			list = list->next;
			i++;
		}

		ListItem<long>* rightHalf = list->next;
		list->next = NULL;
		ListItem<long>* left = hlpsort(leftHalf,len1);
		ListItem<long>* right = hlpsort(rightHalf,len2);
		return merge(left,right);
	}
	else{
		return list;
	}
}
//=====================================================================================


vector<long> QuickSortArray(vector<long> nums)
{
	int len = nums.size();
	long data[len];
	for(int i=0 ; i<len ; i++)
		data[i] = nums[i];

	HlpqsOrt(data ,0,len-1 );

	for(int i=0 ; i<len ; i++)
		nums[i] = data[i];
	return nums;

}


int hlprqsort(long data[] , int lo ,int hi ){

	int var1 = lo-1 ;
	int var2 = lo;
	long pivot = data[hi];
	while(var2 < hi && data[var2] <= pivot){

			var1++;
			long temp = data[var1];
			data[var1] = data[var2];
			data[var2] =  temp;
			var2++;
}
	 var1++;
	long temp = data[var1];
	data[var1] = data[hi];
	data[hi] =  temp;
	return var1;
}
void HlpqsOrt(long data[] , int lo ,int hi){
	if(lo < hi){
		int tmp = hlprqsort(data , lo , hi);
		HlpqsOrt(data ,lo, tmp-1);
		HlpqsOrt(data , tmp+1 , hi);
	}
	else
		return;
}

//=====================================================================================
ListItem<long>* hp2(ListItem<long>*lo ,ListItem<long>* hi){
	ListItem<long>* i = lo;
	long pivot = hi->value;
	for(ListItem<long>* j = lo; j != hi; j = j->next){
		if(pivot >= j->value){
			long temp = j->value ;
			j->value = i->value;
			i->value = temp;
			i = i->next;
		}
	}

	hi->value = i->value;
	i->value = pivot;
	return i;
}

void Hp1(ListItem<long>* lo , ListItem<long>*hi){
	if(lo == hi)
		return;

	else if(!lo || !hi)
		return;

	else{
		ListItem<long> *p = hp2(lo , hi);
		Hp1(lo , p->prev);
		Hp1(p , hi);
	}

}
vector<long> QuickSortList(vector<long> nums)
{
	int len = nums.size();
	List<long>* list = new List<long>;
	for (int i = 0; i < len; ++i){
		list->insertAtHead(nums[i]);
	}

	ListItem<long>* lo = list->getHead();
	ListItem<long>* hi = list->getTail();
	Hp1(lo , hi);

	int i = 0 ;
	while(lo){
		nums[i] =  lo->value ;
		lo= lo->next;
		i++;
	}
	return nums;
}
//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int len = nums.size();
	MinHeap heap(len);
	for(int i=0 ; i < len ; i++)
		heap.insertKey(nums[i]);

	for(int i=0 ; i < len ; i++)
		nums[i] = heap.extractMin();

	return nums;
}


#endif