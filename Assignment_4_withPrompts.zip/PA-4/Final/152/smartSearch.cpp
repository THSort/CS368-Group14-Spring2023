#include <fstream>
#include "sorts.cpp"
#include <iostream>
using namespace std;


//takes lg(n) steps
void binarySearch(long* Nums , int lo , int hi , long x , long y , vector< vector<long> >&pairs){
    if (hi < lo)
        return;

    int mid = (hi+lo)/2;
    vector<long> v;
    if(y == Nums[mid]){
         v.push_back(x);
         v.push_back(y);
         pairs.push_back(v);
         return;
    }
    if(Nums[mid] > y){
            binarySearch(Nums , lo , mid-1 , x , y , pairs);
    }
    else
        binarySearch(Nums , mid+1, hi , x , y , pairs);



}

vector< vector<long> > smartSearch(vector<long> nums, long k){

   nums = QuickSortList(nums);
   int len = nums.size();
   long Array[len];
   int i = 0;
   while (i < len){
        Array[i] = nums[i];
        i++;
   }
   vector< vector<long> > pairs;
  for(int i=0 ; i < len ; i++){
    long x = Array[i];
    long y = k - x; // for sum = 7
    binarySearch(Array , 0 , len-1 , x ,y , pairs);
}
    return pairs;

}

int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}