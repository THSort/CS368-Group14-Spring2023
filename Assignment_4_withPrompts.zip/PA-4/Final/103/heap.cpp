#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"

void swap(int *x, int *y)
{
    int t = *x;
    *x = *y;
    *y = t;
}

MinHeap::MinHeap(int cap)
{
	capacity= cap;
	heap_size=0;
	harr= new int[capacity];
}

void MinHeap::MinHeapify(int i)
{
	int left_i= left(i);
	int right_i= right(i);
	int smallest = i;
	if(left_i< heap_size && harr[left_i]<harr[i])
	{
		smallest = left_i;
		//int temp= harr[i];
		//harr[i]= harr[left_i];
		//harr[left_i]= temp;
	}
	if (right_i < heap_size && harr[right_i]< harr[smallest])
	{
		smallest = right_i;
		//int temp= harr[i];
		//harr[i]= harr[right_i];
		//harr[right_i]= temp;
	}
	if(smallest != i)
	{
		int temp= harr[i];
		harr[i]= harr[smallest];
		harr[smallest]= temp;
		MinHeapify(smallest);
	}
}
 
int MinHeap::parent(int i)
{	
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return 2*i+1;
}
 
int MinHeap::right(int i)
{
	return 2*i+2;
}
 
int MinHeap::extractMin()
{	
	if(heap_size==0)
		return -10000000;
	else if (heap_size==1)
	{
		heap_size--;
		return harr[0];
	}
	else 
	{
		int smallest = harr[0];
		harr[0]= harr[heap_size-1];
		heap_size--;
		MinHeapify(0);
		return smallest;
	}
}	
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]= new_val;
	while (i!=0 && harr[i]<harr[parent(i)])
	{
		int temp=harr[parent(i)];
		harr[parent(i)]= harr[i];
		harr[i]= temp;
		i= parent(i);
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i == heap_size)
	{
		return;
	}
	decreaseKey(i, -100000000);
	extractMin();
}
 
void MinHeap::insertKey(int k)
{
	if(heap_size== capacity)
		return;
	int x= heap_size;
	heap_size++;
	harr[x]= k;
	while (x!=0 && harr[x]<harr[parent(x)])
	{
		int temp=harr[parent(x)];
		harr[parent(x)]= harr[x];
		harr[x]= temp;
		x= parent(x);
	}

}

int* MinHeap::getHeap()
{
	return harr;
}


#endif