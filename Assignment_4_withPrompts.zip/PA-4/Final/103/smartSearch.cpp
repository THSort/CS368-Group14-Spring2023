#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   

    // Write your code in this function
    vector<long> a;
    vector<vector<long> > pairs;
    vector<long> sorted = QuickSortArray(nums);
    // for(int i=0; i<100;i++)
    // {
    //     cout<<sorted[i]<<endl;
    // }
    int count=0;
    int i=0;
    while(sorted[i]<=k)
    {
        count++;
        i++;
    }
    for (int j=0; j<count+1;)
    {
        if(sorted[j]+sorted[count]>k)
        {
            count--;
        }
        else if(sorted[j]+sorted[count]<k)
        {
            j++;
        }
        else if (sorted[j]+sorted[count]==k)
        {
            a.push_back(sorted[j]);
            a.push_back(sorted[count]);
            pairs.push_back(a);
            a.pop_back();
            a.pop_back();
            j++;
        }
        
    }
    return pairs;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}