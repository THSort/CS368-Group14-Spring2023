#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include <vector>
#include "list.cpp"
ListItem<long>* merge(ListItem<long>* a, ListItem<long>* b)
{
	if(a==NULL)
		return b;
	if(b==NULL)
		return a;
	if(a->value<= b->value)
	{
		a->next= merge(a->next, b);
		a->next->prev= a;
		a->prev= NULL;
		return a;
	}
	else if(b->value <= b->value)
	{
		b->next= merge(a, b->next);
		b->next->prev=b;
		b->prev=NULL;
		return b;
	}
}
ListItem<long>* split(ListItem<long>* x)
{
	ListItem<long>* single=x;
	ListItem<long>* double_ = x;
	while(double_ ->next!= NULL && double_->next->next!= NULL)
	{
		single=single->next;
		double_= double_->next->next;
	}
	ListItem<long>* temp= single->next;
	single->next=NULL;
	return temp;
}
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int vec_size = nums.size();
	int arr[vec_size];
	for (int i=0; i<vec_size;i++)
	{
		arr[i]=nums.back();
		nums.pop_back();
	}
	for (int i=1; i<vec_size;i++)
	{
		int x= arr[i];
		int j= i-1;
		while(j>=0 && arr[j]>x)
		{
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=x;
	}
	for (int i=0;i<vec_size;i++)
	{
		nums.push_back(arr[i]);
	}
	return nums;

}

//=====================================================================================
List<long>* vec_to_ll(vector<long> vec)
{
	int x= vec.size();
	List<long>* temp=new List<long>;
	for (int i=0; i<x;i++)
	{
		temp->insertAtHead(vec[i]);
	}
	return temp;
}
vector<long> ll_to_vec(ListItem<long>* ll)
{
	vector<long> x;
	while(ll!=NULL)
	{
		x.push_back(ll->value);
		ll=ll->next;
	}
	return x;
}
List<long>* mysort(List<long>* p){
	if(p->length()>1){
		// cout<<p->length()<<endl;
		int len=p->length();
		ListItem<long>* temp=p->getHead();
		len=len/2;
		int i=0;
		List<long>* left= new List<long>;
		List<long>* right= new List<long>;
		while(i!=len){
			cout << i << endl;
			left->insertAtHead(temp->value);
			cout << len << endl;
			temp=temp->next;
			i++;
		}
		while(temp)
		{
			right->insertAtHead(temp->value);
			temp=temp->next;
		}
		List<long>* l;
		List<long>* r;
		l=mysort(left);
		r=mysort(right);
		ListItem<long>* le=l->getHead();
		ListItem<long>* ri= r->getHead();
		List<long>* mer=new List<long>;
		while(le && ri)
		{
			if(le->value < ri->value)
			{
				mer->insertAtHead(ri->value);
				ri=ri->next;
			}
			else 
			{
				mer->insertAtHead(le->value);
				le=le->next;
			}
		}
		while(le)
		{
			mer->insertAtHead(le->value);
			le=le->next;
		}
		while(ri)
		{
			mer->insertAtHead(ri->value);
			ri=ri->next;
		}
		return mer;
	}
	return p;
}

vector<long> MergeSort(vector<long> nums)
{
	//List<long> temp;
	int vec_size= nums.size();
	List<long>* lis=vec_to_ll(nums);
 	//ListItem<long>* head= temp.getHead();
	// cout<<"mer"<<endl;
	List<long>* merged= mysort(lis);
	ListItem<long>* head=merged->getHead();
	int i=0;
	while(head)
	{
		nums[i]=head->value;
		head=head->next;
		i++;
	}
	return nums;

}

//=====================================================================================
int partition_helper(vector<long> &nums, int min , int max)
{
	// long x= nums[(min+max)/2];
	// int i=min;
	// int j=max;
	// while(i<=j)	
	// {
	// 	while(nums[i]<x)
	// 		i++;
	// 	while(nums[j]>x)
	// 		j--;
	// 	if(i<=j)
	// 	{
	// 		long temp=nums[i];
	// 		nums[i]=nums[j];
	// 		nums[i]=temp;
	// 		i++;
	// 		j--;
	// 	}
	// }
	// if(min<j)
	// {
	// 	partition_helper(nums, min,j);
	// }
	// if(i<max)
	// {
	// 	partition_helper(nums, i, max);
	// }
	// return nums;
	long highest= nums[max];
	int i=min-1;
	for (int k=min;k<max; k++)
	{
		if(nums[k]<=highest)
		{
			i++;
			long temp= nums[i];
			nums[i]=nums[k];
			nums[k]=temp;
		}
	}
	long temp1=nums[i+1];
	nums[i+1]= nums[max];
	nums[max]= temp1;
	return ++i;
}

void quick_sort_helper(vector<long> &nums, int min, int max)
{
	int mid;
	if(min<max)
	{
		mid= partition_helper(nums, min, max);
		quick_sort_helper(nums, min, mid-1);
		quick_sort_helper(nums, mid+1, max);
	}
	return;

}

vector<long> QuickSortArray(vector<long> nums)
{
	int x= nums.size();
	quick_sort_helper(nums, 0, x-1);
	return nums;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int x= nums.size();
	MinHeap temp_heap(x);
	for(int i=0; i<x; i++)
	{
		temp_heap.insertKey(nums[i]);
		nums.pop_back();
	}
	for(int i=0; i<x;i++)
	{
		nums.push_back(temp_heap.extractMin());
	}
	return nums;
}
int main()
{
	vector<long> temp;
	vector<long> temp1;
	// temp.push_back(10);
	// temp.push_back(90);
	// temp.push_back(60);
	// temp.push_back(70);
	// temp.push_back(30);
	temp.push_back(56);
	temp.push_back(50);
	temp.push_back(80);
	temp1=MergeSort(temp);
	for(int i=0; i<3;i++)
	{
		cout<<temp1[i]<<endl;
	}
}
#endif
