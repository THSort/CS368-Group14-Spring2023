#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	harr = new int[cap];
	heap_size = 0;
}

// percolate down
void MinHeap::MinHeapify(int i)
{
	int min_i = i;
	int left_i = left(i);
	int right_i = right(i);
	
	if(left_i<heap_size  &&  harr[left_i]<harr[min_i])
		min_i = left_i;
	if(right_i<heap_size  &&  harr[right_i]<harr[min_i])
		min_i = right_i;

	if(min_i != i){
		int temp = harr[i];
		harr[i] = harr[min_i];
		harr[min_i] = temp;
		MinHeapify(min_i);
	}
}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return 2*i+1;
}
 
int MinHeap::right(int i)
{
	return 2*i+2;
}
 
int MinHeap::extractMin()
{
	int min = harr[0];
	harr[0] = harr[--heap_size];
	MinHeapify(0);
	return min;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;

	while(i > 0){
		int par_i = parent(i);
		if(harr[par_i] > harr[i]){
			int temp = harr[i];
			harr[i] = harr[par_i];
			harr[par_i] = temp;
		} else {
			break;
		}
		i = par_i;
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i<heap_size){
		harr[i] = harr[--heap_size];
		MinHeapify(i);
	}
}
 
void MinHeap::insertKey(int k)
{
	if(capacity > heap_size){
		harr[heap_size] = k;
		heap_size++;
	}
	int i = heap_size-1; 
	while(i > 0){
		int par_i = parent(i);
		if(harr[par_i] > harr[i]){
			int temp = harr[i];
			harr[i] = harr[par_i];
			harr[par_i] = temp;
		} else {
			break;
		}
		i = par_i;
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif