#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int size = nums.size();
	long arr[size];
	int i = 0;
	while(i < size)
	{
		arr[i] = nums[i];
		++i;
	}
	i = 1;
	int j ;
	long temp;
	while(i< size){
		j = i;
		while( j>0 &&  arr[j]<arr[j-1]){
			temp = arr[j];
			arr[j] = arr[j-1];
			arr[j-1] = temp;
		--j;
		}
		++i;
	}
	i=0;
	while(i < size)
	{
		nums[i] = arr[i];
		i++;
	}

	return nums;
}

ListItem<long>* mergeSortHelper(ListItem<long>* tempList, int size){
	if(!tempList || !(tempList->next)){
		return tempList;
	}
	else{
		ListItem<long>* leftList = tempList;
		for (int i = 0; i < size/2; ++i){
			tempList = tempList->next;
		}
		(tempList->prev)->next = NULL;
		ListItem<long>* rightList = tempList;

		leftList = mergeSortHelper(leftList, size/2);
		rightList = mergeSortHelper(rightList, size-size/2);

		ListItem<long>* newList = NULL;
		ListItem<long>* temp = NULL;
		while(leftList || rightList){
			if(leftList && rightList){
				if(leftList->value < rightList->value){
					if(newList){
						temp->next = leftList;
						leftList = leftList->next;
						temp = temp->next;
					} else {
						newList = leftList;
						leftList = leftList->next;
						temp = newList;
					}
				} else {
					if(newList){
						temp->next = rightList;
						rightList = rightList->next;
						temp = temp->next;
					} else {
						newList = rightList;
						rightList = rightList->next;
						temp = newList;
					}					
				}
			} else if(rightList && !leftList){
				if(newList){
					temp->next = rightList;
					rightList = NULL;
				} else{
					newList = rightList;
					rightList = NULL;
				}
			} else{
				if(newList){
					temp->next = leftList;
					leftList = NULL;
				} else{
					newList = leftList;
					leftList = NULL;
				}				
			}
		}
		return newList;
	}
}



//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	List<long> tempList;
	int len = nums.size();
	for (int i = 0; i < len; ++i)
	{
		tempList.insertAtHead(nums[i]);
	}
	ListItem<long>* temp = mergeSortHelper(tempList.getHead(), len);
	for (int i = 0; i < len; ++i)
	{
		nums[i] = temp->value;
		temp = temp->next;
	}
	return nums;
}

//=====================================================================================
int partitionArray(long arr[], int start, int end){
	long pivot = arr[end];
	int i = start-1;
	long temp;
	for (int j = start; j < end; ++j){
		if(arr[j]<=pivot){
			i++;
			temp = arr[j];
			arr[j] = arr[i];
			arr[i] = temp;
		}
	}
	temp = arr[++i];
	arr[i] = arr[end];
	arr[end] = temp;
	return i;
}

void quickSortArrayHelper(long arr[], int start, int end){
	if(start<end){
		int pivotIndex = partitionArray(arr, start, end);
		quickSortArrayHelper(arr, start, pivotIndex-1);
		quickSortArrayHelper(arr, pivotIndex+1, end);
	}
}

vector<long> QuickSortArray(vector<long> nums)
{
	int size = nums.size();
	long arr[size];
	int i;

	for (i = 0; i < size; ++i){
		arr[i] = nums[i];
	}
	quickSortArrayHelper(arr, 0, size-1);
	for (i = 0; i < size; ++i)
	{
		nums[i] = arr[i];
	}
	return nums;
}

//=====================================================================================

ListItem<long>* partitionList(ListItem<long>* start, ListItem<long>* end, int size, int& count){
	int rand_walk = rand()%(size+1);
	ListItem<long> *walk = start;
	while(count<rand_walk && walk!=end){
		walk = walk->next;
		count++;
	}
	long temp;
	if(walk!=end){
		temp = walk->value;
		walk->value = end->value;
		end->value = temp;
	}
	
	long pivot = end->value;

	ListItem<long> *i = start->prev;
	for(ListItem<long> *j = start; j!=end; j=j->next){
		if(j->value <= pivot){
			if(i)
				i = i->next;
			else
				i = start;
			temp = j->value;
			j->value = i->value;
			i->value = temp;
		}
	}
	if(i)
		i = i->next;
	else
		i = start;
	temp = i->value;
	i->value = end->value;
	end->value = temp;
	return i;
}

void quickSortListHelper(ListItem<long>* start, ListItem<long>* end, int size){
	if(end && start!=end  && start != end->next){
		int count = 0;
		ListItem<long> *pivotIndex = partitionList(start, end, size, count);
		quickSortListHelper(start, pivotIndex->prev, count);
		quickSortListHelper(pivotIndex->next, end, size-count);
	}
}

vector<long> QuickSortList(vector<long> nums)
{
	int size = nums.size();
	List<long> list;
	int i;

	for (i = 0; i < size; ++i){
		list.insertAtHead(nums[i]);
	}
	quickSortListHelper(list.getHead(), list.getTail(), size);
	ListItem<long> *temp = list.getHead();
	for (i = 0; i < size; ++i){
		nums[i] = temp->value;
		temp = temp->next;
	}
	return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int size = nums.size();
	MinHeap heap(size);
	for (int i = 0; i < size; ++i)
	{
		heap.insertKey(nums[i]);
	}
	for (int i = 0; i < size; ++i)
	{
		nums[i] = heap.extractMin();
	}
	return nums;
}

#endif