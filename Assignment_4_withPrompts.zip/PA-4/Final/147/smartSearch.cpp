#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{


    nums = MergeSort(nums);
    while(1){
        if(nums[nums.size()-1]>k){
            nums.pop_back();
        } else{
            break;
        }
    }
    int low = 0;
    int high = nums.size()- 1;
    int count = 0;
    vector<long> *pairs = new vector<long>[high]; 
    while (low<nums.size() &&  -1 < high)
    {
        long sum = nums[low] + nums[high];
        if(sum == k){ 
            pairs[count].push_back(nums[low]); 
            pairs[count].push_back(nums[high]);
            count++; 
            low++;
        }
        else if(sum < k)
            low++;
        else 
            high--;
    } 

    vector< vector<long> > vec;
    for(int i =0; i< count; i++)
    {
        vec.push_back(pairs[i]);
    }

    return vec;
    

}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;
    
    int start=clock();

    vector< vector<long> > result = smartSearch(nums, k);

    int stop=clock();

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout << "time: " << (stop-start)/double(CLOCKS_PER_SEC)<<" seconds" << endl;

    return 0;
}