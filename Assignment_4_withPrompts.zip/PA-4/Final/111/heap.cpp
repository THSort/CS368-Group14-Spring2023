#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	harr = new int[cap];
	capacity = cap;
	heap_size = 0;
}

// void MinHeap::swap(int *x, int *y)
// {
//     int temp = *x;
//     *x = *y;
//     *y = temp;
// }

void MinHeap::MinHeapify(int i)
{
	int l = left(i);
	int r = right(i);
	int n = i;
	if (l>heap_size || r>heap_size)
	{
		return;
	}
	if (harr[l]<harr[n])
	{
		n = l;
	}
	if (harr[r]<harr[n])
	{
		n = r;
	}
	if (n != i) //if n has been changed, means the smaller has been changed then swap
	{
		swap(harr[n], harr[i]);
		MinHeapify(n);
	}

	


}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i + 1);
}
 
int MinHeap::right(int i)
{
	return (2*i + 2);
}
 
int MinHeap::extractMin()
{
	// if (heap_size < 1)
	// 	{return INT_MAX;}
	if (heap_size == 1) // agar 1 hi element para hou...
	{
		heap_size-=1;
		return harr[0];
	}
	int minvalue = harr[0];
	harr[0] = harr[heap_size - 1];
	heap_size--;
	MinHeapify(0);
	return minvalue;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;

	while (harr [i] < harr[parent(i)])
	{
		swap (harr[i], harr[parent(i)]);
		i = parent(i);
		if (i==0)
		{return;} 
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if (i>=heap_size)
	{}
	else
	{
		decreaseKey(i, -1000);
    	extractMin();
    }
}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size] = k;
	heap_size++;

	int i = heap_size-1;
	while (harr[parent(i)] > harr [i])
	{
		swap (harr[parent(i)], harr[i]);
		i = parent(i);
		if (i==0)
		{return;} 
	}
}

int* MinHeap::getHeap()
{
	return harr;
}





// int main()
// {
// 	int size = 5;
// 	int *arr = new int[size];
// 	for (int i=0; i<size; i++)
// 	{
// 		arr[i] = i;
// 	}

// 	arr[5] = 5;
// 	size++;
// 	// delete arr[5];
// 	size--;

// 	for (int i=0; i<6; i++)
// 	{
// 		cout << arr[i] << endl;
// 	}
// 	cout << endl;
// 	return 0;
// }




#endif



















