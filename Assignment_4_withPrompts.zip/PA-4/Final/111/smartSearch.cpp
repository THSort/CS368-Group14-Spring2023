#include <fstream>
#include "sorts.cpp"
#include <time.h>
#include <stdio.h>
#include <math.h>


using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.

long binary_search(vector<long> &nums, int l, int r,long findnum)
{
    while (l<=r)
    {
        int m = l + (r-l)/2;
        if (nums[m] == findnum)
            {return findnum;}
        if (nums[m]<findnum)
            {l=m+1;}
        else if (nums[m]>findnum)
            {r=m-1;}
    }
    return INT_MAX;
}


vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    // Write your code in this function
    int size = nums.size();
    nums=QuickSortArray(nums);
    long findnum;
    int l = 0;
    int r = size-1;
    vector< vector<long> > large;

    for (int i=0; i<size; i++)
    {
        findnum = k - nums[i];
        int a = binary_search(nums,l,r,findnum);
        if (a == INT_MAX)
        {}
        else
        {
            vector<long> small;
            small.push_back(a);
            small.push_back(nums[i]);
            large.push_back(small);
        }
    }
    return large;
}


int main()
{
    clock_t t;
    t = clock();
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);
    // cout << result.size() << endl;

    for(int i = 0; i < result.size(); i++)
    {
        // cout << i << endl;
        cout << result[i][0] << ", " << result[i][1] << endl;
    }
    t = clock() - t;
    printf ("It took (%f seconds).\n",t,((float)t)/CLOCKS_PER_SEC);

    return 0;
}