#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int size = nums.size();
	int array[size];
	for (int i=0; i<size; i++)
	{
		array[i] = nums[i];
	}

	int a;
	int i=1;
	while (i<size)
	{
		int temp = array[i];
		a = i-1;
		while (a!=-1 && temp<array[a])
		{
			array[a+1] = array[a];
			a--;		
		}
		array[a+1] = temp;
		i++;
	}

	for (int i=0; i<size; i++)
	{
		nums[i] = array[i];
	}
	return nums;

}

//=====================================================================================


void splitter (ListItem <long> *head, ListItem<long> **left, ListItem <long> **right)
{
	ListItem <long> *two;
	ListItem <long> *one;

	if (head == NULL || head->next == NULL)
	{
		*left = head; //pehla adha
		*right = NULL; //dosra adha
	}

	else
	{
		one = head;
		two = head->next;

		while (two !=NULL)
		{
			two = two->next;
			if(two != NULL)
			{
				two = two->next;
				one = one->next;
			}
		}
	}
	//divide by one and two in 2 parts
	*left = head;
	*right = one->next;
	one->next = NULL;

}

ListItem <long> *merger (ListItem <long> *ptr1, ListItem <long> *ptr2)
{
	ListItem <long> *node = NULL;

	if(ptr1 == NULL)
	{return ptr2;}

	if (ptr2==NULL)
	{return ptr1;}

	// recursively join the linked list
	if(ptr2->value <= ptr1->value)
	{
		node = ptr2;
		node->next = merger(ptr1, ptr2->next);
	}
	else
	{
		node = ptr1;
		node->next = merger(ptr1->next, ptr2);
	}
	return node;
}

void mergesort(ListItem <long> **node)
{
	ListItem<long>* head = *node;
	ListItem<long>* temp1 = NULL;
	ListItem<long>* temp2 = NULL;

	if (head == NULL || head->next == NULL)
	{
		return; //agar list main 0 ya 1 element
	}
	splitter(head, &temp1, &temp2); //splitting the two vectors
	mergesort(&temp2); //keeps shrinking the lists
	mergesort(&temp1); //keeps shrinking the lists
	*node = merger(temp1, temp2); //now pass these lists from merger
}

vector<long> MergeSort(vector<long> nums)
{
	List<long> unsortedlist;
	vector <long> new_vector;
	int size = nums.size();

	int i=0;
	while(i<size)
	{
		unsortedlist.insertAtTail(nums[i]);
		i++;
	}

	ListItem <long> *temp= unsortedlist.getHead();
	mergesort (&temp);

		for (int i=0; i<size ;i++)
		{
			nums[i] = temp->value;
			temp= temp->next;
		}
		return nums;
}




//=====================================================================================
void quicksortarray(int* array, int left, int right)
{
	int i = left;
	int j =  right;
	int pivot = array[(i+j)/2];

	while(i<=j)
	{
		while(array[i]<pivot)
		{
			i++;
		}
		while(array[j]>pivot)
		{
			j--;
		}
		if (i<=j)
		{
			swap(array[i],array[j]);
			i++;
			j--;
		}
	}
	if (left<j)
	{
		quicksortarray(array, left, j);
	}
	if (right>i)
	{
		quicksortarray(array,i, right);
	}


}


vector<long> QuickSortArray(vector<long> nums)
{
	int size = nums.size();
	int*array;
	array = new int[size];
	for (int i=0; i<size; i++)
	{
		array[i] = nums[i];
	}

	int left = 0;
	int right = size-1;
	quicksortarray(array, left, right);

	for (int i=0; i<size; i++)
	{
		nums[i] = array[i];
	}
	return nums;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int size = nums.size();
	MinHeap heap(size);

	for (int i=0;i<size; i++)
	{
		heap.insertKey(nums[i]);
	}

	for (int i=0;i<size;i++)
	{
		nums[i] = heap.extractMin();
	}
	return nums;
}

// int main()
// {
// 	vector<long> v;
// 	v.push_back(12);
// 	v.push_back(11);
// 	v.push_back(13);
// 	v.push_back(5);
// 	v.push_back(6);
// 	for (int i=0; i<v.size(); i++)
// 	{
// 		cout << v[i] << endl;
// 	}
// 	cout << endl;
//     MergeSort(v);
 
//     return 0;
// }

#endif