#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);

vector<long> MergeSort(vector<long> nums);
void splitter (ListItem <long> *head, ListItem<long> **front_half, ListItem <long> **back_half);
ListItem <long> *merger (ListItem <long> *a, ListItem <long> *b);
void mergesort(ListItem <long> ** node);

//helper fucntions for merge sort
// List<long> *mergesort(List<long> *unsortedlist);
// List<long> *merger(List<long> *leftlist, List<long> *rightlist);

vector<long> QuickSortArray(vector<long> nums);
void quicksortarray(int* array, int left, int right);

vector<long> QuickSortList(vector<long> nums);
vector<long> HeapSort(vector<long> nums);

#endif