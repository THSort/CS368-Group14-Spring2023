#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
    	int sorting[nums.size()];
	int size=nums.size();

	int i1 = 0;

	while (i1 <size)
	{
		sorting[i]=nums[i];
		i1++;
	}


	int m=1;
	int ok=0;
	int j=0;
   while ( m < size)
   {
       ok = sorting[m];
       j = m-1;


       while 	( sorting[j] > ok && j>=0)
       {
           sorting[j+1] = sorting[j];
           j = j-1;
       }

      		sorting[j+1] = ok;
      		m++;
    }

    std::vector<long> array;
    int i2=0;
while ( i2 < size)
    {
    	array.push_back(sorting[i]) ;
    	i2++;
    }

    return array;



}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{

	int sort[nums.size()];
	int size=nums.size();
	int i3=0;


	while ( i3 < size)
	{
		sort[i] = nums[i];
		i3++;
	}

	sorting(sort, 0, (size-1));
	int i4=0;

	 std::vector<long> array;
    while (i4 < size)
    {
    	array.push_back(sort[i]);
    	i4++;
    }

    return array;



}

int divider (int arr[], int down, int up)
{
	int i5=low;
	int that = (down - 1);
    int point = arr[up];
    int h1= high-1;


    while ( i5 <= h1)
    {

        if (arr[j] > point)
        {}
        else{
        	 that++;
             int temp=arr[that];
  			 arr[that]=arr[i5];
   			 arr[i5]=temp;
        }

        i5++;
    }

    int temp 	=	 arr[that+1];
    arr[that+1]		=	arr[high];
    arr[high]	=	temp;
    int ans = that +1;

    return ans;
}

void sorting(int arr[],int down,int up)
{
	int all=0;
	if (down >= up)
    {
    }

    else
    {
    	 all = divider(arr, down, up);


        sorting(arr, down, all - 1);

        sorting(arr, all + 1, up);
    }

}


}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int y=0;
	int soh = nums.size();
	int z=0;
	HeapMin* heap = new HeapMin(soh);
	while( y < soh)
	{
		heap->insertKey(nums[i]);
		y++;
	}
	for( z < soh)
	{
		nums[i] = heap->extractMin();
		z++;
	}
	return nums;


}

#endif
