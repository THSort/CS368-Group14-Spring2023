#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <math.h>


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	harr = new int[capacity];
	for(int i =0; i<capacity; i++)
	{
		harr[i]= 0;
	}
}

void MinHeap::MinHeapify(int i)
{
	int root = i;
	int lChild = left(i);
	int rChild = right(i);
	int temp = 0;

	if(harr[root] > lChild && lChild != -1)
	{
		root = lChild;
	}
	if(harr[root] > rChild && rChild != -1)
	{
		root = rChild;
	}
	if(root != i)
	{
		temp = harr[i];
		harr[i] = harr[root];
		harr[root]=temp;
		MinHeapify(root);
	}
}
 
int MinHeap::parent(int i)
{
	float par = (i-1)/2;
	int p = floor(par);

	if(p < heap_size && p >= 0)
		return p;
	else
		return -1;
}
 
int MinHeap::left(int i)
{
	int lChild = (2*i) + 1;
	
	if(lChild < heap_size && lChild >= 0)
		return lChild;
	else
		return -1;
}
 
int MinHeap::right(int i)
{
	int rChild = (2*i) + 2;
	
	if(rChild < heap_size && rChild >= 0)
		return rChild;
	else
		return -1;
}
 
int MinHeap::extractMin()
{
	int temp;
	if(heap_size > 0)
	{
		temp = harr[0];
		harr[0]= harr[heap_size-1];
		heap_size--;
		MinHeapify(0);
		return temp;
	}
	else
	{
		return INT_MAX;
	}
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	int x = i;
	int temp;
	while(x > 0)
	{
		int par = parent(x);
		if(harr[x] < harr[par])
		{
			temp=harr[par];
			harr[par] = harr[x];
			harr[x] = temp;

		}
		else
		{
			break;
		}
		x = par;
	}
}
 
int MinHeap::getMin()
{
	return harr[0];

}
 
void MinHeap::deleteKey(int i)
{
	if(i > heap_size || i < 0)
	{
		return;
	}
	else
	{
		harr[i] = harr[heap_size-1];
		heap_size--;
		MinHeapify(i);

	}

}
 
void MinHeap::insertKey(int k)
{
	if(heap_size < capacity)
	{
		heap_size++;
		harr[heap_size-1]=k;
		int x = heap_size-1;

		while(x > 0)
		{
			int par = parent(x);
			if(harr[x] < harr[par])
			{
				int temp=harr[par];
				harr[par] = harr[x];
				harr[x] = temp;

			}
			else
			{
				break;
			}
			x = par;
		}
	}
	else
	{
		return;
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif