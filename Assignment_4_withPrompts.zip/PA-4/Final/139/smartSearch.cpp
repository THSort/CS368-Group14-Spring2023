#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long sum)
{   

    int start, end;

    nums = MergeSort(nums);
    vector<long> temp;
    vector< vector<long> > box;

    start = 0;
    end = nums.size() - 1; 
    while (start < end)
    {
        if(nums[start] + nums[end] == sum){
            temp.push_back(nums[start]);
            temp.push_back(nums[end]);
            box.push_back(temp);

        }   
        else if(nums[start] + nums[end] < sum)
            start++;
        else 
            end--;
    } 
    return box;

}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}