#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long val;
	int j;
	for (int i = 1; i < nums.size(); i++)
	{
		val = nums[i];
		j = i-1;

		while (j >= 0 && nums[j] > val)
		{
			nums[j+1] = nums[j];
			j = j-1;
		}
		nums[j+1] = val;
	}
	return nums;
}

//=====================================================================================
ListItem<long> *Merge(ListItem<long> *a,  ListItem<long> *b)
{
    if (a == NULL)
        return b;

    if (b == NULL)
        return a;
 
    if (a->value < b->value)
    {
        a->next = Merge(a->next,b);
        a->next->prev = a;
        a->prev = NULL;
        return a;
    }
    else
    {
        b->next = Merge(a,b->next);
        b->next->prev = b;
        b->prev = NULL;
        return b;
    }
}

ListItem<long> *Mergesort(ListItem<long> *head)
{
    if (head == NULL || head->next == NULL){
        return head;
    }
    else{
    	
    	ListItem<long> *x = head;
    	ListItem<long> *y = head;
		while (x->next != NULL && x->next->next != NULL)
		{
		    x = x->next->next;
		    y = y->next;
		}
		ListItem<long> *temp = y->next;
		y->next = NULL;
		ListItem<long> *b = temp;

		head = Mergesort(head);
		b = Mergesort(b);

		return Merge(head,b);
	}
}


vector<long> MergeSort(vector<long> nums)
{
	int siz = nums.size();
	List<long> newList;
	ListItem<long> *temp;
	for (int i = 0; i < siz; i++)
	{
		newList.insertAtHead(nums[i]);
	}
	ListItem<long> *head = newList.getHead();
	temp = Mergesort(head);
 	int i =0;
	while(temp != NULL)
	{	
		nums[i] = temp->value;
		temp = temp->next;
		i++;
	}
	return nums;
}

//=====================================================================================
int partition (long arr[], int low, int high)
{
    int pivot = arr[high];    
    int i = (low - 1);  
    long temp = 0;

    for (int j = low; j <= high- 1; j++)
    {
        if (arr[j] <= pivot)
        {
        	arr[j]=temp;
        	arr[j]=arr[i];
        	arr[i]= temp;
            i++;    
        }
    }
    arr[i+1]=temp;
	arr[i+1]=arr[high];
	arr[high]= temp;
    return (i + 1);
}


void quickSort(long arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

vector<long> QuickSortArray(vector<long> nums)
{
	int siz = nums.size();
	long *arr = new long[siz];
	for (int i = 0; i < siz; i++)
	{
		arr[i]=nums[i];
	}
	quickSort(arr, 0, (siz-1));
	for (int i = 0; i < siz; i++)
	{
		nums[i]= arr[i];
	}
	return nums;
}

//=====================================================================================

ListItem<long>* partition(ListItem<long> *l, ListItem<long> *h)
{
    long val  = h->value;
    long temp = 0;
    ListItem<long> *i = l->prev;

    for (ListItem<long> *j = l; j != h; j = j->next)
    {
        if (j->value <= val)
        {
            if(i == NULL)
            {
            	i = l;
            }
            else
            {
            	i->next;
            }
            
            i->value=temp;
        	i->value=j->value;
        	j->value= temp;

        }
    }
    if(i == NULL)
    {
    	i = l;
    }
    else
    {
    	i->next;
    }
    i->value=temp;
	i->value=h->value;
	h->value= temp;

    return i;
}

void quickSort(ListItem<long>* l, ListItem<long> *h)
{
    if (h != NULL && l != h && l != h->next)
    {
        ListItem<long> *p = partition(l, h);
        quickSort(l, p->prev);
        quickSort(p->next, h);
    }
}


vector<long> QuickSortList(vector<long> nums)
{
	int siz = nums.size();
	List<long> newList;
	ListItem<long> *temp;
	for (int i = 0; i < siz; i++)
	{
		newList.insertAtHead(nums[i]);
	}
	ListItem<long> *head = newList.getHead();
	ListItem<long> *tail = newList.getTail();
	quickSort(head, tail);

	for (int i = 0; i < siz; i++)
	{
		temp = newList.getHead();
		nums[i] = temp->value;
		newList.deleteHead();
	}
	return nums;
}

//=====================================================================================

vector<long> HeapSort(vector<long> nums)
{
	int siz = nums.size();
	
	MinHeap h(siz);
    long temp =0;
    for (int i = 0; i < siz; i++){
    	h.insertKey(nums[i]);
    }
        
    for (int i=0; i<siz; i++)
    {
        nums[i]= h.extractMin();
    }

	return nums;
}

#endif
