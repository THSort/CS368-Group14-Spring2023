#ifndef __SORTS_H
#define __SORTS_H

#include "list.h"
#include "list.cpp"

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>

using namespace std;

vector<long> InsertionSort(vector<long> nums);
vector<long> MergeSort(vector<long> nums);
vector<long> QuickSortArray(vector<long> nums);
vector<long> QuickSortList(vector<long> nums);
vector<long> HeapSort(vector<long> nums);
void quicksortarr(long arr[],int start, int end);
void quicksortlist(ListItem<long>* head,ListItem<long>* tail);
void mergesortlist(List<long>& l );
void merge(List<long>& l,List<long>& l1,List<long>& l2);

#endif