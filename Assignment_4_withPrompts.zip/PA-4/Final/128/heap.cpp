#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <cmath>


MinHeap::MinHeap(int cap)
{
	capacity=cap;
	heap_size=0;
	harr = new int[cap];
}

void MinHeap::MinHeapify(int i)
{
	if(i>heap_size)
	{

		return;
	}
	else 
	{

			if(left(i)<=heap_size && right(i)<=heap_size)
		{
			if(harr[i]<=harr[left(i)] && harr[i]<=harr[right(i)])
			{
				return;
			}

			else if(harr[left(i)]>=harr[right(i)])
			{
				int temp;
				temp=harr[i];
				harr[i]=harr[right(i)];
				harr[right(i)]=temp;
				MinHeapify(right(i));
			}

			else if(harr[left(i)]<harr[right(i)])
			{
				int temp;
				temp=harr[i];
				harr[i]=harr[left(i)];
				harr[left(i)]=temp;
				MinHeapify(left(i));
			}
		}
	else if(left(i)<=heap_size && right(i)>heap_size)
		{
		    if(harr[i]<=harr[left(i)])
			{
				return;
			}
			else if(harr[i]>harr[left(i)])
			{
				int temp;
				temp=harr[i];
				harr[i]=harr[left(i)];
				harr[left(i)]=temp;
				MinHeapify(left(i));
			}
		}
	else
	{
		return;
	}
  }
}
	
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i+1);
}
 
int MinHeap::right(int i)
{
	return (2*i+2);
}
 
int MinHeap::extractMin()
{
    int min = harr[0];
    harr[0] = harr[heap_size-1];
    heap_size--;
    MinHeapify(0);
    return min;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;
	int index=i;
	while( index !=0 && harr[index]<harr[parent(index)])
	{
			int temp;
			temp=harr[parent(index)];
			harr[parent(index)]=new_val;
			harr[index]=temp;
			index=parent(index);
	}
	
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if(i<heap_size-1)
	{
		harr[i]=harr[heap_size-1];
		heap_size--;
		MinHeapify(i);
	}	
}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size]=k;
	int index=heap_size;
	heap_size++;
	while(index !=0 && k<harr[parent(index)])
	{
			int temp;
			temp=harr[parent(index)];
			harr[parent(index)]=k;
			harr[index]=temp;
			index=parent(index);
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

void MinHeap::print()
{
	for(int i=0;i<heap_size;i++)
	{
		cout<<harr[i]<<endl;
	}

	cout<<endl;
	cout<<heap_size<<endl;
}


#endif