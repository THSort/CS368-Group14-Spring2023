#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.h"
#include "list.cpp"
#include <list>
#include <vector>
#include <algorithm>
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long* arr=&nums[0];
	for(int i=1;i<nums.size();i++)
	{
		long x=arr[i];
		int j;
		for(j=i-1;j>=0;)
		{
			if(arr[j]>x)
			{
				arr[j+1]=arr[j];
				j--;
				continue;
			}
			break;
		}
		arr[j+1]=x;
	}

	for(int i=0;i<nums.size();i++)
	{
		nums[i]=arr[i];
	}

	return nums;
}


//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	List<long> l;
	for(int i=0;i<nums.size();i++)
	{
		l.insertAtHead(nums[i]);
	}

	mergesortlist(l); 
	for(int i=0;i<nums.size();i++)
	{
		nums[i]=l.getHead()->value;
		l.deleteHead();
	}
	return nums;
}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
	long* arr = new long[nums.size()];
	for(int i=0;i<nums.size();i++)
	{
		arr[i]=nums[i];
	}
	quicksortarr(arr,0,nums.size()-1);
	for(int i=0;i<nums.size();i++)
	{
		nums[i]=arr[i];
	}

	return nums;

}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	List<long>* l = new List<long>();
	for(int i=0;i<nums.size();i++)
	{
		l->insertAtHead(nums[i]);
	}
		
	quicksortlist(l->getHead(),l->getTail());        
	for(int i=0;i<nums.size();i++)
	{
		nums[i]=l->getHead()->value;
		l->deleteHead();

	}
	return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	long* arr=&nums[0];
	MinHeap* h = new MinHeap(nums.size());
	for(int i=0;i<nums.size();i++)
	{
		h->insertKey(arr[i]);
	}

	for(int i=0;i<nums.size();i++)
	{
		int k=h->extractMin();
		arr[i]=k;
	}

	for(int i=0;i<nums.size();i++)
	{
		nums[i]=arr[i];
	}

	return nums;

}

void mergesortlist( List<long>& l )
{
	if(l.length()<=1 || l.getHead()==NULL)
	{
		return;
	}
	else
	{
		List<long> l1;
		List<long> l2;
		ListItem<long>* temp=l.getHead();
		for(int i=0;i<l.length()/2;i++)
		{
			l1.insertAtHead(temp->value);
			temp=temp->next;
		}

		for(int i=l.length()/2;i<l.length();i++)
		{
			l2.insertAtHead(temp->value);
			temp=temp->next;
		}


		ListItem<long>* temp1=l.getHead();
		while(temp1!=NULL)
		{
			l.deleteHead();
			temp1=temp1->next;
		}


		mergesortlist(l1);
		mergesortlist(l2);
		merge(l,l1,l2);

	}
}

void merge(List<long>& l,List<long>& l1,List<long>& l2)
{
	ListItem<long>* temp1=l1.getHead();
	ListItem<long>* temp2=l2.getHead();
	while(temp1!=NULL && temp2!=NULL)
	{
		if(temp1->value<temp2->value)
		{
			l.insertAtTail(temp1->value);
			temp1=temp1->next;
		}
		else 
		{
			l.insertAtTail(temp2->value);
			temp2=temp2->next;
		}
	}

	if(temp1!=NULL)
	{
		while(temp1!=NULL)
		{
			l.insertAtTail(temp1->value);
			temp1=temp1->next;
		}
	}

	if(temp2!=NULL)
	{
		while(temp2!=NULL)
		{
			l.insertAtTail(temp2->value);
			temp2=temp2->next;
		}
	}
}


void quicksortlist(ListItem<long>* head,ListItem<long>* tail)
{
	if(head==NULL || tail==NULL)
	{
		return;
	}
	else
	{
	long copy1=head->value;
	long pivot=copy1;
	ListItem<long>* i=tail;
	ListItem<long>* j=head;
	ListItem<long>* c=tail;

	while(1)
	{
		while(c->value<=pivot && c!=NULL && c!=j)
		{
			c=c->prev;
		}

		if(c!=j)		
		{
			long copy=i->value;
			i->value=c->value;
			c->value=copy;
			i=i->prev;
			c=c->prev;
			continue;
		}
		break;
	}
	long copy=pivot;
	pivot=i->value;
	head->value=pivot;
	i->value=copy;
	if(i!=head)
	quicksortlist(head,i->prev);
	if(tail!=i)
	quicksortlist(i->next,tail);
	}
}

void quicksortarr(long arr[],int start, int end)
{
	if(start>=end)
	{
		return;
	}
	else
	{
		long pivot=arr[start];
		int i=start;
		int j=end;


		while(1)
		{
			if(arr[i]<=pivot && i<j)
			{
				i=i+1;
				continue;
			}

			if(arr[j]>pivot && j>=i)
			{
				j=j-1;
				continue;
			}

			if(j>i)
			{
				long temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				continue;
			}
			break;
		}

		arr[start]=arr[j];
		arr[j]=pivot;
		int point=j;
		quicksortarr(arr,start,point-1);
		quicksortarr(arr,point+1,end);
	}
}

#endif