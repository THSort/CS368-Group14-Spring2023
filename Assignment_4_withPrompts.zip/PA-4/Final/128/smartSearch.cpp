#include <fstream>
#include "sorts.cpp"
#include <vector>
#include <chrono>
#include <algorithm>
#include <time.h>
using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{  
    vector< vector<long> > v;
    nums=QuickSortArray(nums);

    int f=0;
    int b=nums.size()-1;

    if(nums.size()>0)
    {
    do
    {

        if(nums[f]+nums[b]==k)
         {
            vector<long> temp;
            temp.push_back(nums[f]);
            temp.push_back(nums[b]);
            v.push_back(temp);
            vector<long> temp1;
            temp1.push_back(nums[b]);
            temp1.push_back(nums[f]);
            v.push_back(temp1);
            f++;
            b--;
         }
         else if((nums[f]+nums[b])<k)
         {
            f++;
         }
         else if((nums[f]+nums[b])>k)
         {
            b--;
         }
     }while(f<b);
 }
     return v;
}

int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    using namespace std::chrono;
    high_resolution_clock::time_point timeStart = high_resolution_clock::now();;
    vector< vector<long> > result = smartSearch(nums, k);
    high_resolution_clock::time_point timeEnd = high_resolution_clock::now();;
    duration<double> totalTime = duration_cast<duration<double>>(timeEnd - timeStart);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout<<endl;
    cout<<"Test Passed in"<<" "<<totalTime.count()<<" "<<"seconds"<<endl;



    return 0;
}