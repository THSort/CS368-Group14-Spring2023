#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "List.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
int sise=nums.size();
long* arr=new long[sise];

for(int i=0; i<sise; i++)
{
    arr[i]=nums[i];
}

long key=0; int i=0;
for(int j=1; j<sise; j++){
    key=arr[j];

    i=j-1;
    while(i>=0 && arr[i]>key){
        arr[i+1]=arr[i];
        i=i-1;
    }

    arr[i+1]=key;


}

///nums.clear();

cout<<"size of vector insertion sort = "<<nums.size()<<endl;
for(int i=0; i<sise; i++){
    nums[i]=arr[i];
}
return nums;


}
void Disp(long arr[], int a, int b){

cout<<"*********************"<<endl;
for(int i=a; i<=b; i++)
{
    cout<<arr[i]<<" ";
}
cout<<endl;
cout<<"----------------------"<<endl;

}

//=====================================================================================


List<long>* Merger(ListItem<long>* a1,ListItem<long>* b1,ListItem<long>* a2, ListItem<long>* b2  )
{
    ///cout<<"a1 = "<<a1<<endl;
    List<long>* LL3=new List<long>;
    ListItem<long>* temp1=b1;
    ListItem<long>* temp2=b2;
    ///cout<<"b1 = "<<b1<<endl;
   /// cout<<"a2 = "<<a2<<endl;
    ///cout<<"b2 = "<<b2<<endl;
    while(temp1!=NULL && temp2!=NULL)
    {
        ///cout<<"temp1->value = "<<temp1->value<<endl;
        ///cout<<"temp2->value = "<<temp2->value<<endl;
        if(temp1->value>=temp2->value)
        {   ///cout<<"inserting temp2"<<endl;
            LL3->insertAtHead(temp2->value);
            if(temp2==a2){temp2=NULL; break;}
            temp2=temp2->prev;
        }
        else{
                ///cout<<"inserting temp1"<<endl;
            LL3->insertAtHead(temp1->value);
            if(temp1==a1){temp1=NULL;break;}
            temp1=temp1->prev;
        }

    }





        while(temp1!=NULL){
        ///cout<<"hain??"<<endl;
        LL3->insertAtHead(temp1->value);
        if(temp1==a1){break;}
        temp1=temp1->prev;
        }


       while(temp2!=NULL){
            ///cout<<"hain22??"<<endl;
        LL3->insertAtHead(temp2->value);
        if(temp2==a2){break;}
        temp2=temp2->prev;
        }



///LL3->display();
ListItem<long>* tail=b2;
ListItem<long>* head=a1;
ListItem<long>* man=LL3->getHead();
///cout<<"head = "<<head<<endl;
while(head!=NULL)
{
    head->value=man->value;
    if(head==tail){break;}
    head=head->next;

    man=man->next;

}



return LL3;
}

ListItem<long>* mid(ListItem<long>* a1, ListItem<long>* b2)
{
    ListItem<long>* temp=a1;
 int counter=0;
 while(temp!=NULL)
 {
     if(temp==b2){break;}
     temp=temp->next;
     counter++;
 }


if(counter==0){
    return NULL;
}
else if(counter==1)
{
    return a1;
}
else{

        ListItem<long>* drum=a1;
    counter=counter/2;

    for(int i=0; i<counter; i++)
    {
        drum=drum->next;
    }

    return drum;
}

}

void MergeSorT(ListItem<long>* a1, ListItem<long>* b2){

if(a1!=b2){
        ///cout<<"joy"<<endl;
    ///cout<<a1<<endl;
    ///cout<<mid(a1, b2)<<endl;
    ///cout<<(mid(a1, b2)->next)<<endl;
    ///cout<<b2<<endl;
    ///int hi;
    ///cin>>hi;
    MergeSorT(a1, mid(a1, b2));
    MergeSorT(mid(a1, b2)->next, b2);
    Merger(a1, mid(a1, b2), mid(a1, b2)->next, b2);


}


}


vector<long> MergeSort(vector<long> nums)
{
cout<<"here"<<endl;
List<long>* hey=new List<long>;
for(int i=nums.size()-1; i>=0; i--)
{
    hey->insertAtHead(nums[i]);
}
ListItem<long>* headd=hey->getHead();
ListItem<long>* taill=hey->getTail();
MergeSorT(headd, taill);

ListItem<long>* temp11=taill;
int i=0;
while(temp11!=NULL)
{
    nums[i]=temp11->value;
    i++;
    temp11=temp11->prev;
}


return nums;
}

//=====================================================================================

int Part_arr(long arr[], int p, int r)
{

     ///cout<<"inside Last partition"<<endl;
     ///cout<<"input arr"<<endl;
     ///cout<<"p = "<<p<<" r = "<<r<<endl;
    ///Disp(arr, 0, 29);

    long x=arr[r];
    int i=p-1;
    for(int j=p; j<r; j++)
    {
        if(arr[j]<x)
        {
            i++;
            long temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }

    long temp2=arr[i+1];
    arr[i+1]=arr[r];
    arr[r]=temp2;
     ///cout<<"return = "<<(i+1)<<endl;
    ///cout<<"array output"<<endl;
    ///Disp(arr, 0, 29);

   return i+1;
}

void Q_sort_arr(long arr[], int p, int r){

if(p<r)
{
    int q=Part_arr(arr, p, r);
    Q_sort_arr(arr, p, q-1);
    Q_sort_arr(arr, q, r);
}

}


int part_arr_first(long arr[], int p, int r)
{

     ///cout<<"inside first element pivot"<<endl;
     ///cout<<"p = "<<p<<" r = "<<r<<endl;
     ///Disp(arr, 0, 29);
   ///cout<<"th above is the whole input array"<<endl;
    long x=arr[p];
    int i=p;
    for(int j=i+1; j<=r; j++)
    {
        if(arr[j]<=x)
        {
            i++;
            int temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }
    long temp=arr[i];
    arr[i]=arr[p];
    arr[p]=temp;
    ///cout<<"returning = "<<i<<endl;
    ///cout<<"first pivot returns the following"<<endl;
     ///Disp(arr, 0, 29);
    return i;

}

void Q_sort_arr_first(long arr[], int p, int r)
{
    if(p<r)
    {
        int q=part_arr_first(arr, p, r);
        Q_sort_arr_first(arr, p, q);
        Q_sort_arr_first(arr, q+1, r);

    }

}


int part_arr_median(long arr[], int p, int r, int& value)
{
    /*
    int check;
    cin>>check;
    */
    ///cout<<"heeeeeeeeeeeeehehehehehehehehehehehe p = "<<p<<" r  = "<<r<<endl;

     ///dangerous stuff
///dangerous stuff

int sise=(r-p+1);
if(sise<3){
        ///cout<<"blehhh"<<endl;
    return Part_arr(arr, p, r);

}
else{

    long f=arr[p];
    long s=arr[(p+r)/2];
    long t=arr[r];

    int index=p;

    if(f>=s&&s>=t)
    {
        ///cout<<"case 1"<<endl;
        index=(p+r)/2;
    }
    else if(f>=t&&t>=s)
    {
        ///cout<<"case 2"<<endl;
        index=r;
    }
    else if(s>=f&&f>=t)
    {
        ///cout<<"case 3"<<endl;
        index=p;
    }
    else if(s>=t&&t>=f)
    {
        ///cout<<"case 4"<<endl;
        index=r;
    }
    else if(t>=s&&s>=f)
    {
        ///cout<<"case 5"<<endl;
        index=(p+r)/2;
    }
    else if(t>f&&f>=s)
    {
        ///cout<<"case 6"<<endl;
        index=p;
    }

     ///cout<<"selected index = for this array"<<index<<endl;

    int hello=Part_arr(arr, p, index);
    value=hello;
    int hi=part_arr_first(arr, hello, r);



    /*
    int hee;
    cin>>hee;
    */
    return (hi);










}



}

void Q_sort_arr_median(long arr[], int p, int r)
{

if(p <r)
{    ///cout<<"inside q_sort   p = "<<p<<" r = "<<r<<endl;

    if(arr[p]<=arr[r] && (r-p+1)==2){

         ///cout<<"stop bro"<<endl;
    }
    else if(p==r){
    ///cout<<"stop bruh"<<endl;
    }

    else if((r-p+1)==3 && arr[p]<=arr[p+1]&&arr[p+1]<=arr[p+2]){
       ///cout<<"Bus"<<endl;
    }
    else{
    int value=0;

    int q=part_arr_median(arr, p, r, value);
     ///cout<<"value = " <<value<<endl;
    ///cout<<"q = "<<q<<endl;
     ///if(q==r && value == p){
            //cout<<"helloZ"<<endl;
            ///cout<<"value = "<<value<<endl;
           /// cout<<"aina"<<endl;
        /// cout<<"No scope p = "<<p<<"  q = "<<q<<endl;
        ///this loop is dangerous
     ///}
    /// else{
    Q_sort_arr_median(arr, p, q-1);
    Q_sort_arr_median(arr, q+1, r);
    int hey;
    }
    }
}
///}





vector<long> QuickSortArray(vector<long> nums)
{
 int sise=nums.size();
 long* arr=new long[sise];
 for(int i=0; i<sise; i++)
 {
      arr[i]=nums[i];
 }
///use the last argument as necessary
///Q_sort_arr(arr, 0, sise-1);
///using the first as pivot
///Q_sort_arr_first(arr, 0, sise-1);
///the above is faster
///using median
 Q_sort_arr_median(arr, 0, sise-1);



 ///nums.clear();
 for(int i=0; i<sise; i++)
{
    nums[i]=arr[i];
}
cout<<"size of vector is = "<<nums.size()<<endl;

return nums;

}


void Disp12(ListItem<long>* hey, ListItem<long>* bey){
while(hey!=NULL)
{
    cout<<hey->value<<" ";

    if(hey==bey){break;}
    hey=hey->next;
}

cout<<endl;



}

 ListItem<long> * part_arr_last_l(List<long>* LL, ListItem<long>* p, ListItem<long>* r)
{

    ///cout<<"hello"<<endl;
    ///cout<<"array received"<<endl;
    ///Disp2(p, r);
    ///int check;
    ///cin>>check;
///cout<<"r = "<<r<<endl;
ListItem<long>* i=NULL;
long x=r->value;
ListItem<long>* j=p;

while(j!=r){
///cout<<"j->value = "<<j->value<<"j = "<<j<<endl;
///cout<<"i = "<<i<<endl;
    if(j->value<=x)
        {
            if(i==NULL){i=p;}
            else{
            i=i->next;
            }
            ////cout<<"inverting "<<i->value<<" & "<<j->value<<endl;
            long temp=i->value;
            i->value=j->value;
            j->value=temp;
        }
        j=j->next;
}
///cout<<"burr"<<endl;
ListItem<long>* pos=NULL;
if(i==NULL){
        ///cout<<"hello"<<endl;
    pos=p;
}
else{
    pos=i->next;
}

long temp=pos->value;
pos->value=x;
r->value=temp;
///cout<<"pos->value = "<<pos->value<<endl;
///cout<<"returning   "<<pos <<endl;
///cout<<"array produced"<<endl;

////Disp12(p, r);
return pos;





}

void q_lastPivot_list(List<long>* LL, ListItem<long>* p, ListItem<long>* r){

if(p!=r){
    ListItem<long>* q=part_arr_last_l(LL, p, r);
    if(q!=p){
    q_lastPivot_list(LL, p, q->prev);
    }
    else{
        q_lastPivot_list(LL, p, q);
    }
    if(q!=r){
    q_lastPivot_list(LL, q->next, r);
    }
    else {
        q_lastPivot_list(LL, q, r);

    }

}



}

ListItem<long> * part_arr_first_l(List<long>* LL, ListItem<long>* p, ListItem<long>* r)
{


 ListItem<long>* i=p;
 ListItem<long>* j=p;
 long x =p->value;

 while(j!=NULL)
 {
     if(j==r){break;}
     j=j->next;
        if(j->value<=x)
        {
            i=i->next;
            long temp=i->value;
            i->value=j->value;
            j->value=temp;
        }
 }

 long temp=p->value;
 p->value=i->value;
 i->value=temp;
 return i;


}

void q_firstPivot_list(List<long>* LL, ListItem<long>* p, ListItem<long>* r){


if(p!=r){
    ListItem<long>* q=part_arr_first_l(LL, p, r);
    if(q!=p){
    q_firstPivot_list(LL, p, q->prev);
    }
    else{
        q_firstPivot_list(LL, p, q);
    }
    if(q!=r){
    q_firstPivot_list(LL, q->next, r);
    }
    else {
        q_firstPivot_list(LL, q, r);

    }

}



}




ListItem<long>* part_arr_rand_l(List<long>* LL, ListItem<long>* p, ListItem<long>* r)
{

 ListItem<long>* temp=p;
 int counter=0;
 while(p!=NULL)
 {
     if(temp==r){break;}
     temp=temp->next;
     counter++;
 }

 int index=rand()%counter;

 temp=p;
 for(int i=0; i<index; i++){
    temp=temp->next;
 }

 ///cout<<"index points to  "<<temp->value<<endl;

 ListItem<long>* hey=part_arr_last_l(LL, p, temp);
 ListItem<long>* bum=part_arr_first_l(LL, hey, r);
return bum;




}









void q_Rand_Pivot_list(List<long>* LL, ListItem<long>* p, ListItem<long>* r){


if(p!=r){
    ListItem<long>* q=part_arr_rand_l(LL, p, r);
    if(q!=p){
    q_Rand_Pivot_list(LL, p, q->prev);
    }
    else{
        q_Rand_Pivot_list(LL, p, q);
    }
    if(q!=r){
    q_Rand_Pivot_list(LL, q->next, r);
    }
    else {
        q_Rand_Pivot_list(LL, q, r);

    }

}



}












//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

List<long>* bro=new List<long>;

for(int i=nums.size()-1; i>=0; i--)
{
    bro->insertAtHead(nums[i]);
}




cout<<"using random pivot"<<endl;
q_Rand_Pivot_list(bro, bro->getHead(), bro->getTail());
ListItem<long>* headd=bro->getHead();
int i=0;
while(headd!=NULL)
{
    nums[i]=headd->value;
    headd=headd->next;
    i++;
}
return nums;


}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
int sise=nums.size();
MinHeap* hello=new MinHeap(sise);
for(int i=0; i<sise; i++){
    hello->insertKey(nums[i]);
}
nums.clear();
for(int i=0; i<sise; i++)
{
    nums.push_back(hello->extractMin());
}
return nums;

}

#endif
