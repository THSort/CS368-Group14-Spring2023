#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"
#include <cmath>

MinHeap::MinHeap(int cap)
{

heap_size=0;
capacity=cap;
harr=new int[cap+1];

}

void MinHeap::MinHeapify(int i)
{

 int left=this->left(i);
 int right=this->right(i);
 int parent=this->parent(i);
 int smallest;   ///uninitialized
 if(left<=heap_size-1&& harr[left]<harr[i])
 {
  smallest=left;
 }
 else{
    smallest=i;
 }

 if(right<=heap_size-1 && harr[right]<harr[smallest]){
    smallest=right;
 }

 if(smallest!=i){

    int temp=harr[i];
    harr[i]=harr[smallest];
    harr[smallest]=temp;
    MinHeapify(smallest);

 }


}

int MinHeap::parent(int i)
{

return floor((i-1)/2);

}

int MinHeap::left(int i)
{
return (2*i+1);
}

int MinHeap::right(int i)
{
return (2*i+2);


}

int MinHeap::extractMin()
{
int temp=harr[0];
 deleteKey(0);
return temp;

}

void MinHeap::decreaseKey(int i, int new_val)
{

harr[i]=new_val;

while(harr[i]<harr[parent(i)]&&parent(i)>=0){

    int temp=harr[i];
    harr[i]=harr[parent(i)];
    harr[parent(i)]=temp;
    i=parent(i);
}

}

int MinHeap::getMin()
{
return harr[0];
}

void MinHeap::deleteKey(int i)
{

if(i>=heap_size){
    cout<<"error in delete_key::: out of bounds"<<endl;
}
else{
    harr[i]=harr[heap_size-1];
    heap_size--;
    MinHeapify(i);



}

}

void MinHeap::insertKey(int k)
{
    heap_size++;

    harr[heap_size-1]=INT_MAX;

    this->decreaseKey(heap_size-1, k);


}

int* MinHeap::getHeap()
{   cout<<"Hey Jude"<<endl;
	return harr;
}

#endif
