#include <fstream>
  #include "sorts.cpp"
#include <vector>
#include "List.cpp"
#include <time.h>
#include <algorithm>

#include <thread>
#include <chrono>
#include <future>
using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.



int BinS(long arr[],int l, int r, long target)
{

    ///cout<<"query = "<<target<<endl;
    ///cout<<"l = "<<l<<"  r = "<<r<<endl;


    if(r>=1&& l<=r){
        int mid=(l+r )/2;
        if(arr[mid]==target){
                ///cout<<"helllo"<<endl;
            return mid;
        }
        else if(arr[mid]>target){
            return BinS(arr, 1, mid-1, target);
        }
        else{
            return BinS(arr, mid+1, r, target);
        }



    }
    else{
        return -69;
    }



}
vector< vector<long> >  Binary_dude(long arr[], long target, int sise)
{
///cout<<"This is the input array"<<endl;
 ///for(int i=0; i<sise; i++){cout<<arr[i]<<" ";}
 ///cout<<endl;


 vector< vector<long> > result;
cout<<"sise = "<<sise<<endl;
    for(int i=sise-1; i>=1; i--){

        if(arr[i]<=target && target-arr[i]<=arr[i]){
                ///cout<<"i = "<<i<<endl;
               ///cout<<arr[i]<<endl;
                ///cout<<"target = "<<target<<endl;
                ///int wait;
               /// cin>>wait;
            int heyy=BinS(arr,0, i-1, target-arr[i]);
            ///cout<<"heyy = "<<heyy<<endl;
            if(heyy!=-69)
            {
                ///finding repeated
                ///cout<<"heyy = "<<heyy<<endl;
                int counter=0;
                int temp=heyy;
                while(temp<=sise-1){
                    if(arr[temp]!=target-arr[i]){break;}
                    temp++;
                    ///cout<<"hello1"<<endl;
                    counter++;
                }
                int temp2=heyy-1;
                while(temp2>=0){
                    if(arr[temp2]!=target-arr[i]){break;}
                    temp2--;
                    ///cout<<"hello2"<<endl;
                    counter++;
                }
               /// cout<<"counter = "<<counter<<endl;
                int j=0;

                while(j!=counter){

                vector<long> temp1;

               temp1.push_back(arr[i]);
               temp1.push_back(arr[heyy]);
               result.push_back(temp1);

               vector<long> temp2;


               temp2.push_back(arr[heyy]);
               temp2.push_back(arr[i]);
               result.push_back(temp2);

               j++;
                }
            }
        }


    }


return result;

}








vector< vector<long> > smartSearch(vector<long> nums, long k)
{


    List<long>* hey=new List<long>;
for(int i=nums.size()-1; i>=0; i--){
    hey->insertAtHead(nums[i]);
}

///cout<<"displaying original vector"<<endl;
///hey->display();

MergeSorT(hey->getHead(), hey->getTail());

///cout<<"displaying original vector"<<endl;
///hey->display();
///Disp2(hey->getHead(), hey->getTail());

ListItem<long>* temp=hey->getHead();
long* barr=new long[nums.size()];
for(int i=nums.size()-1; i>=0; i--)
{
    barr[i]=temp->value;
    temp=temp->next;
}


///cout<<"input array is"<<endl;
///for(int i=0; i<nums.size(); i++)
///{
    ///cout<<barr[i]<<" ";
///}
///cout<<endl;

vector< vector<long> > result=Binary_dude(barr, k, nums.size());
cout<<"pair size of vectors = "<<result.size()<<endl;



return result;



}



int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    clock_t tStart = clock();

    vector< vector<long> > result = smartSearch(nums, k);
    printf("Time taken: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);

    for(int i = 0; i < result.size(); i++){
        ///cout << result[i][0] << ", " << result[i][1] << endl;
    }


    return 0;
}
