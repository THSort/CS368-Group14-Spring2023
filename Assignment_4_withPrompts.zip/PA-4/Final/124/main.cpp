#include <iostream>
///#include "sorts.cpp"
#include <vector>
#include "List.cpp"
#include <ctime>
#include <algorithm>
using namespace std;



vector<long> GenerateRandom(long d, long n)
{
    vector<long> nums;
    long k, residue;
    for (k = 0; k < d; k++)
    {
        residue = (long) (((long long)k * (long long) n) % d);
        nums.push_back(residue);
    }
    return nums;
}

void Disp2(ListItem<long>* hey, ListItem<long>* bey){
while(hey!=NULL)
{
    cout<<hey->value<<" ";

    if(hey==bey){break;}
    hey=hey->next;
}

cout<<endl;



}

 ListItem<long> * part_arr_last_l(List<long>* LL, ListItem<long>* p, ListItem<long>* r)
{
    int check;
    cin>>check;
    cout<<"array received"<<endl;
    Disp2(p, r);

cout<<"r = "<<r<<endl;
ListItem<long>* i=NULL;
long x=r->value;
ListItem<long>* j=p;

while(j!=r){
cout<<"j->value = "<<j->value<<"j = "<<j<<endl;
cout<<"i = "<<i<<endl;
    if(j->value<=x)
        {
            if(i==NULL){i=p;}
            else{
            i=i->next;
            }
             cout<<"inverting "<<i->value<<" & "<<j->value<<endl;
            long temp=i->value;
            i->value=j->value;
            j->value=temp;
        }
        j=j->next;
}
cout<<"burr"<<endl;
ListItem<long>* pos=NULL;
if(i==NULL){
        cout<<"hello"<<endl;
    pos=p;
}
else{
    pos=i->next;
}

long temp=pos->value;
pos->value=x;
r->value=temp;
cout<<"pos->value = "<<pos->value<<endl;
cout<<"returning   "<<pos <<endl;
cout<<"array produced"<<endl;
Disp2(p, r);
return pos;





}

ListItem<long> * part_arr_first_l(List<long>* LL, ListItem<long>* p, ListItem<long>* r)
{


 ListItem<long>* i=p;
 ListItem<long>* j=p;
 long x =p->value;

 while(j!=NULL)
 {
     if(j==r){break;}
     j=j->next;
        if(j->value<=x)
        {
            i=i->next;
            long temp=i->value;
            i->value=j->value;
            j->value=temp;
        }
 }

 long temp=p->value;
 p->value=i->value;
 i->value=temp;
 return i;


}














void q_lastPivot_list(List<long>* LL, ListItem<long>* p, ListItem<long>* r){


if(p!=r){
    ListItem<long>* q=part_arr_last_l(LL, p, r);
    if(q!=p){
    q_lastPivot_list(LL, p, q->prev);
    }
    else{
        q_lastPivot_list(LL, p, q);
    }
    if(q!=r){
    q_lastPivot_list(LL, q->next, r);
    }
    else {
        q_lastPivot_list(LL, q, r);

    }

}



}

void q_firstPivot_list(List<long>* LL, ListItem<long>* p, ListItem<long>* r){


if(p!=r){
    ListItem<long>* q=part_arr_first_l(LL, p, r);
    if(q!=p){
    q_firstPivot_list(LL, p, q->prev);
    }
    else{
        q_firstPivot_list(LL, p, q);
    }
    if(q!=r){
    q_firstPivot_list(LL, q->next, r);
    }
    else {
        q_firstPivot_list(LL, q, r);

    }

}



}


ListItem<long>* part_arr_rand_l(List<long>* LL, ListItem<long>* p, ListItem<long>* r)
{

 ListItem<long>* temp=p;
 int counter=0;
 while(temp!=NULL)
 {
     if(temp==r){break;}
     temp=temp->next;
     counter++;
 }

 int index=rand()%counter;
 cout<<"index chosen = "<<index<<endl;

 temp=p;
 for(int i=0; i<index; i++){
    temp=temp->next;
 }

 cout<<"index points to  "<<temp->value<<endl;

 ListItem<long>* hey=part_arr_last_l(LL, p, temp);
 ListItem<long>* bum=part_arr_first_l(LL, hey, r);
return bum;




}









void q_Rand_Pivot_list(List<long>* LL, ListItem<long>* p, ListItem<long>* r){


if(p!=r){
    ListItem<long>* q=part_arr_rand_l(LL, p, r);
    if(q!=p){
    q_Rand_Pivot_list(LL, p, q->prev);
    }
    else{
        q_Rand_Pivot_list(LL, p, q);
    }
    if(q!=r){
    q_Rand_Pivot_list(LL, q->next, r);
    }
    else {
        q_Rand_Pivot_list(LL, q, r);

    }

}



}

vector<long> summer1;
vector<long> summer2;

List<long>* Merger(ListItem<long>* a1,ListItem<long>* b1,ListItem<long>* a2, ListItem<long>* b2 , long target )
{
     ///cout<<"a1 = "<<a1<<endl;
    List<long>* LL3=new List<long>;
    ListItem<long>* temp1=b1;
    ListItem<long>* temp2=b2;
     ///cout<<"b1 = "<<b1<<endl;
     ///cout<<"a2 = "<<a2<<endl;
    /// cout<<"b2 = "<<b2<<endl;
    while(temp1!=NULL && temp2!=NULL)
    {
        ///cout<<"temp1->value = "<<temp1->value<<endl;
        ///cout<<"temp2->value = "<<temp2->value<<endl;
        if(temp1->value>=temp2->value)
        {   ///cout<<"inserting temp2"<<endl;
            LL3->insertAtHead(temp2->value);
            if(temp2->value+temp1->value==target){
            ///cout<<"pushed here"<<endl;
            summer1.push_back(temp2->value);
            summer2.push_back(temp1->value);
            }
            if(temp2==a2){temp2=NULL; break;}
            temp2=temp2->prev;
        }
        else{
                ///cout<<"inserting temp1"<<endl;
            LL3->insertAtHead(temp1->value);
            if(temp2->value+temp1->value==target){
            ///cout<<"pushed there"<<endl;
            summer1.push_back(temp1->value);
            summer2.push_back(temp2->value);
            }
            if(temp1==a1){temp1=NULL;break;}
            temp1=temp1->prev;
        }

    }




        while(temp1!=NULL){
        ///cout<<"hain??"<<endl;
        LL3->insertAtHead(temp1->value);
        if(temp1==a1){break;}
        temp1=temp1->prev;
        }


       while(temp2!=NULL){
            ///cout<<"hain22??"<<endl;
        LL3->insertAtHead(temp2->value);
        if(temp2==a2){break;}
        temp2=temp2->prev;
        }

///cout<<"LL3 = "<<endl;
///LL3->display();
///cout<<endl;


///LL3->display();
ListItem<long>* tail=b2;
ListItem<long>* head=a1;
ListItem<long>* man=LL3->getHead();
///cout<<"head = "<<head<<endl;
while(head!=NULL)
{
    head->value=man->value;
    if(head==tail){break;}
    head=head->next;

    man=man->next;

}



return LL3;
}

ListItem<long>* mid(ListItem<long>* a1, ListItem<long>* b2)
{
    ListItem<long>* temp=a1;
 int counter=0;
 while(temp!=NULL)
 {
     if(temp==b2){break;}
     temp=temp->next;
     counter++;
 }


if(counter==0){
    return NULL;
}
else if(counter==1)
{
    return a1;
}
else{

        ListItem<long>* drum=a1;
    counter=counter/2;

    for(int i=0; i<counter; i++)
    {
        drum=drum->next;
    }

    return drum;
}

}

void MergeSorT(ListItem<long>* a1, ListItem<long>* b2, long target){

if(a1!=b2){
        ///cout<<"joy"<<endl;
    ///cout<<a1<<endl;
    ///cout<<mid(a1, b2)<<endl;
    ///cout<<(mid(a1, b2)->next)<<endl;
    ///cout<<b2<<endl;
    ///int hi;
    ///cin>>hi;
    MergeSorT(a1, mid(a1, b2), target);
    MergeSorT(mid(a1, b2)->next, b2, target);
    Merger(a1, mid(a1, b2), mid(a1, b2)->next, b2, target);


}


}






vector<long> GenerateReverseSorted(long n)
{
    vector<long> nums;
    for (long k = n; k > 0; k--)
    {
        nums.push_back(k);
    }
    return nums;
}

void checker(vector<long> hey, long k)
{
    int l=0;
    int r=hey.size()-1;
    long sum=0;
    while(l!=r)
    {
        sum=hey[l]+hey[r];
       if(sum>k){
          r--;
       }
       else if(sum<k)
       {
           l++;
       }
       else if(sum==k){
        if(hey[r]==hey[r-1]){
            r--;
        }
        else{
        l++;
        }
       }


    }


}

int BinS(long arr[],int l, int r, long target)
{

    ///cout<<"query = "<<target<<endl;
    ///cout<<"l = "<<l<<"  r = "<<r<<endl;


    if(r>=1&& l<=r){
        int mid=(l+r )/2;
        if(arr[mid]==target){
                ///cout<<"helllo"<<endl;
            return mid;
        }
        else if(arr[mid]>target){
            return BinS(arr, 1, mid-1, target);
        }
        else{
            return BinS(arr, mid+1, r, target);
        }



    }
    else{
        return -69;
    }



}
vector< vector<long> >  Binary_dude(long arr[], long target, int sise)
{
///cout<<"This is the input array"<<endl;
 for(int i=0; i<sise; i++){cout<<arr[i]<<" ";}
 cout<<endl;


 vector< vector<long> > result;
 ///cout<<"sise = "<<sise<<endl;
    for(int i=sise-1; i>=1; i--){

        if(arr[i]<=target && target-arr[i]<=arr[i]){
                ///cout<<"i = "<<i<<endl;
                ///cout<<arr[i]<<endl;
                ///cout<<"target = "<<target<<endl;
            int heyy=BinS(arr,0, i-1, target-arr[i]);
            ///cout<<"heyy = "<<heyy<<endl;
            if(heyy!=-69)
            {
                ///finding repeated
                ///cout<<"heyy = "<<heyy<<endl;
                int counter=0;
                int temp=heyy;
                while(temp<=sise-1){
                    if(arr[temp]!=target-arr[i]){break;}
                    temp++;
                    ///cout<<"hello1"<<endl;
                    counter++;
                }
                int temp2=heyy-1;
                while(temp2>=0){
                    if(arr[temp2]!=target-arr[i]){break;}
                    temp2--;
                    ///cout<<"hello2"<<endl;
                    counter++;
                }
               /// cout<<"counter = "<<counter<<endl;
                int j=0;

                while(j!=counter){
               vector<long> temp1;

               temp1.push_back(arr[i]);
               temp1.push_back(arr[heyy]);
               result.push_back(temp1);
               j++;
                }
            }
        }


    }


return result;

}




int main()
{

List<long>* hey=new List<long>;
vector<long> nums  =GenerateRandom( 100 ,17 );



for(int i=nums.size()-1; i>=0; i--){
    hey->insertAtHead(nums[i]);
}
cout<<"displaying original vector"<<endl;
hey->display();

MergeSorT(hey->getHead(), hey->getTail(), 5);
cout<<"displaying original vector"<<endl;
hey->display();
///Disp2(hey->getHead(), hey->getTail());
ListItem<long>* temp=hey->getHead();
long barr[nums.size()];
for(int i=nums.size()-1; i>=0; i--)
{
    barr[i]=temp->value;
    temp=temp->next;
}


cout<<"input array is"<<endl;
for(int i=0; i<nums.size(); i++)
{
    cout<<barr[i]<<" ";
}
cout<<endl;

vector< vector<long> > result=Binary_dude(barr, 18, nums.size());
cout<<"displaying bhai jaan"<<endl;
for(int i=0; i<result.size(); i++){
    cout<<"pair "<<i<<" = "<<endl;
    cout<<(result[i])[0]<<" "<<(result[i])[1]<<endl;
}



}
