#include <fstream>
#include "sorts.cpp"

using namespace std;

int binarySearch(long* arr, int l, int r, int x)
{
   if (r >= l)
   {
        int mid = l + (r - l)/2;
 
        if (arr[mid] == x)  
            return mid;
 
        if (arr[mid] > x) 
            return binarySearch(arr, l, mid-1, x);

        return binarySearch(arr, mid+1, r, x);
   }
 
   return -1;
}




// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    vector<vector<long> > temp; 
    nums=QuickSortArray(nums); 
    long* arr=new long[nums.size()];

    for(int i=0; i<nums.size(); i++)
    {
        arr[i]=nums[i];
    }
    long store;

    for(int i=0; i<nums.size(); i++)
    {
        /*if(!temp.empty() && arr[i]== store )
        {

        }*/

        //else
        //{
            int x=binarySearch(arr,i+1,nums.size()-1,arr[i]+k);
            //cout<<"here"<<endl;
            if(x==-1)
            {
                //cout<<"match not found"<<endl;

            }

            else
            {
                if(temp.empty())
                {
                    store=arr[x];
                }
                //cout<<"should"<<endl;
                vector<long> v;
                v.push_back(arr[i]);
                v.push_back(arr[x]);
                temp.push_back(v);
                v[0]=arr[x];
                v[1]=arr[i];
                temp.push_back(v);
            }
        //}  
    }
    return temp;
}


int main()
{
    /*vector<long> v;
    v.push_back(10);
    v.push_back(10);
    v.push_back(5);
    v.push_back(5);
    v.push_back(2);
    v.push_back(2);
    v.push_back(2);
    //v.push_back(2);
    //v.push_back(2);
    smartSearch(v,0);
    for(int i=0; i<v.size(); i++)
    {
        cout<<(v[i])[0]<<" "<<(v[i])[1]<<endl;
    }*/    
   vector<long> nums;
    ifstream in("ran.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}