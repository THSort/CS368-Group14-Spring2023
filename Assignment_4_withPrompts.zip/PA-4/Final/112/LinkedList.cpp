#ifndef __LIST_CPP
#define __LIST_CPP

#include <cstdlib>
#include "LinkedList.h"
#include <iostream>
#include <vector>
using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
}

template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
	if (otherLinkedList.head != NULL)
  	{
   	 	ListItem<T> *temphead = otherLinkedList.head;
    	T tempdata = temphead->value;
    	ListItem<T> *newNode = new ListItem<T>;
   	 	newNode->value=tempdata;
    	head = newNode;
    	newNode->prev=NULL;


  while (temphead->next!=NULL)
    {
      temphead = temphead->next;
      insertAtTail(temphead->value);
    }

  }

  else
  {
    head = NULL;
  }

}

template <class T>
LinkedList<T>::~LinkedList()
{
  ListItem<T>* current = head;
  while(current != NULL ) 
  {
      ListItem<T>* next = current->next;
      delete current;
      current = next;
  }
  head = NULL;
}

template <class T>
void LinkedList<T>::insertAtHead(T item)
{
  ListItem<T> *temp = new ListItem<T>;
  temp->value=item;
  temp -> prev = NULL;
  if(head ==NULL)
  {
    head = temp;
    temp -> next = NULL;
  }
  else
  {
    temp->next = head;
    head -> prev = temp;
    head = temp;
  }


}

template <class T>
void LinkedList<T>::insertAtTail(T item)
{

  //cout<<"0 ";
	ListItem<T>* current=head;
  	ListItem<T> *temp = new ListItem<T>;
  	temp->value=item;

  	if(head==NULL)
  	{
      //cout<<"1 ";

    	head=temp;
    	temp->prev=NULL;
  	}

  	else
  	{

    	current=getTail();

    	current->next=temp;
    	temp->prev=current;
      //cout<<getTail()->prev->value<<getTail()->value<<"    ";
  	} 	

}

template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{
	ListItem<T> *current=searchFor(afterWhat);
	if(current != NULL)
	{
		ListItem<T>* newNode=new ListItem<T>;
		newNode->value= toInsert;
		newNode->next = current->next;
		newNode -> prev = current;
		current -> next = newNode;	
	}

	else
	{
		return;
	}
}

template <class T>
bool LinkedList<T>::isPalindrome()
{
  bool yes=true;
  int count =0;
  ListItem<T>*start=head;
  ListItem<T>*End=getTail();

  if(length()>1)
  {
     while(count < length()/2)
    {
      if(start->value != End->value)
      {
        yes=false;
        break;
      }
      start=start->next;
      End=End->prev;
      count++;
      
    }
    return yes;

  }

  else
  {
    cout<<"List too small"<<endl;
    return 0;
  }
 
}




template <class T>
void LinkedList<T>::insertSorted(T item)
{
 // if(searchFor(item)==NULL)
     if(head ==NULL || (head->value)>=item)
    {
      insertAtHead(item);
    }

    else if((getTail()->value)<item)
    {
      insertAtTail(item);
    }

    else
    {
      ListItem<T>* temp = head;

      while( temp->next != NULL && temp->value < item)
      {

        temp=temp->next;
      }

      ListItem<T>* newnode= new ListItem<T>;
      newnode->value=item;


      (temp->prev)->next= newnode;
      newnode->prev = (temp->prev);
      newnode->next=temp;
      temp->prev=newnode;
   }

  return;


  //else
  //{
    //cout<<"element repeating"<<endl;
    //return;
  //}

 

}

template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
	return head;

}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
  ListItem<T> *current=head;
  if(head==NULL)
  {
    return head;
  }

  else
  {
    current=head;
    while(current->next != NULL)
    {
      current=current->next;
    }

    return current;
  }	

}

template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
 if(head==NULL)
  {
    cout<<"LinkedList is empty"<<endl;
    return head;
  }

  else
  {
    bool found=false;
    ListItem<T> *current=head;
    while(current != NULL)
    {
      if(current->value == item)
      {
        found = true;
        break;
      }
        current=current->next;

    }

    if(found==true)
    {
      return current;
    }

    else
    {
    	//cout<<"element not found"<<endl;
      	return NULL;
    }
  }


}

template <class T>
void LinkedList<T>::deleteElement(T item)
{

     if(head == NULL)
     {
         cout<<"nothing to delete"<<endl;
         return;
     }

     else
     {
     	ListItem<T>* todelete = searchFor(item);

     	if(todelete != NULL)
     	{
     		if(todelete->next == NULL)
     		{
     			deleteTail();
     		}

     		else if(todelete->prev==NULL)
     		{
     			deleteHead();
     		}

     		else
     		{
     			(todelete->prev)->next = todelete -> next;
     			(todelete->next)->prev = todelete -> prev;
     			delete todelete;

     		}
     	}

     	else
     	{
     		return;
     	}
     }



}

template <class T>
void LinkedList<T>::deleteHead()
{
  if(head==NULL)
  {
    return;
  }

  else if(head->next==NULL)
  {
  	delete head;
  	head=NULL;
  }

  else
  {
    ListItem<T> *temp;
    temp=head->next;
    temp->prev=NULL;
    delete head;
    head=temp;

  }


}

template <class T>
void LinkedList<T>::deleteTail()
{
  if(head==NULL)
  {
    return;
  }
  else if(head->next==NULL)
  {
  	delete head;
  	head=NULL;
  	
  }
  else
  {
    ListItem<T> *current = getTail();
    (current->prev)->next=NULL;
    current->prev=NULL;
    delete current;

  }	

}

template <class T>
int LinkedList<T>::length()
{
	int count=0;
	ListItem<T>* current=head;
	while(current != NULL)
	{
		count++;
		current=current->next;
	}
	return count;

}

template <class T>
void LinkedList<T>::reverse()
{
	ListItem<T>* temp= getTail();
	head=temp;
	ListItem<T>* store;
	while(temp->prev != NULL)
	{
		store=temp->next;
		temp->next = temp-> prev;
		temp->prev = store;
		temp=temp->next;
	}

	temp->prev=temp->next;
	temp->next = NULL;	
}

template <class T>
void LinkedList<T>::parityArrangement()
{
  if(head==NULL)
  {
    cout<<"LinkedList is empty; parity arrangement can't be called"<<endl;
    return;
  }

  else if(head->next == NULL)
  {
    return;
  }

  else
  {
    ListItem<T>* temp=head;
    ListItem<T>* _end= getTail();

    while(temp!=_end)
    {
      if((temp->value)%2 != 0)
      {
        
        int current= temp->value;
        temp = temp->next;
        deleteElement(current);
        insertAtTail(current); 
      }

      else
      {
        temp=temp->next;
      }
    }

    int current= _end->value;
    deleteElement(current);
    insertAtTail(current);
  }

}

template <class T>
void LinkedList<T>::printlist()
{
  ListItem<T> *pointer = head;

  if(head == NULL)
  {
    cout<<"List is empty"<<endl;
  }
  else
  {
    while(pointer != NULL)
    {
      cout<<pointer->value<<endl;
      pointer=pointer->next;
    }
  }
}

template <class T>
void LinkedList<T>::print(ListItem<T>* p)
{
  ListItem<T> *pointer = p;

  if(pointer == NULL)
  {
    cout<<"List is empty"<<endl;
  }
  else
  {
    while(pointer != NULL)
    {
      cout<<pointer->value<<endl;
      pointer=pointer->next;
    }
  }
}






#endif
