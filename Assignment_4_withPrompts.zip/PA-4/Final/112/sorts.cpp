#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "LinkedList.cpp"
#include <ctime>




void print(ListItem<long>* p)
{
  ListItem<long> *pointer = p;

  if(pointer == NULL)
  {
    cout<<"List is empty"<<endl;
  }
  else
  {
    while(pointer != NULL)
    {
      cout<<pointer->value<<" ";
      pointer=pointer->next;
    }
    cout<<endl;
  }
}

void printArray(long* arr, long s)
{
	for(int i=0; i<s; i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;

}

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long* arr=new long[nums.size()];
	for(int i=0; i<nums.size();i++)
	{
		arr[i]=nums[i];
	}

	for(int i=1; i<nums.size(); i++)
	{
		if(arr[i]<arr[i-1])
		{
			int j=i;
			while(j>0 && arr[j]<arr[j-1])
			{
				long temp=arr[j-1];
				arr[j-1]=arr[j];
				arr[j]=temp;
				j--;
			}
		}
	}

	for(int i=0; i<nums.size();i++)
	{
		nums[i]=arr[i];

	}
	return nums;

}

//=====================================================================================

void MergeSplit(ListItem<long> *head, ListItem<long>* &firsthalf, ListItem<long>* &secondhalf)
{

    if (head == NULL || head->next == NULL)
    {
        firsthalf = head; 
        secondhalf = NULL; 
    }

    else
    {
        ListItem<long>* first = head;
        ListItem<long>*second = head->next;

        while(second != NULL)
        {
            second = second->next;
            if(second != NULL)
            {
                first = first->next;
                second = second->next;
            }
        }

        firsthalf = head;
        secondhalf = first->next;
        secondhalf->prev=NULL; 
        first->next = NULL;
        //print(front);
        //print(back);
    }
    return;
}

ListItem<long>* mergeLists(ListItem<long> *firsthalf, ListItem<long>  *secondhalf)
{

    ListItem <long> *mergedlist = NULL;

    if (firsthalf == NULL)
    {
        return secondhalf;
    }
    else
    {
    	if (secondhalf == NULL)
    	{
        	return firsthalf;
        }
    } 

    if (firsthalf->value <= secondhalf->value)
    {
        mergedlist = firsthalf;
        mergedlist->next = mergeLists(firsthalf->next, secondhalf);
    }
    else
    {
        mergedlist = secondhalf;
        mergedlist->next = mergeLists(firsthalf, secondhalf->next);
    }

    return mergedlist;
}

void mergeSort(ListItem<long>* &source)
{

    ListItem<long>* head = source;
    ListItem<long> *a =NULL;
    ListItem<long> *b = NULL;

    if(head == NULL || head->next == NULL){

        return;

    }

    MergeSplit(head, a, b); 

    mergeSort(a);
    mergeSort(b);

    source = mergeLists(a, b);
}



 vector<long> MergeSort(vector<long> nums)
{
	LinkedList<long> list;
	for(int i=0; i<nums.size(); i++)
	{
		list.insertAtHead(nums[i]);
	}
	//list.printlist();
	ListItem<long>* temp=list.getHead();

	mergeSort(temp);
	//print(temp);
	list.head=temp;
	for(int i=0; i<nums.size(); i++)
	{
		nums[i]=list.getHead()->value;
		list.deleteHead();
	}
	return nums;

}

//=====================================================================================

 int random(int min, int max) 
{
   static bool first = true;
   if ( first ) 
   {  
      srand(time(NULL)); 
      first = false;
   }
   return min + rand() % (max - min);
}

int partitionA(long* arr, int start, int end)
{
	int pivot=arr[end];
	int parIndex=start;
	for(int i=start; i<=end-1; i++)
	{
		if(arr[i]<=pivot)
		{
			long temp=arr[i];
			arr[i]=arr[parIndex];
			arr[parIndex]=temp;
			parIndex++;
		}
	}
	arr[end]=arr[parIndex];
	arr[parIndex]=pivot;
	return parIndex;	
}
/*
int partitionB(long* arr, int start, int end)
{
	int pivot=arr[start];
	arr[start]=arr[end];
	arr[end]=pivot;
	int parIndex=start;
	for(int i=start; i<=end-1; i++)
	{
		if(arr[i]<=pivot)
		{
			long temp=arr[i];
			arr[i]=arr[parIndex];
			arr[parIndex]=temp;
			parIndex++;
		}
	}
	arr[end]=arr[parIndex];
	arr[parIndex]=pivot;
	return parIndex;	
}
int pivotselection(long *arr, int start, int end)
{
	int* temp=new int[3];
	for(int i=0; i<2; i++)
	{
		temp[i]=random(start,end);
	}
	for(int i=0; i<2; i++)
	{
		for(int j=i; j<2; j++)
		{
			if(temp[i]<=temp[j])
			{
				int t=temp[i];
				temp[i]=temp[j];
				temp[j]=t;
			}
		}
	}
	return temp[1];
}

int partitionC(long* arr, int start, int end)
{
	int pivot;
	int ii;
	if(end-(start-1)>=3)
	{
		ii=pivotselection(arr,start,end);
	}
	else
	{
		ii=start;
	}
	pivot=arr[ii];
	arr[ii]=arr[end];
	arr[end]=pivot;
	int parIndex=start;
	for(int i=start; i<=end-1; i++)
	{
		if(arr[i]<=pivot)
		{
			long temp=arr[i];
			arr[i]=arr[parIndex];
			arr[parIndex]=temp;
			parIndex++;
		}
	}
	arr[end]=arr[parIndex];
	arr[parIndex]=pivot;
	return parIndex;	
}*/



void quickSortA(long* arr, int start,int end)
{
	if(start>=end)
	{
		return;			
	}

	else
	{
		int pivot=partitionA(arr, start, end);
		quickSortA(arr, start, pivot-1);
		quickSortA(arr,pivot+1, end);
	}

}

vector<long> QuickSortArray(vector<long> nums)
{
	long* arr=new long[nums.size()];
	for(int i=0; i<nums.size(); i++)
	{
		arr[i]=nums[i];
	}
	//printArray(arr,nums.size());
	//cout<<endl;
	quickSortA(arr, 0,nums.size()-1);
	//printArray(arr,nums.size());
	//cout<<endl;	
	
	for(int i=0; i<nums.size(); i++)
	{
		nums[i]=arr[i];
	}
	return nums;

}


//=====================================================================================
int length(ListItem<long> *t)
{
	int length=0;
	while (t != NULL)
	{
		t = t->next;
		length++;
	}
	return length;
}


ListItem<long>*  Merged(ListItem<long> *p,ListItem<long> *l, ListItem<long>  *r)
{
	ListItem <long>* MergedList=NULL;

	if(r==NULL)
	{
		ListItem <long> *leftTail = l;
	    while(leftTail->next!=NULL)
	    {
	    	leftTail=leftTail->next;
	    }
	    leftTail->next=p;
	    p->next=NULL;
	    p->prev=leftTail;
	    return l;
	}

	else if (l==NULL)
	{
		p->next=r;
		r->prev=p;
		p->prev=NULL;
		return p;
	}
    else
    {
        MergedList = l;
        MergedList->next = Merged(p,l->next, r);
        return MergedList;
        //cout<<"HOGAYA"<<endl;
    } 
}


void quickSortL(ListItem<long>* &head)
{
	ListItem<long>* biglist = head;
	ListItem<long>* firsthalf=NULL;
	ListItem<long> *secondhalf=NULL;
    ListItem <long>* pointerToPivot = head;
	
	if(biglist == NULL || biglist->next == NULL)
	{
		firsthalf = biglist;
        return;
    }
    else
    {
    	int r = random(0,(length(biglist)));
    	for(int i=0; i<r; i++)
    	{
    		pointerToPivot= pointerToPivot->next;
    	}

		
    	long pivot = pointerToPivot->value;
    	


    	ListItem<long>* temp = biglist;
    	
    	while(temp!=NULL)
    	{
    		if(temp!=pointerToPivot)
    		{
    			if(temp->value<pivot)
	    		{
	    			if(firsthalf==NULL)
	    			{
	    				firsthalf = temp;
	    				temp=temp->next;
	    				firsthalf->prev=NULL;
	    				firsthalf->next=NULL;

	    			}
	    			else
	    			{
	    				ListItem<long>* tempo = temp;
	   					temp=temp->next;
						firsthalf->prev = tempo;
						tempo->next=firsthalf;
						tempo->prev = NULL;
						firsthalf=tempo;
	    			}
	    		}
	    		else
	    		{
	    			if(secondhalf==NULL)
	    			{
	    				secondhalf = temp;
	   					temp=temp->next;
	   					secondhalf->prev=NULL;
	    				secondhalf->next=NULL;

	    			}
	    			else
	    			{
						ListItem<long>* tempo = temp;
	    				temp=temp->next;
						secondhalf->prev = tempo;
						tempo->next=secondhalf;
						tempo->prev = NULL;
						secondhalf = tempo;
	    			}

    			}
    		
    		}
    		else
			{
				temp=temp->next;
			}
		
    	}
    	

    }

	   	quickSortL(firsthalf);
    	quickSortL(secondhalf);
    	pointerToPivot->prev=NULL;


		head=Merged(pointerToPivot, firsthalf,secondhalf);


}


vector<long> QuickSortList(vector<long> nums)
{
	LinkedList<long> list;
	long size = nums.size();
	for(int i=0; i<size; i++)
	{
		list.insertAtHead(nums[i]);
	}

	ListItem<long>* temp=list.getHead(); 
	quickSortL(temp);

	for(int i=0; i<nums.size(); i++)
	{
		nums[i]=temp->value;
		temp=temp->next;
	}

	return nums;

}



//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap t(nums.size());
	for(int i=0; i<nums.size(); i++)
	{
		t.insertKey(nums[i]);

	}
	for(int i=0; i<nums.size();i++)
	{
		nums[i]=t.extractMin();

	}

	return nums;
}

/*int main()
{
	vector<long> v;
	v.push_back(-995190);
	v.push_back(-975632);
	v.push_back(-981297);
	v.push_back(-976612);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(10);
	// v.push_back(-7);
	// v.push_back(4);
	// v.push_back(11);
	// v.push_back(2);
	// v.push_back(2);	
	// v.push_back(10);
	// v.push_back(-7);
	// v.push_back(4);
	// v.push_back(11);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(2);
	// v.push_back(10);
	// v.push_back(-7);
	// v.push_back(4);
	// v.push_back(11);
	// v.push_back(2);
	// v.push_back(2);		
	QuickSortArray(v);

}*/

#endif