#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"



void MinHeap::Print()
{
	for(int i=0; i<heap_size; i++)
	{
		cout<<harr[i]<<endl;
	}
	return;
}
/*
MinHeap::MinHeap(int cap)
{
	cout<<"here"<<endl;
	int arr[7]={45,50,40,71,60,30,46};
	capacity=7;
	heap_size=6;
	for(int i=0; i<7; i++)
	{
		harr[i]=arr[i];
	}
	MinHeapify(0);
	Print();	
}*/

MinHeap::MinHeap(int cap)
{
	capacity=cap;
	harr=new int[capacity]; 
    heap_size=0;

}

void MinHeap::MinHeapify(int i)
{
	if(left(i)>heap_size) 
	{
		return;
	}

	else if(right(i)>heap_size)
	{

		if(harr[i]>harr[left(i)])
		{
			int temp=harr[i];
			harr[i]=harr[left(i)];
			harr[left(i)]=temp;
		}
		MinHeapify(left(i));
	}

	else 
	{
		if(harr[right(i)]<harr[i] && harr[right(i)]<=harr[left(i)])
		{
			int temp=harr[i];
			harr[i]=harr[right(i)];
			harr[right(i)]=temp;
			MinHeapify(right(i));			
		}

		else if(harr[left(i)]<harr[i] && harr[left(i)]<=harr[right(i)])
		{
			int temp=harr[i];
			harr[i]=harr[left(i)];
			harr[left(i)]=temp;
			MinHeapify(left(i));			
		}
	}
}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;

}
 
int MinHeap::left(int i)
{
	return 2*i+1;
}
 
int MinHeap::right(int i)
{
	return 2*i+2;
}
 
int MinHeap::extractMin()
{
	int temp=harr[0];
	deleteKey(0);
	return temp;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i]=new_val;
	int curindex=i;
	while(heap_size>1 && curindex>0)
	{
		if(harr[curindex]<harr[parent(curindex)])
		{
			harr[curindex]= harr[parent(curindex)];
			harr[parent(curindex)]=new_val;
			curindex=parent(curindex);
		}

		else
		{
			break;
		}
	}

	return;	

}
 
int MinHeap::getMin()
{
	return harr[0];

}
 
void MinHeap::deleteKey(int i)
{
	if(i<heap_size-1)
	{
		heap_size--;
		harr[i]=harr[heap_size];
		
		MinHeapify(i);

	}

	return;

}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size]=k;
	int curindex=heap_size;
	heap_size++;
	while(heap_size>1 && curindex>0)
	{
		if(harr[curindex]<harr[parent(curindex)])
		{
			harr[curindex]= harr[parent(curindex)];
			harr[parent(curindex)]=k;
			curindex=parent(curindex);
		}

		else
		{
			break;
		}
	}

	return;

}

int* MinHeap::getHeap()
{
	return harr;
}

/*
int main()
{
	MinHeap t(6);

	t.insertKey(10);
	t.insertKey(33);
	t.insertKey(9);
	t.insertKey(9);
	t.insertKey(9);
	t.insertKey(9);
	//t.insertKey(9);
	//t.insertKey(9);
	t.Print();
	cout<<endl;
	t.extractMin();
	t.extractMin();
	t.extractMin();
	t.extractMin();
	t.extractMin();
	t.extractMin();
	//t.extractMin();
	//t.extractMin();

}*/

#endif