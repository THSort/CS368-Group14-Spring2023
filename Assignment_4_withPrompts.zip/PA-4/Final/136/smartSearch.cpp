#include <fstream>
#include "sorts.cpp"
#include<iostream>
#include<time.h>
using namespace std;

int Bin_Search(int array1[],long max,long min,long k)
{
    int middle;

    if (min <= max)
    {
        middle=((max-min)/2)+min;

        if(array1[middle]==k)
        {
           return middle;
        }

        if (array1[middle]<k)
        {
             return Bin_Search(array1,max,(middle+1),k);
        }

        else
        {
             return Bin_Search(array1,(middle-1),min,k);
        }

    }

    return 0;
}

// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    // Write your code in this function
    
    int ret;
    int counter=0;
    int iterate=0;
    int size = nums.size();
    int *arr = new int[size];
   
    vector<long> sorted = HeapSort(nums);
    
    vector<vector<long> > return_vec;
    
    for(int i=0;i<size;i++)
    {
        arr[i]=sorted[i];
    }
   
    for(int i=0;i<size-1;i++)
    {
        if(arr[i]!=arr[i+1])
        {
            counter++;
        }
    }

    int *res = new int[counter];
    for(int i=0;i<size-1;i++)
    {
        if(arr[i]!=arr[i+1])
        {
            res[iterate]=arr[i];
            iterate++;
        }
    }
    
    iterate=0;
    for(int i=0;i<counter;i++)
    {
        ret = Bin_Search(res,counter,i+1,k-res[i]);
        if(ret!=0)
         {
             return_vec.push_back(vector<long>());
             return_vec[iterate].push_back(res[i]);
             return_vec[iterate].push_back(res[ret]);
             iterate++;
         }

    }

    for(int i=return_vec.size()-1;i>=0;i--)
    {
        
             return_vec.push_back(vector<long>());
             return_vec[iterate].push_back(return_vec[i][1]);
             return_vec[iterate].push_back(return_vec[i][0]);
             iterate++;
         

    }


    return return_vec;
}

int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;
    double start_time=clock();
    vector< vector<long> > result = smartSearch(nums, k);
    double stop_time=clock();
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    double time_taken = stop_time-start_time; 
    cout << "Time: " << time_taken/double(CLOCKS_PER_SEC) << " seconds" << endl;
    return 0;
}