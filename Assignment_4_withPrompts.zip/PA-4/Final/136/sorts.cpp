#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include <iostream>
#include "list.cpp"
#include "list.h"
using namespace std;
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
int len = nums.size();
int *arr = new int[len];

for(int i=0;i<len;i++)
{arr[i]=nums[i];}

int pre_index,next;

for(int i=1;i<len;i++){
    pre_index=i-1;
    next=arr[i];

    while(arr[pre_index]>next&&pre_index>=0){
        arr[pre_index+1]=arr[pre_index];
        pre_index=pre_index-1;
    }

    arr[pre_index+1]=next;
}

for(int i=0;i<len;i++)
{nums[i]=arr[i];}

return nums;
}

//=====================================================================================

ListItem<long>* combine(ListItem<long>*& tem,ListItem<long>*& temp)
{
    if(temp==NULL)
    {
        return tem;
    }

    else if(tem==NULL)
    {
        return temp;
    }

    else
    {
        ListItem<long> *temp_head;

        if(temp->value<tem->value)
        {
            temp_head=temp;
            temp_head->next=combine(tem,temp->next);
        }

        else
        {
            temp_head=tem;
            temp_head->next=combine(tem->next,temp);
        }

        return temp_head;
    }
}

void M_sort(ListItem<long> *&temp)
{
    if(temp->next==NULL)
    {
        return;
    }

    else
    {
        int size=0;
        ListItem<long> *tempo = temp;
        ListItem<long> *H1 = temp;
        ListItem<long> *H2;


        while(tempo!=NULL)
        {
            size++;
            tempo=tempo->next;
        }
        //cout<<size<<endl;

        for(int j=0;j<size/2;j++)
        {
            H2=H1;
            H1=H1->next;
        }
    /*while(tempo!=NULL)
        {
            size++;
            tempo=tempo->next;
        }
        //cout<<size<<endl;*/
    H2->next=NULL;
    H2=temp;

    M_sort(H2);
    M_sort(H1);

    temp=combine(H2,H1);

    }

}

vector<long> MergeSort(vector<long> nums)
{
    int size = nums.size();
    List<long> temp;
    for(int i=0;i<size;i++)
    {
        temp.insertAtHead(nums[i]);
    }
    ListItem<long>* h = temp.getHead();
    M_sort(h);
    for(int i=0;i<size;i++)
    {
        nums[i]=h->value;
        h=h->next;
    }
    return nums;
}

//=====================================================================================
int divide (int array[],int max,int min)
{
	int iterator = min-1;
	int temp1 = max-1;
	int root = array[max];
	
	for(int i=min;i<=temp1;i++){
		if(root>=array[i]){
			iterator++;
			int s = array[iterator];
			array[iterator]=array[i];
			array[i]=s;
		}
	}
	int s = array[iterator+1];
	array[iterator+1]=array[max];
	array[max]=s;
	int ret = iterator+1;
	return ret;
}

void Q_arr_sort(int array[],int max,int min)
{
	if(max>min){
		int index = divide(array,max,min);
		Q_arr_sort(array,index-1,min);
		Q_arr_sort(array,max,index+1);
	}
}
vector<long> QuickSortArray(vector<long> nums)
{
	int len = nums.size();
	int *arr = new int[len];

	for(int i=0;i<len;i++)
	{arr[i]=nums[i];}

	Q_arr_sort(arr,len-1,0);

	for(int i=0;i<len;i++)
	{nums[i]=arr[i];}

	return nums;
}

//=====================================================================================
void Q_sort(ListItem<long> *&temp)
{
    

    if(temp==NULL || temp->next==NULL)
    {
        return;
    }

    else if(temp && temp->next)
    {
	    ListItem<long>* pivot=temp;
	    temp=temp->next;
	    ListItem<long>* temporary = temp;
	    ListItem<long>* right=NULL;
	    ListItem<long>* left=NULL;
	    ListItem<long>** right_address=&right;
	    ListItem<long>** left_address=&left;

	    
	    int count=0;
	    while(temporary)
	    {
	    	count++;
	    	temporary=temporary->next;
	    }
	    //cout<<count<<endl;
		while(temp!=NULL){
            if(pivot->value<temp->value){
                *right_address = temp;

                right_address=&(*right_address)->next;
            }

            else if(pivot->value>=temp->value){
                *left_address = temp;
                
                left_address=&(*left_address)->next;
            }

            temp=temp->next;}
		*right_address = NULL;
        *left_address = NULL;
        temporary=temp;
        count=0;
         while(temporary)
	    {
	    	count++;
	    	temporary=temporary->next;
	    }
	    //cout<<count<<endl;
        Q_sort(left);
        Q_sort(right);
        while(*left_address)
        {
            left_address=&(*left_address)->next;
        }
		*left_address=pivot;
        pivot->next=right;
        temp=left;}
    


}

vector<long> QuickSortList(vector<long> nums)
{
    int size = nums.size();
    List<long> temp;
    for(int i=0;i<size;i++)
    {
        temp.insertAtHead(nums[i]);
    }
    ListItem<long>* h = temp.getHead();
    Q_sort(h);
    for(int i=0;i<size;i++)
    {
        nums[i]=h->value;
        h=h->next;
    }
    return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
    int size = nums.size();

    int *arr = new int[size];
    for(int i=0;i<size;i++)
    {
        arr[i]=nums[i];
    }
    MinHeap A(size);

    for(int i=0;i<size;i++)
    {
        A.insertKey(arr[i]);
    }

    A.MinHeapify(0);

    for(int i=0;i<size;i++)
    {

        arr[i]=A.getMin();
        A.deleteKey(0);


    }
    for(int i=0;i<size;i++)
    {
    	nums[i]=arr[i];
    }
    return nums;

}

#endif
