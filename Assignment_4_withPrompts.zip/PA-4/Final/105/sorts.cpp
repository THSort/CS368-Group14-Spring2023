#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//=====================================================================================
 void printarr(long *ans,int size)
{   
	for(int i=0; i<size; i++)
    {
    	cout<<ans[i]<<"  ";
    }
    cout<<endl;
}


void printList(ListItem<long>* pointer)
{
  if(pointer == NULL)
  {
    cout<<"NULL ";
  }
  else
  {
    while(pointer != NULL)
    {
      cout<<pointer->value<<" ";
      pointer=pointer->next;
    }
  }

    cout<<endl;
}

void printvect(vector<long> ans,int size)
{   
	for(int i=0; i<size; i++)
    {
    	cout<<ans[i]<<endl;
    }
    cout<<endl;
}


vector<long> InsertionSort(vector<long> nums)
{
	long *arr = new long[nums.size()];
	int size = nums.size();
	for(int i=0; i<size; i++)
	{
		arr[i]=nums.back();
		nums.pop_back();
	}


	for(int i=1; i<size; i++)
	{
		int j=i;
		do
		{
			if(arr[j-1]>arr[j])
			{
				int temp=arr[j-1];
				arr[j-1]=arr[j];
				arr[j]=temp;
			}
			else
			{
				break;
			}

			j--;
		}
		while(j>0);
	}

/*
//for my own reference
this is the code for not in place insertion sort (efficient)
	int filled_i=-1;
	int size = nums.size();

	long input = nums.back();
	nums.pop_back();

	if(filled_i==-1)
	{
		arr[0]=input;
		filled_i++;
	}

	
	do
	{
	
		input = nums.back();
		nums.pop_back();

		if(input>arr[filled_i])
		{
			filled_i++;
			arr[filled_i]=input;
		}
		else
		{
			int index =0;
			while(arr[index]<input)
			{
				index++;
			}

			int i=filled_i;
			while(index<=i)
			{
				arr[i+1]=arr[i];
				i--;
			}
			arr[index]= input;
			filled_i++;

		}
	}
	while(!(nums.empty()));
*/
	for(int i=0; i<size; i++)
	{
		nums.push_back(arr[i]);
	}

	return nums;
}

//=====================================================================================

int length(ListItem<long> *temp)
{
	int len=0;
	while (temp != NULL)
	{
		temp = temp->next;
		len++;
	}
	return len;
}
ListItem<long>* merge(ListItem<long> *part1, ListItem<long>  *part2)
{

    ListItem <long> *toret = NULL;

    if (part1 == NULL)
    {
        return part2;
    }
    else if (part2 == NULL)
    {
    	return part1;
    }
    else if (part2->value >= part1->value)
    {
        toret = part1;
        toret->next = merge(part1->next, part2);
    }
    else
    {
        toret = part2;
        toret->next = merge(part1, part2->next);
    }

    return toret;

}


void split(ListItem<long>* &head)
{
	ListItem<long>* tosplit = head;

	ListItem<long> *part1=NULL;
	ListItem<long> *part2=NULL;

	if(tosplit == NULL || tosplit->next == NULL)
	{
		part1 = tosplit;
		part2 = NULL;
        return;
    }
    else
    {
    	//list divide karni hai
    	ListItem<long>* temp = tosplit; 
    	for(int i=0; i<length(tosplit)/2; i++)
    	{
    		temp=temp->next;
    	}


    	part2 = temp;
    	part1 = tosplit;
    	temp->prev->next=NULL;
    	part2->prev = NULL;
	   	//printList(part1);
    	//printList(part2);

    }

    split(part1);
    split(part2);

    head = merge(part1,part2);



}



vector<long> MergeSort(vector<long> nums)
{
	List<long> list;
	int size = nums.size();
	for(int i=0; i<size; i++)
	{
		list.insertAtHead(nums.back());
		nums.pop_back();
	}

	// list.display_list();
	// cout<<endl;

	ListItem<long>* head = list.getHead(); 

	split(head);
	
	//cout<<endl;
	//printList(head);

	while(head!=NULL)
	{
		nums.push_back(head->value);
		head=head->next;
	}



	return nums;

}


int partition(long* &arr, int low, int high)
{
    srand(time(NULL));
    int rand1 = low + rand() % (high - low);
    int rand2= low + rand() % (high - low);
    int rand3 = low + rand() % (high - low);

    int random=low;

    // =low;
    // = low + rand() % (high - low);
    /*if(arr[rand1]>=arr[rand2] && arr[rand1]>arr[rand3])
    {
    	if(arr[rand2]>arr[rand3])
    	{
    		random = rand2;
    		//cout<<arr[rand1]<<" "<<arr[rand2]<<" "<<arr[rand3]<<endl;
    		//cout<<"   "<<random<<" "<<arr[random]<<endl;
    	}
    	else
    	{
    		random = rand3;
    		//cout<<arr[rand1]<<" "<<arr[rand3]<<" "<<arr[rand2]<<endl;
    		//cout<<"   "<<random<<" "<<arr[random]<<endl;
    	}

    }
    else if(arr[rand2]>arr[rand1] && arr[rand2]>=arr[rand3])
    {
    	if(arr[rand1]>arr[rand3])
    	{
    		random = rand1;
    		//cout<<arr[rand2]<<" "<<arr[rand1]<<" "<<arr[rand3]<<endl;
    		//cout<<"   "<<random<<" "<<arr[random]<<endl;
    	}
    	else
    	{
    		random = rand3;
    		//cout<<arr[rand2]<<" "<<arr[rand3]<<" "<<arr[rand1]<<endl;
    		//cout<<"   "<<random<<" "<<arr[random]<<endl;
    	}

    }
    else if(arr[rand3]>arr[rand2] && arr[rand3]>=arr[rand1])
    {
    	if(arr[rand2]>arr[rand1])
    	{
    		random = rand2;
    		//cout<<arr[rand3]<<" "<<arr[rand2]<<" "<<arr[rand1]<<endl;
    		//cout<<"   "<<random<<" "<<arr[random]<<endl;
    	}
    	else
    	{
    		random = rand1;
    		//cout<<arr[rand3]<<" "<<arr[rand1]<<" "<<arr[rand2]<<endl;
    		//cout<<"   "<<random<<" "<<arr[random]<<endl;
    	}

    }
    else
    {
    	//sab same hai
    	random = rand1;
    	//cout<<"herere"<<arr[rand1]<<" "<<arr[rand2]<<" "<<arr[rand3]<<endl;
    }*/


      
 
    long temp = arr[random];
    arr[random]=arr[low];
    arr[low]=temp;
 
    int pivot = arr[low];
    int i = low - 1, j = high + 1;
 
    while(true) 
    {
 
        do 
        {
            i++;
        }
        while (arr[i] < pivot);
 
        do
        {
            j--;
        }
        while (arr[j] > pivot);
 
        if (i >= j)
       	{
            return j;        
      	}
 
        temp = arr[j];
        arr[j]=arr[i];
        arr[i]=temp;
    }

}
 

void quickSort(long* &arr, int low, int high)
{
    if (low < high) {
        int pivot = partition(arr, low, high);

        quickSort(arr, low, pivot);
        quickSort(arr, pivot + 1, high);
    }
}



vector<long> QuickSortArray(vector<long> nums)
{
	int size = nums.size();
	long* arr = new long[size];


	for(int x=0; x<size; x++)
	{
		arr[x]=nums[x];
	}
	//printarr(arr,size);

	quickSort(arr, 0, size-1);


	for(int i=0; i<size; i++)
	{
		nums[i]=arr[i];
		//cout<<arr[x]<<endl;
	}

	return nums;
}


//=====================================================================================
ListItem<long>*  mergeQSLL(ListItem<long> *left, ListItem<long>  *right, ListItem<long> *pivot)
{
	ListItem <long>* toret=NULL;

	if (left==NULL)
	{
		//cout<<"here1"<<endl;
		pivot->next=right;
		right->prev=pivot;
		pivot->prev=NULL;
		return pivot;
	}
	else if(right==NULL)
	{
		//cout<<"here2"<<endl;
		ListItem <long> *leftTail = left;
	    while(leftTail->next!=NULL)
	    {
	    	leftTail=leftTail->next;
	    }
	    leftTail->next=pivot;
	    pivot->next=NULL;
	    pivot->prev=leftTail;
	    return left;
	}
    else
    {
		//cout<<"here3"<<endl;
        toret = left;
        toret->next = mergeQSLL(left->next, right, pivot);
        return toret;
    }


  
}
void splitQSLL(ListItem<long>* &head)
{
	ListItem<long>* tosplit = head;
	ListItem<long> *part1=NULL;
	ListItem<long> *part2=NULL;
    long pivot;
    ListItem <long>* toret=NULL;
    ListItem <long>* pivotPtr = head;
	
	if(tosplit == NULL || tosplit->next == NULL)
	{
		part1 = tosplit;
		//part2 = NULL;
        return;
    }
    else
    {
    	//list divide karni hai
    		srand(time(NULL));
    	int x = rand()%(length(tosplit));
    	for(int i=0; i<x; i++)
    	{
    		pivotPtr= pivotPtr->next;
    	}



		//pivotPtr = tosplit->next;
		
    	pivot = pivotPtr->value;
    	//cout<<"   "<<pivot<<endl;
    	


    	ListItem<long>* temp = tosplit;
    	
    	while(temp!=NULL)
    	{
    		//cout<<"    "<<temp->value<<endl;
    		if(temp!=pivotPtr)
    		{
    			if(temp->value<pivot)
	    		{
	    			//join to part1
	    			if(part1==NULL)
	    			{
	    				part1 = temp;

	    				temp=temp->next;
	    				part1->next=NULL;
	    				part1->prev=NULL;

	    			}
	    			else
	    			{
	    				ListItem<long>* t = temp;

	   					temp=temp->next;
						t->next=part1;
						part1->prev = t;
						t->prev = NULL;
						part1=t;
	    			}
	    		}
	    		else
	    		{
	    			//join to part2
	    			if(part2==NULL)
	    			{
	    				part2 = temp;

	   					temp=temp->next;
	    				part2->next=NULL;
	    				part2->prev=NULL;

	    			}
	    			else
	    			{
						ListItem<long>* t = temp;
	    				temp=temp->next;
						t->next=part2;
						part2->prev = t;
						t->prev = NULL;
						part2 = t;
	    			}

    			}
    		
    		}
    		else
			{
				temp=temp->next;
			}
		
    	}
    	

    }
    	// cout<<"pivot "<<tosplit->value<<endl;
    	// printList(part1);
    	// printList(part2);
	   	splitQSLL(part1);
    	splitQSLL(part2);
    	pivotPtr->prev=NULL;
    	//cout<<"   pivot "<<tosplit->value<<endl;
    	// printList(part1);
    	// printList(part2);


		head=mergeQSLL(part1,part2,pivotPtr);
	   	// printList(part1);
    //	printList(head);
    //head = merge(part1,part2);



}

vector<long> QuickSortList(vector<long> nums)
{
	List<long> list;
	int size = nums.size();
	for(int i=0; i<size; i++)
	{
		list.insertAtHead(nums.back());
		nums.pop_back();
	}

	// list.display_list();
	// cout<<endl;

	ListItem<long>* head = list.getHead(); 
	splitQSLL(head);

	while(head!=NULL)
	{
		nums.push_back(head->value);
		head=head->next;
	}

	return nums;

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{

	MinHeap heap(nums.size());
	int size = nums.size();
	for(int i=0; i<size; i++)
	{
		heap.insertKey(nums[i]);
	}
	//heap.printHeap();

	for(int i=0; i<size; i++)
	{
		nums[i] = heap.extractMin();
	}



	return nums;

}

#endif


// int main()
// {

//     vector<long> entries;
//     entries.push_back(3);
//     entries.push_back(4);
//     entries.push_back(0);
//     entries.push_back(5);
//     entries.push_back(8);
//     entries.push_back(7);
//     entries.push_back(9);
 
	
//     // for(int i=0; i<entries.size(); i++)
//     // {
//     // 	cout<<entries[i]<<endl;
//     // }

// 	vector<long> ans;
//     // cout<<endl;
//     ans = QuickSortArray(entries);
//     for(int i=0; i<ans.size(); i++)
//     {
//     	cout<<ans[i]<<endl;
//     }


// }