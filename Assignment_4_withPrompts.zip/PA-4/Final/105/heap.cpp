#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{

	capacity = cap;
	harr = new int[capacity]; 
    heap_size=-1;

	/*fo rtesting minheapify
	harr[0]=45;
	harr[1]=50;
	harr[2]=40;
	harr[3]=71;
	harr[4]=60;
	harr[5]=30;
	harr[6]=46;
	heap_size= 6;
	printHeap();
	//cout<<"here "<<capacity<<endl;
	MinHeapify(0);
	//cout<<"aftre "<<capacity<<endl;

	printHeap();

*/
}

void MinHeap::MinHeapify(int i)
{
	int min;
	if(left(i)>heap_size) 
	{
		//cout<<"is  a leaf node "<<endl;
		return;
	}
	else 
	{
		//cout<<"min "<<min<<" "<<harr[min]<<endl;
 		//cout<<"haep-size "<<heap_size<<endl;
 		//cout<<"left(node) "<<left(node)<<" = "<<harr[left(node)]<<endl;
 		//cout<<"right(node) "<<right(node)<<" = "<<harr[right(node)]<<endl;

		if(right(i)>heap_size)
		{
			min = left(i);
			if(harr[i]>harr[left(i)])
			{	
				int temp=harr[i];
				harr[i]=harr[min];
				harr[min]=temp;
			}
			
		}
		else if(harr[right(i)]<=harr[left(i)] && harr[right(i)]<harr[i])
		{
			min = right(i);
			int temp=harr[i];
			harr[i]=harr[min];
			harr[min]=temp;				
		}

		else if(harr[left(i)]<=harr[right(i)] && harr[left(i)]<harr[i])
		{
			min = left(i);	
			int temp=harr[i];
			harr[i]=harr[min];
			harr[min]=temp;
		}

 		//cout<<"now min "<<min<<" "<<harr [min]<<endl<<endl;
	    
		MinHeapify(min);
	}
}


int MinHeap::parent(int i)
{
	return (i-1)/2;

}
 
int MinHeap::left(int i)
{
	return 2*i + 1;
}
 
int MinHeap::right(int i)
{
	return 2*i + 2;
}
 
int MinHeap::extractMin()
{
	int min= harr[0];
	deleteKey(0);
	return min;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	//perculare up karna ho ga
	harr[i]=new_val;
	int p = parent(i);

	if(harr[p]>new_val)
	{
		while(p!=0)
		{
			if(harr[i]<harr[p])
			{
				int temp = harr[i];
				harr[i] = harr[p];
				harr[p] = temp;
			}
			i=p;
			p = parent(i);
			
		}
		//comparison with parent
		if(harr[i]<harr[p])
		{
			int temp = harr[i];
			harr[i] = harr[p];
			harr[p] = temp;
		}
	}
	else
	{
		//cout<<"fit hai"<<endl;
		return;

	}



}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
//perculate down
	if(i<heap_size)
	{
		int replace = harr[heap_size];
		heap_size--;
		harr[i]=replace;
		////cout<<"going into min hepify"<<endl;
		MinHeapify(i);
		////cout<<"came out of minheapify"<<endl;
	}



}
 
void MinHeap::insertKey(int k)
{		
	heap_size++;
	int i = heap_size;
	harr[i]=k;
	int p = parent(i);
	while(p!=0)
	{
		if(harr[i]<harr[p])
		{
			int temp = harr[i];
			harr[i] = harr[p];
			harr[p] = temp;
		}
		i=p;
		p = parent(i);
		
	}
	//comparison with parent
	if(harr[i]<harr[p])
	{
		int temp = harr[i];
		harr[i] = harr[p];
		harr[p] = temp;
	}
//	//cout<<"heap_size "<<heap_size<<endl;

}


void MinHeap::printHeap()
{
	for(int i=0; i<= heap_size; i++)
	{
		cout<<"index "<<i<<": "<<harr[i]<<endl;
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif



