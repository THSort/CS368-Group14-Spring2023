#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.

vector< vector<long> >  smartSearch(vector<long> nums, long k)
{   
    vector< vector<long> > final;

    nums=QuickSortArray(nums);
    //printvect(nums,nums.size());
    long* arr = new long[nums.size()];
    int size = nums.size();
    for(int i=0; i<size; i++)
    {
        arr[i]=nums[i];
    }

    
    int start=0;
    int end = size;

    int indexRef=0;
    
    int found=10000000;
    int j=0;
    int mid=0;
    while(found==10000000)
    {
        long forwhat=arr[j];
        long tofind=k-forwhat;
        //cout<<"to find "<<tofind<<endl;
        start=0;
        end=size;
        while(start<=end)
        {     

            mid=(end-start)/2 + start;
            //<<mid<<" "<<"s "<<start<<"end"<<end<<endl;
       //
            if(arr[mid]==tofind)
            {
                found = arr[mid];
               // cout<<found<<endl;
                vector<long> pair;
                pair.push_back(forwhat);
                pair.push_back(tofind);
                final.push_back(pair);
                //push in vector
                break;
            }
            if(arr[mid]<tofind)
            {
                start = mid+1;
               

            }
            else if(arr[mid]>tofind)
            {
                end = mid-1;
 
            }
        
        }
        j++;
    }

    int i=j;
    start=i;
    end = size;

    if(found!=10000000)
    {
        while(arr[i]<found)
        {
            long forwhat=arr[i];
            long tofind=k-forwhat;
               start=i+1;
                end = size;

            while(start<=end)
            {
                mid=(end-start)/2 + start;
                if(arr[mid]==tofind)
                {
                    //cout<<arr[mid]<<endl;
                    vector<long> pair;
                    pair.push_back(forwhat);
                    pair.push_back(arr[mid]);
                    final.push_back(pair);

                    //push in vector
                    break;
                }
                else if(arr[mid]<tofind)
                {
                    start = mid+1;
                   
                }
                else if(arr[mid]>tofind)
                {
                    end = mid-1;
                }
            
            }
            i++;


        }


        int finsize=final.size()-1;
        while(finsize>=0)
        {
            long tofind=final[finsize][0];
            long forwhat=final[finsize][1];
            vector<long> pair;
            pair.push_back(forwhat);
            pair.push_back(tofind);
            final.push_back(pair);
            finsize--;

        }
        return final;
    }
    else
    {
        cout<<"error there is no matching pair!!!!"<<endl;
    }



   
}


int main()
{
    //vector<long> nums;
    // ifstream in("random.txt");
    // long n;
    // while(in >> n)
    //     nums.push_back(n);
    // in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector<long> nums;
    nums.push_back(3);
    nums.push_back(2);
    nums.push_back(1);
    nums.push_back(5);
    nums.push_back(8);
    nums.push_back(7);
    nums.push_back(4);
    nums.push_back(34);
    nums.push_back(22);
    nums.push_back(11);
    nums.push_back(15);
    nums.push_back(18);
    nums.push_back(27);
    nums.push_back(14);
    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}
























/*int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    return 0;
}*/