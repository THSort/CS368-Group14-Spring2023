#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	heap_size = 0;
	harr = new int[cap];
	for (int i=0; i < capacity; i++)
	{
		harr[i]=0;
	}
}

int MinHeap::parent(int i)
{
	int j = (i-1)/2;
	return j;
}
 
int MinHeap::left(int i)
{
	int j = (2*i +1);
	return j;
}
 
int MinHeap::right(int i)
{
	int j = (2*i +2);
	return j;
}

void MinHeap::MinHeapify(int i)
{
	if (i> heap_size)
	{
		return;
	}

	int right1 = right(i);
	int left1 = left(i);
	int small = i;

	if (right1 < heap_size && harr[right1] < harr[small])
	{
		small = right1;
	}
	if (left1 < heap_size && harr[left1] < harr[i])
	{
		small = left1;
	}
	if (small != i)
	{
		long temp = harr[i];
		harr[i]=harr[small];
		harr[small]=temp;
	}
	MinHeapify(small);
}


int MinHeap::extractMin()
{
	int maxint = 2147483647;
	if (heap_size <= 0)
	{
		return maxint;
	}
	else 
	{
		maxint=harr[0];
		if (heap_size == 1)
		{
			heap_size--;
			return harr[0];
		}
		else
		{
			int y = harr[heap_size-1];
			harr[heap_size-1] = maxint;
			harr[0]=y; 
			heap_size--;
			MinHeapify(0);

			return maxint;
		}
	}
	
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	if (harr[parent(i)]<new_val)
	{
		return;
	}
	harr[i]=new_val;
	while(i >= 0 && harr[parent(i)] > harr[i])
	{
		int temp = harr[i];
		harr[i]=harr[parent(i)];
		harr[parent(i)]=temp;
		i = parent(i);
	}
}
 
int MinHeap::getMin()
{
	if (heap_size<0)
	{
		return -10;
	}
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if (i < heap_size && i >=0)
	{
		/*int minint= -2147483648;
		decreaseKey(i, minint);
		extractMin();*/
		int temp=harr[i];
		harr[i]=harr[heap_size-1];
		harr[heap_size-1]=temp;
		heap_size--;
		MinHeapify(i);
	}
	else 
	{
		return;
	}
}
 
void MinHeap::insertKey(int k)
{
	if (heap_size >= capacity)
	{
		return;
	}
	else 
	{
		harr[heap_size]=k;
		int i = heap_size;

		if (harr[parent(i)]<k)
		{
			heap_size++;
			return;
		}

		while (i != 0 && harr[parent(i)] > harr[i])
		{
			int temp = harr[i];
			harr[i]=harr[parent(i)];
			harr[parent(i)]=temp;
			i = parent(i);
		}
	heap_size++;
	}
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif

