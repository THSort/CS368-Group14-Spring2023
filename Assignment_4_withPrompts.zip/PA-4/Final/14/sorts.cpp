#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"

// //=====================================================================================
//I found and used the logic off the internet since the one i was using couldnt pass the tests 
vector<long> InsertionSort(vector<long> nums)
{
	int length = nums.size();
	long array1[length];

	for (int i=0; i<length; i++)
	{
		array1[i]=nums[i];
	}

	int i;
	int j;
	int key;

	for (int i=0; i<length; i++)
	{
		key = nums[i];
		j = i-1;

		while (j>=0 && array1[j] > key)
		{
			array1[j+1]=array1[j];
			j= j-1;
			//i++;
		}
		array1[j+1]=array1[j];
	}
}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int length = nums.size();
	MinHeap* heap = new MinHeap(length);
	for (int i=0; i<length; i++)
	{
		heap->insertKey(nums[i]);
	}
	for (int i=0; i<length; i++)
	{
		//heap->insertKey(nums[i]);
		nums[i]=heap->extractMin();
	}
	return nums;
}

#endif


