#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
    capacity = cap;
    heap_size = 0;
    harr = new int[cap];
}

void MinHeap::MinHeapify(int i)
{
    int left_index = left(i);
    int right_index = right(i);
    int parent_index;

    if(left_index < heap_size && harr[left_index] < harr[i])
    {
        parent_index = left_index;
    }
    else
    {
        parent_index = i;
    }

    if(right_index < heap_size && harr[right_index] < harr[parent_index])
    {
        parent_index = right_index;
    }

    if(parent_index != i)
    {
        int temp = harr[i];
        harr[i] = harr[parent_index];
        harr[parent_index] = temp;
        MinHeapify(parent_index);
    }
}

int MinHeap::parent(int i)
{
    int temp = (i-1)/2;
    return temp;
}

int MinHeap::left(int i)
{
    int temp = (2*i)+1;
    if(temp>heap_size)
    {
        return INT_MAX;
    }
    else
    {
        return temp;
    }
}

int MinHeap::right(int i)
{
    int temp = (2*i)+2;
    if(temp>heap_size)
    {
        return INT_MAX;
    }
    else
    {
        return temp;
    }
}

int MinHeap::extractMin()
{
    if(heap_size <= 0)
    {
        return 0;
    }
    if(heap_size == 1)
    {
        heap_size = heap_size - 1;
        return harr[0];
    }

    int min_value = harr[0];
    int last_element_index = heap_size-1;
    harr[0] = harr[last_element_index];
    heap_size = heap_size - 1;
    MinHeapify(0);

    return min_value;
}

void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i] = new_val;
    while(i!=0 && harr[parent(i)] > harr[i])
    {
        int temp = harr[i];
        harr[i] = harr[parent(i)];
        harr[parent(i)] = temp;
        i = parent(i);
    }
}

int MinHeap::getMin()
{
    return harr[0];
}

void MinHeap::deleteKey(int i)
{
    if(i>0 && i<heap_size)
    {
        decreaseKey(i, INT_MIN);
        extractMin();
    }
}

void MinHeap::insertKey(int k)
{
    if(heap_size == capacity)
    {
        return;
    }
    int i = heap_size;
    harr[i] = k;
    heap_size = heap_size + 1;

    while(i!=0 && harr[parent(i)] > harr[i])
    {
        int temp = harr[i];
        harr[i] = harr[parent(i)];
        harr[parent(i)] = temp;
        i = parent(i);
    }
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif
