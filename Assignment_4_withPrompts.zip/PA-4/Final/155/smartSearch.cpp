#include <fstream>
#include "sorts.cpp"
#include <random>
#include <time.h>

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{

    // Write your code in this function
    long *arr = new long[nums.size()];
    //long arr[nums.size()];
    vector< vector<long> > vector_of_pairs;
    vector<long> pairs;
    vector<long> sorted = QuickSortArray(nums);
    for(int i=0; i<sorted.size(); i++)
    {
        arr[i] = sorted[i];
    }
    int first = 0;
    int last = sorted.size()-1;

    while(first<last)
    {
        if(arr[first] + arr[last] == k)
        {
            //cout << arr[first] << " " << arr[last] << endl;
            pairs.push_back(arr[first]);
            pairs.push_back(arr[last]);
            vector_of_pairs.push_back(pairs);
            pairs.clear();
            first++;
            last--;
        }

        if(arr[first] + arr[last] > k)
        {
            last--;
        }

        if(arr[first] + arr[last] < k)
        {
            first++;
        }
    }

    return vector_of_pairs;
}


int main()
{
    clock_t start, end;
    double cpu_time_used;

    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

//    while(!in.eof())
//        nums.push_back(n);
//    in.close();


//    for(int i=0; i<10000; i++)
//    {
//        n = rand()%100;
//        nums.push_back(n);
//    }

//    nums.push_back(1);
//    nums.push_back(2);
//    nums.push_back(3);
//    nums.push_back(4);
//    nums.push_back(12);
//    nums.push_back(6);
//    nums.push_back(7);
//    nums.push_back(8);
//    nums.push_back(9);
//    nums.push_back(10);
//    nums.push_back(11);
//    nums.push_back(5);
//    nums.push_back(13);
//    nums.push_back(14);

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    start = clock();
    vector< vector<long> > result = smartSearch(nums, k);
    end = clock();
    cpu_time_used = ((double)(end-start)) / CLOCKS_PER_SEC;

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    if(result.size()==0 || nums.size()==0)
    {
        cout << "No pairs found" << endl;
    }
    cout << "Time taken: " << cpu_time_used << " seconds." << endl;
    return 0;
}
