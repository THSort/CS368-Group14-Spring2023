#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//#include "list.h"
#include <time.h>
#include <ctime>


//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
    long arr[nums.size()];
    for(int i=0; i<nums.size(); i++)
    {
        arr[i] = nums[i];
    }

    int value;
    int pos;
    for(int i=1; i<nums.size(); i++)
    {
        value = arr[i];
        pos=i-1;
        while(pos>=0 && arr[pos]>value)
        {
            arr[pos+1] = arr[pos];
            pos=pos-1;
        }
        arr[pos+1] = value;
    }

    for(int i=0; i<nums.size(); i++)
    {
        nums[i] = arr[i];
    }
    return nums;

}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{

}

//=====================================================================================
void QuicksortArr(long arr[], int starting, int ending)
{
    int starting_index = starting;
    int ending_index = ending;
    if(starting_index < ending_index)
    {
        long pivot = arr[ending_index];
        int i = starting_index-1;

        for(int j=starting_index; j<=ending_index-1; j++)
        {
            if(arr[j] <= pivot)
            {
                i++;
                long temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        long temp = arr[i+1];
        arr[i+1] = arr[ending_index];
        arr[ending_index] = temp;
        int pivot_index = i+1;

        QuicksortArr(arr, starting_index, pivot_index-1);
        QuicksortArr(arr, pivot_index+1, ending_index);
    }
}
vector<long> QuickSortArray(vector<long> nums)
{
    long* arr = new long[nums.size()];
    for(int i=0; i<nums.size(); i++)
    {
        arr[i] = nums[i];
    }

    int starting = 0;
    int ending = nums.size()-1;
    QuicksortArr(arr, starting, ending);

    for(int i=0; i<nums.size(); i++)
    {
        nums[i] = arr[i];
    }

    return nums;
}

//=====================================================================================
void QuicksortL(ListItem<long>* h, ListItem<long>* t)
{
    if(t!=NULL && h!=t && h!=t->next)
    {
        long pivot = t->value;
        ListItem<long>* i = h->prev;
        ListItem<long>* j;
        for(j=h->next; j!=t; j=j->next)
        {
            if(j->value <= pivot)
            {
                if(i==NULL){}
                else
                    i = i->next;
                long temp = i->value;
                i->value = j->value;
                j->value = temp;
            }
        }
        i = i->next;
        long temp = i->value;
        i->value = h->value;
        h->value = temp;

        ListItem<long>* p = i;
        QuicksortL(h, p->prev);
        QuicksortL(p->next, t);
    }
}

vector<long> QuickSortList(vector<long> nums)
{
    srand(time(NULL));

    //long counter=0;
    List<long> obj;

    for(int i=0; i<nums.size(); i++)
    {
        obj.insertSorted(nums[i]);
        //cout << counter << endl;
        //counter++;
    }

    ListItem<long>* head = obj.getHead();
    ListItem<long>* tail = obj.getTail();
    long random_pivot = head->value;
    ListItem<long>* temp = head;
    ListItem<long>* rand_pivot;

    for(int i=2; temp!=NULL; i++)
    {
        if(rand()%i == 0)
        {
            random_pivot = temp->value;
            rand_pivot = temp;
        }
        temp = temp->next;
    }

    //long temp2 = tail->value;
    //tail->value = rand_pivot->value;
    //rand_pivot->value = temp2;

    //QuicksortL(head, tail);

    for(int i=0; i<nums.size(); i++)
    {
        ListItem<long>* head = obj.getHead();
        nums[i] = head->value;
        obj.deleteHead();
    }
    return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
    MinHeap m(nums.size());
    long* arr = new long[nums.size()];
    for(int i=0; i<nums.size(); i++)
    {
        arr[i] = nums[i];
    }

    for(int i=0; i<nums.size(); i++)
    {
        m.insertKey(arr[i]);
    }

    m.MinHeapify(0);
    for(int i=0; i<nums.size(); i++)
    {
        arr[i] = m.extractMin();
    }

    for(int i=0; i<nums.size(); i++)
    {
        nums[i] = arr[i];
    }

    return nums;
}

#endif
