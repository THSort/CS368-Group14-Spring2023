#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int length = nums.size();
	long* sortArray = new long[length];
	for (int i = 0; i < length; ++i)
	{
		sortArray[i] = nums[i];
	}
	
	for (int i = 1; i < length; ++i)
	{
		long key = sortArray[i];
		int index = i;
		
		for (int j = i-1; j >= 0 ; --j)
		{
			if (key<sortArray[j])
			{
				sortArray[j+1] = sortArray[j];
				index = j;
				
			}
			else
			{
				
				break;
			}


			
	
		}
		
		
		sortArray[index] = key;
		
		

	}
	for (int i = 0; i < length; ++i)
	{
		nums[i] = sortArray[i];
	}

	return nums;

}

//=====================================================================================


List<long>* Merger(List<long>*list1,List<long>*list2)
{
	int Len_List1 = list1->length();
	int Len_List2 = list2->length();
	// int sizeofLoop = 0;
	
	List<long>* returnList = new List<long>();
	
	int counter = 0;
	ListItem<long>* iterator1 = list1->getHead();
	ListItem<long>* iterator2 = list2->getHead();
	
		
		while(Len_List1&&Len_List2)
		{
			if (iterator1->value < iterator2->value)
			{
				returnList->insertAtTail(iterator1->value);
				list1->deleteHead();
				iterator1 = list1->getHead();
				Len_List1--;
			}
			else
			{
				returnList->insertAtTail(iterator2->value);
				list2->deleteHead();
				iterator2 = list2->getHead();
				Len_List2--;
			}

		    counter++;

		}


		if (Len_List1)
		{
			// Len_List1 = list1->length();
			iterator1 = list1->getHead();
			for (int i = 0; i < Len_List1; ++i)
			{
				returnList->insertAtTail(iterator1->value);
				list1->deleteHead();
				iterator1 = list1->getHead();
			}
			
			return returnList;
		}

		if (Len_List2)
		{
			// Len_List2 = list2->length();
			iterator2 = list2->getHead();
			for (int i = 0; i < Len_List2; ++i)
			{
				returnList->insertAtTail(iterator2->value);
				list2->deleteHead();
				iterator2 = list2->getHead();
			}
			
			
			return returnList;		
		}



		return returnList;

}
List<long>* MergeSortHelper(List<long>*Divide)
 {
	// cout<<"display_list"<<endl;
	// Divide->display_list();
	if (Divide->length()==1)
	{
		return Divide;
		
	}
	int DivLen = Divide->length();


	ListItem<long>* headP = Divide->getHead();
	ListItem<long>* tailP = Divide->getTail();

	List<long>* half1 = new List<long>();
	List<long>* half2 = new List<long>();
	int counter = 0;
	while(counter!=DivLen/2)
	{
		half1->insertAtHead(headP->value);
		// half2->insertAtHead(tailP->value);

		headP= headP->next;
		// tailP = tailP->prev;
		
		counter++;

	}
	half2->setHead(headP);
	// if (DivLen%2==1)
	// {
	// 	half1->insertAtHead(headP->value); //oddcase
	// }
	



	List<long>* Divide1 = MergeSortHelper(half1);
	List<long>* Divide2 = MergeSortHelper(half2);

	return Merger(Divide1,Divide2);
	// return Merger(half1,half2);


}
vector<long> MergeSort(vector<long> nums)
{
	List<long>sortlist;

	for (int i = 0; i < nums.size(); ++i)
	{
		sortlist.insertAtHead(nums[i]);
		
	}
	
	List<long>* returnpoint = MergeSortHelper(&sortlist);
	// cout<<"END"<<endl;
	// returnpoint->display_list();

	for (int i = 0; i < nums.size(); ++i)
	{
		nums[i] = (returnpoint->getHead())->value;
		returnpoint->deleteHead();
		
	}

	return nums;

}



//=====================================================================================


int partition(long* sortArray, int start, int end)
{
	int pivot = sortArray[start];
	int i =  start;

	for (int j = start+1; j <= end; ++j)
	{
		if (sortArray[j]<pivot)
		{
			i++;
			swap(sortArray[j],sortArray[i]);
			// long temp = sortArray[j];
			// sortArray[j] = sortArray[i];
			// sortArray[i] = sortArray[j];

			
		}
	}

	swap(sortArray[start],sortArray[i]);
	// sortArray[start] = sortArray[i+1];
	// sortArray[i+1] = pivot;

	return i;



}
long* recursiveQuickSort(long* sortArray, int start, int end) //Helper for quickSort
{
	if(start<end)
	{
		int centre = partition(sortArray,start,end);
		recursiveQuickSort(sortArray,start,centre);
		recursiveQuickSort(sortArray,centre+1,end);
	}

	return sortArray;

}


vector<long> QuickSortArray(vector<long> nums)
{
	int length = nums.size();
	long* sortArray = new long[length];
	for (int i = 0; i < length; ++i)
	{
		sortArray[i] = nums[i];
	}

	long* returnArray = recursiveQuickSort(sortArray,0,length-1);		

	

	for (int i = 0; i < length; ++i)
	{
		nums[i] = returnArray[i];
	}

	return nums;

}

long* QuickSort(vector<long> nums)
{
	int length = nums.size();
	long* sortArray = new long[length];
	for (int i = 0; i < length; ++i)
	{
		sortArray[i] = nums[i];
	}

	long* returnArray = recursiveQuickSort(sortArray,0,length-1);		

	return returnArray;

	// for (int i = 0; i < length; ++i)
	// {
	// 	nums[i] = returnArray[i];
	// }

	// return nums;

}

//=====================================================================================




vector<long> QuickSortList(vector<long> nums)
{

	

	 return nums;

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap* heap = new MinHeap(nums.size());

	
	for (int i = 0; i < nums.size(); ++i)
	{
		heap->insertKey(nums[i]);
		// cout<<nums[i]<<endl;

		
	}


	
	for (int i = 0; i < nums.size(); ++i)
	{
		nums[i] = heap->extractMin();
	}
	return nums;

}

#endif