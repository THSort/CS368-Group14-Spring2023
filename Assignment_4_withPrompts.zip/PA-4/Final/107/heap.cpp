#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{ 
	capacity = cap;
	heap_size = 0;
	harr = new int [capacity];

}

void MinHeap::MinHeapify(int i)
{
		
	
	
	bool check = false;
	int index_small = i;
    if (left(i) < heap_size && harr[left(i)] < harr[i])
    {	
    	index_small = left(i);
    	check = true;
    }
    if (right(i) < heap_size && harr[right(i)] < harr[index_small])
    {
        index_small = right(i);
    	check = true;
    }
    if (check!=false)
    {
         
        int temp = harr[i];
		harr[i] = harr[index_small];
		harr[index_small] = temp;
        MinHeapify(index_small);
    }
}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return 2*i+1;

}
 
int MinHeap::right(int i)
{
	return 2*i+2;

}
 
int MinHeap::extractMin()
{

	if (heap_size<=0)
	{
		return INT_MIN;
	}
	long minvalue = harr[0];
	harr[0] =  harr[heap_size-1];
	

	heap_size--;

	MinHeapify(0);
	
	return minvalue;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;

	int temp;
	for (int j =i; j>0; j--)
	{
		if (harr[parent(j)]>harr[j])
			{
				temp = harr[parent(j)];
				harr[parent(j)] = harr[j];
				harr[j] = temp;
			}
			
		
	}

}
 
int MinHeap::getMin()
{

	if (heap_size==0)
	{
		return INT_MIN;
	}
	return harr[0];

}
 
void MinHeap::deleteKey(int i)
{
	

	if (i>=heap_size)
	{
		return;

	}

	harr[i] = harr[heap_size-1];

	heap_size--;
	
	MinHeapify(i);


	
	
}
 
void MinHeap::insertKey(int k)
{

	if (heap_size<capacity)
	{
		if (heap_size==0)
		{
			harr[heap_size] = k;
			heap_size++;
			return;
		}

		harr[heap_size] = k;
		heap_size++;
		int temp;
		

		for (int i = heap_size-1; i!=0 ; i= parent(i))
		{
			if (harr[parent(i)]>harr[i])
			{
				temp = harr[parent(i)];
				harr[parent(i)] = harr[i];
				harr[i] = temp;
			}
			

		}

	}
	else
	{
		cout<<"Overflow"<<endl;
		return;
	}

}

int* MinHeap::getHeap()
{
	return harr;
}

#endif