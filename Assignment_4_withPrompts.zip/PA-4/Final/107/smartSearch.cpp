#include <fstream>
#include "sorts.cpp"
#include<time.h>
using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
bool binarySearch(long* array, int start, int end, long key)
{

	// 
	if (start<= end)
	{
				
			int mid = start + (end-start)/2;

			if (array[mid] == key)
			{
				return true;
			}
				

				if(array[mid]<key)
				{
					return binarySearch(array,start,mid, key);
				}
				else
				{
					return binarySearch(array,mid+1, end,key);
				}
			

			return false;


	}
}

vector< vector<long> > smartSearch(vector<long> nums, long k)
{   

	long* array = QuickSort(nums);
	int size = nums.size();
	int start = 0;
	int end = size-1;
	vector< vector<long> > final;
	vector<long> temp;
	long tem;
	
	for (int i = 0; i < size; ++i)
	{
		if (array[i]>k)
		{
			
			break;
		}
		// cout<<array[i]<<endl;
		tem = k - array[i];
		// cout<<tem<<endl;
		if (binarySearch(array,start,end,tem) == true)
		{
			// cout<<"true"<<endl;
			// cout<<array[i]<<endl;
			// cout<<k-array[i]<<endl;
			temp.push_back(array[i]);
			temp.push_back(k-array[i]);

			final.push_back(temp);
			temp.pop_back();
			temp.pop_back();
		}
		
	}
	
	return final;
}


int main()
{
	
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;
    int start_s=clock();
    vector< vector<long> > result = smartSearch(nums, k);
    cout<<"result"<<endl;
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;


    int stop_s=clock();
    cout << "time (s): " << (stop_s-start_s)/double(CLOCKS_PER_SEC) << endl;

    return 0;
}