#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	heap_size = 0;
	capacity = cap;
	harr = new int[capacity];
}

void MinHeap::MinHeapify(int i)
{
    if(i>=heap_size)
        return;

    int minIndex = i;
    if (left(i) < heap_size && harr[left(i)] < harr[i])
        minIndex = left(i);
    if (right(i) < heap_size && harr[right(i)] < harr[minIndex])
        minIndex = right(i);

    if (minIndex != i)
    {
        swap(&harr[i], &harr[minIndex]);
        MinHeapify(minIndex);
    }

}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return 2*i + 1;
}
 
int MinHeap::right(int i)
{
	return 2*i + 2;
}
 
int MinHeap::extractMin()
{
    
    if (heap_size == 1)
    {
        heap_size--;
        return harr[0];
    }
 
    int min = harr[0];
    harr[0] = harr[heap_size-1];
    heap_size--;
    MinHeapify(0);
 
    return min;

}
 
void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i] = new_val;
    while (i != 0 && harr[parent(i)] > harr[i])
    {
       swap(&harr[i], &harr[parent(i)]);
       i = parent(i);
    }
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
    if(i>=heap_size)
        return;
	decreaseKey(i, -50000000);
    extractMin();
}
 
void MinHeap::insertKey(int k)
{
	if (heap_size == capacity)
    {
        return;
    }
 
    int i = heap_size;
    heap_size++;
    harr[i] = k;
 
    while (i != 0 && harr[parent(i)] > harr[i])
    {
       swap(&harr[i], &harr[parent(i)]);
       i = parent(i);
    }

}

int* MinHeap::getHeap()
{
	return harr;
}

void swap(int *x, int *y)
{
    int t = *x;
    *x = *y;
    *y = t;
}

#endif