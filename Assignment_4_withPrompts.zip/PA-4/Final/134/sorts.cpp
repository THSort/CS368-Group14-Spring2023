#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "list.cpp"
#include "heap.cpp"
#include "time.h"

ListItem<long>* getTail(ListItem<long>* here)
{
	while(here!=NULL && here->next !=NULL)
	{
		here=here->next;
	}
	return here;
}


void swap(long *x, long *y)
{
    long t = *x;
    *x = *y;
    *y = t;
}
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	int size = nums.size();
	int arr[size];

	for(int i=0; i<size; i++)
	{
		arr[i]= nums[i];
	}

	int i=1;
	int j=0;
	long here = arr[0];
	while(i < size)
	{
	   here = arr[i];
	   j = i-1;

	   while (arr[j] > here)
	   {
	   		if(j<0)
	   			break;
	       arr[j+1] = arr[j];
	       j--;
	   }
	   arr[j+1] = here;
	   i++;
	}

	vector<long> sortedNums;
	for(int i=0; i<size; i++)
	{
		sortedNums.push_back(arr[i]);
	}

	return sortedNums;
}

//=====================================================================================

template<class T>
int getLength(ListItem<T>* low)
{
	int length =0;
	for(ListItem<T>* here=low; here!=NULL; here=here->next)
	{
		length++;
	}
	return length;


}

template <class T>
ListItem<T> * Merge(ListItem<T>* left, ListItem<T>* right)
{
	if (left && right)
	{
		if (left->value > right->value)
		    right->next = Merge(left, right->next);
		else
		    left->next = Merge(left->next, right);
	}
	else
		return left ? left : right;
}
 
template <class T>
ListItem<T>* mergesort(ListItem<T>* head)
{

	if(head==NULL || head->next == NULL)
		return head;

 	int length = getLength(head);  
    int mid = length/2;

    ListItem<long>* midList=head;
    
    for(int i=0;i<mid;i++)
      midList=midList->next;

    midList->prev->next=NULL;

    ListItem<long>* left = mergesort(head);
    ListItem<long>* right = mergesort(midList);
    

    return Merge(left,right);
}

vector<long> MergeSort(vector<long> nums)
{
	List<long> numsList;
	int size = nums.size();
	for(int i=0; i<size; i++)
	{
		numsList.insertAtHead(nums[i]);
	}

	ListItem<long>* head = numsList.getHead();
	ListItem<long>* sortedHead = mergesort(head);

	vector<long> sortedNums;
	
	for(ListItem<long>* here=sortedHead; here!=NULL; here=here->next)
	{
		sortedNums.push_back(here->value);
	}

	return sortedNums;
}



//=====================================================================================

int partition (vector<long> &nums, int low, int high)
{
	int mid = (low + high)/2;
	swap(&nums[mid], &nums[high]);
    long* pivot = &nums[high];
    int i = low; 
    for (int j = low; j < high; j++)
    {
        if (nums[j] <= *pivot)
        {
            swap(&nums[i], &nums[j]);
            i++;
        }
    }
    swap(&nums[i], pivot);
    return i;
}

int quickSortArray(vector<long> &nums, int low, int high)
{
	if(low < high)
	{
		int pivotIndex = partition(nums, low, high);
		quickSortArray(nums, low, pivotIndex -1);
		quickSortArray(nums, pivotIndex+1, high);
	}
	return 0;
}

vector<long> QuickSortArray(vector<long> nums)
{
	int size = nums.size();
	quickSortArray(nums, 0, size-1);
	return nums;
}
//=====================================================================================
ListItem<long>* quickSortList(ListItem<long>* head)
{

	if(head==NULL || head->next == NULL)
		return head;


  int length = getLength(head);


    srand(time(NULL));
    int pivot = rand()%length;
    List<long> left;
    List<long> right;
    List<long> middle;


    ListItem<long>* pivotPtr = head;
    for(int i =0;i<pivot;i++)
    {
      pivotPtr = pivotPtr->next;
    }

    long pivotVal = pivotPtr ->value;

    for(ListItem<long>* here=head; here!=NULL; here=here->next)
    {
    	
      if(here->value < pivotVal)
        left.insertAtHead(here->value);
      else if(here ->value > pivotVal)
        right.insertAtHead(here->value);
      else
        middle.insertAtHead(here->value);
    }

    
    ListItem<long>* leftHead = quickSortList(left.getHead());
    
    ListItem<long>* rightHead = quickSortList(right.getHead());


    ListItem<long>* leftTail = getTail(leftHead);

    
    if(leftTail != NULL)
      leftTail->next = middle.getHead();
    else
    {
      leftHead = middle.getHead();
    }


    leftTail = getTail(middle.getHead());

    leftTail->next = rightHead;

    return leftHead;

}

vector<long> QuickSortList(vector<long> nums)
{
	List<long> numsList;
	int size = nums.size();
	for(int i=0; i<size; i++)
	{
		numsList.insertAtHead(nums[i]);
	}

	ListItem<long>* sortedHead = quickSortList(numsList.getHead());

	vector<long> sortedNums;
	
	for(ListItem<long>* here=sortedHead; here!=NULL; here=here->next)
	{
		sortedNums.push_back(here->value);
	}

	return sortedNums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int size = nums.size();
	MinHeap numsHeap(size);
	for(int i=0; i<size; i++)
	{
		numsHeap.insertKey(nums[i]);
	}


	vector<long> sortedNums;
	
	for(int i=0; i<size; i++)
	{
		sortedNums.push_back(numsHeap.extractMin());
	}

	return sortedNums;




}

void print(vector<long> nums)
{
	int size = nums.size();
	for(int i=0; i<size; i++){
		cout << nums[i] << endl;
	}
}



#endif