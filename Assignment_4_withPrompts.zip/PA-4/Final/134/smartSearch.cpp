#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.

long binarySearch(vector<long> vec, long val, int start, int end){
  if(start == end)
    return -1;

  int mid = (start+end)/2;

  if(val == vec[mid])
    return val;
  else if(val > vec[mid])
    return binarySearch(vec,val,mid+1,end);
  else 
    return binarySearch(vec,val,start,mid);

}
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   

    vector<long> sortedNums = QuickSortArray(nums);

  vector< vector<long> > pairs;

  for(int i =0; i<sortedNums.size(); i++)
  {
    long diff = k - sortedNums[i];
    if(diff<=0 || diff < sortedNums[i])
    {
      break;
    }


    long requiredValue = binarySearch(sortedNums,diff,i,nums.size());

    if(requiredValue != -1)
    {
      vector<long> pair1;
      pair1.push_back(sortedNums[i]);
      pair1.push_back(requiredValue);
      pairs.push_back(pair1);
      vector<long> pair2;
      pair2.push_back(requiredValue);
      pair2.push_back(sortedNums[i]);
      pairs.push_back(pair2);


    }
      
  }

  return pairs;

}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    // vector<long> nums;
    // nums.push_back(3);
    // nums.push_back(4);
    // nums.push_back(1);
    // nums.push_back(2);
    // nums.push_back(5);

    time_t start;
    time_t end;


    time(&start);
    vector< vector<long> > result = smartSearch(nums, k);
    time(&end);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout << "Elapsed time is: " << end-start << endl;

    return 0;
}