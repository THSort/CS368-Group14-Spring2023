#include <fstream>
#include "sorts.cpp"
#include <ctime>

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    nums = QuickSortArray(nums);
    int i = 0;
    int j = nums.size()-1;


    vector< vector<long> > all_pairs;

    while(i<j)
    {
        if((nums[i] + nums[j]) < k)
        {
            i++;
        }
        else if((nums[i] + nums[j]) > k)
        {
            j--;
        }
        else if((nums[i] + nums[j]) == k)
        {
            vector<long> onepair;
            onepair.push_back(nums[i]);
            onepair.push_back(nums[j]);
            all_pairs.push_back(onepair);
            onepair.clear();
            onepair.push_back(nums[j]);
            onepair.push_back(nums[i]);
            all_pairs.push_back(onepair);
            j--;
            i++;
        }
    }
    return all_pairs;
    // Write your code in this function

}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    clock_t begintime = clock();
    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;
    
    cout << "Time taken: " << double(clock()-begintime) / CLOCKS_PER_SEC << "s";


    return 0;
}