#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long n = nums.size();
	long* arr = new long[n];
	for(int x = 0; x < n; x++)
	{
		arr[x] = nums[x];
	}

	long i = 1;
	while(i < n)
	{
		long temp = arr[i];
		long j = i-1;
		while (j >= 0 && arr[j] > temp)
        {
           arr[j+1] = arr[j];
           j = j-1;
        }
       arr[j+1] = temp;
       i++;
	}
	vector<long> result;
	for(int x = 0; x < n; x++)
	{
		result.push_back(arr[x]);
	}	
	return result;
}

//=====================================================================================

void mergelist(List<long> *leftlist, List<long> *rightlist, List<long> *list)
	{
	    ListItem<long> *leftindex = leftlist->getHead();
	    ListItem<long> *rightindex = rightlist->getHead();

	    for(int i = 0; i < leftlist->length()+rightlist->length(); i++)
	    	{list->insertAtHead(0);}


	    ListItem<long> *listpointer = list->getHead();

	    while (leftindex != NULL && rightindex != NULL)
	    {
	        if (leftindex->value < rightindex->value)
	        {
	        	listpointer->value=leftindex->value;
	        	listpointer = listpointer -> next;
	        	leftindex = leftindex->next;
	        }
	        else
	        {
	        	listpointer->value=rightindex->value;
	        	listpointer = listpointer -> next;
	        	rightindex = rightindex->next;
	        }
	    }
	 
	    while (leftindex != NULL) // copies all remaining elements from left into the main list.
	    {
	        	listpointer->value=leftindex->value;
	        	listpointer = listpointer -> next;
	        	leftindex = leftindex->next;
	    }
	 
	    while (rightindex != NULL) // copies all remaining elements from right into the main list.
	    {
	        	listpointer->value=rightindex->value;
	        	listpointer = listpointer -> next;
	        	rightindex = rightindex->next;
	    }
	}

void breaklist(List<long>* list)
	{
		long n = list->length();

	    if (n <= 1)
	    {return;}
	   
	    	List<long>* leftlist = new List<long>();
	    	//ListItem<long> *start = list->getHead();

	    	for(int i = 0; i < n/2; i++)
	    	{
	    		leftlist->insertAtHead(list->getHead()->value);
	    		list->deleteHead();
	    	}

		    List<long>* rightlist = new List<long>();
	    	for(int i = n/2; i < n; i++)
	    	{
	    		rightlist->insertAtHead(list->getHead()->value);
	    		list->deleteHead();
	    	}

		    breaklist(leftlist);
		    breaklist(rightlist); 

	    	mergelist(leftlist,rightlist,list); // merge all the lists
 	    
	    
	}

vector<long> MergeSort(vector<long> nums)
{
	long n = nums.size();
	List<long>* list = new List<long>();

	for(int x = n-1; x >= 0; x--)
	{
		list->insertAtHead(nums[x]); // conversion from vector to list
	}
	breaklist(list); // start the merge sort
	
	 //list->display_list();

	ListItem<long> *start = list->getHead();
	
	vector<long> result;
	for(int x = 0; x < n; x++)
	{
		result.push_back(start->value); // put the list back into vector for returning
		start=start->next;
	}	
	return result;

}

//=====================================================================================

long findpivot(long arr[], int first, int last)
{
	return arr[last]; // last element as pivot

	//return arr[first];//first element as pivot

//median
	// long x = arr[rand()%size];
	// long y = arr[rand()%size];
	// long z = arr[rand()%size];

	// if((x < y) && (x < z))
	// 	return x;
	// if((y < x) && (y < z))
	// 	return y;
	// if((z < x) && (z < y))
	// 	return z;
}


void sortquick(long arr[], int leftbound, int rightbound) {
    long pivot = findpivot(arr, leftbound, rightbound);
 	int i = leftbound;
    int j = rightbound;
      
    while(i<=j)
    {
    	while(arr[i] < pivot)
    	{
    		i++;
    	}
       	while(arr[j] > pivot)
    	{
    		j--;
    	}
    	if(i<=j)
    	{
    		long temp = arr[i];
    		arr[i] = arr[j];
    		arr[j] = temp;
    		i++;
    		j--;
    	}
    }

    if (j > leftbound)
    	sortquick(arr,leftbound,j);
    if (i < rightbound)
    	sortquick(arr,i,rightbound);
}

vector<long> QuickSortArray(vector<long> nums)
{
	long n = nums.size();
	long* arr = new long[n];
	for(int x = 0; x < n; x++)
	{
		arr[x] = nums[x];
	}
	sortquick(arr,0,n-1);
	nums.clear();
	for(int x = 0; x < n; x++)
	{
		nums.push_back(arr[x]);
	}
	return nums;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	long n = nums.size();
	
	MinHeap mainheap(n);
	for(int i = 0; i < n; i++)
	{
		mainheap.insertKey(nums[i]);
	}

	nums.clear();

	for(int x = 0; x < n; x++)
	{
		nums.push_back(mainheap.extractMin());
	}
	return nums;
}

#endif