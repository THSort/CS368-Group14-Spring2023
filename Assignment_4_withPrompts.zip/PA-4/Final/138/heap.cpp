#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
    capacity = cap;
    harr = new int[capacity];
    heap_size=0;
}

void MinHeap::MinHeapify(int i)
{
    if(i< heap_size-1)
    {
        int smallest_index = i;
        int Left = left(i);
        int Right = right(i);
        if( Left< heap_size && harr[Left] < harr[smallest_index])
        {
            smallest_index = Left;
        }
        if( Right<heap_size && harr[Right]< harr[smallest_index])
        {
            smallest_index= Right;
        }
        if(smallest_index!=i)
        {
            swap(harr[i],harr[smallest_index]);
            MinHeapify(smallest_index);
        }
    }
}

int MinHeap::parent(int i)
{
    return (i-1)/2;
}

int MinHeap::left(int i)
{
    return ((2*i)+1);
}

int MinHeap::right(int i)
{
    return ((2*i)+2);
}

int MinHeap::extractMin()
{
    int minimum = harr[0];
    swap(harr[0],harr[heap_size-1]);
    heap_size--;
    MinHeapify(0);
    return minimum;
}

void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i]= new_val;
    for(int j=i;j>0;j=parent(j))
    {
        int parent_index= parent(j);
        if(harr[j] < harr[parent_index])
        {
            swap(harr[j], harr[parent_index]);
        }
        else
        {
            break;
        }
    }

}

int MinHeap::getMin()
{
    return harr[0];
}

void MinHeap::deleteKey(int i)
{
    if(i<=heap_size-1)
    {
        swap(harr[i],harr[heap_size-1]);
        heap_size--;
        MinHeapify(i);
    }
}

void MinHeap::insertKey(int k)
{
//    cout << "hello" << endl;
    harr[heap_size]= k;
    int current_index=heap_size;
    heap_size++;
    for(int i=current_index;i>0;i=parent(i))
    {
//        cout << "hello" << endl;
        int parent_index= parent(i);
        if(harr[i] < harr[parent_index])
        {
//            cout << "hello" << endl;
            swap(harr[i], harr[parent_index]);
        }
        else
        {
            break;
        }
    }
}

int* MinHeap::getHeap()
{
	return harr;
}
//int main()
//{
//    MinHeap Aimen(10);
//    Aimen.insertKey(9);
//}

#endif
