#include <fstream>
#include "sorts.cpp"

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    vector< vector <long> > vector_of_pairs;
    nums = MergeSort(nums);
    int n=nums.size();
    vector <long> SubVector;
    long temp=0;
    int i=0;
    while(temp<=k)
    {
        temp=nums[i];
        i++;
        SubVector.push_back(temp);
    }
    for(int j=0;j<SubVector.size();j++)
    {
        SubVector[j]=nums[j];
    }
    int start_index=0;
    int last_index=SubVector.size()-1;
    while(start_index<last_index)
    {
        long sum = SubVector[start_index]+SubVector[last_index];
        if(sum==k)
        {
            vector<long> Pair;
            Pair.push_back(nums[start_index]);
            Pair.push_back(nums[last_index]);
            vector_of_pairs.push_back(Pair);
            last_index--;

        }
        else if(sum>k)
        {
            last_index--;
        }
        else
        {
            start_index++;
        }
    }
    return vector_of_pairs;

    // Write your code in this function
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;
    int time=clock();
    vector< vector<long> > result = smartSearch(nums, k);
    cout << "time taken is " ;
    cout<<(float)time/CLOCKS_PER_SEC<<endl;
    cout << endl;
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;
    return 0;
}
