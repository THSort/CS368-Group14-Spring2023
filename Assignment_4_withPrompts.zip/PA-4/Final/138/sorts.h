#ifndef __SORTS_H
#define __SORTS_H

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "list.h"
#include "list.cpp"

using namespace std;

vector<long> InsertionSort(vector<long> nums);
void Divide(List<long> &numList);
void Merge(List<long> &Left, List<long> &Right, List<long> &nums);
vector<long> MergeSort(vector<long> nums);
void HelperSort(long ARRAY[],int start_index, int last_index);
int  Partition(long* ARRAY, int start_index, int last_index);
vector<long> QuickSortArray(vector<long> nums);
void QuickSortHelper(List<long> &numList, ListItem<long>*start_index, ListItem<long>*last_index);
ListItem<long> * PartitionList(List<long> &numList, ListItem<long>*start_index, ListItem<long>*last_index);
vector<long> QuickSortList(vector<long> nums);
vector<long> HeapSort(vector<long> nums);

#endif
