#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.h"
#include "list.cpp"
#include <cmath>

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
    int n=nums.size();
    long ARRAY[n];
    for(int i=0;i<n;i++)
    {
        ARRAY[i]=nums[i];
    }
    long temp = 0;
    int hole = 0;
    for(int i=1;i<n;i++)
    {
        temp= ARRAY[i];
        hole=i;
        while(hole>0 && ARRAY[hole-1]>temp)
        {
            ARRAY[hole]=ARRAY[hole-1];
            hole=hole-1;
        }
        ARRAY[hole]=temp;
    }
    for(int i=0;i<n;i++)
    {
        nums[i]=ARRAY[i];
    }
    return nums;

}
//=====================================================================================
void Merge(List<long> &Left, List<long> &Right, List<long> &numList)
{
    ListItem<long> *temp = Left.getHead();
    ListItem<long> *temp1 = Right.getHead();
    ListItem<long> *temp2 = numList.getHead();
    while(temp!=NULL && temp1!=NULL)
    {
        if(temp->value <= temp1->value)
        {
            temp2->value=temp->value;
            temp=temp->next;
            temp2=temp2->next;
        }
        else
        {
            temp2->value=temp1->value;
            temp1=temp1->next;
            temp2=temp2->next;
        }
    }
    while(temp!=NULL)
    {
        temp2->value=temp->value;
        temp2=temp2->next;
        temp=temp->next;
    }
    while(temp1!=NULL)
    {
        temp2->value=temp1->value;
        temp1=temp1->next;
        temp2=temp2->next;
    }
}

void Divide(List<long> &numList)
{
    int n= numList.length();
    if(n<2)
    {
        return;
    }
    else
    {
        int size_of_left_list= n/2;
        int size_of_right_list= n - size_of_left_list;
        List<long>LeftLinkedList;
        int i;
        ListItem<long> *temp = numList.getHead();
        for(i=0;i<size_of_left_list;i++)
        {
            LeftLinkedList.insertAtHead(temp->value);
            temp=temp->next;
        }
        List<long>RightLinkedList;
        int j;
        for(j=i;j<n;j++)
        {
            RightLinkedList.insertAtHead(temp->value);
            temp=temp->next;
        }
        Divide(LeftLinkedList);
        Divide(RightLinkedList);
        Merge(LeftLinkedList,RightLinkedList,numList);
    }


}
vector<long> MergeSort(vector<long> nums)
{
        int n=nums.size();
        List<long>numList;
        for(int i =0; i<n;i++)
        {
            numList.insertAtHead(nums[i]);

        }
        Divide(numList);
        ListItem<long> *temp = numList.getHead();
        for(int i=0;i<n;i++)
        {
            nums[i]=temp->value;
            temp=temp->next;
        }
        return nums;
}

//=====================================================================================
int Partition(long ARRAY[], int start_index, int last_index)
{
    long pivot = ARRAY[last_index];
    int pIndex = start_index;
    for(int i=start_index;i<last_index;i++)
    {
        if(ARRAY[i]<=pivot)
        {
            swap(ARRAY[i],ARRAY[pIndex]);
            pIndex++;
        }
    }
    swap(ARRAY[pIndex],ARRAY[last_index]);
    return pIndex;
}
void HelperSort(long ARRAY[],int start_index, int last_index)
{

    if(start_index<last_index)
    {
        int pIndex;
        pIndex= Partition(ARRAY,start_index,last_index);
        HelperSort(ARRAY,start_index,pIndex-1);
        HelperSort(ARRAY,pIndex+1, last_index);
    }
    else
    {
        return;
    }
}
vector<long> QuickSortArray(vector<long> nums)
{
    int n=nums.size();
    long *ARRAY=new long[n];
    for(int i=0;i<n;i++)
    {
        ARRAY[i]=nums[i];
    }
    int start = 0;
    int Last = n-1;
    HelperSort(ARRAY,start,Last);
    for(int i=0;i<n;i++)
    {
        nums[i]=ARRAY[i];
    }
    return nums;
}

//=====================================================================================
ListItem<long> * PartitionList(List<long> &numList, ListItem<long>*start_index, ListItem<long>*last_index)
{
    ListItem<long>* randomNo=start_index;
    srand(time(0));
    ListItem<long>*pIndextemp=start_index;
    for (int i=2; pIndextemp!=last_index; i++)
    {
        if (rand()%i==0)
        {
            randomNo=pIndextemp;
        }
            pIndextemp=pIndextemp->next;
    }
    swap(randomNo->value,last_index->value);
    long pivot = last_index->value;
    ListItem<long> *pIndex=start_index;
    for(ListItem<long>* i=start_index;i!=last_index;i=i->next)
    {
        if(i->value <= pivot)
        {
            swap(i->value,pIndex->value);
            pIndex=pIndex->next;
        }
    }
    swap(pIndex->value,last_index->value);
    return pIndex;
}
void QuickSortHelper(List<long> &numList, ListItem<long>*start_index, ListItem<long>*last_index)
{
    if (!last_index || start_index==last_index || start_index==last_index->next)
    {

    }
    else
    {
        ListItem<long> *pIndex;
        pIndex=PartitionList(numList,start_index,last_index);
        QuickSortHelper(numList,start_index,pIndex->prev);
        QuickSortHelper(numList,pIndex->next,last_index);
    }
}
vector<long> QuickSortList(vector<long> nums)
{
        int n=nums.size();
        List<long>numList;
        for(int i =0; i<n;i++)
        {
            numList.insertAtHead(nums[i]);

        }
        ListItem<long> *start_index = numList.getHead();
        ListItem<long> *last_index =  numList.getTail();
        QuickSortHelper(numList,start_index,last_index);
        ListItem<long> *temp = numList.getHead();
        for(int i=0;i<n;i++)
        {
            nums[i]=temp->value;
            temp=temp->next;
        }
        return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
    MinHeap Maneesha(nums.size());
    int i=0;
    while(i<nums.size())
    {
        Maneesha.insertKey(nums[i]);
        i++;
    }
    int j=0;
    while(j<nums.size())
    {
        nums[j]=Maneesha.extractMin();
        j++;
    }
    return nums;
}
//int main()
//{
//  vector<long> nums;
//  nums.push_back(3);
//  nums.push_back(7);
//  nums.push_back(4);
//  nums.push_back(2);
//  nums.push_back(9);
//  nums.push_back(-1);
//  QuickSortArray(nums);
//}
#endif
