#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
#include <cstdlib>
#include <time.h>

void mergesorting(ListItem<long>* list, int size)
{
    if(size==1)
    {
        return;
    }
    else
    {
        int mid = size/2;
        int size2 = size-mid;

        ListItem<long> *temp=list;
        List<long> *list1 = new List<long>;
        for(int i=0; i<mid; i++)
        {
            list1->insertAtTail(temp->value);
            temp=temp->next;
        }

        List<long> *list2 = new List<long>;
        for(int i=mid; i<size; i++)
        {
            list2->insertAtTail(temp->value);
            temp=temp->next;
        }

        mergesorting(list1->getHead(), mid);
        mergesorting(list2->getHead(), size2);

        ListItem<long> *x=list1->getHead();
        ListItem<long> *y=list2->getHead();
        ListItem<long> *z=list;

        while(x!=NULL && y!=NULL)
        {
            if((x->value)<(y->value))
            {
                z->value=x->value;
                z=z->next;
                x=x->next;
            }
            else
            {
                z->value=y->value;
                z=z->next;
                y=y->next;
            }
        }

        if (y!=NULL)
        {
            while(y!=NULL)
            {
                z->value=y->value;
                z=z->next;
                y=y->next;
            }
        }

        else if (x!=NULL)
        {
            while(x!=NULL)
            {
                z->value=x->value;
                z=z->next;
                x=x->next;
            }
        }
    }
}
//========================================================================================
void quicksort_array(long *arr, int startingIndex, int endingIndex)
{
    if(startingIndex>=endingIndex)
    {
        return;
    }

    else
    {
        /*vector<long> x;
        x.push_back(arr[startingIndex]);
        x.push_back(arr[endingIndex]);
        x.push_back(arr[endingIndex/2]);
        for(int i=0; i<3; i++)
        {
            for(int j=i+1; j<3; j++)
            {
                if(x[i]>x[j])
                {
                    int temp=x[i];
                    x[i]=x[j];
                    x[j]=temp;
                }
            }
        }

        int pivot=x[1];
        int pivot_index;
        if(pivot==arr[startingIndex])
        {
            pivot_index=startingIndex;
        }
        else if(pivot==arr[endingIndex])
        {
            pivot_index=endingIndex;
        }
        else if(pivot==arr[endingIndex/2])
        {
            pivot_index=endingIndex/2;
        }*/

        int pivot_index=startingIndex;
        int pivot=arr[pivot_index];
        int low=startingIndex;
        int i=low-1;
        int j=endingIndex;

        int temp=arr[j];
        arr[j]=pivot;
        arr[pivot_index]=temp;

        while(i!=j)
        {
            while(i<j)
            {
                i++;
                if(arr[i]>=pivot)
                    break;
            }

            while(j>i)
            {
                j--;
                if(arr[j]<=pivot)
                    break;
            }

            if(i!=j)
            {
                int temp1=arr[j];
                arr[j]=arr[i];
                arr[i]=temp1;
                i--;
            }

        }

        if(i<=j)
        {
            int temp=arr[i];
            arr[i]=arr[endingIndex];
            arr[endingIndex]=temp;
        }

        quicksort_array(arr, startingIndex, i-1);
        quicksort_array(arr, i+1, endingIndex);
    }
}
//=====================================================================================
void quicksort_LL(ListItem<long>* listhead, ListItem<long>* listtail, int startingIndex, int endingIndex)
{
    if(startingIndex>=endingIndex)
    {
        return;
    }
    else
    {
        srand(time(NULL));
        int random_index=rand()%(endingIndex-startingIndex);

        ListItem<long> *a=listhead;
        for(int i=0; i<random_index; i++)
        {
            a=a->next;
        }
        int pivot=a->value;

        int low=startingIndex;
        int i=low-1;
        int j=endingIndex;

        int temp=listtail->value;
        listtail->value=pivot;
        a->value=temp;

        ListItem<long> *temp1=listhead;
        ListItem<long> *temp2=listtail;

        while(i!=j)
        {
            while(i<j)
            {
                i++;
                if(temp1->value>=pivot)
                    break;
                temp1=temp1->next;
            }

            while(j>i)
            {
                j--;
                temp2=temp2->prev;
                if(temp2->value<=pivot)
                    break;
            }

            if(i!=j)
            {
                int t=temp2->value;
                temp2->value=temp1->value;
                temp1->value=t;
                i--;
            }
        }

        if(i<=j)
        {
            int t=temp1->value;
            temp1->value=listtail->value;
            listtail->value=t;
        }

        ListItem<long> *mylist=listhead;

        quicksort_LL(listhead, temp1->prev, startingIndex, i-1);
        quicksort_LL(temp1->next, listtail, i+1, endingIndex);
    }
}
//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
    int s = nums.size();
    long myarray[s];
    for(int i=0; i<s; i++)
    {
        myarray[i]=nums[i];
    }

    for(int i=1; i<s; i++)
    {
        int y=i;
        for(int j=i-1; j>=0; j--)
        {
            if(myarray[j]>myarray[y])
            {
                int temp = myarray[y];
                myarray[y]=myarray[j];
                myarray[j]=temp;
                y--;
            }
            else
                break;
        }
    }

    vector<long> myvector;
    for(int i=0; i<s; i++)
    {
        myvector.push_back(myarray[i]);
    }
    return myvector;
}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
    List<long> *mylist = new List<long>;
    for(int i=nums.size()-1; i>=0; i--)
    {
        mylist->insertAtHead(nums[i]);
    }

    mergesorting(mylist->getHead(), nums.size());

    ListItem<long> *h=mylist->getHead();
    vector<long> myvector;

    while(h!=NULL)
    {
        myvector.push_back(h->value);
        h=h->next;
    }
    return myvector;
}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{
    int s = nums.size();
    long *myarray=new long[s];
    for(int i=0; i<s; i++)
    {
        myarray[i]=nums[i];
    }
    quicksort_array(myarray, 0, s-1);

    vector<long> myvector;
    for(int i=0; i<s; i++)
    {
        myvector.push_back(myarray[i]);
    }
    return myvector;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
    List<long> *mylist = new List<long>;
    for(int i=nums.size()-1; i>=0; i--)
    {
        mylist->insertAtHead(nums[i]);
    }
    int x=mylist->length();
    quicksort_LL(mylist->getHead(), mylist->getTail(), 0, x-1);

    ListItem<long> *h=mylist->getHead();
    vector<long> myvector;

    while(h!=NULL)
    {
        myvector.push_back(h->value);
        h=h->next;
    }
    return myvector;

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
    int s = nums.size();
    MinHeap myheap(s);

    for(int i=0; i<s; i++)
    {
        myheap.insertKey(nums[i]);
    }

    vector<long> myvector;
    for(int i=0; i<s; i++)
    {
        myvector.push_back(myheap.extractMin());
    }
    return myvector;
}

#endif
