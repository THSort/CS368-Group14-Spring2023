#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
    harr = new int[cap];
    capacity = cap;
    heap_size = 0;
}

void MinHeap::MinHeapify(int i)
{
    int leftchild_index = left(i);
    int rightchild_index = right(i);
    int smallerchild;

    if(leftchild_index<heap_size)
    {
        if(rightchild_index<heap_size)
        {
            if(harr[leftchild_index]<harr[rightchild_index])
            {
                smallerchild=leftchild_index;
            }
            else
            {
                smallerchild=rightchild_index;
            }
        }
        else
        {
            smallerchild=leftchild_index;
        }

        if(harr[smallerchild]<harr[i])
        {
            int temp = harr[i];
            harr[i]=harr[smallerchild];
            harr[smallerchild]=temp;
            MinHeapify(smallerchild);
        }
    }
}

int MinHeap::parent(int i)
{
    int parent_index = (i-1)/2;
    return parent_index;
}

int MinHeap::left(int i)
{
    int leftchild = 2*i+1;
    return leftchild;
}

int MinHeap::right(int i)
{
    int rightchild = 2*i+2;
    return rightchild;
}

int MinHeap::extractMin()
{
    int min=harr[0];
    harr[0]=harr[heap_size-1];
    heap_size--;
    MinHeapify(0);
    return min;
}

void MinHeap::decreaseKey(int i, int new_val)
{
    harr[i]=new_val;
    MinHeapify(i);
    while(i!=0)
    {
        if(harr[i]<harr[parent(i)])
        {
            int temp = harr[i];
            harr[i]=harr[parent(i)];
            harr[parent(i)]=temp;
        }
        i=parent(i);
    }
}

int MinHeap::getMin()
{
    return harr[0];
}

void MinHeap::deleteKey(int i)
{
    if (i<heap_size)
    {
        harr[i]=harr[heap_size-1];
        heap_size--;

        MinHeapify(i);
        while(i!=0)
        {
            if(harr[i]<harr[parent(i)])
            {
                int temp = harr[i];
                harr[i]=harr[parent(i)];
                harr[parent(i)]=temp;
            }
            i=parent(i);
        }
    }
}

void MinHeap::insertKey(int k)
{
    if(heap_size < capacity)
    {
        int i = heap_size;
        harr[i]=k;
        heap_size++;

        while(i!=0)
        {
            if(harr[i]<harr[parent(i)])
            {
                int temp = harr[i];
                harr[i]=harr[parent(i)];
                harr[parent(i)]=temp;
            }
            i=parent(i);
        }
    }
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif
