#include <fstream>
#include "sorts.cpp"
#include <time.h>

using namespace std;

long binary_s(vector<long> arr, int starting_index, int ending_index, int value)
{
    if(ending_index<starting_index)
    {
        return 0;
    }

    int i = starting_index + (ending_index-starting_index)/2;
    if(arr[i]==value)
    {
        return arr[i];
    }
    else
    {
        if(arr[i]>value)
        {
            return binary_s(arr, starting_index, i-1, value);
        }
        else
        {
            return binary_s(arr, i+1, ending_index, value);
        }
    }
}

// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{
    nums=HeapSort(nums);

    vector<vector<long>> myvector;
    for(int i=0; i<k; i++)
    {
        long x=k-nums[i];
        long result=binary_s(nums, 0, nums.size()-1, x);
        vector<long> y;

        if(x==0 && result==0 && result!=nums[i])
        {
            y.push_back(nums[i]);
            y.push_back(result);
            myvector.push_back(y);
        }

        else if(result!=0 && result!=nums[i])
        {
            y.push_back(nums[i]);
            y.push_back(result);
            myvector.push_back(y);
        }
    }
    return myvector;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    const clock_t begin_time = clock();
    vector< vector<long> > result = smartSearch(nums, k);

    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;

    cout << float( clock () - begin_time ) /  CLOCKS_PER_SEC << endl;

    return 0;
}
