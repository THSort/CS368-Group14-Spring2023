#include <fstream>
#include "sorts.cpp"

using namespace std;
void smartSearch(vector<long> nums, long k)
{  
    vector< vector<long> > result;   
    nums = HeapSort(nums);
    int l = 0;
    int r = nums.size() - 1; 
    while (l < r)
    {
        if(nums[l] + nums[r] == k)
            {
            	cout<<nums[l]<<","<<nums[r]<<endl;
            	l++;
            	r++;
            }

        else if(nums[l] + nums[r] < k)
            l++;
        else 
            r--;
    } 
    cout<<endl;
    cout<<"All results above"<<endl;
    return ;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;
    cout<<endl;
    // k = 7;

    smartSearch(nums, k);
    return 0;
}