#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	
    int arr_size = nums.size();
    long sort_array[arr_size];
    // for (int i = 0; i < arr_size; ++i)
    // {
    // 	sort_array[i] = nums[i];
    // }
   
    copy(nums.begin(), nums.end(), sort_array);

    // long *sort_array = &nums[0];
    // long *sort_array = v.data();

	int i,j;
	long k;
	for (int i = 1; i < arr_size; ++i)
	{
		k = sort_array[i];
		j = i-1;

		while(j>=0 && sort_array[j]>k){
			sort_array[j+1] = sort_array[j];
			j = j-1;
		}
		sort_array[j+1] = k;
	}

    // for (int i = 0; i < arr_size; ++i)
    // {
    // 	nums[i] = sort_array[i];
    // }
    
    std::vector<long> ret(sort_array, sort_array + sizeof sort_array/ sizeof sort_array[0]);
	return  ret;
}

//=====================================================================================
ListItem<long>* MergeList(ListItem<long>* a, ListItem<long>* b);
ListItem<long>* recursive_merge(ListItem<long>* a);


vector<long> MergeSort(vector<long> nums)
{
	List<long>* sort_list = new List<long>();
	// cout<<"flag 1"<<endl;
	for (int i = 0; i < nums.size(); ++i)
	{
		sort_list->insertAtHead(nums[i]);
	}
	// cout<<"flag 2"<<endl;

	ListItem<long>* sorted_root = recursive_merge(sort_list->getHead());
    
    int i = 0;
    while(sorted_root!=NULL){
    	nums[i]=sorted_root->value;
    	i++;
    	sorted_root = sorted_root->next;
    }
    return nums;

}

ListItem<long>* MergeList(ListItem<long>* a, ListItem<long>* b) {
	ListItem<long>* result = NULL;
	if (a == NULL)
		return b;
	if (b == NULL)
		return a;
	if (a->value > b->value) {
		result = b;
		result->next = MergeList(a, b->next);
	} else {
		result = a;
		result->next = MergeList(a->next, b);
	}
	return result;
}

ListItem<long>* recursive_merge(ListItem<long>* a) {
	ListItem<long>* oldHead = a;
    
    //lenght of list
    ListItem<long>* root = a;
    int count = 0;
    while(root!=NULL){
        count++;
        root = root->next;
    }
    
    int mid = count / 2;
	if (a->next == NULL)
		return a;

	while (mid  > 1) {
		oldHead = oldHead->next;
		mid--;
	}

	ListItem<long>* newHead = oldHead->next;
	oldHead->next = NULL;
	oldHead = a;
	ListItem<long>* half1 = recursive_merge(oldHead); 
	ListItem<long>* half2 = recursive_merge(newHead);
	return MergeList(half1, half2);
}

//=====================================================================================
void rec_quick_calls(long arr[], int left, int right);
vector<long> QuickSortArray(vector<long> nums)
{
	int arr_size = nums.size();
    long sort_array[arr_size];
    copy(nums.begin(), nums.end(), sort_array);
    rec_quick_calls(sort_array,0,arr_size-1);
    std::vector<long> ret(sort_array, sort_array + sizeof sort_array/ sizeof sort_array[0]);
	return  ret;
}

void rec_quick_calls(long arr[], int left, int right) {
      int i = left, j = right;
      long tmp;
      long pivot = arr[(left + right) / 2];
      /* partition */
      while (i <= j) {
            while (arr[i] < pivot)
                  i++;
            while (arr[j] > pivot)
                  j--;

            if (i <= j) {
                  tmp = arr[i];
                  arr[i] = arr[j];
                  arr[j] = tmp;
                  i++;
                  j--;
            }
      };
      if (left < j)
            rec_quick_calls(arr, left, j);
      if (i < right)
            rec_quick_calls(arr, i, right);
}
//=====================================================================================
void recursive_quick(ListItem<long>* l,  ListItem<long> *h);
ListItem<long>* partition(ListItem<long> *l, ListItem<long> *h);
void swap(long *x, long *y){
    long temp = *x;
    *x = *y;
    *y = temp;
}

vector<long> QuickSortList(vector<long> nums)
{
	List<long>* sort_list = new List<long>();
	// cout<<"flag 1"<<endl;
	for (int i = 0; i < nums.size(); ++i)
	{
		sort_list->insertAtHead(nums[i]);
	}
	// cout<<"flag 2"<<endl;

	recursive_quick(sort_list->getHead(),sort_list->getTail());
	ListItem<long>* sorted_root = sort_list->getHead();
    
    int i = 0;
    while(sorted_root!=NULL){
    	nums[i]=sorted_root->value;
    	i++;
    	sorted_root = sorted_root->next;
    }
    return nums;

}

ListItem<long>* partition(ListItem<long> *l, ListItem<long> *h)
{
    long x  = h->value; 
    ListItem<long> *i = l->prev;
 
    ListItem<long> *j = l;
    while (j != h)
    {
        
        if (j->value <= x)
        {
            if(i==NULL) i=l;
            else i = i=i->next;
            swap(&(i->value), &(j->value));
        }
        j = j->next;
    }
    
    if(i==NULL) i=l;
    else i = i=i->next;
    swap(&(i->value), &(h->value));
    return i;
}
 
void recursive_quick(ListItem<long>* l, ListItem<long> *h)
{
    if (h != NULL && l != h && l != h->next)
    {
        ListItem<long> *p = partition(l, h);
        recursive_quick(l, p->prev);
        recursive_quick(p->next, h);
    }
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	MinHeap* heap = new MinHeap(nums.size());
	for (int i = 0; i < nums.size(); ++i) heap->insertKey(nums[i]);
    for (int i = 0; i < nums.size(); ++i) nums[i] = heap->extractMin();
    return nums;
}

#endif