#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	harr = new int [capacity];
	heap_size = 0;
}

void MinHeap::MinHeapify(int i)
{
	if (i >= heap_size-1)
	{
		return;
	}
	if ((2*i+1) >= heap_size || (2*i+2) >= heap_size){
		if ((2*i+1) <= heap_size && harr[2*i+1] < harr[i])
		{
			if (2*i+1 > heap_size-1)
			{
				return;
			}
			int temp = harr[2*i+1];
			harr[2*i+1] = harr[i];
			harr[i] = temp;
		}	
		else if ((2*i+2) <= heap_size && harr[2*i+2] < harr[i]) {
			if (2*i + 2 > heap_size-1)
			{
				return;
			}
			int temp = harr[2*i+2];
			harr[2*i+2] = harr[i];
			harr[i] = temp;
		}	
	}
	else{
		if (harr[2*i+1] < harr[i] && harr[2*i+2] > harr[2*i+1])
		{	
			if (2*i+1 > heap_size-1)
			{
				return;
			}
			int temp = harr[2*i+1];
			harr[2*i+1] = harr[i];
			harr[i] = temp;
			MinHeapify(2*i+1);
		}
		else if (harr[2*i+2] < harr[i]) {
			if (2*i+2 > heap_size-1)
			{
				return;
			}
			int temp = harr[2*i+2];
			harr[2*i+2] = harr[i];
			harr[i] = temp;
			MinHeapify(2*i+2);
		}
	}
}

int MinHeap::parent(int i)
{
	int parent;
	if (i % 2 == 0)
	{
		if (i == 0)
		{
			return i;
		}
		parent = i-2;
		parent = parent/2;
	}
	else{
		if (i == 0)
		{
			return i;
		}
		parent = i-1;
		parent = parent/2;
	}

	return parent;
}
 
int MinHeap::left(int i)
{
	return (2*i + 1);
}
 
int MinHeap::right(int i)
{
	return (2*i + 2);
}
 
int MinHeap::extractMin()
{
	int mintoreturn = harr[0];
	deleteKey(0);
	return mintoreturn;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	int j=i;
	while (j != 0)
	{
		if (harr[parent(j)] > harr[j])
		{
			int temp = harr[parent(j)];
			harr[parent(j)] = harr[j];
			harr[j] = temp;
			j = parent(j);
		}
		else{

			break;
		}
	}
}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if (i > heap_size-1)
	{
		MinHeapify(0);
		return;
	}
	harr[i] = harr[heap_size-1];
	heap_size--;
	MinHeapify(i);
}
 
void MinHeap::insertKey(int k)
{
	harr[heap_size] = k;
	int j = heap_size;
	while (j != 0)
	{
		if (harr[parent(j)] > harr[j])
		{
			int temp = harr[parent(j)];
			harr[parent(j)] = harr[j];
			harr[j] = temp;
			j = parent(j);
		}
		else{

			break;
		}
	}
	heap_size++;
	if (j == 0)
	{
	   MinHeapify(0);
	}	
}

int* MinHeap::getHeap()
{
	return harr;
}

#endif