#include <fstream>
#include "sorts.cpp"
#include <ctime>

using namespace std;


// A single pair is stored in a Vector<long>
// You have to return a vector of all pairs.
vector< vector<long> > smartSearch(vector<long> nums, long k)
{   
    vector <long> tocopy;
    for (int i=0; i<nums.size(); i++)
    {
        tocopy.push_back(nums[i]);
    }
    vector <long> newvec = HeapSort(tocopy);
    vector <long> newvec2;
    for (int i=0; i<newvec.size(); i++)
    {   
        if (newvec[i] < k)
            newvec2.push_back(newvec[i]);
        else{
            break;
        }
    }
    vector < vector<long> > toreturn;
    int endindex = (newvec2.size()) -1; 
    for (int i=0; i<newvec2.size(); i++)
    {
        int temp = newvec2[i];
        int difference = k - temp;
        while (newvec2[endindex] > difference)
        {
            endindex--;
        }
        if (difference == newvec2[endindex])
        {
            vector <long> toreturn1;
            toreturn1.push_back(temp);
            toreturn1.push_back(newvec2[endindex]);
            toreturn.push_back(toreturn1);
        }
    }

    return toreturn;
}


int main()
{
    vector<long> nums;
    ifstream in("random.txt");
    long n;
    while(in >> n)
        nums.push_back(n);
    in.close();

    long k;
    cout << "Enter the value of K: ";
    cin >> k;

    int starttime = clock();
    vector< vector<long> > result = smartSearch(nums, k);
    int stoptime = clock();
    for(int i = 0; i < result.size(); i++)
        cout << result[i][0] << ", " << result[i][1] << endl;
    cout << "time for execution : " << ((stoptime-starttime)/double(CLOCKS_PER_SEC))<< endl;
    return 0;
}   