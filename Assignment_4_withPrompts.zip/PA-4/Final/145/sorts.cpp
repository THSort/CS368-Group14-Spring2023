#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
#include <cstdlib>
#include <time.h>
//=======================		==============================================================
vector<long> InsertionSort(vector<long> nums)
{
	long newarr [nums.size()];
	for (int i=0; i<nums.size(); i++){
		newarr[i] = nums[i];
	}
	int sizes = nums.size();

	for (int i=0; i<nums.size(); i++)
	{
		int minimum = newarr[i];
		int index = i;
		for (int j=i; j<sizes; j++)
		{
			if (newarr[j] < minimum)
			{
				minimum = newarr[j];
				index = j;
			}
		}
		if (minimum != newarr[i])
		{
			int temp = newarr[i];
			newarr[i] = newarr[index];
			newarr[index] = temp;
		}

	}
	nums.clear();

	for (int i=0; i<sizes; i++)
	{
		nums.push_back(newarr[i]);
	}

	return nums;
}

//=====================================================================================

List <long>* Mergehelper (List <long>* templist, int sizes){
	if (sizes == 1)
	{
		return templist;
	}
	if (sizes == 2)
	{
		ListItem <long>* test = templist->getHead();
		ListItem <long>* test2 = templist->getTail();

		List <long>* toreturn = new List <long>;

		if (test->value > test2->value)
		{
			toreturn->insertAtHead(test->value);
			toreturn->insertAtHead(test2->value);
		}
		else{
			toreturn->insertAtHead(test2->value);
			toreturn->insertAtHead(test->value);
		}

		return toreturn;
	}
	else{
		ListItem <long>* midpoint = templist->getHead();
		for (int i=0; i< (sizes-1)/2; i++)
		{		
			midpoint = midpoint -> next;
		}
		
		List<long>*  leftlist = new List <long>;
		List<long>*  rightlist = new List <long>;

		ListItem <long>* left = midpoint;
		ListItem <long>* right = templist->getTail();
		while (left != NULL)
		{
			leftlist->insertAtHead(left->value);
			left = left -> prev;
		}
		while (right != midpoint)
		{
			rightlist->insertAtHead(right->value);
			right = right -> prev;
		}

		List <long>* sortedleft = Mergehelper (leftlist, leftlist->length());

		List <long>* sortedright = Mergehelper (rightlist, rightlist->length());

			

		ListItem <long>* templeft = sortedleft->getTail();
		ListItem <long>* tempright = sortedright->getTail();

	    List <long>* toreturn = new List <long>;


	    for (int i=0; i<sortedright->length(); i++)
	    {
	    	if (templeft == NULL)
	    	{
	    		while (tempright != NULL)
	    		{
					toreturn->insertAtHead(tempright->value);
					tempright = tempright -> prev;
	    		}
	    		break;
	    	}
	    	if (templeft -> value > tempright -> value)
	    	{
				toreturn->insertAtHead(templeft->value);
				templeft = templeft -> prev;
	    		i--;
	    	}
	    	else{
				toreturn->insertAtHead(tempright->value);
				tempright = tempright -> prev;
	    	}
	    }
	    while (templeft != NULL)
	    {
	    	toreturn->insertAtHead(templeft->value);
			templeft = templeft -> prev;
	    }

		return toreturn;
	}
}
vector<long> MergeSort(vector<long> nums)
{
	List<long> *templist = new List <long>;
	int sizes = nums.size();

	for (int i=sizes-1; i>=0; i--)
	{
		templist->insertAtHead(nums[i]);
	}
	
	List <long>* toreturn = Mergehelper(templist, templist->length());
	nums.clear();
	ListItem <long>* headtemp = toreturn->getHead();
	for (int i=0; i<sizes;  i++)
	{
		nums.push_back(headtemp->value);
		headtemp = headtemp->next;
	}

	return nums;
}

//=====================================================================================
void QSHelper (long nums[], int startindex, int endindex, int pivot){
	int totalsize = endindex-startindex+1;

	if (totalsize <= 1)
	{
		return;
	}
	else if (totalsize == 2)
	{
		int toswap = nums[pivot];
		nums[pivot] = nums[startindex];
		nums[startindex] = toswap;
		pivot = startindex;
		if (nums[endindex] < nums[pivot])
		{
			toswap = nums[pivot];
			nums[pivot] = nums[endindex];
			nums[endindex] = toswap;
		}
		return;
	}
	else{
		int toswap = nums[pivot];
		nums[pivot] = nums[startindex];
		nums[startindex] = toswap;
		pivot = startindex;
		int j;
		int temp;

		int counter = startindex+1;
		for (int i=endindex; i>=startindex+1; i--)
		{
			if (nums[i] < nums[pivot])
			{
				while (nums[counter] <= nums[pivot])
				{
					if (counter == i)
					{
						temp = nums[i];
						nums[i] = nums[pivot];
						nums[pivot] = temp;
						pivot = i;
						break;
					}
					if (counter == endindex)
					{
						break;
					}
					counter++; 
				}
				if (counter == i)
				{
					break;
				}
				if (counter == endindex && nums[counter] >= nums[pivot])
				{
					temp = nums[pivot];
					nums[pivot] = nums[i];
					nums[i] = temp;
					break;
				}
				temp = nums[counter];
				nums[counter] = nums[i];
				nums[i] = temp;
			}
		}
		QSHelper(nums,startindex,pivot-1,startindex);
		QSHelper(nums,pivot+1,endindex,pivot+1);
	}
}


vector<long> QuickSortArray(vector<long> nums)
{
	long * newarr =	 new long [nums.size()];
	int sizes = nums.size();
	for (int i=0; i<sizes; i++)
	{
		newarr[i] = nums[i];
	}
	QSHelper(newarr,0,sizes-1,sizes/2);
	nums.clear();
	for (int i=0; i<sizes; i++)
	{
		nums.push_back(newarr[i]);
	}
	return nums;
}

//=====================================================================================
List <long>* QSHelperList (List <long>* templist,int sizes){
	if (sizes <= 1)
	{
		return templist;
	}
	else if (sizes == 2)
	{
		ListItem <long>* test = templist->getHead();
		ListItem <long>* test2 = templist->getTail();
		List <long>* toreturn = new List <long>;

		if (test->value > test2->value)
		{
			toreturn->insertAtHead(test->value);
			toreturn->insertAtHead(test2->value);
		}
		else{
			toreturn->insertAtHead(test2->value);
			toreturn->insertAtHead(test->value);
		}
		return toreturn;	
	}
	else {
		srand (time(NULL));
		int pivot = rand()%(sizes-1);

		ListItem <long>* pivotptr = templist -> getHead();

		for (int i=1; i<=pivot; i++)
		{
			pivotptr = pivotptr->next;
		}
		List <long>* greater = new List <long>;
		List <long>* lessthan = new List <long>;
		ListItem <long>* left = pivotptr->prev;
		ListItem <long>* right = pivotptr->next;
		

		while (left != NULL)
		{
			if (left -> value < pivotptr -> value){
				lessthan->insertAtHead(left -> value);
			}
			else{
				greater->insertAtHead(left->value);
			}
			left = left -> prev;
		}
		

		while (right != NULL)
		{	
			if (right -> value < pivotptr -> value){
				lessthan->insertAtHead(right -> value);
			}
			else{
				greater->insertAtHead(right->value);
			}
			right = right -> next;
		}
		List <long>* less = QSHelperList(lessthan, lessthan->length());
		List <long>* greaterthan = QSHelperList(greater, greater->length());
		List <long>* toreturn = new List <long>;
		ListItem <long>* get = greaterthan->getTail();
		if ((greaterthan->length()) != 0)
		{
			while (get != NULL)
			{
				toreturn->insertAtHead(get->value);
				get = get -> prev;
			}	
		}
		toreturn->insertAtHead(pivotptr->value);
		get = less->getTail();
		if ((less->length()) != 0)
		{
			while (get != NULL)
			{
				toreturn->insertAtHead(get->value);
				get = get -> prev;
			}
		}


		return toreturn;	
	}
	
}
vector<long> QuickSortList(vector<long> nums)
{
	List <long>* newlist = new List <long>;
	int sizes = nums.size();
	for (int i=0; i<sizes; i++)
	{
		newlist->insertAtHead(nums[i]);
	}
	List <long>* toreturn = QSHelperList (newlist,sizes);
	nums.clear();
	ListItem <long>* temp = toreturn->getHead();
	for (int i=0; i<sizes; i++)
	{
		nums.push_back(temp->value);
		temp = temp -> next;
	}
	return nums;
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int sizes = (nums.size());
	long *newarr = new long [nums.size()];

	MinHeap defaulted (nums.size());

	for (int i=0; i<sizes; i++)
	{
		newarr[i] = nums[i];
	}
	for (int i=0; i<sizes; i++)
	{
		defaulted.insertKey(newarr[i]);
	}
	nums.clear();

	int *get = defaulted.getHeap();

	for (int i=0; i<sizes; i++)
	{
		nums.push_back(defaulted.extractMin());
	}

	return nums;
}

#endif