#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{
	capacity = cap;
	harr = new int[capacity];
	heap_size = 0;
}

void MinHeap::MinHeapify(int i)
{
	if (left(i) >= heap_size)
	{
		return;
	}

	int min = harr[i];
	if (right(i) < heap_size)
	{
		if (harr[left(i)] < harr[right(i)])
		{
			min = left(i);
		}
		else
		{
			min = right(i);
		}
	}
	else
	{
		min = left(i);
	}
	
	if(harr[min] < harr[i])
	{
		int temp = harr[i];
		harr[i] = harr[min];
		harr[min] = temp;
 	}
 	MinHeapify(min);
}
 
int MinHeap::parent(int i)
{
	return (i-1)/2;
}
 
int MinHeap::left(int i)
{
	return (2*i)+1;
}
 
int MinHeap::right(int i)
{
	return (2*i)+2;
}
 
int MinHeap::extractMin()
{
	int min = harr[0];

	heap_size--;
	harr[0] = harr[heap_size];

	MinHeapify(0);
	return min;
}
 
void MinHeap::decreaseKey(int i, int new_val)
{
	harr[i] = new_val;
	int par = parent(i);
	while (par != 0)
	{
		MinHeapify(par);
		par = parent(par);
	}
	MinHeapify(par);

}
 
int MinHeap::getMin()
{
	return harr[0];
}
 
void MinHeap::deleteKey(int i)
{
	if (i >= heap_size)
	{
		return;
	}
	decreaseKey(i, (harr[0]-1));

	heap_size--;
	harr[0] = harr[heap_size];
	MinHeapify(0);
}
 
void MinHeap::BubbleUp(int i)
{
	if (left(i) >= heap_size)
	{
		return;
	}

	int min = harr[i];
	if (right(i) < heap_size)
	{
		if (harr[left(i)] < harr[right(i)])
		{
			min = left(i);
		}
		else
		{
			min = right(i);
		}
	}
	else
	{
		min = left(i);
	}
	
	if(harr[min] < harr[i])
	{
		int temp = harr[i];
		harr[i] = harr[min];
		harr[min] = temp;
 	}
}

void MinHeap::insertKey(int k)
{
	harr[heap_size] = k;
	heap_size++;

	int par = parent(heap_size-1);
	while (par != 0)
	{
		BubbleUp(par);
		par = parent(par);
	}
	BubbleUp(par);
}

int* MinHeap::getHeap()
{
	return harr;
}


void MinHeap::print()
{
	int j = 0;
	for(int i=0; i<heap_size; i++)
	{
		if (i == (j*2 + 1))
		{
			cout << endl;
			j = i;
		}
		cout << harr[i] << " ";
	}
}

#endif