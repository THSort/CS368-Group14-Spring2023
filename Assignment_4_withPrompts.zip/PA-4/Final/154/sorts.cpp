#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "heap.cpp"
#include "list.cpp"
#include <stdlib.h> 
#include <time.h>


vector<long> list2vectorRev(List<long>* l, int size)
{
	vector<long> temp;
	ListItem<long>* here = l->getTail();
	for (int i=0; i<size; i++)
	{
		temp.push_back(here->value);
		here = here->prev;
	}
	return temp;
}


//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	long* array = &nums[0];
	int temp;
	int j;
	int size = nums.size();
	for (int i=0; i<size; i++)
	{
		j = 0;
		while (array[i] >= array[j] && j != i)
		{
			j++;
		}
		if (j == i)
		{
			continue;
		}
		temp = array[i];
		for(int k=i-1; k>=j; k--)
		{
			array[k+1] = array[k];
		}
		array[j] = temp;
	}
	return nums;
}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	int size = nums.size();
	if (size == 1)
	{
		return nums;
	}
	int size1 = size/2;
	int size2 = size - size1;

	List<long> list;
	for (int i=0; i<size; i++)
	{
		list.insertAtHead(nums[i]);
	}
	ListItem<long>* here = list.getHead();

	List<long> left;
	List<long> right;
	for (int i=0; i<size1; i++)
	{
		left.insertAtHead(here->value);
		here = here ->next;
	}
	for (int i=size1; i<size; i++)
	{
		right.insertAtHead(here->value);
		here = here ->next;
	}
	nums = MergeSort(list2vectorRev(&left, size1));
	vector <long> nums_right = MergeSort(list2vectorRev(&right, size2));



	List<long> final;

	int i = 0;
	int j = 0;

	while (i<size1 && j<size2)
	{
		if (nums[i] < nums_right[j])
		{
			final.insertAtHead(nums[i]);
			i++;
		}
		else
		{
			final.insertAtHead(nums_right[j]);
			j++;
		}
	}
	while (i<size1)
	{
		final.insertAtHead(nums[i]);
		i++;
	}
	while (j<size2)
	{
		final.insertAtHead(nums_right[j]);
		j++;
	}

	nums = list2vectorRev(&final, size);
	return nums;

}
//=====================================================================================
int pivot1(int size, long* array)
{
	return 0;
}
int pivot2(int size, long* array)
{
	return size-1;
}
int pivot3(int size, long* array)
{
	int p1 = array[0];
	int p2 = array[size-1];
	int p3 = array[size/2];

	if (p1<p2)
	{
		if (p2<p3)
		{
			return size/2;
		}
		else
		{
			return size-1;
		}
	}
	else if (p2<p1)
	{
		if(p1<p3)
		{
			return 0;
		}
		else
		{
			return size-1;
		}
	}
	else
	{
		if(p1<p2)
		{
			return 0;
		}
		else
		{
			return size/2;
		}
	}

}

vector<long> QuickSortArray(vector<long> nums)
{
	int size = nums.size();
	if (size < 2)
	{
		return nums;
	}
	long* array = &nums[0];
	
	int pivot_index = pivot2(size, array);
	int pivot_value = array[pivot_index]; 

	vector<long> left;
	int l_c = 0;
	vector<long> right;
	int r_c = 0;
	vector<long> middle;
	int m_c = 0;

	for (int i=0; i<size; i++)
	{
		if (array[i] == pivot_value)
		{
			middle.push_back(array[i]);
			m_c++;
		}
		if(array[i] < pivot_value)
		{
			left.push_back(array[i]);
			l_c++;
		}
		if(array[i] > pivot_value)
		{
			right.push_back(array[i]);
			r_c++;
		}
	}

	left = QuickSortArray(left);
	right = QuickSortArray(right);

	vector<long> final;
	for (int i=0; i<l_c; i++)
	{
		final.push_back(left[i]);
	}
	for (int i=0; i<m_c; i++)
	{
		final.push_back(middle[i]);
	}
	for (int i=0; i<r_c; i++)
	{
		final.push_back(right[i]);
	}

	return final;
}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{
	int size = nums.size();
	if (size < 2)
	{
		return nums;
	}
	srand(time(0));
	int pivot_index = rand() % size;

	long* array = &nums[0];
	int pivot_value = array[pivot_index]; 

	List<long> left;
	int l_c = 0;
	List<long> right;
	int r_c = 0;
	List<long> middle;
	int m_c = 0;

	for (int i=0; i<size; i++)
	{
		if (array[i] == pivot_value)
		{
			middle.insertAtHead(array[i]);
			m_c++;
		}
		if(array[i] < pivot_value)
		{
			left.insertAtHead(array[i]);
			l_c++;
		}
		if(array[i] > pivot_value)
		{
			right.insertAtHead(array[i]);
			r_c++;
		}
	}

	vector<long> LEFT = QuickSortArray(list2vectorRev(&left, l_c));
	vector<long> RIGHT = QuickSortArray(list2vectorRev(&right, r_c));

	List<long> final;
	for (int i=0; i<l_c; i++)
	{
		final.insertAtHead(LEFT[i]);
	}
	ListItem<long>* here = middle.getHead();
	for (int i=0; i<m_c; i++)
	{
		final.insertAtHead(here->value);
		here = here->next;
	}
	for (int i=0; i<r_c; i++)
	{
		final.insertAtHead(RIGHT[i]);
	}

	return list2vectorRev(&final, size);
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	int size = nums.size();
	long* array = &nums[0];
	MinHeap heap(size);
	for (int i=0; i<size; i++)
	{
		heap.insertKey(array[i]);
	}
	for(int i=0; i<size; i++)
	{
		array[i] = heap.extractMin();
	}
	return nums;
}

#endif