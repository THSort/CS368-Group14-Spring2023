#include <iostream>
#include <vector>
#include "sorts.cpp"

using namespace std;

void quicksort(vector<int>& v, int left, int right) {
    if (left >= right) {
        return;
    }
    int pivot = v[(left + right) / 2];
    int i = left;
    int j = right;
    while (i <= j) {
        while (v[i] < pivot) {
            i++;
        }
        while (v[j] > pivot) {
            j--;
        }
        if (i <= j) {
            swap(v[i], v[j]);
            i++;
            j--;
        }
    }
    quicksort(v, left, j);
    quicksort(v, i, right);
}

void find_pairs(vector<int>& v, int k) {
    int i = 0;
    int j = v.size() - 1;
    while (i < j) {
        int sum = v[i] + v[j];
        if (sum == k) {
            cout << v[i] << ", " << v[j] << endl;
            i++;
            j--;
        } else if (sum < k) {
            i++;
        } else {
            j--;
        }
    }
}

int main() {
    vector<int> v = {3, 4, 1, 2, 5};
    int k = 7;

    cout << "Before sorting: ";
    for (auto x : v) {
        cout << x << " ";
    }
    cout << endl;

    quicksort(v, 0, v.size() - 1);

    cout << "After sorting: ";
    for (auto x : v) {
        cout << x << " ";
    }
    cout << endl;

    cout << "Pairs that add up to " << k << ":" << endl;
    find_pairs(v, k);

    return 0;
}
