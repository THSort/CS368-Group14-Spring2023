#include <iostream>
#include <vector>
#include "sorts.h"
#include "list.h"
using namespace std;

// Task 2: Insertion Sort
std::vector<int> InsertionSort(std::vector<int> nums) {
    int n = nums.size();
    for (int i = 1; i < n; i++) {
        int current = nums[i];
        int j = i - 1;
        while (j >= 0 && nums[j] > current) {
            nums[j + 1] = nums[j];
            j--;
        }
        nums[j + 1] = current;
    }
    return nums;
}

// Task 3: Merge Sort
template <class T>
ListItem<T>* merge(ListItem<T>* left, ListItem<T>* right) {
    ListItem<T>* result = NULL;

    // base cases
    if (left == NULL)
        return right;

    if (right == NULL)
        return left;

    // recursive case
    if (left->value <= right->value) {
        result = left;
        result->next = merge(left->next, right);
    } else {
        result = right;
        result->next = merge(left, right->next);
    }

    return result;
}

template <class T>
void split(ListItem<T>* head, ListItem<T>** left, ListItem<T>** right) {
    ListItem<T>* slow = head;
    ListItem<T>* fast = head->next;

    while (fast != NULL) {
        fast = fast->next;
        if (fast != NULL) {
            slow = slow->next;
            fast = fast->next;
        }
    }

    *left = head;
    *right = slow->next;
    slow->next = NULL;
}

template <class T>
void MergeSort(List<T>& list) {
    // base case: list is empty or has one element
    if (list.length() <= 1)
        return;

    ListItem<T>* head = list.getHead();
    ListItem<T>* left = NULL;
    ListItem<T>* right = NULL;

    // split the list into two halves
    split(head, &left, &right);

    // recursively sort the left and right halves
    MergeSort(List<T>(left));
    MergeSort(List<T>(right));

    // merge the sorted halves
    ListItem<T>* sorted = merge(left, right);

    // put the sorted elements back into the list
    list.deleteAll();
    while (sorted != NULL) {
        list.insertAtTail(sorted->value);
        sorted = sorted->next;
    }
}

// Task 4: Prompt 1 - Quick Sort Array


// Partition the array around a pivot and return the index of the pivot
int partition(vector<int>& arr, int low, int high) {
    int mid = (low + high) / 2;
    if (arr[mid] < arr[low]) {
        swap(arr[low], arr[mid]);
    }
    if (arr[high] < arr[low]) {
        swap(arr[low], arr[high]);
    }
    if (arr[mid] < arr[high]) {
        swap(arr[mid], arr[high]);
    }
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// The recursive function to perform quicksort
void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pivot = partition(arr, low, high);
        quickSort(arr, low, pivot - 1);
        quickSort(arr, pivot + 1, high);
    }
}

// Sort the integer vector using the QuickSort algorithm with median-of-three pivot selection strategy
vector<int> QuickSortArray(vector<int> arr) {
    int n = arr.size();
    quickSort(arr, 0, n - 1);
    return arr;
}

// Task 4: Prompt 2 - Quick Sort List

// Partition the linked list into two parts and return the pivot index
template <class T>
ListItem<T> *partition(List<T> &list, ListItem<T> *low, ListItem<T> *high)
{
    T pivot = high->value;
    ListItem<T> *i = low->prev;

    for (ListItem<T> *j = low; j != high; j = j->next)
    {
        if (j->value <= pivot)
        {
            i = (i == NULL) ? low : i->next;
            swap(i->value, j->value);
        }
    }
    i = (i == NULL) ? low : i->next;
    swap(i->value, high->value);
    return i;
}

// Quicksort algorithm for linked list
template <class T>
void QuickSortList(List<T> &list, ListItem<T> *low, ListItem<T> *high)
{
    if (low != NULL && high != NULL && low != high && low != high->next)
    {
        ListItem<T> *pivot = partition(list, low, high);
        QuickSortList(list, low, pivot->prev);
        QuickSortList(list, pivot->next, high);
    }
}

// Wrapper function for QuickSortList
template <class T>
vector<T> QuickSortList(vector<T> input)
{
    List<T> list;
    for (T i : input)
    {
        list.insertAtTail(i);
    }
    QuickSortList(list, list.getHead(), list.getTail());
    vector<T> sorted;
    for (ListItem<T> *i = list.getHead(); i != NULL; i = i->next)
    {
        sorted.push_back(i->value);
    }
    return sorted;
}

// Task 5: Heap Sort Array

void heapify(std::vector<int>& arr, int n, int i) {
    int largest = i; 
    int l = 2 * i + 1; 
    int r = 2 * i + 2; 
  
    if (l < n && arr[l] > arr[largest])
        largest = l;
  
    if (r < n && arr[r] > arr[largest])
        largest = r;
  
    if (largest != i) {
        std::swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void HeapSort(std::vector<int>& arr) {
    int n = arr.size();
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);
    for (int i = n - 1; i >= 0; i--) {
        std::swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}




