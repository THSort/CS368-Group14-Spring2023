#include "heap.h"

// Constructor
MinHeap::MinHeap(int cap) {
    capacity = cap;
    harr = new int[capacity];
    heap_size = 0;
}

// to heapify a subtree with root at given index
void MinHeap::MinHeapify(int i) {
    int l = left(i);
    int r = right(i);
    int smallest = i;
    if (l < heap_size && harr[l] < harr[i])
        smallest = l;
    if (r < heap_size && harr[r] < harr[smallest])
        smallest = r;
    if (smallest != i) {
        swap(harr[i], harr[smallest]);
        MinHeapify(smallest);
    }
}

// return index of the parent of a node at index i
int MinHeap::parent(int i) {
    return (i - 1) / 2;
}

// get index of left child of node at index i
int MinHeap::left(int i) {
    return 2 * i + 1;
}

// get index of right child of node at index i
int MinHeap::right(int i) {
    return 2 * i + 2;
}

// remove minimum element (or root) from min heap
int MinHeap::extractMin() {
    if (heap_size <= 0)
        return INT_MAX;
    if (heap_size == 1) {
        heap_size--;
        return harr[0];
    }

    int root = harr[0];
    harr[0] = harr[heap_size - 1];
    heap_size--;
    MinHeapify(0);

    return root;
}

// Decreases key value of key at index i to new_val 
// (assume new_val will always be smaller than harr[i])
void MinHeap::decreaseKey(int i, int new_val) {
    harr[i] = new_val;
    while (i != 0 && harr[parent(i)] > harr[i]) {
        swap(harr[i], harr[parent(i)]);
        i = parent(i);
    }
}

// Returns the minimum key (key at root) from min heap
int MinHeap::getMin() {
    if (heap_size <= 0)
        return INT_MAX;
    return harr[0];
}

// Deletes a key stored at index i
void MinHeap::deleteKey(int i) {
    decreaseKey(i, INT_MIN);
    extractMin();
}

// Inserts a new key 'k'
void MinHeap::insertKey(int k) {
    if (heap_size == capacity) {
        cout << "Heap overflow\n";
        return;
    }
    heap_size++;
    int i = heap_size - 1;
    harr[i] = k;
    while (i != 0 && harr[parent(i)] > harr[i]) {
        swap(harr[i], harr[parent(i)]);
        i = parent(i);
    }
}

int* MinHeap::getHeap() {
    return harr;
}